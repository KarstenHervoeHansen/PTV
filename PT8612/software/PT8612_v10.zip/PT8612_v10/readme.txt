This derectory contains PT8612 software version 80.
Uploading FPGA an uP software implemented.
Querrying status of FPGA implemented. (start: 07.02.2007)

08.03.2007
:JK
***
