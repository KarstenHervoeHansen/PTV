#!/usr/local/gnu/bin/perl
#  FILE NAME:  packet_gen.pl                        
#  AUTHOR   :  Mahesh Umasankar x 7402                  
#  COMPANY  :  XILINX                                    
#  GROUP    :  ENSEG                                     
#  DESCRIPTION : This is a simple packet generator. 
#  User needs to provide the size of the data bus, number of packets and size of each 
#  packet (in terms of number of data words..)
#  usage: packgen -w bus_width -p no_of_packets -l packet_length -o output_file
#  Rev 1.0: Initial version
#  Rev 1.1: modified on 12/25/03 by Mahesh Umasankar
#	    1. Added features to dump packets with sequentially increasing lengths
#	       with programmable increments
#	    2. Added minimum length variable
#	    3. Added ability to send decrementing sizes of packets

sub usage {
	print " ERROR! missing parameters \n";
	print " for usage , type $0  -h \n";
	exit;
	}
sub h_usage {
	print " usage options for $0 \n";
	printf"\t-bw <bus_width>, in bytes. default is 32 \n";
	printf"\t-p <no_of_pkts>, default is 10\n";
	printf"\t-l <pkt_len>, takes integer values \(default is 100 \) \n";
	printf"\t\t or \"var\"\(randomized packet lengths\)\n";
	printf"\t\t or \"seq\"\(sequential packet lengths\)\n";
	printf"\t-minl <min_pkt_len>, takes integer values \(default is 1\)\n";
	printf"\t-maxl <max_pkt_len>, takes integer values \(default is 1500\)\n";
	printf"\t-incr <step_value>, takes integer values \(default is 1500\)\n";
	printf"\t\tused only when -l seq option is used\n";
	printf"\t\tpkt_len sizes start at min_pkt_len value and end at max_pkt_len value\n";
	printf"\t-decr <step_value>, takes integer values \(default is 1500\)\n";
	printf"\t\tused only when -l seq option is used\n";
	printf"\t\tpkt_len sizes start at max_pkt_len value and end at min_pkt_len value\n";
	printf"\t\tNOTE!! if -l seq is used, by default -incr is assumed unless -decr is specified\n";
	printf"\t-ty <packet_type>,\"ud\"\(user_data\) or \"uf\"\(user flow\) \"nfc\"\(native flow\)  \n";
	printf"\t\tdefault is user data  \n";
	printf"\t-seq or -rand, data values are generated sequentiallly or random\n";
	printf"\t\tdefault is sequential\n";
	printf"\t-o <output_file>, name of output file\n"; 
   printf"\t\t default names for \"ud\" , \"uf\" and \"nfc\" are user_data_packets.dat user_flow_packets.dat native_flow_packets.dat\n";
	exit;
	}

$bus_width = 32;
$no_of_packets = 10;
$packet_length = 64;
$rand_length = 0;
$max_pkt_len = 1500;
$min_pkt_len = 1;
$seq_length = 0;
$stepper = 1;
$incr_decr = 0;
$packet_type = "ud";
$packet_file_ud = "user_data_packets.dat";
$packet_file_uf = "user_flow_packets.dat";
$packet_file_nfc = "native_flow_packets.dat";
$data_seq = 1;

if (($#ARGV +1) < 1) 
   { 
   printf ("NO ARGUMENTS FOUND !! DEFAULT VALUES WILL BE USED \n");
   printf ("********NOTE: type $0 -h for usage info \n");
   $zero_args = 1;
   }
else
 {

 #print "@ARGV\n";

 #print "there are ",$#ARGV+1,"arguments\n";

 while ($param =shift(@ARGV))
   {
   #print " param is $param \n";
   if ($param eq "-bw")
      {
      print " inside -bw \n";
      $bus_width = shift(@ARGV);
      if ($bus_width eq "")
         {
         &usage;
         }
		print " bus_width is $bus_width \n";
      }
   elsif ($param eq "-p")
      {
      $no_of_packets = shift(@ARGV);
      if ($no_of_packets eq "")
         {
         &usage;
         }
		print " no_of_packets is $no_of_packets \n";
      }
   elsif ($param eq "-l")
      {
      $pkt_length = shift(@ARGV);
      if ($pkt_length eq "")
         {
         &usage;
         }
      elsif ($pkt_length eq "var")
         {
         $rand_length = 1;
         }
      elsif ($pkt_length eq "seq")
         {
         $seq_length = 1;
         }
      else
         {
         $packet_length = $pkt_length;
         }
		print " packet_length is $packet_length \n";
      }
   elsif ($param eq "-minl")
      {
      $min_pkt_len = shift(@ARGV);
      if ($min_pkt_len eq "")
         {
         &usage;
         }
		print " min packet_length is $min_pkt_len \n";
      }
   elsif ($param eq "-maxl")
      {
      $max_pkt_len = shift(@ARGV);
      if ($max_pkt_len eq "")
         {
         &usage;
         }
		print " max packet_length is $max_pkt_len \n";
      }
   elsif ($param eq "-incr")
      {
      $stepper = shift(@ARGV);
      if ($stepper eq "")
         {
         &usage;
         }
		print " stepper is $stepper \n";
      }
   elsif ($param eq "-decr")
      {
      $incr_decr = 1;
      $stepper = shift(@ARGV);
      if ($stepper eq "")
         {
         &usage;
         }
		print " stepper is $stepper \n";
      }
   elsif ($param eq "-o")
      {
      $packet_file = shift(@ARGV);
      if ($packet_file eq "")
        {
        &usage;
        }
		print " packet_file is $packet_file \n";
      }
   elsif ($param eq "-ty")
      {
      $packet_type = shift(@ARGV);
      if ($packet_type eq "")
        {
        &usage;
        }
		print " packet_type is $packet_type \n";
      }
   elsif ($param eq "-seq")
      {
      $data_seq = 1;
		print " data  is sequential \n";
      }
   elsif ($param eq "-rand")
      {
      $data_seq = 0;
		print " data  is random \n";
      }
   elsif ($param eq "-h")
      {
      &h_usage;
      }
   else
      {
      &usage;
      }
   }
 }

$num_of_bytes = $bus_width/8;
$uf_packet = 0;
$nfc_packet = 0;
if ($packet_file eq "")
   {
   if ($packet_type eq "ud")
      {
      $packet_file = $packet_file_ud;
      }
   elsif($packet_type eq "uf")
      {
      $uf_packet = 1;
      $packet_file = $packet_file_uf;
      }
   elsif($packet_type eq "nfc")
      {
      $nfc_packet = 1;
      $packet_file = $packet_file_nfc;
      }
   }

   if($packet_type eq "uf")
      {
      $uf_packet = 1;
      }
   elsif($packet_type eq "nfc")
      {
      $nfc_packet = 1;
      }

open(PACKET_DAT,">$packet_file") || die "cant open newfile:$!\n";
printf ("parameters \n");
printf ("packet type %s\n",$packet_type);
printf ("bus_width is %d \n",$bus_width);
printf PACKET_DAT ("# bus words is %d \n",$num_of_bytes);
printf ("no_of_packets is %d \n",$no_of_packets) ;
if (($rand_length == 0) && ($seq_length == 0))
   {
   printf ("packet_length is %d \n",$packet_length);
   }
else
   {
   printf ("min packet_length is %d \n",$min_pkt_len);
   printf ("max packet_length is %d \n",$max_pkt_len);
   if ($rand_length ==1)
      {
      printf ("random pkt lengths will be created \n");
      }
   else
      {
      if ($incr_decr == 0)
         {
         printf ("seq pkt lengths will be created in increments of ");
         }
      else
         {
         printf ("seq pkt lengths will be created in decrements of ");
         }
      printf("%d\n",$stepper);
      }
   }
printf ("name of output file is %s \n",$packet_file );
printf ("data seq flag is %d \n",$data_seq );

for ($i=0;$i<$no_of_packets;$i++)
   {
   printf PACKET_DAT ("############\n");
   if($rand_length == 1)
      {
      if ($uf_packet == 1)
         {
         #printf ("uf pkt length %d \n",$packet_length );
         $packet_length = rand($max_pkt_len-1) + 1;
         #if odd packet length for uf 
         if (($packet_length %2) == 1)
            {
            #printf ("odd pkt length %d \n",$packet_length );
            #if packet length is 1, then add 1 to make it even
            if ($packet_length >= 2)
               {
               $packet_length = $packet_length -1;
               #printf ("make even !pkt length %d \n",$packet_length );
               }
            #else subtract 1 to make it even
            else
               {
               #printf ("make even !pkt length 2 \n" );
               $packet_length = 2;
               }
            }
         }
      else
         {
         $packet_length = rand($max_pkt_len-1)+1;
         }
      }
   elsif($seq_length == 1)
      {
      if ($incr_decr == 0)
      #increasing order of packet lengths
         {
         $packet_length = $min_pkt_len + ($stepper*$i);
         if ($packet_length > $max_pkt_len)
            {
            $packet_length = $max_pkt_len;
            }
         }
      else
      #decreasing order of packet lengths
         {
         $packet_length = $max_pkt_len - ($stepper*$i);
         if ($packet_length < $min_pkt_len)
            {
            $packet_length = $min_pkt_len;
            }
         }
      }
   printf ("packet length is %d \n",$packet_length);
   &write_packet($packet_length,$i+1,$packet_type);
   printf PACKET_DAT ("############\n");
   }

sub write_packet
   {
   printf ("entering write packet routine \n");
   my $packet_type = $_[2];
   printf PACKET_DAT ("#SOF\t packet_length is %d bytes\n",$_[0]);
   #printf ("#SOF\t packet_length is %d bytes\n",$_[0]);
   for($j=1;$j<=$_[0];$j+=$num_of_bytes)
      {
      #printf (" j is %d\n",$j);
      #printf PACKET_DAT (" j is %d\n",$j);
      $rem_bytes = $_[0] + 1 - $j;
      #printf ("total_rem_bytes %d ",$rem_bytes);
      if ($rem_bytes > $num_of_bytes)
         {
         $rem_bytes = $num_of_bytes;
         }
      #printf PACKET_DAT ("rem_bytes is %d\n",$rem_bytes);
      for($k =1;$k <=$rem_bytes; $k++) 
         {
         $random_number = rand(255);
         #printf (" random number is %d \n",$random_number);
         if ($data_seq == 0)
            {
            $data_byte = $random_number;
            }
         else
            {
            $data = $j + $k - 1;
            $data_byte = $data%256;
	    if($packet_type eq "nfc") {
            $data_byte = $data_byte<<4;
	    }
            }
         # replace the first byte with the packet index
         if (($j == 1) && ($k == 1) && ($packet_type ne "nfc"))
            {
            $data_byte = $_[1];
            }
         ##############################################
         #printf (" %d %02x ",$data, $data_byte);
         printf PACKET_DAT ("%02x ",$data_byte);
         }
         printf PACKET_DAT ("\n");
         #printf ("\n");
      }
   #printf ("#EOF\n");
   printf PACKET_DAT ("#EOF\n");
   }







