#!/usr/bin/perl -w

### usage -  perl runtest_release.pl -t <testcase> 
while ($param = shift(@ARGV)) 
{
    if($param eq "-l") 
	{
        $language = shift(@ARGV);
        }     
     else 
	{
        die "Illegal option";
        }

#### run packet_gen script to generate dat files 
system("perl ./packet_gen.pl -bw 64 -p 10 -ty ud -l 15 -o user_data_packets_1.dat"); 
system("perl ./packet_gen.pl -bw 64 -p 10 -ty uf -l 10 -o user_flow_packets_1.dat"); 
system("perl ./packet_gen.pl -bw 64 -p 5 -ty nfc -l 1 -o native_flow_packets_1.dat"); 
system("perl ./packet_gen.pl -bw 64 -p 10 -ty ud -l 15 -o user_data_packets_2.dat"); 
system("perl ./packet_gen.pl -bw 64 -p 10 -ty uf -l 10 -o user_flow_packets_2.dat"); 
system("perl ./packet_gen.pl -bw 64 -p 5 -ty nfc -l 1 -o native_flow_packets_2.dat"); 

#### compile the testbench and run simulation. These are done by the makefile
if ($language eq "verilog") 
 {
   system("make -f ./Makefile mti_vlog");
 }
elsif ($language eq "vhdl")
 {
	system("make -f ./Makefile mti_vhdl");
 }

	system("./checktalk2.csh");
	system("./checktalk1.csh");
}
