
�ndret:	fr 09-06-00 15:11
sh.110-1 10758603_110-1.pdf
10758603.dwg
10758603.dxf (AutoCad 14)
sh.115-1 1270392_115-1.pdf
sh.115-1 1270392_115-1.dxf (AutoCad 14)
sh.115-1 1270392_115-1.dwg
1270392.dwg (side 110-1 samt 115-1 tekstlayout)
1270392.dxf (side 110-1 samt 115-1 tekstlayout) (AutoCad 14)
                             postscript    windows
Fonte som bruges er: arim  - arim.shx   -  Arial MT Medium      (PT nr. +tekst)
                     arie  - arie.shx   -  Arial MT Extra Bold  (ProTeleVision)
                     ariab - ariab.shx  -  Arial MT Bold        (resten af teksten)
                        

For farvespecifikation se 4008 140 00000