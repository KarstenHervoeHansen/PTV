26/07-2004/Gbg

Original part number: 4008 117 08102
New part number 4008 117 08014
This version also includes changes incorporated into 4008 117 08013


Gerber files modified by means of a Gerber editor.
For the ACM files the following is changed:

tm_01_ne.ger (added pads to the mask).

No other ACM-files have been modified


Position of the components:

	x(mil)	y(mil)		x(mm)		y(mil)		footprint
R405	7655	2990		194.437		75.9473		0805
C81	11675	6000		296.545		152.4013	0805


Note:
The componentplacement files complist.all ad complist.sat are NOT modified.

See readme.txt in 11708104-pcb.zip for detailed description.




New part number: 4008 117 08013


Original Gerber files modified by means of a Gerber editor.

For the .ACM files the only change is:

tm_01_ne.ger   (two pads removed from tin mask).

Note:
See readme.txt in 11708103-pcb.zip for detailed description.


19. March, 2003
GBg