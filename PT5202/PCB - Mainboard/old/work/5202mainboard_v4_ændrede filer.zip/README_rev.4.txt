25/07-2004
Orginal part number: 4008 1107 08102
New part number: 4008 117 08014

NOTE: this is a revision to the below.

Two parts have been added: V81 and V405

Changes to following files 

	cu_01_po.ger	(top layer)
	sm_01_ne.ger	(solder mask, top layer)
	tm_01_ne.ger	(tin mask, top layer)
	no_01_po.ger	(notaion mask, top layer)





Original part number: 4008 117 08102
New part number: 4008 117 08013


Original Gerber files modified by means of a Gerber editor.

Changes to following files:

	cu_01_po.ger	(top layer)
	cu_06_po.ger	(bottom layer
	sm_01_ne.ger	(solder mask, top layer)
	tm_01_ne.ger	(tin mask, top layer=

The changes consist of following:

Top layer:
	- two pads removed (connecting track modified)
	- part number changed

Bottom layer:
	- small piece of track removed.




NOTE:
The specification file, pcb-spec.pdf has NOT been corrected.
Except for referencing to 4008 117 08012 instead of 4008 117 08013, all data is valid.



19. March, 2003
GBg