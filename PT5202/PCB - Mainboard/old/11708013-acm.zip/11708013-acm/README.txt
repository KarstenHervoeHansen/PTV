Original part number: 4008 117 08102
New part number: 4008 117 08013


Original Gerber files modified by means of a Gerber editor.

For the .ACM files the only change is:

tm_01_ne.ger   (two pads removed from tin mask).

Note:
See readme.txt in 11708103-pcb.zip for detailed description.


19. March, 2003
GBg