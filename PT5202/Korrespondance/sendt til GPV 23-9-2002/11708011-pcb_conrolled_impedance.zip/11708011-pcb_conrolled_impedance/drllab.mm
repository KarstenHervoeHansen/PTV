Supermax ECAD drill version 8.2.7
WARNING: PCB is from a newer version of Supermax E-CAD
plated :
   num:   2 size:  15.8mill =   0.4mm
   num: 4339 size:  15.8mill =   0.4mm TOL= +0/-0.2mm
   num:  20 size:  35.4mill =   0.9mm
   num:  49 size:  39.4mill =     1mm
   num:   4 size:  47.2mill =   1.2mm
   num:   6 size:    63mill =   1.6mm
   num:   7 size:  66.9mill =   1.7mm
   num:  12 size:  78.7mill =     2mm
   num:  10 size:   126mill =   3.2mm
non plated :
   num:  96 size:  31.5mill =   0.8mm
   num:  14 size:    61mill =  1.55mm TOL= +/-0.075mm
   num:   2 size:    63mill =   1.6mm
   num:   2 size:  78.7mill =     2mm
   num:   4 size: 118.1mill =     3mm
first drilled hole x,y (1598.4,5655.5) mill = (  40.6,143.65) mm
FILE 71569 BYTES 1204<x<15574 and 1204<y<7803 lay : 255
drill completed
