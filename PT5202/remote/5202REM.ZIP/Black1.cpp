// functions LineEditExit(), FieldEditExit() and OffsetEditExit()
// have been eliminated to avoid problems with error message of
// invalid entry.
// In function OKButtonClick() ValidateEntry() is now always
// executed, regardless of Tags, because of the same reason.
// The same is made for bb2, bb3, tsg and genlock.
// JK 15.08.01


//--------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <registry.hpp>
#pragma hdrstop

#include "mainform.h"
#include "proper.h"
#include "Black1.h"
#include "util.h"
#include "pt52class.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"
TBlack1Form *Black1Form;

static char do_not_adjust_tb;
extern Boolean timeout2;

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
__fastcall TBlack1Form::TBlack1Form(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FormCreate(TObject *Sender)
{
 	const char* *ptr;

	// Prepare TV system choices
	SystemComboBox->Items->Clear();

  ptr = SystemTxt;
	while ( *ptr)
		SystemComboBox->Items->Add( *ptr++);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FormShow(TObject *Sender)
{
	RestoreWindowPosition( Black1Form, "Black1Window");

	// Setup pointer to actual settings
	BlackSetup = PT5201Setup->GetBlackSettings( Black1Output);

	BlackCancel = new TBlackGenerator;

	// Copy original settings temporarily to BlackCancel
	*BlackCancel = *BlackSetup;

	// Setup TV system selection
	SystemComboBox->ItemIndex = BlackSetup->System;

	// Setup ScHPhase selection
	ScHPhaseEdit->Text = IntToStr( BlackSetup->ScHPhase);

	// Display timing selection
	SamplesToFLO( BlackSetup->System, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  TrackBarSetup( BlackSetup->System, OffsetTrackBar, MinLabel, MaxLabel);

  LockForm( PropertiesForm->ConfigureLockItem->Checked);

  if ( !PropertiesForm->ConfigureLockItem->Checked)
		ActiveControl = SystemComboBox;

	FieldEdit->Tag = 0;
	LineEdit->Tag = 0;
	OffsetEdit->Tag = 0;

  ModelessResult = mrNone;
  do_not_adjust_tb = 0;

}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FormClose(TObject *Sender, TCloseAction &Action)
{
	delete BlackCancel;
	SaveWindowPosition( Black1Form, "Black1Window");
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FormCloseQuery(TObject *Sender, bool &CanClose)
  {
	if (( ModelessResult != mrOk) && !PT5201Setup->VerifyBlackSettings( Black1Output, BlackCancel))
    {
			PT5201Setup->SetBlackSettings( Black1Output, BlackCancel);
			UpdateOutput( BlackCancel);
    }
	PT5201Form->SystemStatusUpdate( Black1Field);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::OKButtonClick(TObject *Sender)
{
	if ( ScHPhaseEdit->Focused())
		if ( !ValidateScHPhase( Black1Form, ScHPhaseEdit, &BlackSetup->ScHPhase))
  		return;

	if ( FieldEdit->Focused())
		FieldEdit->Tag = true;
  else
		if ( LineEdit->Focused())
			LineEdit->Tag = true;
  else
		if ( OffsetEdit->Focused())
			OffsetEdit->Tag = true;

//	if ( FieldEdit->Tag || LineEdit->Tag || OffsetEdit->Tag)  //JK 15.08.01
		if ( !ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  												FieldEdit, LineEdit, OffsetEdit))
	  	return;
#if 1
  // call to *(Clicking OK button now reads all edit fields regardless of whether
  //           RETURN was pressed after edititng or not ) :JK 21.11.01
	FieldEdit->Tag = true;
	LineEdit->Tag = true;
	OffsetEdit->Tag = true;

	if (!ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit))
    return;  								
  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;
	
	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());
	PT5201Form->SystemStatusUpdate( Black1Field);
// *********
#endif

	ModelessResult = mrOk;

	Close();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::CancelButtonClick(TObject *Sender)
{
	ModelessResult = mrCancel;

	Close();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::SystemComboBoxChange(TObject *Sender)
  {

   if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
     {
     return;
     }

	if ( ValidatePALToNTSC( SystemComboBox->ItemIndex, &BlackSetup->Samples, OffsetTrackBar))
    {
		BlackSetup->System = SystemComboBox->ItemIndex;

    TrackBarSetup( BlackSetup->System, OffsetTrackBar, MinLabel, MaxLabel);

		SamplesToFLO( SystemComboBox->ItemIndex, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

    do_not_adjust_tb = 1;
  	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
    do_not_adjust_tb = 0;

		TrxBBSystem( Black1Output, BlackSetup->System);
	  }
  else
		SystemComboBox->ItemIndex = BlackSetup->System;

 	PT5201Form->SystemStatusUpdate( Black1Field);
  timeout2 = false;
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::ScHPhaseUpDownClick(TObject *Sender,
	TUDBtnType Button)
{
	ActiveControl = ScHPhaseEdit;

  ScHPhaseAdjust( &BlackSetup->ScHPhase, ScHPhaseEdit, Button);

	TrxBBScHPhase( Black1Output, BlackSetup->ScHPhase);

 	PT5201Form->SystemStatusUpdate( Black1Field);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::ScHPhaseEditExit(TObject *Sender)
{
	if ( ValidateScHPhase( Black1Form, ScHPhaseEdit, &BlackSetup->ScHPhase))
		TrxBBScHPhase( Black1Output, BlackSetup->ScHPhase);

 	PT5201Form->SystemStatusUpdate( Black1Field);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FieldUpDownClick(TObject *Sender, TUDBtnType Button)
{
	ActiveControl = FieldEdit;

	TimingAdjust( BlackSetup->System, &BlackSetup->Samples, BlackType, FieldEdit, Button);

	SamplesToFLO( BlackSetup->System, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	FieldEdit->SelectAll();

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
#if 0
void __fastcall TBlack1Form::FieldUpDownChanging(TObject *Sender,
	bool &AllowChange)
{
	FieldUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FieldEditExit(TObject *Sender)
  {
  return; // JK 15.08.01
	FieldEdit->Tag = true;

	ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::LineUpDownClick(TObject *Sender, TUDBtnType Button)
{
	ActiveControl = LineEdit;

  TimingAdjust( BlackSetup->System, &BlackSetup->Samples, BlackType, LineEdit, Button);

	SamplesToFLO( BlackSetup->System, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	LineEdit->SelectAll();

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
#if 0
void __fastcall TBlack1Form::LineUpDownChanging(TObject *Sender,
	bool &AllowChange)
{
	LineUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::LineEditExit(TObject *Sender)
  {
   return;  // JK 15.08.01
	 LineEdit->Tag = true;

	 ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;
 
	 TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

   PT5201Form->SystemStatusUpdate( Black1Field);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::OffsetUpDownClick(TObject *Sender, TUDBtnType Button)
{
	ActiveControl = OffsetEdit;

	TimingAdjust( BlackSetup->System, &BlackSetup->Samples, BlackType, OffsetEdit, Button);

	SamplesToFLO( BlackSetup->System, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	OffsetEdit->SelectAll();

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
#if 0
void __fastcall TBlack1Form::OffsetUpDownChanging(TObject *Sender,
	bool &AllowChange)
{
	OffsetUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::OffsetEditExit(TObject *Sender)
  {
  return;  // JK 15.08.01
	OffsetEdit->Tag = true;

	ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::OffsetTrackBarChange(TObject *Sender)
  {
//  This function is entered when user changes slider position and ALSO when 
//  TrackBar->Position is changed programatically, like TrackBar->Position = tmp;
//  Unfortunately, TrackBarAdjust() will modify BlackSetup->Samples.  
//  If we change TrackBar->Position programatically, we do NOT want to modify
//  BlackSetup->Samples, because only field and line values are modified, offset is
//  always set to zero by TrackBarAdjust().
//  We introduce a global variable to notify that TrackBar->Position was changed
//  programatically, in which case we just return from this function.

  if (do_not_adjust_tb)
    return;
  if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
    {
    return;
    }

  TrackBarAdjust( SystemComboBox->ItemIndex, &BlackSetup->Samples, OffsetTrackBar);
	SamplesToFLO( SystemComboBox->ItemIndex, BlackSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

	PT5201Form->SystemStatusUpdate( Black1Field);
  timeout2 = false;
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::LockForm( bool Lock)
{
	bool enable = !Lock;

	SystemComboBox->Enabled = enable;
	FieldUpDown->Enabled = enable;
	FieldEdit->Enabled = enable;
	LineUpDown->Enabled = enable;
	LineEdit->Enabled = enable;
	OffsetUpDown->Enabled = enable;
	OffsetEdit->Enabled = enable;
	OffsetTrackBar->Enabled = enable;
	ScHPhaseUpDown->Enabled = enable;
	ScHPhaseEdit->Enabled = enable;

  CancelButton->Enabled = enable;

	if ( Black1Form->Visible)
	  Black1Form->Refresh();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::UpdateOutput( TBlackGenerator *setup)
{
	TrxBBSystem( Black1Output, setup->System);

	SamplesToFLO( setup->System, setup->Samples, Field1Edit, Line1Edit, Offset1Edit);
	TrxBBDelay( Black1Output, Field1Edit->Text.ToInt(), Line1Edit->Text.ToInt(), Offset1Edit->Text.ToDouble());

	TrxBBScHPhase( Black1Output, setup->ScHPhase);
}
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::HelpButtonClick(TObject *Sender)
{
	Application->HelpContext( IDH_EDITBB);
}
// This function tackles editing offset field and pressing Return.
// Value in the offset field should be transmitted to the genrator.
//---------------------------------------------------------------------------
#if 0
void __fastcall TBlack1Form::ScHPhaseUpDownChanging(TObject *Sender,
 bool &AllowChange)
{
ScHPhaseUpDown->Position = 0;
}
#endif

void __fastcall TBlack1Form::OffsetEditKeyUp(TObject *Sender, WORD &Key,
                                              TShiftState Shift)
 {
 if (Key != 13) // if other than CR
   return;
	OffsetEdit->Tag = true;

	if (!ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit))
    return;

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 PT5201Form->SystemStatusUpdate( Black1Field);
 }
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::LineEditKeyUp(TObject *Sender, WORD &Key,
                                           TShiftState Shift)
  {
  if (Key != 13)
    return;
	LineEdit->Tag = true;

	ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);
  
  return; 
  }
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::FieldEditKeyUp(TObject *Sender, WORD &Key,
                                            TShiftState Shift)
  {
  if (Key != 13)
    return;
    
	FieldEdit->Tag = true;

	if (!ValidateEntry( Black1Form, BlackSetup->System, &BlackSetup->Samples, \
  								FieldEdit, LineEdit, OffsetEdit))
    return;

  do_not_adjust_tb = 1;
	TrackBarUpdate( BlackSetup->System, BlackSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

	TrxBBDelay( Black1Output, FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

 	PT5201Form->SystemStatusUpdate( Black1Field);

  return; 
  }
//---------------------------------------------------------------------------
void __fastcall TBlack1Form::ScHPhaseEditKeyUp(TObject *Sender, WORD &Key,
                                               TShiftState Shift)
  {
  if (Key != 13)
    return;
	 if (!ValidateScHPhase( Black1Form, ScHPhaseEdit, &BlackSetup->ScHPhase))
    return;
  TrxBBScHPhase( Black1Output, BlackSetup->ScHPhase);

  PT5201Form->SystemStatusUpdate( Black1Field);

  return;
  }
//---------------------------------------------------------------------------
