// 31.05.2001 modified for JNTS: JK

//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <stdio.h>
#include <vcl\registry.hpp>
#include "names.h"
#pragma hdrstop

#include "mainform.h"
#include "preset.h"
#include "connect.h"
#include "genlock.h"
#include "proper.h"
#include "black1.h"
#include "black2.h"
#include "black3.h"
#include "tsg.h"
#include "audio.h"
#include "apparatu.h"
#include "system.h"
#include "about.h"
#include "util.h"
#include "pt52class.h"
#include "comm.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma resource "*.dfm"

TPT5201Form *PT5201Form;

TSyncGenerator *PT5201Setup;
TCommPort *PT5201CommPort;

TGenlockGenerator *GenlockStatus;
TBlackGenerator *BBStatus[3];
TTSGenerator *TSGStatus;
TAudioGenerator *AudioStatus;

bool TestMode=false, TestModeConnected=false;
AnsiString MasterVersion, GenlockVersion, BBVersion;
bool Genlocked;
char sw_version;  // version control, holds NEW or OLD

const SystemStatusPanelHeight = 313;

int delay_tick;

char *QuerryTxt[] =
  {
  "SYST:ERR?\r\n",
  "INP:GENL?\r\n",
  "STAT:PRES?\r\n",
  NULL
  };



//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
__fastcall TPT5201Form::TPT5201Form(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::FormCreate(TObject *Sender)
  {
  char *commPort;

  PT5201Setup    = new TSyncGenerator;
  PT5201CommPort = new TCommPort;

  TestMode = false;
  sw_version = NEW;
  
#ifdef LEADER
  PT5201Form->Caption  = MNAME;
  Image1->Visible      = true;
  Image2->Visible      = false;
  Label24->Caption     = MODEL;
  Label24->Left        = 314;
  Label24->Top         = 16;
  Label34->Caption     = RIGHTTOP;
  Label34->Font->Size  = 14;
  Label34->Left        = 638;
  Label34->Top         = 10;
  Label30->Caption     = RESPONSE;
  PTVonttheWeb1->Caption = PTVWEB;
  PTVHomepage1->Caption = PTVHOME;
  CBarGroupBox->Caption = SDINAME;
  Label35->Caption      = L35CAP;
  ConfigureColorBarItem->Caption = CCBIC;
  Shape2->Visible                = true;
  Shape3->Visible                = true;
  Shape4->Visible                = true;
  Shape5->Visible                = false;
  Shape6->Visible                = true;
  Shape7->Visible                = false;
#else
  PT5201Form->Caption            = MNAME;
  Image2->Visible                = true;
  Label24->Caption               = MODEL;
  Label24->Left                  = 12;
  Label24->Top                   = 16;
  Label34->Caption               = RIGHTTOP;
  Label34->Font->Size            = 10;
  Label34->Left                  = 585;
  Label34->Top                   = 16;
  Label30->Caption               = RESPONSE;
  PTVonttheWeb1->Caption         = PTVWEB;
  PTVHomepage1->Caption          = PTVHOME;
  CBarGroupBox->Caption          = SDINAME;
  ConfigureColorBarItem->Caption = CCBIC;
#endif

  RestoreWindowPosition(PT5201Form, "");
  RestoreCommPort(&commPort);

  PT5201Form->ClientHeight = PT5201FrontPanel->Height;

  SystemStatusPanel->Visible; // = PT5201Form->ViewSystemStatusItem->Checked;

  PT5201Form->ClientHeight += SystemStatusPanelHeight;
  StatusBar->Visible = true;  //PT5201Form->ViewStatusBarItem->Checked;
  PT5201Form->ClientHeight += StatusBar->Height;

#if 0
  if (PT5201Form->ViewSystemStatusItem->Checked)
    PT5201Form->ClientHeight += SystemStatusPanelHeight;
  StatusBar->Visible = PT5201Form->ViewStatusBarItem->Checked;

  if (PT5201Form->ViewStatusBarItem->Checked)
    PT5201Form->ClientHeight += StatusBar->Height;
#endif

  PT5201Form->Refresh();

  if (PT5201Setup->ReadFromFile((AnsiString)"PT5202.ini") == -1)
    {
    Application->MessageBox(NOOPEN, "Information", MB_OK|MB_ICONINFORMATION);
    PT5201Setup->SaveToFile((AnsiString)"PT5202.ini");
    }

  DecimalSeparator = '.';         // Neccesary cause some transformations will
                                                                                                  //  otherwise use the decimal separator from windows

  // COM port may be changed by the user
  StatusBar->Panels->Items[CommPortPanel]->Text     = commPort;
  StatusBar->Panels->Items[CommSettingsPanel]->Text = "9600";
  StatusBar->Panels->Items[ConnectedPanel]->Text    = "Disconnected";

  // Baudrate, Data-parity-stop i.e. 8-N-2 may NOT be changed by the user
  PT5201CommPort->SetCommPort(commPort);
  PT5201CommPort->SetBaudRate(9600);
  PT5201CommPort->SetByteSize(8);
  PT5201CommPort->SetParity(NOPARITY);
  PT5201CommPort->SetStopBits(2);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::FormClose(TObject *Sender, TCloseAction &Action)
  {
  SaveWindowPosition(PT5201Form, "");

	SaveCommPort( PT5201CommPort->GetCommPort());
	PT5201Setup->SaveToFile((AnsiString) "PT5202.INI");

  PT5201CommPort->CloseCommPort();
  while(PT5201CommPort->Connected())
    ;
  Action = caFree;
  delete PT5201Setup;
  delete PT5201CommPort;
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::RestoreFromFileClick(TObject *Sender)
  {
  if (FileOpenDialog->Execute())
    {
    if (PT5201Setup->ReadFromFile(FileOpenDialog->FileName) == -1)
      {
      Application->MessageBox("The chosen file is not a valid configuration file.",\
                              "Error", MB_OK|MB_ICONERROR);
      }
    if (PT5201CommPort->Connected())
      {
      GenlockForm->UpdateOutput(PT5201Setup->GetGenlockSettings());

      Black1Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black1Output));
      Black2Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black2Output));
      Black3Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black3Output));

      TSGForm->UpdateOutput(PT5201Setup->GetTSGSettings());

      AudioForm->UpdateOutput(PT5201Setup->GetAudioSettings());

      SystemStatusUpdate(AllFields);

      PT5201LEDsUpdate();
      }
    }
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::OpenPresetClick(TObject *Sender)
  {
  if (PT5201CommPort->Connected() && !TestMode)
    {
    PresetForm->Tag = 1;
    PresetForm->ShowModal();
    }
  else
    {
    Application->MessageBox(NOCONNECT, "Information", MB_OK|MB_ICONINFORMATION);
    }
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::toFileAs1Click(TObject *Sender)
  {
  if (FileSaveDialog->Execute())
  PT5201Setup->SaveToFile(FileSaveDialog->FileName);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::SavePresetClick(TObject *Sender)
  {
  if (PT5201CommPort->Connected() && !TestMode)
    {
    PresetForm->Tag = 0;
    PresetForm->ShowModal();
    }
  else
    {
    Application->MessageBox(NOCONNECT, "Information", MB_OK|MB_ICONINFORMATION);
    }
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::FilePrintItemClick(TObject *Sender)
{
        PrintDialog->Execute();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::FilePropertiesItemClick(TObject *Sender)
{
        PropertiesForm->ShowModal();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::FileItemExitClick(TObject *Sender)
  {
  PT5201Form->Close();
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConnectItemClick(TObject *Sender)
  {
  if (TestMode)
    ConnectUsingGeneratorSettings->Enabled = false;
  else
    ConnectUsingGeneratorSettings->Enabled = true;
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConnectUsingGeneratorSettingsClick(TObject *Sender)
  {

  if (!ConnectToGenerator())
    return;

  StatusBar->Panels->Items[0]->Text = "Connected";
  TrxApparatusInfoRequest();
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConnectUsingPCSettingsClick(TObject *Sender)
  {

  if (!ConnectToGenerator())
    return;

  StatusBar->Panels->Items[0]->Text = "Connected";

  GenlockForm->UpdateOutput(PT5201Setup->GetGenlockSettings());

  Black1Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black1Output));
  Black2Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black2Output));
  Black3Form->UpdateOutput(PT5201Setup->GetBlackSettings(Black3Output));
  AudioForm->UpdateOutput(PT5201Setup->GetAudioSettings());

  TSGForm->UpdateOutput(PT5201Setup->GetTSGSettings());


  SystemStatusUpdate(AllFields);

  PT5201LEDsUpdate();
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConnectDisconnectItemClick(TObject *Sender)
  {
  if (!TestMode)
    {
    try
      {
      PT5201CommPort->CloseCommPort();
      }
    catch(ECommError &e)
      {
      char *buffer = new char[40];

      strcpy(buffer, "Unable to close ");
      strcat(buffer, PT5201CommPort->GetCommPort());
      strcat(buffer, ".");
      Application->MessageBox(buffer, "Connect", MB_OK|MB_ICONINFORMATION);
      delete [] buffer;
      return;
      }
    }
  else
    TestModeConnected = false;

  StatusBar->Panels->Items[0]->Text = "Disconnected";
#if 0
  if (ViewSystemStatusItem->Checked)
#endif
  SystemStatusUpdate(AllFields);
  PT5201LEDsUpdate();
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConnectDemoModeItemClick(TObject *Sender)
{
        if (!PT5201CommPort->Connected())
  {
                if (ConnectDemoModeItem->Checked)
        {
                        // Be sure to disconnect BEFORE clearing testmode
                        ConnectDisconnectItemClick(Sender);

                        ConnectDemoModeItem->Checked = false;
                TestMode = false;
                        StatusBar->Panels->Items[DemoModePanel]->Text = "";
                }
                else
        {
                        ConnectDemoModeItem->Checked = true;
                TestMode = true;
                        StatusBar->Panels->Items[DemoModePanel]->Text = "DEMO MODE";
                }
        }
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConfigureGenlockItemClick(TObject *Sender)
{
        GenlockForm->Show();
}
//---------------------------------------------------------------------------
//
//
void __fastcall TPT5201Form::BlackBurst1ItemClick(TObject *Sender)
{
        Black1Form->Show();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::BlackBurst2ItemClick(TObject *Sender)
{
        Black2Form->Show();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::BlackBurst3ItemClick(TObject *Sender)
{
        Black3Form->Show();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConfigureColorBarItemClick(TObject *Sender)
{
        TSGForm->Show();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ConfigureAudioItemClick(TObject *Sender)
{
        AudioForm->Show();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::EditSystemItemClick(TObject *Sender)
  {
  SystemForm->ShowModal();
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ViewSystemStatusItemClick(TObject *Sender)
  {
#if 0
  if (ViewSystemStatusItem->Checked)
    {
    ViewSystemStatusItem->Checked = false;
    SystemStatusPanel->Visible    = false;
    SystemStatusPanel->Height     = SystemStatusPanelHeight;
    PT5201Form->ClientHeight     -= SystemStatusPanelHeight;
    }
  else
    {
    SystemStatusUpdate(AllFields);
    ViewSystemStatusItem->Checked = true;
    SystemStatusPanel->Visible    = true;
    SystemStatusPanel->Height     = SystemStatusPanelHeight;
    SystemStatusPanel->Align      = alTop;
    PT5201Form->ClientHeight     += SystemStatusPanelHeight;
    }
#endif
  return;    
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::ViewStatusBarItemClick(TObject *Sender)
  {
#if 0
  if (ViewStatusBarItem->Checked)
    {
    ViewStatusBarItem->Checked = false;
    StatusBar->Visible = false;
    PT5201Form->ClientHeight -= StatusBar->Height;
    }
  else
    {
    ViewStatusBarItem->Checked = true;
    StatusBar->Visible = true;
    PT5201Form->ClientHeight += StatusBar->Height;
    }
#endif
  return;    
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::Contents1Click(TObject *Sender)
{
        Application->HelpCommand(HELP_FINDER, 0);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::Frequentlyaskedquestions1Click(TObject *Sender)
{
        ShellExecute(NULL, "open", WEBSITE, NULL, NULL, SW_RESTORE);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::OnlineSupport1Click(TObject *Sender)
{
        ShellExecute(NULL, "open", WEBSITE, NULL, NULL, SW_RESTORE);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::PTVHomepage1Click(TObject *Sender)
{
        ShellExecute(NULL, "open", WEBSITE, NULL, NULL, SW_RESTORE);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::HelpAboutItemClick(TObject *Sender)
{
        AboutBox->ShowModal();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::SystemStatusUpdate(int StatusField)
  {
  const char* *ptr;
  TColor activeColor; // = clBtnFace;      JK

  PT5201LEDsUpdate();

  if (PT5201CommPort->Connected() || TestModeConnected)
    {
    if ((StatusField == GenlockField) || (StatusField == AllFields))
      {
      // Get genlock settings
      GenlockStatus = PT5201Setup->GetGenlockSettings();
      GenlockSystemEdit->Text = GenlockSystemTxt[GenlockStatus->System];
      SamplesToFLO(GenlockStatus->System, GenlockStatus->Samples, \
      GenlockFieldEdit, GenlockLineEdit, GenlockOffsetEdit);
      StatusTrackBarUpdate(GenlockStatus->System, GenlockStatus->Samples, GenlockOffsetTrackBar);
      }

      if ((StatusField == Black1Field) || (StatusField == AllFields))
        {
        // Get BB1 settings
        BBStatus[Black1Output] = PT5201Setup->GetBlackSettings(Black1Output);

        BB1SystemEdit->Text = SystemTxt[BBStatus[Black1Output]->System];
        SamplesToFLO(BBStatus[Black1Output]->System, BBStatus[Black1Output]->Samples, \
                      BB1FieldEdit, BB1LineEdit, BB1OffsetEdit);
        StatusTrackBarUpdate(BBStatus[Black1Output]->System, BBStatus[Black1Output]->Samples, BB1OffsetTrackBar);
                              BB1ScHEdit->Text = IntToStr(BBStatus[Black1Output]->ScHPhase);
        }

      if ((StatusField == Black2Field) || (StatusField == AllFields))
        {
        // Get BB2 settings
        BBStatus[Black2Output] = PT5201Setup->GetBlackSettings(Black2Output);

        BB2SystemEdit->Text = SystemTxt[BBStatus[Black2Output]->System];
        SamplesToFLO(BBStatus[Black2Output]->System, BBStatus[Black2Output]->Samples, \
                      BB2FieldEdit, BB2LineEdit, BB2OffsetEdit);
        StatusTrackBarUpdate(BBStatus[Black2Output]->System, BBStatus[Black2Output]->Samples, BB2OffsetTrackBar);
                              BB2ScHEdit->Text = IntToStr(BBStatus[Black2Output]->ScHPhase);
        }

      if ((StatusField == Black3Field) || (StatusField == AllFields))
        {
        // Get BB3 settings
        BBStatus[Black3Output] = PT5201Setup->GetBlackSettings(Black3Output);

        BB3SystemEdit->Text = SystemTxt[BBStatus[Black3Output]->System];
        SamplesToFLO(BBStatus[Black3Output]->System, BBStatus[Black3Output]->Samples, \
                                                BB3FieldEdit, BB3LineEdit, BB3OffsetEdit);
        StatusTrackBarUpdate(BBStatus[Black3Output]->System, BBStatus[Black3Output]->Samples, BB3OffsetTrackBar);
        BB3ScHEdit->Text = IntToStr(BBStatus[Black3Output]->ScHPhase);
        }

      if ((StatusField == TSGField) || (StatusField == AllFields))
        {
        TSGStatus = PT5201Setup->GetTSGSettings();

        TSGTextEdit->Text = TSGStatus->Text;
    
/*  Original algor from PT5202 software....

    if ((Settings.CBSetup.Pattern == SMPTECBar) || (Settings.CBSetup.Pattern == EBUCBar))
      {
      if (CBSetup.TextData.TextEnable == ON)
        text_on = ON;
      else
        text_on = OFF;
      }
    else
      text_on = OFF;


enum TSGPatterns
  {
  SMPTECBar = 0, EBUCBar,  FCCCBar, EBUCBarITU, CBar75ITU, CBar100,\
  CBarGrey75, CBarRed75, Red75, Multiburst, CCIR18,\
  Window10, Window15, Window20, Window100, BlWh15kHz,\
  White100, Black, CheckField, DigitalGrey,Stair5,\
  Stair10,Crosshatch, PLUGE
  };

*/
      // Now grey text field if text is off.... grey  grey  grayed    grayed
      if ((TSGStatus->Pattern == SMPTECBar) || (TSGStatus->Pattern == EBUCBar))
        {
        if (TSGStatus->TextEnable == true)
          TSGTextEdit->Enabled = true;
        else
          TSGTextEdit->Enabled = false;
        }
      else
        TSGTextEdit->Enabled = false;

       switch (TSGStatus->System)
         {
         case PAL:
           TSGSystemEdit->Text = PALTxt;
           break;
         case NTSC:
           TSGSystemEdit->Text = NTSCTxt;
           break;
         case JNTS:
           TSGSystemEdit->Text = JNTSTxt;
           break;
         default:
           TSGSystemEdit->Text = PALTxt;
           break;
         }
    
        SamplesToFLO(TSGStatus->System, TSGStatus->Samples, \
        TSGFieldEdit, TSGLineEdit, TSGOffsetEdit);
        StatusTrackBarUpdate(TSGStatus->System, TSGStatus->Samples, TSGOffsetTrackBar);
        TSGScHEdit->Text = IntToStr(TSGStatus->ScHPhase);
        /**** here *** check TSGPatternTxt janusz */
        TSGPatternEdit->Text = TSGPatternTxt[TSGStatus->Pattern]; //JK change TSGSettings
        TSGEmbAudioEdit->Text = EmbAudioToneTxt[TSGStatus->EmbAudio];
    
    
        }  //if ((StatusField == TSGField) || (StatusField == AllFields))

      if ((StatusField == AudioField) || (StatusField == AllFields))
        {
        // Get audio settings
        AudioStatus = PT5201Setup->GetAudioSettings();

        AudioOutputEdit->Text = AudioOutputTxt[AudioStatus->Output];

        if (AudioStatus->Output == AnalogAudio)
          {
          // System, Timing and WordClock is not possible
#ifdef LEADER          
          ptr = AnalogLevelTxtNew;
#else
          if (sw_version == NEW)
            ptr = AnalogLevelTxtNew;
          else
            ptr = AnalogLevelTxtOld;
#endif          
          AudioSystemEdit->Text = "NA";
          AudioTimingEdit->Text = "NA";
          AudioWordEdit->Text = "NA";
           }
        else
          {
          // Timing is not possible for WordClock = 48kHz
#ifdef LEADER          
          ptr = AESEBULevelTxtNew;
#else
          if (sw_version == NEW)
            ptr = AESEBULevelTxtNew;
          else
            ptr = AESEBULevelTxtOld;
#endif          

          AudioSystemEdit->Text = AudioSystemTxt[AudioStatus->System];
          AudioWordEdit->Text = AudioWordTxt[AudioStatus->WordClock];

          //if (AudioStatus->WordClock == f441kHz)
          if (AudioStatus->WordClock == f48kHz) //  *JK* change
            {
            AudioTimingEdit->Text = FloatToStrF(((float)AudioStatus->Timing)/10., ffFixed, 5, 1);
            AudioTrackBar->Position = AudioStatus->Timing/AESTimingStep;
            }
          else
            AudioTimingEdit->Text = "NA";
          }
        AudioToneEdit->Text = AudioToneTxt[AudioStatus->Tone[AudioStatus->Output]];
        AudioLevelEdit->Text = ptr[AudioStatus->Level[AudioStatus->Output]];
        AudioLevelLabel->Caption = (AudioStatus->Output == AnalogAudio ? AnsiString("dBu"):AnsiString("dBFS"));
        AudioClickEdit->Text = AudioClickTxt[AudioStatus->ClickPeriod[AudioStatus->Output]];
        // we delete PLL and Video fields from the main form JK change
        //AudioPLLEdit->Text = "NA";
        //AudioVideoEdit->Text = "NA";
        }

      // The following are initialised from the received IDN string
      //  ErrorStatusEdit->Text = "";
      //  KUNumberEdit->Text = "";
      //  SWRevisionEdit->Text = "";
      //  PresetStatusEdit->Text = "";
      //  GeneratorInfoMemo->Lines->Add("MTV:" + MasterVersion);
      //  GeneratorInfoMemo->Lines->Add("GV: " + GenlockVersion);
      //  GeneratorInfoMemo->Lines->Add("BV: " + BBVersion);
     activeColor = clLime;
     }
   else
    {
    GenlockSystemEdit->Text = "";
    GenlockFieldEdit->Text = "";
    GenlockLineEdit->Text = "";
    GenlockOffsetEdit->Text = "";
    StatusTrackBarUpdate(PAL, 0, GenlockOffsetTrackBar);

    BB1SystemEdit->Text = "";
    BB1FieldEdit->Text = "";
    BB1LineEdit->Text = "";
    BB1OffsetEdit->Text = "";
    StatusTrackBarUpdate(PAL, 0, BB1OffsetTrackBar);
    BB1ScHEdit->Text = "";

    BB2SystemEdit->Text = "";
    BB2FieldEdit->Text = "";
    BB2LineEdit->Text = "";
    BB2OffsetEdit->Text = "";
    StatusTrackBarUpdate(PAL, 0, BB2OffsetTrackBar);
    BB2ScHEdit->Text = "";

    BB3SystemEdit->Text = "";
    BB3FieldEdit->Text = "";
    BB3LineEdit->Text = "";
    BB3OffsetEdit->Text = "";
    StatusTrackBarUpdate(PAL, 0, BB3OffsetTrackBar);
    BB3ScHEdit->Text = "";

    TSGSystemEdit->Text = "";
    TSGFieldEdit->Text = "";
    TSGLineEdit->Text = "";
    TSGOffsetEdit->Text = "";
    StatusTrackBarUpdate(PAL, 0, TSGOffsetTrackBar);
    TSGScHEdit->Text      = "";
    TSGPatternEdit->Text  = "";
    TSGEmbAudioEdit->Text = "";
    TSGTextEdit->Text        = "";

    AudioOutputEdit->Text = "";
    AudioSystemEdit->Text = "";
    AudioTimingEdit->Text = "";
    AudioTrackBar->Position = 0;
    AudioToneEdit->Text = "";
    AudioLevelEdit->Text = "";
    AudioWordEdit->Text = "";
    AudioClickEdit->Text = "";
    //AudioPLLEdit->Text = "";
    //AudioVideoEdit->Text = "";
    ErrorStatusEdit->Text = "";
    KUNumberEdit->Text = "";
    SWRevisionEdit->Text = "";
    PresetStatusEdit->Text = "";
    GeneratorInfoMemo->Lines->Clear();
    activeColor = clBtnFace; //JK 9.09.2001
    }

  GenlockSystemEdit->Color = activeColor;
  GenlockFieldEdit->Color = activeColor;
  GenlockLineEdit->Color = activeColor;
  GenlockOffsetEdit->Color = activeColor;

  BB1SystemEdit->Color = activeColor;
  BB1FieldEdit->Color = activeColor;
  BB1LineEdit->Color = activeColor;
  BB1OffsetEdit->Color = activeColor;
  BB1ScHEdit->Color = activeColor;

  BB2SystemEdit->Color = activeColor;
  BB2FieldEdit->Color = activeColor;
  BB2LineEdit->Color = activeColor;
  BB2OffsetEdit->Color = activeColor;
  BB2ScHEdit->Color = activeColor;

  BB3SystemEdit->Color = activeColor;
  BB3FieldEdit->Color = activeColor;
  BB3LineEdit->Color = activeColor;
  BB3OffsetEdit->Color = activeColor;
  BB3ScHEdit->Color = activeColor;

  TSGSystemEdit->Color   = activeColor;
  TSGFieldEdit->Color    = activeColor;
  TSGLineEdit->Color     = activeColor;
  TSGOffsetEdit->Color   = activeColor;
  TSGScHEdit->Color      = activeColor;
  TSGPatternEdit->Color  = activeColor;
  TSGEmbAudioEdit->Color = activeColor;
  TSGTextEdit->Color     = activeColor;

  AudioOutputEdit->Color = activeColor;
  AudioSystemEdit->Color = activeColor;
  AudioTimingEdit->Color = activeColor;
  AudioToneEdit->Color = activeColor;
  AudioLevelEdit->Color = activeColor;
  AudioWordEdit->Color = activeColor;
  AudioClickEdit->Color = activeColor;
  //AudioPLLEdit->Color = activeColor;
  //AudioVideoEdit->Color = activeColor;

  ErrorStatusEdit->Color = activeColor;
  KUNumberEdit->Color = activeColor;
  SWRevisionEdit->Color = activeColor;
  PresetStatusEdit->Color = activeColor;

  GeneratorInfoMemo->Color = activeColor;
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::PT5201LEDsUpdate(void)
{
  return;
}
//----------------------------Enabled-----------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::UpdateLEDs(bool LEDOn, TImage *LED)
{
  return;
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
#if 0
void __fastcall TPT5201Form::Timer1Timer(TObject *Sender)
  {
  char PresetNo;
  int  i;

  if (PT5201CommPort->Connected() && !TestMode)
    {
    char *buffer = new char[80];
    char *tmp    = new char[80]; // JK

  for (i = 0; i < 3; i++)
    {
    if (!TrxRequest(QuerryTxt[i], 60, (Byte *) buffer))
      {
      Timer1->Enabled = false;
      delete [] tmp;
      strcpy(buffer, NORESPONSE);
      strcat(buffer, ".");
      ErrorStatusEdit->Text = "Error connecting to unit";
      Application->MessageBox(buffer, "Communication", MB_OK|MB_ICONINFORMATION);
      PT5201CommPort->CloseCommPort();
      ConnectDisconnectItemClick(Sender);
      delete [] buffer;
      Timer1->Enabled = true;
      return;
      }    
    switch (i)
      {
      case 0:
        ErrorStatusEdit->Text  = buffer;
        break;
      case 1:
        if ((Genlocked = strstr(buffer, "UNLOCKED")) == 0)
          UpdateLEDs(false, GenlockImage);
        else
          UpdateLEDs(true, GenlockImage);
        break;
      case 2:
        PresetStatusEdit->Text = buffer;
        if (strcmp(buffer, "OFF"))
          {
          PresetNo = buffer[0];
          sprintf(buffer, "SYST:PRES:NAME? %c\r\n", PresetNo);
  
          if (!TrxRequest(buffer, 20, (Byte *)buffer))
            {
            Timer1->Enabled = false;
            delete [] tmp;
            strcpy(buffer, NORESPONSE);
            //strcat(buffer, PT5201CommPort->GetCommPort());
            strcat(buffer, ".");
            ErrorStatusEdit->Text = "Error connecting to unit";
            Application->MessageBox(buffer, "Communication", MB_OK|MB_ICONINFORMATION);
            PT5201CommPort->CloseCommPort();
            ConnectDisconnectItemClick(Sender);
            delete [] buffer;
            Timer1->Enabled = true;
            return;
            }    
          PresetStatusEdit->Text = PresetStatusEdit->Text + ": " + buffer;
          }
        break;
      }
    }

    delete [] buffer;
    delete [] tmp;
    }
  }
#else
void __fastcall TPT5201Form::Timer1Timer(TObject *Sender)
  {
  char PresetNo;

  delay_tick++;

  if (PT5201CommPort->Connected() && !TestMode)
    {
    char *buffer = new char[80];
    char *tmp;                    //    = new char[80]; // JK

    if (TrxRequest("SYST:ERR?\r\n", 60, (Byte *)buffer))
      {
      ErrorStatusEdit->Text = buffer;
      TrxRequest("STAT:PRES?\r\n", 60, (Byte *)buffer);
      PresetStatusEdit->Text = buffer;

      if (strcmp(buffer, "OFF"))
        {
        PresetNo = buffer[0];
        sprintf(buffer, "SYST:PRES:NAME? %c\n", PresetNo);

        TrxRequest(buffer, 20, (Byte *)buffer);

        PresetStatusEdit->Text = PresetStatusEdit->Text + ": " + buffer;
        }
      TrxRequest("INP:GENL?\r\n", 60, (Byte *)buffer);
      tmp = strchr(buffer, ',');
      if (tmp == 0)
        {
        delete [] tmp;
        strcpy(buffer, NORESPONSE);
        //strcat(buffer, PT5201CommPort->GetCommPort());
        strcat(buffer, ".");
        ErrorStatusEdit->Text = "Error connecting to unit";
        Application->MessageBox(buffer, "Information", MB_OK|MB_ICONINFORMATION);
        PT5201CommPort->CloseCommPort();
        ConnectDisconnectItemClick(Sender);
        delete [] buffer;
        return;
        }
      *tmp = 0;  // potential danger, may be NULL

      if ((Genlocked = strcmp(buffer, "UNLOCKED")) == 0) //JK
        ;
      else
        ;
      }
    else
      {
      ErrorStatusEdit->Text = "Error connecting to unit";
      ConnectDisconnectItemClick(Sender);
      }
    delete [] buffer;
    }
  }
#endif

//---------------------------------------------------------------------------
bool __fastcall TPT5201Form::ConnectToGenerator(void)
  {
  int vnum;
  
  if (!TestMode)
    {
    try
      {
      PT5201CommPort->OpenCommPort();
      }
    catch(ECommError &e)
      {
      char *buffer = new char[100];

      strcpy(buffer, "Port ");
      strcat(buffer, PT5201CommPort->GetCommPort());
      strcat(buffer, " cannot be opened.");

      Application->MessageBox(buffer, "Connect to Generator", MB_OK|MB_ICONINFORMATION);

      delete [] buffer;
      Timer1->Enabled = true;
      return(false);
      }

    PT5201CommPort->FlushCommPort();
    PT5201CommPort->WriteString("*IDN?\r\n");

    char *buffer = new char[100];  // 80
    char *tmp, *ProductPtr, *KUNumberPtr, *SWPtr;
    bool errorState;

    PT5201CommPort->ReadBytes((Byte *)buffer, 80);

    tmp = ProductPtr = strchr(buffer, ',');
    errorState = (tmp == NULL);

    if (!errorState)
      {
      *tmp = 0;
      ProductPtr++;

      tmp = KUNumberPtr = strchr(ProductPtr, ',');
      errorState = (tmp == NULL);
      }

    if (!errorState)
      {
      *tmp = 0;
      KUNumberPtr++;

      tmp = SWPtr = strchr(KUNumberPtr, ',');
      errorState = (tmp == NULL);
      }

    if (!errorState)
      {
      *tmp = 0;
      SWPtr++;

      tmp = strchr(SWPtr, '\n');
      errorState = (tmp == NULL);
      }

    if (!errorState)
      {
      *tmp = 0;

      KUNumberEdit->Text   = KUNumberPtr;
      SWRevisionEdit->Text = SWPtr;

/********    Version control    ****************/      

      vnum = atoi(SWPtr);
      if (vnum < 30)
        sw_version = OLD;
      else
        sw_version = NEW;

/***********************************************/
      }
    else
      {
      strcpy(buffer, NORESPONSE);
      strcat(buffer, PT5201CommPort->GetCommPort());
      strcat(buffer, ".");
      Application->MessageBox(buffer, "Connect to Generator", MB_OK|MB_ICONINFORMATION);
      PT5201CommPort->CloseCommPort();
      delete [] buffer;
      Timer1->Enabled   = true;
      return(false);
      }

    PT5201CommPort->FlushCommPort();
    PT5201CommPort->WriteString("FACT:MAIN:VERS?\r\n");

    PT5201CommPort->ReadBytes((Byte *)buffer, 80);

    tmp = strchr(buffer, '\n');
    if (tmp == 0)
      {
      strcpy(buffer, NORESPONSE);
      strcat(buffer, PT5201CommPort->GetCommPort());
      strcat(buffer, ".");
      Application->MessageBox(buffer, "Connect to Generator", MB_OK|MB_ICONINFORMATION);
      PT5201CommPort->CloseCommPort();
      delete [] buffer;
      Timer1->Enabled   = true;
      return(false);
      }
    *tmp = 0;
    MasterVersion = buffer;

    PT5201CommPort->FlushCommPort();
    PT5201CommPort->WriteString("FACT:GENL:VERS?\r\n");

    PT5201CommPort->ReadBytes((Byte *)buffer, 80);
    tmp = strchr(buffer, '\n');
    if (tmp == 0)
      {
      strcpy(buffer, NORESPONSE);
      strcat(buffer, PT5201CommPort->GetCommPort());
      strcat(buffer, ".");
      Application->MessageBox(buffer, "Connect to Generator", MB_OK|MB_ICONINFORMATION);
      PT5201CommPort->CloseCommPort();
      delete [] buffer;
      Timer1->Enabled   = true;
      return(false);
      }
    delete [] buffer;
    }
  else
    {
    KUNumberEdit->Text   = "KUDEMO";
    SWRevisionEdit->Text = "00.0";

    MasterVersion        = "000";
    GenlockVersion       = "000";
    BBVersion            = "000";

    TestModeConnected = true;
    Timer1->Enabled   = true;
    }
  return(true);
  }
//---------------------------------------------------------------------------
void __fastcall TPT5201Form::Image1DblClick(TObject *Sender)
  {
  if (InternalPanel->Visible)
    InternalPanel->Visible = false;
  else
    InternalPanel->Visible = true;
  }
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
