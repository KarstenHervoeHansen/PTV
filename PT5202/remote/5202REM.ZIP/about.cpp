//--------=-------------------------------------------------------------
#include <vcl\vcl.h>
#include <stdio.h>
#include <printers.hpp>
#include <shellapi.h>

#pragma hdrstop

#include "about.h"
#include "names.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TAboutBox *AboutBox;

const TCursor crMyCustomCursor = 1;    // ID for custom cursor

//---------------------------------------------------------------------
__fastcall TAboutBox::TAboutBox(TComponent* AOwner)
	: TForm(AOwner)
{
	Screen->Cursors[crMyCustomCursor] = LoadCursor((void*)HInstance, "handpnt");
}
//---------------------------------------------------------------------------
void __fastcall TAboutBox::FormShow(TObject *Sender)
  {
	TMemoryStatus MS;
	OSVERSIONINFO info;
	long tmp = 0xFFFFFFFF;

// Version control below.  We have two versions: LT428 and PT5201, which have 
// different About forms.
// Definitions in names.h

#ifdef LEADER
  Image1->Visible      = true;
  Image2->Visible      = false;
  ProductName->Caption = PRODNAME;
  Version->Caption     = VERSION;
  WebLabel->Caption    = WEBSITE;
  emailLabel->Caption  = MAIL;
  AboutBox->Caption    = ABOUT;
#else
  Image1->Visible      = false;
  Image2->Visible      = true;
  ProductName->Caption = PRODNAME;
  Version->Caption     = VERSION;
  WebLabel->Caption    = WEBSITE;
  emailLabel->Caption  = MAIL;
  AboutBox->Caption    = ABOUT;
#endif

	info.dwOSVersionInfoSize = sizeof( OSVERSIONINFO);
	GetVersionEx( &info);

	AboutMemo->Lines->Clear();
 	AboutMemo->Lines->Add( "System:");

	if ( info.dwMajorVersion < 4)
  		AboutMemo->Lines->Add( "    Microsoft NT 3.X");
	else
		switch ( info.dwPlatformId)
    	{
			case VER_PLATFORM_WIN32s:
		  		AboutMemo->Lines->Add( "    Microsoft Win32s");
        		break;

			case VER_PLATFORM_WIN32_WINDOWS:
				if (( info.dwMajorVersion > 4) || (( info.dwMajorVersion == 4) && (info.dwMinorVersion > 0)))
			 	 	AboutMemo->Lines->Add( "    Microsoft Windows 98");
				else
				  	AboutMemo->Lines->Add( "    Microsoft Windows 95");

				tmp = 0x0000FFFF;
     			break;

			case VER_PLATFORM_WIN32_NT:
		 		AboutMemo->Lines->Add( "    Microsoft Windows NT");
     			break;
	    }

	AboutMemo->Lines->Add( "    " + IntToStr( info.dwMajorVersion) + "." +\
  											  IntToStr( info.dwMinorVersion) + "." +\
											  IntToStr( info.dwBuildNumber & tmp));
	AboutMemo->Lines->Add("");

	MS.dwLength = sizeof( MS);
	GlobalMemoryStatus( &MS);

	LPSTR lpMemLoad = new char[5];
	sprintf( lpMemLoad, "%d %%", MS.dwMemoryLoad);

 	AboutMemo->Lines->Add( "Memory:");
 	AboutMemo->Lines->Add( "    Physical memory :  " + FormatFloat(( AnsiString)"#,###' KB'", MS.dwTotalPhys/1024));
 	AboutMemo->Lines->Add( "    Memory in use    :  " + ( AnsiString) lpMemLoad);

	delete [] lpMemLoad;
}
//---------------------------------------------------------------------------
void __fastcall TAboutBox::FormCloseQuery(TObject *Sender, bool &CanClose)
{
	Close();
}
//---------------------------------------------------------------------
void __fastcall TAboutBox::WebLabelClick(TObject *Sender)
{
	ShellExecute( NULL, "open", WEBSITE, NULL, NULL, SW_RESTORE);

	WebLabel->Font->Color = clRed;
}
//---------------------------------------------------------------------------
void __fastcall TAboutBox::emailLabelClick(TObject *Sender)
{
	ShellExecute( NULL, "open", MAIL, NULL, NULL, SW_RESTORE);

	emailLabel->Font->Color = clRed;
}
//---------------------------------------------------------------------------
