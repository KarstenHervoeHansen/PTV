
#ifdef LEADER

#define INIFILE     "LT428.ini"
#define WEBSITE     "http://www.leader.co.jp"
#define MAIL        "mailto:sales@leader.co.jp"
#define SAVECHANGES "Save changes to LT428 PC Remote Control?"
#define NOOPEN      "The LT428.ini file could not be opened. Default settings will be used."
#define NOCONNECT   "No connection to the LT428 unit. Please connect and try again."
#define NORESPONSE  "No response from the LT428"
#define VERSION     "Version 1.0D"
#define ABOUT       "About LT428 PC Remote Control"
#define PRODNAME    "LT428 PC Remote Control"
#define HLPFILE     .\\lt428.hlp
#define MODEL       "COMPONENT DIGITAL SYNC GENERATOR"
#define RIGHTTOP    "LT428"
#define RESPONSE    "LT428 COMPONENT DIGITAL SYNC GENERATOR Response"
#define PTVWEB      "LEADER on the &Web"
#define PTVHOME     "LEADER Home Page"
#define MNAME       "LT428 PC Remote Control"
#define SDINAME     "SDI"
#define CCBIC       "&SDI"
#define ESDIS       "Edit SDI Settings"
#define EDIS        "SDI Settings"

#else

#define INIFILE     "PT5202.ini"
#define WEBSITE     "http://www.dk-audio.com"
#define MAIL        "mailto:info@dk-audio.com"
#define SAVECHANGES "Save changes to PT5202 PC Remote Control?"
#define NOOPEN      "The PT5202.ini file could not be opened. Default settings will be used."
#define NOCONNECT   "No connection to the PT5202 unit. Please connect and try again."
#define NORESPONSE  "No response from the PT5202"
#define VERSION     "Version 2.0"
#define ABOUT       "About PT5202 PC Remote Control"
#define PRODNAME    "PT5202 PC Remote Control"
#define HLPFILE     .\\PT5202.hlp
#define MODEL       "PT5202 Compact VariTime Sync Generator"
#define RIGHTTOP    "DK-Audio"
#define RESPONSE    "PT5202 Compact VariTime Sync Generator Response"
#define PTVWEB      "PTV on the &Web"
#define PTVHOME     "PTV Home Page"
#define MNAME       "PT5202 PC Remote Control"
#define SDINAME     "SDI+Video"
#define CCBIC       "&SDI+Video"
#define ESDIS       "Edit SDI Settings"
#define EDIS        "SDI Settings"
#endif


