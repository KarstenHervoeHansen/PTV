// 31.05.2001 modified for JNTS: JK
// 13.12.2002 error of sending Genlock Timing when clicking OK on TSG pannel
//            corrected.
//--------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <registry.hpp>
#pragma hdrstop

#include <string.h>
#include "mainform.h"
#include "proper.h"
#include "tsg.h"
#include "util.h"
#include "pt52class.h"
#include "names.h"
//---------------------------------------------------------------------------
#pragma resource "*.dfm"

extern Boolean timeout2;

int ValidPattern(int system, int pattern);      // Return validation information
int PatternToIndex(int system, int pattern);    // Return an index
int IndexToPattern(int system, int index);      // Return a pattern

TTSGForm *TSGForm;

static char do_not_adjust_tb;

//---------------------------------------------------------------------------
__fastcall TTSGForm::TTSGForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FormCreate(TObject *Sender)
{
  const char* *ptr;

  // Prepare TV system choices
  SystemComboBox->Items->Clear();

//  ptr = SystemTxt;
//  while (*ptr)
//    SystemComboBox->Items->Add(*ptr++);
  SystemComboBox->Items->Add(PALTxt);
  SystemComboBox->Items->Add(NTSCTxt);
  SystemComboBox->Items->Add(JNTSTxt);     // JK change

  // Prepare Embedded Audio choices
  EmbAudioComboBox->Items->Clear();

  ptr = EmbAudioToneTxt;
  while (*ptr)
    EmbAudioComboBox->Items->Add(*ptr++);

  // Prepare TextCombo choices
  TextComboBox->Items->Clear();
  ptr = OffOnCmdTxt;
  while (*ptr)
    TextComboBox->Items->Add(*ptr++);

  // Prepare MovementCombo choices
  MovementComboBox->Items->Clear();
  ptr = OffOnCmdTxt;
  while (*ptr)
    MovementComboBox->Items->Add(*ptr++);

}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FormShow(TObject *Sender)
{
  const char* *ptr;

  RestoreWindowPosition(TSGForm, "TSGWindow");

  // Setup pointer to actual settings
  TSGSetup = PT5201Setup->GetTSGSettings();

  TSGCancel = new TTSGenerator;


  TSGForm->Caption                = ESDIS;
  AnalogSettingsTabSheet->Caption = EDIS;


  // Copy original settings temporarily to TSGCancel
  *TSGCancel = *TSGSetup;
/*
  // Setup TV system selection, (ONLY PAL & NTSC I TSG)
  SystemComboBox->ItemIndex = !(TSGSetup->System == PAL);
*/
// JK change

// SystemComboBox->ItemIndex = TSGSetup->System;

 switch (TSGSetup->System)
   {
   case PAL:
     SystemComboBox->ItemIndex = 0;
     break;
   case NTSC:
     SystemComboBox->ItemIndex = 1;
     break;
   case JNTS:
     SystemComboBox->ItemIndex = 2;
     break;
   default:
     SystemComboBox->ItemIndex = 0;
     break;
   }

  // Setup ScHPhase selection
  ScHPhaseEdit->Text = IntToStr(TSGSetup->ScHPhase);

  // Setup Embedded Audio selection
  EmbAudioComboBox->ItemIndex = TSGSetup->EmbAudio;

  // Setup Text selection
  TextComboBox->ItemIndex = TSGSetup->TextEnable;

  // Setup TextMovement selection
  MovementComboBox->ItemIndex = TSGSetup->TextMovement;

  // Setup Text selection
  TextEdit->Text = TSGSetup->Text;

  // Prepare pattern choices, (this one is system dependant)
  ptr = TSGPatternTxt;
  PatternComboBox->Items->Clear();
             //FormShow
  int i = SMPTECBar;
  while (*ptr)
    {
    if (ValidPattern(TSGSetup->System, i++))
      PatternComboBox->Items->Add(*ptr);
    ptr++;
    }

  PatternComboBox->ItemIndex = PatternToIndex(TSGSetup->System, TSGSetup->Pattern);

  // Display timing selection
  SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  // Setup TrackBar markings and resolution
  TrackBarSetup(TSGSetup->System, OffsetTrackBar, MinLabel, MaxLabel);


  LockForm(PropertiesForm->ConfigureLockItem->Checked);

                    // It is not possible to focus an invisible or disabled
                    //  window, hence the statement below.
  if (!PropertiesForm->ConfigureLockItem->Checked)
  {
#if 0
    if (AnalogSettingsTabSheet->Visible)
      ActiveControl = SystemComboBox;
    else
      ActiveControl = EmbAudioComboBox; // here exception error: JK
#endif
    if (AnalogSettingsTabSheet->Visible)
      ActiveControl =  SystemComboBox;
    else
      ActiveControl = ScHPhaseEdit; // we simply invert this
  }
                    // Edit tags are used during validation of an entry to
                    //  separate which edit field is used.
  FieldEdit->Tag  = 0;
  LineEdit->Tag   = 0;
  OffsetEdit->Tag = 0;

  ModelessResult = mrNone;
  do_not_adjust_tb = 0;
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  delete TSGCancel;

  SaveWindowPosition(TSGForm, "TSGWindow");

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FormCloseQuery(TObject *Sender, bool &CanClose)
{
  if ((ModelessResult != mrOk) && !PT5201Setup->VerifyTSGSettings(TSGCancel))
  {
      PT5201Setup->SetTSGSettings(TSGCancel);
      UpdateOutput(TSGCancel);
  }
  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
// 13.12.2002: Error found here.  When clicking OK button in TSG form,
//             Genlock Delay was transmitted.  Fail lies in the line at
//             the end of this function:
//             TrxGenlockDelay(FieldEdit->Text.ToInt(),......)
//             should be:
//             TrxTSGDelay(FieldEdit->Text.ToInt(),......)

void __fastcall TTSGForm::OKButtonClick(TObject *Sender)
  {
  if (ScHPhaseEdit->Focused())
    if (!ValidateScHPhase(TSGForm, ScHPhaseEdit, &TSGSetup->ScHPhase))
      return;

  if (FieldEdit->Focused())
    FieldEdit->Tag = true;
  else
    if (LineEdit->Focused())
      LineEdit->Tag = true;
    else
      if (OffsetEdit->Focused())
        OffsetEdit->Tag = true;

  //if (FieldEdit->Tag || LineEdit->Tag || OffsetEdit->Tag)
    if (!ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                          FieldEdit, LineEdit, OffsetEdit))
      return;
#if 1
  // Clicking OK button now reads all edit fields regardless of whether
  // RETURN was pressed after edititng or not ) :JK 21.11.01
  FieldEdit->Tag = true;
  LineEdit->Tag = true;
  OffsetEdit->Tag = true;

  if (!ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit))
    return;

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;


  //TrxGenlockDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());
  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());
  PT5201Form->SystemStatusUpdate(TSGField);
// *********
#endif
  ModelessResult = mrOk;
  Close();
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::CancelButtonClick(TObject *Sender)
{
  ModelessResult = mrCancel;

  Close();
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::SystemComboBoxChange(TObject *Sender)
{
  const char* *ptr;
  int OldSystem, System;
  
 if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
   {
   return;
   }

/*
  if ((OldSystem = SystemComboBox->ItemIndex) == 1)
    System = NTSC;
  else
    System = PAL;
*/
//JK change
switch (SystemComboBox->ItemIndex)
  {
  case 0: // PAL is choosen
    System = OldSystem = PAL;
    break;
  case 1: //NTSC is choosen
    System = OldSystem = NTSC;
    break;
  case 2: //JNTS is choosen
    System = OldSystem = JNTS;
    break;
  }

//System = OldSystem = SystemComboBox->ItemIndex;

  if (ValidatePALToNTSC(System, &TSGSetup->Samples, \
                                  OffsetTrackBar))
  {
    TSGSetup->System = System;

    if (!ValidPattern(TSGSetup->System, TSGSetup->Pattern))
    {
      //if (TSGSetup->System < NTSC) 
      if ((TSGSetup->System)< NTSC)
        TSGSetup->Pattern = EBUCBar;
       else
       {
        if (TSGSetup->Pattern == CCIR18)
          TSGSetup->Pattern = Multiburst;
        else
          TSGSetup->Pattern = SMPTECBar;
       }
     }

    // Prepare pattern choices
    ptr = TSGPatternTxt;
    PatternComboBox->Items->Clear();

    int i = SMPTECBar;
    while (*ptr)
     {
      if (ValidPattern(TSGSetup->System, i++))
        PatternComboBox->Items->Add(*ptr);
      ptr++;
     }
        //SystemComboBoxChange
    PatternComboBox->ItemIndex = PatternToIndex(TSGSetup->System, TSGSetup->Pattern);

    TrackBarSetup(TSGSetup->System, OffsetTrackBar, MinLabel, MaxLabel);

    SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

    TrxTSGSystem(TSGSetup->System);

    TrxTSGPattern(TSGSetup->Pattern);  // Really not necessary! Illegal patterns
                                       //  will be altered in the PT5201.
  }
  else
    SystemComboBox->ItemIndex = OldSystem;

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::ScHPhaseUpDownClick(TObject *Sender,
  TUDBtnType Button)
{
  ActiveControl = ScHPhaseEdit;

  ScHPhaseAdjust(&TSGSetup->ScHPhase, ScHPhaseEdit, Button);

  TrxTSGScHPhase(TSGSetup->ScHPhase);

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::ScHPhaseEditExit(TObject *Sender)
{
  if (ValidateScHPhase(TSGForm, ScHPhaseEdit, &TSGSetup->ScHPhase))
    TrxTSGScHPhase(TSGSetup->ScHPhase);

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FieldUpDownClick(TObject *Sender, TUDBtnType Button)
{
  ActiveControl = FieldEdit;

  TimingAdjust(TSGSetup->System, &TSGSetup->Samples, TSGType, FieldEdit, Button);

  SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  FieldEdit->SelectAll();

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
#if 0
void __fastcall TTSGForm::FieldUpDownChanging(TObject *Sender,
bool &AllowChange)
{
  FieldUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
void __fastcall TTSGForm::FieldEditExit(TObject *Sender)
{
  return; // JK 15.08.01

  FieldEdit->Tag = true;

  ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::LineUpDownClick(TObject *Sender, TUDBtnType Button)
{
  ActiveControl = LineEdit;

   TimingAdjust(TSGSetup->System, &TSGSetup->Samples, TSGType,  LineEdit, Button);

  SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  LineEdit->SelectAll();

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
#if 0
void __fastcall TTSGForm::LineUpDownChanging(TObject *Sender,
  bool &AllowChange)
{
  LineUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
void __fastcall TTSGForm::LineEditExit(TObject *Sender)
{
  return; // JK 15.08.01

  LineEdit->Tag = true;

  ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::OffsetUpDownClick(TObject *Sender, TUDBtnType Button)
{
  ActiveControl = OffsetEdit;

   TimingAdjust(TSGSetup->System, &TSGSetup->Samples, TSGType,  OffsetEdit, Button);

  SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  OffsetEdit->SelectAll();

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
}
//---------------------------------------------------------------------------
#if 0
void __fastcall TTSGForm::OffsetUpDownChanging(TObject *Sender,
  bool &AllowChange)
{
  OffsetUpDown->Position = 0;
}
#endif

//---------------------------------------------------------------------------
void __fastcall TTSGForm::OffsetEditExit(TObject *Sender)
{
  return; // JK 15.08.01
#if 0
  OffsetEdit->Tag = true;

  ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit);

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
#endif
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::OffsetTrackBarChange(TObject *Sender)
  {
//  This function is entered when user changes slider position and ALSO when 
//  TrackBar->Position is changed programatically, like TrackBar->Position = tmp;
//  Unfortunately, TrackBarAdjust() will modify BlackSetup->Samples.  
//  If we change TrackBar->Position programatically, we do NOT want to modify
//  BlackSetup->Samples, because only field and line values are modified, offset is
//  always set to zero by TrackBarAdjust().
//  We introduce a global variable to notify that TrackBar->Position was changed
//  programatically, in which case we just return from this function.

  if (do_not_adjust_tb)
    return;

   if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
   {
   return;
   }

   TrackBarAdjust(TSGSetup->System, &TSGSetup->Samples, OffsetTrackBar);
  SamplesToFLO(TSGSetup->System, TSGSetup->Samples, FieldEdit, LineEdit, OffsetEdit);

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::PatternComboBoxChange(TObject *Sender)
  {
   if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
     {
     return;
     }

  TSGSetup->Pattern = IndexToPattern(TSGSetup->System, PatternComboBox->ItemIndex);

  TrxTSGPattern(TSGSetup->Pattern);

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::EmbAudioComboBoxChange(TObject *Sender)
  {
   if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
     {
     return;
     }
  
  TSGSetup->EmbAudio = EmbAudioComboBox->ItemIndex;

  TrxTSGEmbAudioSignal(TSGSetup->EmbAudio);

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::LockForm(bool Lock)
  {
  bool enable = !Lock;

  SystemComboBox->Enabled   = enable;
  PatternComboBox->Enabled  = enable;
  FieldUpDown->Enabled      = enable;
  FieldEdit->Enabled        = enable;
  LineUpDown->Enabled       = enable;
  LineEdit->Enabled         = enable;
  OffsetUpDown->Enabled     = enable;
  OffsetEdit->Enabled       = enable;
  OffsetTrackBar->Enabled   = enable;
  ScHPhaseUpDown->Enabled   = enable;
  ScHPhaseEdit->Enabled     = enable;
  EmbAudioComboBox->Enabled = enable;
  TextComboBox->Enabled     = enable;
  MovementComboBox->Enabled = enable;

  CancelButton->Enabled     = enable;

  if (TSGForm->Visible)
    TSGForm->Refresh();
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::UpdateOutput(TTSGenerator *setup)
  {
  char buffer[60];
  TrxRequest("SYST:ERR?\r\n", 30, (Byte *)buffer);

  TrxTSGSystem(setup->System);
  TrxTSGPattern(setup->Pattern);

  SamplesToFLO(setup->System, setup->Samples, Field1Edit, Line1Edit, Offset1Edit);

  TrxTSGDelay(Field1Edit->Text.ToInt(), Line1Edit->Text.ToInt(), Offset1Edit->Text.ToDouble());
  TrxTSGScHPhase(setup->ScHPhase);
  TrxTSGEmbAudioSignal(setup->EmbAudio);

  TrxTSGTextONOFFSignal(setup->TextEnable);
  TrxTSGTextMOvementSignal(setup->TextMovement);
  TrxTSGTextSignal(setup->Text);
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
int ValidPattern(int system, int pattern)
  {
  switch (pattern)
    {
    case SMPTECBar:
    case FCCCBar:
    case CBar75ITU:  // JK addition
      if (system < NTSC)
          return(0);
      break;

    case Multiburst: // At present Multiburst is not valid at all
       return(0);

    case EBUCBar:
    case CBarRed75:
    case CCIR18:
    case EBUCBarITU: // JK addition
      if (system >= NTSC)
         return(0);
       break;

    case CBarGrey75:
       return(0);
    }
  return(-1);
  }
//---------------------------------------------------------------------------
int PatternToIndex(int system, int pattern)
  {
  if (system < NTSC)
     {
    switch (pattern)
       {
      case SMPTECBar:
      case EBUCBar:
      case FCCCBar:
      case Multiburst:
     case CBar75ITU:  // JK addition
         return(0);

      case EBUCBarITU:
         return(pattern-2);    // JK change: new case for CBar100

      case CBar100:
       return (pattern-3);  // JK change: new case for CBar100


      case CBarRed75:
      case Red75:
         //return(pattern-3);
         return(pattern-4);    // JK change

      default:
         //return(pattern-4);
         return(pattern-5);   // JK change
       }
    }
  else
    {    // NTSC
    switch (pattern)
      {
      case SMPTECBar:    // ?? JK question
      case EBUCBar:
      case CBarGrey75:
      case CBarRed75:
      case CCIR18:
      case Multiburst:
     case EBUCBarITU:  // JK addition
         return(0);

      case FCCCBar:
         return (pattern-1);
      //case EBUCBarITU:
     case CBar75ITU:
      case CBar100:
         //return(pattern-1);
         return(pattern-2);  // JK change

      case Red75:
         //return(pattern-3);
         return(pattern-4);  // JK change

      default:
        //return(pattern-5);
        return(pattern-6);  // JK change
       }
     }
  }
//---------------- JK version  -------------------------------------
int IndexToPattern(int system, int index)
  {
  if (system < NTSC)
     {
    switch (index)
     {
      case 0:
        return(index + 1);
      case 1:
       return (index + 2);
      case 2:
         return (index + 3);
      case 3:
      case 4:
         return(index + 4);
      default:
         return(index + 5);
     }
    }
  else
    {
    switch (index)
      {
      case 0:
        return(index);

      case 1:
       return (index + 1);
      case 2:
      case 3:
        return(index + 2);

      case 4:
          return(index + 4);

      default:
          return(index + 6);
      }
    }
  }

#if 0
int IndexToPattern(int system, int index)
  {
  if (system < NTSC)
     {
    switch (index)
      {
      case 0:
         return(index + 1);

      case 1:
      case 2:
         return(index + 2);

      case 3:
      case 4:
         return(index + 3);

      default:
         return(index + 4);
      }
    }
  else
    {
    switch (index)
      {
      case 0:
        return(index);

      case 1:
      case 2:
      case 3:
        return(index + 1);

      case 4:
          return(index + 3);

      default:
          return(index + 5);
      }
    }
  }
#endif
  //---------------------------------------------------------------------------
/*
  Index to PAL pattern:         Index to NTSC pattern:
  -,  //  0 SMPTECBar        0,  //  0 SMPTECBar
  0,   //  1 EBUCBar         -,   //  1 EBUCBar
  -,  //  2 FCCCBar          1,  //  2 FCCCBar
  1,   //  3 EBUCBarITU      2,   //  3 EBUCBarITU
  2,   //  4 CBar100          3,   //  4 CBar100
  -,   //  5 CBarGrey75      -,   //  5 CBarGrey75
  3,   //  6 CBarRed75        -,   //  6 CBarRed75
  4,   //  7 Red75            4,   //  7 Red75
  -,   //  8 Multiburst      -,   //  8 Multiburst
  5,   //  9 CCIR18          -,   //  9 CCIR18
  6,   // 10 Window10        5,   // 10 Window10
  7,   // 11 Window15        6,   // 11 Window15
  8,   // 12 Window20        7,   // 12 Window20
   9,  // 13 Window100       8,   // 13 Window100
   10, // 14 BlWh15kHz       9,  // 14 BlWh15kHz
  11, // 15 White100        10, // 15 White100
  12, // 16 BlackBurst      11, // 16 BlackBurst
   13, // 17 CheckField       12, // 17 CheckField
   14, // 18 DigitalGrey     13, // 18 DigitalGrey
   15, // 19 Stair5           14, // 19 Stair5
  16,  // 20 Stair10          15,  // 20 Stair10
  17, // 21 Crosshatch      16, // 21 Crosshatch
  18   // 22 PLUGE            17   // 22 PLUGE
*/
//---------------------------------------------------------------------------
void __fastcall TTSGForm::HelpButtonClick(TObject *Sender)
{
  Application->HelpContext(IDH_EDITTSG);
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::OffsetEditKeyUp(TObject *Sender, WORD &Key,
 TShiftState Shift)
{
  if (Key != 13)
    return;
  OffsetEdit->Tag = true;

  if (!ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit))
    return;                  

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);

return; 
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::LineEditKeyUp(TObject *Sender, WORD &Key,
 TShiftState Shift)
{
  if (Key != 13)
    return;

  LineEdit->Tag = true;

  if (!ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit))
    return;                  

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);

return; 
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::FieldEditKeyUp(TObject *Sender, WORD &Key,
 TShiftState Shift)
{
  if (Key != 13)
    return;

  FieldEdit->Tag = true;

  if (!ValidateEntry(TSGForm, TSGSetup->System, &TSGSetup->Samples, \
                  FieldEdit, LineEdit, OffsetEdit))
    return;                  

  do_not_adjust_tb = 1;
  TrackBarUpdate(TSGSetup->System, TSGSetup->Samples, OffsetTrackBar);
  do_not_adjust_tb = 0;

  TrxTSGDelay(FieldEdit->Text.ToInt(), LineEdit->Text.ToInt(), OffsetEdit->Text.ToDouble());

  PT5201Form->SystemStatusUpdate(TSGField);

return; 
}
//---------------------------------------------------------------------------
void __fastcall TTSGForm::ScHPhaseEditKeyUp(TObject *Sender, WORD &Key,
 TShiftState Shift)
  {
  if (ValidateScHPhase(TSGForm, ScHPhaseEdit, &TSGSetup->ScHPhase))
    TrxTSGScHPhase(TSGSetup->ScHPhase);

  PT5201Form->SystemStatusUpdate(TSGField);

  return; 
  }
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
void __fastcall TTSGForm::TextEditEnter(TObject *Sender)
  {
  int Size;
  char * tmp;
  char jkbuffer[20];

  Size = TextEdit->GetTextLen();  //Get length of string in TextEdit

	char *name   = new char[++Size];      //Allocate space for the string
  char *buffer = new char[80];

	TextEdit->GetTextBuf(name, Size);   //Puts TextEdit->Text into name
  strcpy(buffer, name);

#if 0
  // we must enclose string in quotes (')
  strcpy(buffer, "\'");
  strcat(buffer, jkbuffer);
  strcat(buffer, "\'");
#endif

  TrxTSGTextSignal(buffer);  // this encloses string in quotas...
  TrxRequest("SYST:ERR?\r\n", 60, (Byte *)buffer);
  tmp = strstr(buffer, "No error");
  if (tmp != NULL) // if does  occur....
    {
    strcpy(TSGSetup->Text, name);  // This should not be here, because of CANCEL action !!!
    PT5201Form->SystemStatusUpdate(TSGField);
    }

	delete name;
  delete buffer;

  return;  
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::TextComboBoxChange(TObject *Sender)
  {
  if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
    {
    return;
    }
  
  TSGSetup->TextEnable = TextComboBox->ItemIndex;

  TrxTSGTextONOFFSignal(TSGSetup->TextEnable);

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
  return;  
  }
//---------------------------------------------------------------------------
void __fastcall TTSGForm::MovementComboBoxChange(TObject *Sender)
  {
  if (timeout2 == false) // if not 100 mS elapsed since last transmission, return
    {
    return;
    }
  
  TSGSetup->TextMovement = MovementComboBox->ItemIndex;

  TrxTSGTextMOvementSignal(TSGSetup->TextMovement);

  PT5201Form->SystemStatusUpdate(TSGField);
  timeout2 = false;
  return;  
  }
//---------------------------------------------------------------------------
