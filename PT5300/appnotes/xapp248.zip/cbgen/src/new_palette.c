//-----------------------------------------------------------------
// new_palette.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called when a new PALETTE definition begins. It
// increments the current_palette pointer to the next empty PALETTE
// struct in the array. If the maximum number of palettes allowed is
// exceeded, an error message is printed.
//
// The palette name string supplied by the name argument is copied to
// a buffer and the PALETTE's name pointer is set to point to that
// buffer. The number of colors in the new palette is set to zero.
//

#include "defs.h"

void new_palette(
	char *name
)
{
	//
	// If the current_palette is NULL, then we are defining the first
	// palette, so set current_palette to the address of the first
	// PALETTE struct in the array. If current_palette is not NULL,
	// then increment it to point to the next PALETTE in the array.
	//
	if (current_palette == NULL)
		current_palette = palt;
	else
		current_palette++;

	//
	// If we have exceeded the maximum number of palettes allowed, then
	// print an error message and exit.
	//
	if (current_palette >= palt + MAX_PALETTES)
	{
		do_error("Attempt to define too many color palettes.");
		exit(1);
	}

	//
	// Copy the palette name to a permanent buffer and set the name pointer
	// in the PALETTE struct to point to that buffer.
	//
	current_palette->name = strsave(name);

	//
	// Set the number of colors defined in this new palette to zero.
	//
	current_palette->num_colors = 0;
}
