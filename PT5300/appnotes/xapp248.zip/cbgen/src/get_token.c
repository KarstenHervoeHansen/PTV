//-----------------------------------------------------------------
// get_token.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function will return the code value associated with the next
// token found in the input buffer. All tokens are white space delimited.
// The function first calls find_token() to search for the next non-whitespace
// character. If the end of the buffer is found first, TKN_NONE is returned.
// Otherwise, the whitespace delimited token is copied from the input buffer
// to a temporary buffer and then check_token() is called to compare the
// token against all known reserved words. If a match is found, the token
// value is returned. If no match is found, TKN_NOT_A_KEYWORD is returned.
//
// The argument to this function is passed on to find_token() which, in turn,
// passes it to get_next_char(). Refer to get_next_char() for a description
// of the argument.
//

#include "defs.h"

int get_token(
	char *s						// argument to pass to get_next_char()
)
{
	char *t, *c;				// temporary char pointers
	char x;						// used to store the current character
	static char *tmp = NULL;	// buffer used to store copy of token
	int tkn;					// the tkn code to be returned

	//
	// If tmp is NULL, then allocate the static temporary buffer space for
	// the token string. This storage is only allocated the first time this
	// function is called.
	//
	if (tmp == NULL)
		tmp = xmalloc((ULONG) INPUT_BUF_SIZE);

	//
	// Call find_token() to find the next non whitespace character in buffer.
	// If it returns NULL, then return TKN_NONE. Otherwise, copy all the chars
	// of the token into the tmp buffer then call check_token() to compare the
	// token string against all known keywords. Return the token code returned
	// by check_token() if the string matches a reserved word. Otherwise, reset
	// the get_next_char() static pointer to the first non-whitespace character
	// of the string and return TKN_NOT_A_KEYWORD.
	//
	
	if ((t = find_token(s)) == NULL)
		tkn = TKN_NONE;
	else
	{
		c = tmp;
		*c++ = *get_next_char(t);

		do
			*c++ = x = *get_next_char(NULL);
		while (x != '\t' && x != ' ' && x != '\000' && x != '\n' && x != '/' && x != '*');

		*(c - 1) = '\000';

		if ((tkn = check_token(tmp)) == TKN_NOT_A_KEYWORD)
			get_next_char(t);
	}

	return tkn;
}
		