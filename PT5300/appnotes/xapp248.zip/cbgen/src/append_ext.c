//-----------------------------------------------------------------
// append_ext.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

// This file function scans a filename string to determine if it already
// contains an extension. If so, the filename is returned unchanged. If
// not, the extension string supplied in the ext parameter is appended
// to the filename.

#include "defs.h"

char *append_ext(
	char *filename,			// file name string 
	char *ext)				// extension to append to filename
{
	char *p;				// temporary char pointer

	// Search for a period in filename, indicating the presence of
	// and extension. If not found, then allocate memory large
	// enough to hold the new filename with extension and concatenate
	// the filename string and extension string.

	if (strchr(filename, '.') == NULL)
	{
		p = xmalloc((unsigned) (strlen(filename) + strlen(ext)));
		strcpy(p, filename);
		strcat(p, ext);
		return(p);
	}
	else
		return(filename);
}
