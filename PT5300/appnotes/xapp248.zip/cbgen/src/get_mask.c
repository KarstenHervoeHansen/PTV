//-----------------------------------------------------------------
// get_mask.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function will return a mask with the number of LS bits specified
// by the bits argument set to ones.
//

#include "defs.h"

ULONG get_mask(
	ULONG bits				// specifies the number of one bits
)
{
	ULONG i;				// for loop variable
	ULONG x = 1;			// mask is created in this variable

	//
	// If the bits argument is greated than 32, return a 32-bit value with
	// all the bits set.
	//
	if (bits > 32)
		return 0xffffffff;

	//
	// Otherwise, generate the mask by shifting x left one bit and setting the
	// LSB in this for loop.
	//
	for (i=1; i<bits; i++)
		x = (x << 1) | 1;

	//
	// Return the generated mask.
	//
	return x;
}
