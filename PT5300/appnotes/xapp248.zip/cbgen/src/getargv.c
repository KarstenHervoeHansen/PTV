//-----------------------------------------------------------------
// getargv.c
//
//
// This function is from UNIX Tool Building by Kenneth Ingham. The
// code may be freely copied , as long as it is not sold for profit
// and the copyright and author notices remain intact.
//
// Kenneth Ingham
// Copyright (c) 1988 The University of New Mexico
//

//
// This function is called by the routine that parses the command line arguments.
// It sets the pointer that is pointed at by the "what" argument to a string
// containing the next valid argument on the command line. If no other argument is
// found, then it complains and the program is terminated.
//
// This function is called after the command line parser encounters a "-" flag
// character. The function is written so as to correctly find the argument string
// associated with that "-" flag whether there were white space characters between
// the "-" flag and the argument or not.
//
// This function returns an index into the argv[] array matching the array element
// containing the argument string.
//

#include "defs.h"

int getargv(
	char **what, 
	char *argv[], 
	int i, 
	char *err
)
{
	if (argv[i][2])							// If no separating whitespace, then copy
		*what = strsave(&argv[i][2]);		// the argument and point to it.
	else
	{
		if (argv[++i])						// Otherwise, see if the next argv[] element
			*what = strsave(argv[i]);		// is valid and copy and return a pointer to it.
		else
		{
			printf("Missing %s!\n", err);	// No argument, complain and exit.
			exit(1);
		}
	}

	return i;
}
