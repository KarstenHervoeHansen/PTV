//-----------------------------------------------------------------
// make_filename.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function generates a complete output filename with an HDL language
// specific extension and returns a pointer to the filename string.
//
// The base for the output filename will be either the user supplied base
// name as specified by the user argument or the default base name as
// specified by the dflt argument if user is NULL. The string pointed to
// by the type argument is appended to the base filename and then a HDL
// language specific file extension is appended to complete the file name.
// Type string usually specifies whether the output file is for simulation
// or synthesis.
// 

#include "defs.h"

char *make_filename(
	const char *user,		// user supplied base filename
	const char *dflt,		// default base filename
	const char *type		// type string pointer
)
{
	char *f;				// pointer to filename storage

	//
	// Allocate storage for the file name string.
	//
	f = xmalloc(MAX_NAME);

	//
	// Determine whether to use the user supplied base name or the
	// default base name and copy the chosen string to the filename
	// buffer.
	//
	if (user == NULL)
		strcpy(f, dflt);
	else
		strcpy(f, user);

	//
	// Append the type string.
	//
	strcat(f, type);

	//
	// Append the HDL language specific file extension.
	//
	if (language == VERILOG)
		strcat(f, ".v");
	else if (language == VHDL)
		strcat(f, ".vhd");
	else if (language == XDL)
		strcat(f, ".xdl");

	//
	// Return a pointer to the file name buffer.
	//
	return(f);
}
