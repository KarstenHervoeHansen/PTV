//-----------------------------------------------------------------
// find_palette.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function searches the list of palettes to find the one
// that matches the supplied palette name. It returns a pointer
// to the matching PALETTE struct or NULL if no match is found.
//

#include "defs.h"

PALETTE *find_palette(
	char *name				// Palette name to match
)
{
	PALETTE *p;				// Temp PALETTE pointer

	//
	// Compare the palette name to the names of each of the
	// defined palettes.
	//
	for (p = palt; p < palt + palettes; p++)
		if (p != NULL && strcmp(name, p->name) == 0)
			return p;

	//
	// If no match is found, return NULL.
	//
	return NULL;
}

