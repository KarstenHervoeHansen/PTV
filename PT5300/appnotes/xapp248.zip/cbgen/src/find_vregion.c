//-----------------------------------------------------------------
// find_vregion.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function searches for a vertical region that contains the specified
// vertical line. It returns a pointer to the matching V_REGION struct or
// NULL if no match is found.
//

#include "defs.h"

V_REGION *find_vregion(
	int vcount				// Vertical line value to search for
)
{
	V_REGION *p, *t;		// Temp pointers

	//
	// Init the pointers
	//
	p = v_regions;
	t = NULL;

	//
	// Scan through the list of V_REGION structs until the one that contains
	// the supplied vertical line number is found.
	//
	while ((p - v_regions) < MAX_VREGIONS && p->code != -1 && t == NULL)
		if (vcount < (p->start / v_divisor) || vcount > (p->end / v_divisor))
			p++;
		else
			t = p;

	//
	// If no match is found, return NULL.
	//
	if (t == NULL)
	{
		fprintf(stderr, "Vert count %d didn't match a defined region.\n", vcount);
		return NULL;
	}

	//
	// Otherwise, return a pointer to the matching V_REGION struct.
	//
	return t;
}