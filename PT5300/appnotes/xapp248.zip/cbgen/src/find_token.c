//-----------------------------------------------------------------
// find_token.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function scans the input buffer looking for the first
// non-whitespace character in the buffer. If the start argument is
// NULL, the function begins scanning from where the position in the
// input buffer where it last left off. If the start argument is not
// NULL, it uses start as a pointer into the input buffer to start
// scanning from.
//
// This function returns NULL if a newline character or NUL character
// is found before a non-whitespace character is found. Otherwise, it
// returns a character pointer to the first non-whitespace character
// it finds in the input buffer.
//
// This function calls the get_next_char() routine to get characters
// from the input buffer. get_next_char() contains a static pointer
// into the input buffer to allow it to remember the active position
// in the buffer.
//

#include "defs.h"

char *find_token(
	char *start			// Starting position for scan, NULL == resume from last position
)
{
	char *c;			// Temporary character pointer

	//
	// If start is not NULL, then use start as an address to start scanning
	// from. Supply start to the get_next_char() function. If start is NULL
	// call get_next_char with an argument of -1. This causes get_next_char
	// to return the character at the last used position without increment
	// its static pointer first.
	//
	if (start != NULL)
		c = get_next_char(start);
	else
		c = get_next_char((char *) -1);

	//
	// While get_next_char returns a whitespace character, keep calling it
	// to get the next character in the buffer until a non-whitespace character
	// is found.
	while (c != NULL && (*c == '\t' || *c == ' '))
		c = get_next_char(NULL);

	//
	// If a NUL charadter or end of line character is found, return NULL, otherwise
	// return a pointer to the non-whitespace character in the input buffer.
	//
	if (c == NULL || *c == '\n' || *c == '\000')
		return NULL;
	else
		return c;
}

