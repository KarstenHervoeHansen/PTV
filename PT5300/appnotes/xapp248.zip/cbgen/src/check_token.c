//-----------------------------------------------------------------
// check_token.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function checks the supplied string against the list of
// predefined keywords to determine if it matches any of them.
// If a match is found, the function returns the integer code
// corresponding to the keyword found. The codes for the keywords
// are defined in defs.h.
//
// If the supplied string is a NULL pointer, then the function
// returns the code TKN_NONE. If the the string is not NULL and
// does not match any keyword, the function returns the code
// TKN_NOT_A_KEYWORD.

#include "defs.h"

int check_token(
	char *name				// pointer to keyword string to be checked
)
{
	//
	// This is an array full of all the predefined keywords listed in numerical
	// order of their corresponding keyword codes.
	//
	static char *tokens[] = {
		"/", "color_width", "palettes", "h_total", "v_total", "hrom_filename",
		"vrom_filename", "crom_filename", "hrom_instance", "vrom_instance",
		"crom_instance", "hrom_init_state", "vrom_init_state", "palette",
		"end", "blank", "horizontal_regions", "line_formats",
		"vertical_regions", "type0", "type1", "type2", "type3", "type4",
		"is", "to", "in", "field0", "field1", "active", "eav", "sav", "*", 
		"v_increment", "are", "hregion_bits", "vregion_bits", NULL};

	int i;							// index into tokens array
	static char *tmp = NULL;		// pointer to temporary buffer

	//
	// The first this function is called, allocate memory for the temporary
	// string buffer.
	//
	if (tmp == NULL)
		tmp = (char *) xmalloc((ULONG) INPUT_BUF_SIZE);

	//
	// If the supplied string is NULL, return TKN_NONE.
	//
	if (name == NULL)
		return TKN_NONE;

	//
	// Copy the supplied string to the temporary buffer then convert the copy
	// to all lower case.
	//
	strcpy(tmp, name);
	tolower_str(tmp);


	//
	// Init the tokens array index variable to zero then compare string
	// sequentially to each keyword in the array until either a match is
	// found or the end of the array is reached.
	//
	i = 0;

	while (tokens[i] != NULL)
	{
		if (strcmp(tmp, tokens[i]) == 0)
			return i;

		i++;
	}

	//
	// If we get to here, a match was not found so return TKN_NOT_A_KEYWORD.
	//
	return TKN_NOT_A_KEYWORD;
}

