//-----------------------------------------------------------------
// do_palette_line.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called by process_line() when the parser is parsing
// the lines of a PALETTE block. Three types of lines are allowed in
// the PALETTE block: blank or comment lines which are ignored, the END
// command line which terminate the PALETTE block, and color definition
// lines.
//
// A color definition line has the following format:
//
// <color_name> <type> IS <comp value> ...
//
// Current if type is TYPE0, three component values are expected in this
// order: Cb, Y, and Cr. If type is TYPE1, four component values are
// expected in this order: Cb, Y0, Cr, Y1.
//
// The first color definition of a PALETTE block must have a color name
// of BLANK. If the first argument is TRUE, then do_palette_line will
// expect to parse the first color definition.
//
// This function returns TRUE if it parsed a valid color definition line
// or false if it parsed a blank or comment line.
//

#include "defs.h"

int do_palette_line(
	int first				// TRUE if expecting the BLANK color definition
)
{
	int tkn;				// Holds the token code returned by get_token()
	int type;				// Holds the color type code
	int max_color_value;	// Holds the maximum allowable value for a color component
	int num_colors;			// Holds the number of colors defined in the palette
	COLOR *color;			// Pointer to COLOR struct being defined

	//
	// The maximum value for any color component is dictated by the global
	// variable color_width.
	//
	max_color_value = (1 << color_width) - 1;
	
	//
	// Scan for the next token on the line
	//
	tkn = get_token(inbuf);

	//
	// If there are no tokens on the line or the next token is the
	// comment character, then ignore the line and return with a
	// value of FALSE.
	//
	if (tkn == TKN_NONE || tkn == TKN_COMMENT)
		return FALSE;

	//
	// If the next token is END, then we are done processing this palette.
	// Set the parser state to IN_STATE_ANY to indicate that the parser
	// is done parsing the PALETTE block.
	if (tkn == TKN_END)
	{
		in_state = IN_STATE_ANY;
		return TRUE;
	}

	//
	// The line is ot blank and not END, so it must be a color definition. Check 
	// that the number of colors doesn't exceed the maximum then assign the color 
	// pointer to the color struct in the palette.
	//
	if ((num_colors = current_palette->num_colors) >= MAX_COLORS)
	{
		do_error("Attempt to define too many colors in a palette.");
		exit(1);
	}
	color = &(current_palette->color[num_colors]);

	//
	// If the next token is BLANK then this must be the first color of this
	// palette (make sure first is asserted). If not the first line then we
	// are expecting a valid color name as the first element of the line.
	//
	if (tkn == TKN_BLANK && first)
		color->name = "BLANK";
	else if (first)
	{
		do_error("First color of a palette must be called BLANK.");
		exit(1);
	}
	else if (tkn == TKN_NOT_A_KEYWORD && !first)
		color->name = strsave(do_name());
	else
	{
		do_error("Expecting a color name.\n");
		exit(1);
	}

	//
	// Next, we should have a color TYPE code. Ignore an IS token.
	//
	do
	{
		tkn = get_token(NULL);

		switch (tkn)
		{
		case TKN_TYPE0:
		case TKN_TYPE1:
		case TKN_TYPE2:
			type = tkn - TKN_TYPE0;
			break;

		case TKN_IS:
			break;

		default:
			do_error("Expected a color TYPE code immediately following color name.");
			exit(1);
		}
	}
	while (tkn == TKN_IS);

	//
	// Next we should have an IS or a number. Ignore the IS.
	//
	tkn = get_token(NULL);

	if (tkn == TKN_IS)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected a color component value.");
		exit(1);
	}

	color->type = type;

	//
	// If TYPE0, consume three numbers. If not TYPE0, consume 4 numbers.
	//
	color->c[0] = do_number(0, max_color_value);
	color->c[1] = do_number(0, max_color_value);
	color->c[2] = do_number(0, max_color_value);

	if (type != 0)
		color->c[3] = do_number(0, max_color_value);


	if (debug_flag)
	{
		printf("  palette entry %s set to TYPE%d %d %d %d", color->name, color->type, color->c[0], color->c[1], color->c[2]);
		if (type != 0)
			printf(" %d\n", color->c[3]);
		else
			printf("\n");
	}

	//
	// Increment the num_colors element of the palette.
	//
	current_palette->num_colors++;

	//
	// Indicate that we are still parsing the PALETTE block, but are no
	// longer expecting the BLANK color definition.
	//
	in_state = IN_STATE_PALETTE;

	return TRUE;
}
