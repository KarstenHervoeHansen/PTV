//-----------------------------------------------------------------
// parse_palt_frmt.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called when parsing a vertical region definition line
// from the input file. It parses a palette name, optional IS separator, and
// the name of format to be be used for the vertical region. The function
// then finds the FORMAT struct associated with the named format for the
// given palette and returns a pointer to that FORMAT struct.  If either the
// palette name or the format name are not found or do not match defined
// palettes and formats, an error is printed and the program terminates.
//

#include "defs.h"

FORMAT *parse_palt_frmt()
{
	int tkn;				// token code returend by get_token()
	char *s;				// temp string pointer
	PALETTE *palette;		// points to the found palette
	FORMAT *format;			// points to the found format
	
	//
	// The next element should be the name of a palette. Get the name
	// and find the matching palette. First call get_token() to find
	// the next non-whitespace argument in the input buffer. If a reserved
	// word is found, report an error. Call do_name() to parse the
	// palette name from the input buffer. If an invalid name is found,
	// report an error.
	//
	tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD || (s = do_name()) == NULL)
	{
		do_error("Expected a palette name.");
		exit(1);
	}

	//
	// Call find_palette() to search for the PALETTE struct with the
	// given name. If not found, report an error, otherwise set the
	// palette variable to point to the matching PALETTE struct.
	//
	if ((palette = find_palette(s)) == NULL)
	{
		fprintf(stderr, "Undefined palette name %s\n", s);
		do_error("Palette name doesn't match a defined palette.");
		exit(1);
	}

	//
	// Consume the optional IS separator token.
	//
	tkn = get_token(NULL);

	if (tkn == TKN_IS)
		tkn = get_token(NULL);

	//
	// Next argument in the input buffer must be a line format name. If
	// a reserved word is found or an invalid format name is found, report
	// an error.
	//
	if (tkn != TKN_NOT_A_KEYWORD || (s = do_name()) == NULL)
	{
		do_error("Expected a format name.");
		exit(1);
	}

	//
	// Search the list of formats defined in the palette for one with a
	// matching name. If not found, report an error.
	//
	if ((format = find_format(palette, s)) == NULL)
	{
		fprintf(stderr, "Undefined line format %s\n", s);
		do_error("Format name doesn't match a defined format.");
		exit(1);
	}

	//
	// Return a pointer to the matching FORMAT.
	//
	return format;
}