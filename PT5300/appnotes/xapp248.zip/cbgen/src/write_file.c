//-----------------------------------------------------------------
// write_file.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called to create the output files for one ROM.
// It calls HDL-specific file creation routines, depending on which
// output language has been chosen.
//

#include "defs.h"
#define TIMESIZE 64

void write_file(
	int width,					// the width, in bits, of the ROM's output
	char *sim_filename,			// simulation output filename
	char *syn_filename,			// synthesis output filename
	char *instance_name,		// ROM instance name in the HDL code
	ULONG init_value,			// ROM init value
	ULONG *rom,					// pointer to the ROM contents array
	int define_attributes		// for VHDL only, will cause attribute definitions to be generated if TRUE
)
{
	static char timebuf[TIMESIZE];
	size_t len;
	time_t now;
	struct tm *loctime;

	now = time(NULL);
	loctime = localtime(&now);
	len = strftime(timebuf, TIMESIZE, "%a %d %b %Y %H:%M", loctime);


	if (language == VERILOG)
	{
		write_verilog(width, sim_filename, syn_filename, instance_name, init_value, rom, timebuf);
		printf("wrote file %s\nwrote file %s\n", sim_filename, syn_filename);
	}
	else if (language == VHDL)
	{
		write_vhdl(width, sim_filename, syn_filename, instance_name, init_value, rom, timebuf, define_attributes);
		printf("wrote file %s\nwrote file %s\n", sim_filename, syn_filename);
	}
	else if (language == XDL)
	{
		write_xdl(width, syn_filename, instance_name, init_value, rom, timebuf);
		printf("wrote file %s\n", syn_filename);
	}
	else
	{
		fprintf(stderr, "Invalid language type.\n");
		exit(1);
	}
}