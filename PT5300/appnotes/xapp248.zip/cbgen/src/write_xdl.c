//-----------------------------------------------------------------
// write_xdl.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function writes the XDL-specific output file for the specified ROM.
// The output file contains XLD formatted block RAM initialization code that
// can be inserted into the XDL description of a Xilinx FPGA.
//
#include "defs.h"

void write_xdl(
	int width,						// the width, in bits, of the ROM's output
	char *filename,					// output filename
	char *instance_name,			// block RAM instance name
	ULONG init_value,				// init value for the block RAM
	ULONG *rom,						// pointer to an array defining the ROM's contents
	char *timedate					// pointer to time & date string
)
{
	FILE	*f1;					// pointer to the output file
	int		lines, words;			// counters
	int		init_fw;				// number of digits in the ROM INIT value
	int		val_fw;					// number of digits in the ROM SRVAL value
	int		words_per_line;			// number of words in each INIT line
	int		words_per_line_parity;	// number of words in each INITP line
	ULONG	parity;					//temp variable used to generate INITP lines	
	int		bits;					// bit counter
	ULONG	mask;					// mask variable
	int		hrgn_bits, vrgn_bits;	// used to generate comment lines
	char	*format;				// points to an fprintf() format string for the WRITEMODEx lines
	char	*spaces;				// points to a string of six space characters


	//
	// Calculate the number of h_rgn code and v_rgn code bits so they can
	// be reported in the file comment header.
	//
	hrgn_bits = get_bits(max_num_hregions);
	vrgn_bits = get_bits(max_num_vregions);

	spaces = "      ";

	//
	// Based on the ROM output width, define these parameters that affect
	// the formatting of the initialization code.
	//
	if (width == 18)
	{
		init_fw = 5;
		val_fw = 4;
		words_per_line = 16;
		words_per_line_parity = 128;
		mask = 0x0000ffff;
		format = "1024X18";
	} else if (width == 9)
	{
		init_fw = 3;
		val_fw = 2;
		words_per_line = 32;
		words_per_line_parity = 256;
		mask = 0x000000ff;
		format = "2048X9";
	}
	else
	{
		fprintf(stderr, "Invalid width specified to write_file.\n");
		exit(1);
	}

	//
	// Open the output file
	//
	if ((f1 = fopen(filename, "w")) == NULL)
	{
		fprintf(stderr, "Unable to open output file %s\n", filename);
		exit(1);
	}

	//
	// Write the Header, WRITE_MODE, INIT, and SRVAL parameters
	//
	fprintf(f1, "# -----------------------------------------------------------------\n");
	fprintf(f1, "# XDL Block SelectRAM initialization values for %s.\n", instance_name);
	fprintf(f1, "# Created from input file %s on %s\n", input_filename, timedate);
	fprintf(f1, "# Number of patterns = %d, hregion bits = %d, vregion bits = %d\n",
			palettes, hrgn_bits, vrgn_bits);
	fprintf(f1, "#\n");
	fprintf(f1, "# Insert the code below into the %s instance starting at the line\n", instance_name); 
	fprintf(f1, "# beginning with WRITEMODEA through all the INIT, INIT_P, INIT_A,\n");
	fprintf(f1, "# INIT_B, SRVAL_A, and SRVAL_B lines.\n");
	fprintf(f1, "# -----------------------------------------------------------------\n");
	fprintf(f1, "%sWRITEMODEA::READ_FIRST PORTA_ATTR::%s RAMB16A:%s.A:\n", spaces, format, instance_name);
	fprintf(f1, "%sWRITEMODEB::READ_FIRST PORTB_ATTR::%s RAMB16B:%s.B:\n", spaces, format, instance_name);


	//
	// Write all the INIT_XX lines
	//
	for (lines = 0; lines < MAX_INIT_LINES; lines++)
	{
		// Write the line beginning
		fprintf(f1, "%sINIT_%02x::0X", spaces, lines);
		
		// Write all words of an INIT line
		for (words = (words_per_line - 1); words >= 0; words--)
			fprintf(f1, "%0*X", val_fw, rom[lines * words_per_line + words] & mask);

		fprintf(f1,"\n");
	}

	//
	// Write all the INITP_XX lines
	//
	for (lines = 0; lines < MAX_INITP_LINES; lines++)
	{
		// Write the line beginning for the simulation file
		fprintf(f1, "%sINITP_%02x::0X", spaces, lines);
		
		bits = 31;
		parity = 0;

		// Generate the parity lines in 32-bit chunks and write each chunk when completed
		for (words = (words_per_line_parity - 1); words >= 0; words--)
		{
			if (width == 9)
			{
				parity |= (((rom[lines * words_per_line_parity + words] >> 8) & 1) << bits);
				bits--;
			} else if (width == 18)
			{
				parity |= (((rom[lines * words_per_line_parity + words] >> 16) & 3) << (bits - 1));
				bits -= 2;
			}

			if (bits < 0)
			{
				fprintf(f1, "%08X", parity);
				bits = 31;
				parity = 0;
			}
		}

		fprintf(f1, "\n");
	}

	//
	// Write the INIT and SRVAL fields
	//
	fprintf(f1, "%sINIT_A::0X%0*X INIT_B::0X%0*X\n", spaces, init_fw, init_value, init_fw, init_value);
	fprintf(f1, "%sSRVAL_A::0X%0*X SRVAL_B::0X%0*X\"\n", spaces, init_fw, init_value, init_fw, init_value);

	//
	// Close the output file.
	//
	fclose(f1);
}