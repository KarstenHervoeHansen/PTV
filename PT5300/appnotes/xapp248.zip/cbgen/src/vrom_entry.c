//-----------------------------------------------------------------
// vrom_entry.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function calculates the value for a VROM location. The v argument
// should contain the current vertical state (usually equivalent to the
// vertical line number). The function returns the value to be stored in
// the VROM at that address. This returned value corresponds to the next
// state of the VROM state machine and contains four fields: the field bit
// (field), the vertical sync bit (v_sync), the vertical region code
// (v_rgn), and the next vertical state value (v_next).
//

#include "defs.h"

ULONG vrom_entry(
	int v				// current vertical state
)
{
	ULONG field;		// calculated field bit
	ULONG v_sync;		// calculated v_sync bit
	ULONG v_next;		// calculated v_next bit
	ULONG v_rgn;		// calculated v_rgn code
	V_REGION *vn;		// calculated next vertical state

	//
	// Increment the current vertical state and wrap around to 1 if
	// it exceeds the total number of states. 
	v_next = (v + 1) % ((v_total / v_divisor) + 1);
	if (v_next == 0)
		v_next = 1;

	//
	// Find the vertical region that contains the next state. If none
	// found, then terminate the program with an error.
	//
	if ((vn = find_vregion(v_next)) == NULL)
		exit(1);

	//
	// Using the next vertical region definition, calculate the fields
	// of the VROM output.
	//
	v_rgn = vn->code;
		
	if (vn->type == BLANK)
		v_sync = 1;
	else
		v_sync = 0;

	field = vn->field;

	//
	// Generate the final VROM output value from the various fields.
	//
	return (ULONG) (field << FIELD_OFFSET | v_sync << V_SYNC_OFFSET | v_rgn << V_RGN_OFFSET | v_next);
}