//-----------------------------------------------------------------
// process_line.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is the main input file parser code. 
//
// It reads a line from the input file into the input buffer and, 
// if that line ends in a line continuation character, it reads another 
// line from the input file and appends it to the previous line. This continues
// until the entire command line is in the input buffer.
//
// Next, specific functions are called to parse the input buffer depending on
// the current state of the parser as specified by the in_state variable. 
//
// If the end of the input file is found, the function returnds EOF. Otherwise
// it returns OK after successfully parsing the line.
//
 
#include "defs.h"

int process_line()
{
	char *cont = NULL;			// pointer to line continuation character
	char *in = inbuf;			// temp pointer

	//
	// Read a line from the input file into the input buffer. If EOF is found,
	// return EOF. Search the line just read for a line continuation character
	// and if found, read more lines in until the entire command line is
	// contained in the input buffer.
	//
	do
	{
		in_linenum++;

		if (in + 256 > inbuf + INPUT_BUF_SIZE)
		{
			do_error("Maximum input line size exceeded.\n");
			exit(1);
		}

		if (fgets(in, INPUT_BUF_SIZE, infd) == NULL)
		{
			if (cont == NULL)
			{
				if (feof(infd))
					return EOF;
				else
				{
					fprintf(stderr,"Error encountered while reading input file.\n");
					exit(1);
				}
			}
		}
	}
	while ((in = cont = strchr(in, '\\')) != NULL);

	//
	// Based on the current state of the parser, execute a specific line parser
	// routine to parse the line in the input buffer.
	//
	switch (in_state)
	{
	//
	// Not in a block, so expect any type of command line.
	//
	case IN_STATE_ANY:		
		do_any_line();
		break;

	//
	// Expecting the first color definition line of a PALETTE block. This line must
	// define the BLANK color for the palette.
	//
	case IN_STATE_PALETTE_1:
		if (do_palette_line(TRUE) == TRUE)
			if (in_state == IN_STATE_PALETTE_1)
				in_state = IN_STATE_PALETTE;
		break;

	//
	// Expecting a color definition line for a pallet or the END command to end the
	// palette definition.
	//
	case IN_STATE_PALETTE:
		do_palette_line(FALSE);
		break;

	//
	// Expecting a horizontal region definition line or the END command line.
	//
	case IN_STATE_HREGION:
		do_hregion_line();
		break;

	//
	// Expecting a vertical region definition line or the END command line.
	//
	case IN_STATE_VREGION:
		do_vregion_line();
		break;

	//
	// Expecting a line format defintion line or the END command line.
	//
	case IN_STATE_FORMAT:
		do_format_line();
		break;
	}

	return OK;
}



