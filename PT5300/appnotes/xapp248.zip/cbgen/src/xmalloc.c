//-----------------------------------------------------------------
// xmalloc.c
//
//
// This function is from UNIX Tool Building by Kenneth Ingham. The
// code may be freely copied , as long as it is not sold for profit
// and the copyright and author notices remain intact.
//
// Kenneth Ingham
// Copyright (c) 1988 The University of New Mexico
//
//
//

//
// This function is just like malloc() except that it checks the pointer
// returned by the malloc() function and if it is NULL, it reports an
// error and terminates the program.
//

#include "defs.h"

char *xmalloc(
	ULONG size
)
{
	char *cp;

	cp = malloc(size);

	if (cp == NULL)
	{
		fprintf(stderr, "malloc died.\n");
		exit(1);
	}

	return cp;
}
