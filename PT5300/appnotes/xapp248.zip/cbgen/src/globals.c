//-----------------------------------------------------------------
// globals.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function defines all the global variables used by cbgen.
//

#include "defs.h"

int			synth_tool;				// Indicates which synthesis tool to target
int			language;				// Indicates the output language: Verilog, VHDL, or XDL
int			debug_flag;				// Causes debug messages to print if TRUE
char		*input_filename;		// Pointer to the input file name
char		*vrom_filename;			// Pointer to the VROM base output file name
char		*hrom_filename;			// Pointer to the HROM base output file name
char		*crom_filename;			// Pointer to the CROM base output file name
char		*vrom_sim_filename;		// Pointer to the VROM simulation output file name
char		*vrom_syn_filename;		// Pointer to the VROM synthesis output file name
char		*hrom_sim_filename;		// Pointer to the HROM simulation output file name
char		*hrom_syn_filename;		// Pointer to the HROM synthesis output file name
char		*crom_sim_filename;		// Pointer to the CROM simulation output file name
char		*crom_syn_filename;		// Pointer to the CROM synthesis output file name
char		*cromls_sim_filename;	// Currently not used
char		*cromls_syn_filename;	// Currently not used
int			color_width;			// Specifies the number of bits used to define the color components
int			crom_width;				// Specifies the width of the color components stored in the CROM
int			h_total;				// Specifies the total number of counts on a horizontal line
int			h_divisor;				// Specifies the horizontal divisor (number of counts per HROM state)
int			v_total;				// Specifies the total number of vertical lines in a field
int			v_divisor;				// Specifies the vertical divisor (number of lines per VROM state), usually = 1
int			v_increment;			// Specifies the horizontal state on which the vertical line counter increments
int			palettes;				// Specifies the number of palettes in use, 1 or 2
ULONG		hrom_init_state;		// Specifies the init value for the HROM
ULONG		vrom_init_state;		// Specifies the init value for the VROM
PALETTE		*palt;					// Pointer to the array of PALETTE structs
PALETTE		*current_palette;		// Pointer to the current PALETTE struct
FORMAT		*formats;				// Pointer to the array of FORMAT structs
FORMAT		*current_format;		// Pointer to the current FORMAT struct
H_REGION	*h_regions;				// Pointer to the array of H_REGION structs
H_REGION	*current_hregion;		// Pointer to the current H_REGION struct
V_REGION	*v_regions;				// Pointer to the array of V_REGION structs
V_REGION	*current_vregion;		// Pointer to the current V_REGION struct
char		*hrom_instance;			// Pointer to the name of the HROM instance in the HDL code
char		*vrom_instance;			// Pointer to the name of the VROM instance in the HDL code
char		*crom_instance;			// Pointer to the name of the CROM instance in the HDL code
char		*cromls_instance;		// Currently not used
FILE		*infd;					// FILE pointer associated with the input file
int			in_state;				// Current state of the input file parser
char		*inbuf;					// Pointer to the input line buffer
int			in_linenum;				// Input file line number of line currently being parsed
int			max_num_hregions;		// Maximum number of H_REGIONs allowed
int			max_num_vregions;		// Maximum number of V_REGIONs allowed
int			num_formats;			// Number of FORMATs defined
int			max_hregion_code;		// Maximum horizontal region code value
int			max_vregion_code;		// Maximum vertical region code value





