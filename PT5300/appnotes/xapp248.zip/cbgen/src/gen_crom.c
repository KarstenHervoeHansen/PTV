//-----------------------------------------------------------------
// gen_crom.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function generates the contents of video component ROM (CROM)
// and writes the output files for this ROM.
//
// A for loop initializes an array (rom) with the values to be stored
// in the CROM. The function crom_entry() is called once for each
// location within the CROM to generate the value to be stored at that
// location. After the rom array is initialized, write_file() is called
// to write the output files for the CROM.
//

#include "defs.h"

void gen_crom(
	ULONG rom_size,				// specifies the number of address in CROM
	int crom_width				// specifies the width of the CROM
)
{
	ULONG c;					// for loop variable
	ULONG *rom;					// pointer to ROM array
	ULONG h_rgn;				// horizontal region index into rom array
	ULONG v_rgn;				// vertical region index into rom array
	ULONG sample;				// sample number index into rom array
	ULONG pat;					// pattern select index into rom array
	ULONG h_rgn_bits;			// indicates the number of bits in h_rgn
	ULONG h_rgn_mask;			// a bit mask for the h_rgn
	ULONG v_rgn_bits;			// indicates the number of bits in v_rgn
	ULONG v_rgn_mask;			// a bit mask for the v_rgn
	ULONG sample_bits;			// indicates the number of bits in sample
	ULONG sample_mask;			// a bit mask for sample
	ULONG pat_bits;				// indicates the number of bit in pat
	ULONG pat_mask;				// a bit mask for pat

	if (rom_size > 2048)
	{
		printf("Color ROM size must be smaller than 2048 words.\n");
		exit(1);
	}

	//
	// Generate the bit numbers and masks for the values that
	// make up the address of the CROM.
	//
	h_rgn_bits = get_bits(max_num_hregions);
	v_rgn_bits = get_bits(max_num_vregions);
	sample_bits = get_bits(NUM_SAMPLES);
	pat_bits = get_bits(palettes);

	h_rgn_mask = get_mask(h_rgn_bits);
	v_rgn_mask = get_mask(v_rgn_bits);
	sample_mask = get_mask(sample_bits);
	pat_mask = get_mask(pat_bits);

	if (debug_flag)
	{
		printf("h_rgn size=%d bits=%d mask=%x\n", max_num_hregions, h_rgn_bits, h_rgn_mask);
		printf("v_rgn size=%d bits=%d mask=%x\n", max_num_vregions, v_rgn_bits, v_rgn_mask);
		printf("samples size=%d bits=%d mask=%x\n", NUM_SAMPLES, sample_bits, sample_mask);
		printf("patterns size=%d bits=%d mask=%x\n", NUM_PATTERNS, pat_bits, pat_mask);
	}

	//
	// Allocate storage for the rom array.
	//
	rom = (ULONG *) xmalloc((ULONG)(rom_size * sizeof (ULONG)));

	//
	// Init the rom array to zeros
	//
	for (c = 0; c < rom_size; c++)
		*(rom + c) = 0;

	//
	// create the contents of the ROM
	//
	// This for loop indexes through each possible location in the CROM,
	// calculating the sample, h_rgn, v_rgn, and pat indecies that make
	// up each address and calling crom_entry() to get the value that
	// should be stored in the rom based on the sample, h_rgn, v_rgn, and
	// pat values.
	//
	for (c = 0; c < rom_size; c++)
	{
		sample = c & sample_mask;
		h_rgn = (c >> sample_bits) & h_rgn_mask;
		v_rgn = (c >> (h_rgn_bits + sample_bits)) & v_rgn_mask;
		pat = (c >> (v_rgn_bits + h_rgn_bits + sample_bits)) & pat_mask;

		*(rom + c) = crom_entry(pat, sample, v_rgn, h_rgn);
	}

	//
	// If the number of bits used to define the color values is more than
	// the number of bits available on the output of the CROM, scale all
	// the color values down to the CROM width.
	//
	if (crom_width < color_width)
		for (c = 0; c < rom_size; c++)
			*(rom + c) >>= (color_width - crom_width);

	//
	// The write_file() function will write the output files for the CROM.
	//
	write_file(crom_width, crom_sim_filename, crom_syn_filename, crom_instance, 0, rom, FALSE);

	//
	// Deallocate the storage for the rom array.
	//
	free(rom);

	if (debug_flag)
		printf("Done generating video component ROM files.\n");
}