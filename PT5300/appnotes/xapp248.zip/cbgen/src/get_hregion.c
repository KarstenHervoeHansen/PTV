//-----------------------------------------------------------------
// get_hregion.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function scans the array of h_regions to find the first one
// that has a horizontal code value matching the argument supplied
// to the this function. It returns a pointer to the H_REGION struct
// that matches or NULL if a no matching region is found.
//
// This function should not be confused with find_hregion() which also
// seaches the array of H_REGIONs, but looks for a H_REGION that
// contains a certain horizontal count value.
//

#include "defs.h"

H_REGION *get_hregion(
	ULONG code				// horizontal code value to be matched
)
{
	H_REGION *p, *t;		// pointers used in searching H_REGION array

	//
	// Init the pointers, p to the beginning of the array of H_REGION
	// structs and t to NULL.
	//
	p = h_regions;
	t = NULL;

	//
	// Sequentially look through the array of H_REGION structs for a 
	// match. If one is found, set t to point to the matching H_REGION.
	//
	while ((p - h_regions) < MAX_HREGIONS && p->code != -1 && t == NULL)
		if (p->code == (int) code)
			t = p;
		else
			p++;

	//
	// Return the contents of the t pointer
	//
	return t;
}