//-----------------------------------------------------------------
// do_number.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called when the parser is expecting a numeric argument.
// The find_token() function is called to skip past all whitespace characters.
// check_token() is called to determine if the a reserved word has been found.
// Reserved words IS, IN, and TO are ignored and the next token is found.
// Any other reserved words cause the program to exit with an error.
// If a string is found that is not a reserved word, it is scanned and converted to
// an integer value. If it contains non-numeric characters, the program exits
// with an error. If successfully converted to a number, it is compared to the
// supplied bounds for the argument. If outside of the bounds, the program
// exits with an error. Otherwise the function returns the numeric argument.
//

#include "defs.h"

int	do_number(
	int min,			// Lower acceptable bound for argument value
	int max				// Upper acceptable bound for argument value
)
{
	char *s;			// Temp string pointer
	char c;				// Temp char holder
	int num;			// Holds the converted numeric argument
	int tkn;			// Holds the token code returned by check_token()

	//
	// Call find_token() to skip past whitespace characters. When a token
	// is found, called check_token() to determine if it is a reserved word.
	// If the reserved words IN, IS, or TO are found, repeat this process
	// to skip past these separator tokens and find the next token. If any
	// other reserved word is found, exit with an error.
	// 
	do
	{
		if ((s = find_token(NULL)) == NULL)
		{
			do_error("Expecting a numeric value after key word.");
			exit(1);
		}

		tkn = check_token(s);

		if (tkn != TKN_IS && tkn != TKN_IN && tkn == TKN_TO && tkn != TKN_NOT_A_KEYWORD)
		{
			do_error("Unexpected keyword when looking for a number.\n");
			exit(1);
		}

	} while (tkn != TKN_NOT_A_KEYWORD);

	//
	// Try to interpret the token as a numeric value. If it contains non-numeric
	// characters, exit with an error.
	//
	if (sscanf(s, "%d", &num) != 1)
	{
		do_error("Expecting a numeric value after key word.\n");
		exit(1);
	}

	//
	// Compare the numeric value to the upper and lower bounds and
	// exit with an error if it is outside of those bounds.
	//
	if (num < min || num > max)
	{
		do_error("Numeric value out of range.\n");
		exit(1);
	}

	//
	// Advance get_next_char pointer past number.
	//
	do
		c = *get_next_char(NULL);
	while (isdigit(c));

	//
	// Return the numeric argument.
	//
	return num;
}


