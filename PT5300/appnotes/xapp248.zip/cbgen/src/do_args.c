//-----------------------------------------------------------------
// do_args.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function parses the various command line flags and arguments.
// The command line must contain the input file name and may contain
// flags to specify the output file language and the synthesis tool.
// A debug flag is also supported that causes verbose debug messages
// to be printed during execution.
//

#include "defs.h"

void do_args(
	int argc, 
	char *argv[]
)
{
	int i;
	char *s;

	//
	// Initialize default values.
	//
	synth_tool =		XST;
	language =			VERILOG;
	debug_flag =		FALSE;
	input_filename =	NULL;
	
	//
	// First parse through the command line for all valid arguments.
	//
	for (i=1; i<argc; i++)
	{
		//
		// If the first character of an arument is a hypen, then it is assumed to be
		// a flag.
		//
		if (argv[i][0] == '-')
		{
			switch(tolower(argv[i][1]))
			{
			//
			// The -s flag is used to specify the name of the synthesis tool to be targetted.
			//
			case 's':
				i = getargv(&s, argv, i, "synthesis tool specifier");
				tolower_str(s);
				if (strcmp(s, "xst") == 0)
					synth_tool = XST;
				else if (strcmp(s, "synopsys") == 0)
					synth_tool = SYNOPSYS;
				else if (strcmp(s, "synplify") == 0)
					synth_tool = SYNPLIFY;
				else if (strcmp(s, "leonardo") == 0)
					synth_tool = LEONARDO;
				else
				{
					fprintf(stderr,"Synthesis tool must be one of XST, SYNOPSYS, SYNPLIFY, LEONARDO: input was %s\n", s);
					exit(1);
				}
				break;

			//
			// The -l flag is used to specify the language to be used for the output files.
			//
			case 'l':
				i = getargv(&s, argv, i, "language specifier");
				tolower_str(s);
				if (strcmp(s, "verilog") == 0)
					language = VERILOG;
				else if (strcmp(s, "vhdl") == 0)
					language = VHDL;
				else if (strcmp(s, "xdl") == 0)
					language = XDL;
				else
				{
					fprintf(stderr,"Language must be one of VERILOG, VHDL, or XDL: input was %s\n", s);
					exit(1);
				}
				break;

			//
			// The -d flag is used to enable verbose debugging messages.
			//
			case 'd':
				debug_flag = TRUE;
				break;
			}
		//
		// An argument of ? will cause the syntax of the cbgen command line to be printed.
		//
		} else if (argv[i][0] == '?') {
				fprintf(stderr,"\nColorbar ROM init file generator %s\n", VERSION);
				fprintf(stderr,"usage: cbgen [-s synth_tool] [-l language] input_filename\n");
				fprintf(stderr,"  synth_tool is one of XST, SYNOPSYS, SYNPLIFY, or LEONARDO.\n");
				fprintf(stderr,"  synth_tool defaults to XST.\n");
				fprintf(stderr,"  language is one of VERILOG, VHDL, or XDL.\n");
				fprintf(stderr,"  language defaults to VERILOG.\n");
				exit(1);
		//
		// Anything else is assumed to be the input file name.
		//
		} else
			input_filename = argv[i];

	}

	//
	// If no input file name argument was provided, report this as an error.
	//
	if (input_filename == NULL)
	{
		fprintf(stderr, "Error: no input filename supplied.\n");
		exit(1);
	}

	//
	// If the debug flag is set, then echo all the settings.
	//
	if (debug_flag)
	{
		printf("\nColorbar ROM init file generator %s\n\n", VERSION);

		printf("Input filename:     %s\n", input_filename);

		printf("Synthesis tool:     ");
		switch (synth_tool)
		{
		case XST:
			printf("XST\n");
			break;

		case SYNOPSYS:
			printf("SYNOPSYS\n");
			break;

		case SYNPLIFY:
			printf("SYNPLIFY\n");
			break;

		case LEONARDO:
			printf("LEONARDO\n");
			break;

		default:
			printf("unknown\n");
		}

		printf("Language:           ");
		switch (language)
		{
		case VERILOG:
			printf("VERILOG\n");
			break;

		case VHDL:
			printf("VHDL\n");
			break;

		case XDL:
			printf("XDL\n");
			break;

		default:
			printf("unknown\n");
		}
	}
}