//-----------------------------------------------------------------
// get_syn_tool_name.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function returns a pointer to a string that describes the
// selected synthesis tool. The synthesis tool is selected by a
// command line flag and is stored as a numeric value in the global
// variable synth_tool.
//

#include "defs.h"

char *get_syn_tool_name()
{
	//
	// Define a static array of the names of the synthesis tools.
	//
	static char *syn_tool_names[] = {
		"Xilinx XST",
		"Synopsys FPGA Express",
		"Synplicity Synplify",
		"Mentor Graphics LeonardoSpectrum"};


	//
	// Return a pointer to the array entry corresponding to the selected
	// synthesis tool.
	//
	return syn_tool_names[synth_tool];
}
