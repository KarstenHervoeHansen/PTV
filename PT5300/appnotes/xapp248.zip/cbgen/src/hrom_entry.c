//-----------------------------------------------------------------
// hrom_entry.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function returns the HROM contents for a given HROM location based on
// the horizontal position specified by the argument h. The h argument
// represent the current state of the HROM state machine and the ROM
// contents to be generated are for the next state of the horizontal
// state machine. This function takes the h argument and increments to
// the next state and calls find_hregion() to find the horizontal region
// that matches that next state. The H_REGION struct that is located by
// find_hregion() contains the information needed to generate the HROM
// contents for the next state. The next state value is made up of four
// fields: the vertical state machine clock enable bit (v_enable), the
// horizontal sync bit (h_sync), the horizontal region code (h_rgn), and
// the next horizontal state value (h_next).
//

#include "defs.h"

ULONG hrom_entry(
	int h				// current HROM state
)
{
	ULONG h_sync;		// horizontal sync value
	ULONG v_enable;		// vertical state machine clock enable
	ULONG h_next;		// horizontal next state
	ULONG h_rgn;		// horizontal region code
	H_REGION *hn;		// pointer to H_REGION struct of next horizontal region

	//
	// find out which horizontal region the next state is in
	//
	h_next = (h + 1) % (h_total / h_divisor);

	if ((hn = find_hregion(h_next)) == NULL)
		exit(1);

	//
	// set the next h_region code value			
	//
	h_rgn = hn->code;
		
	// 
	// set the h_sync signal when in EAV, SAV, or blanking region
	//
	if ((hn->type == EAV) || (hn->type == BLANK) || (hn->type == SAV))
		h_sync = 1;
	else
		h_sync = 0;

	//
	// set the v_enable signal if current h position matches v_increment
	//
	v_enable = 0;

	if (h == ((v_increment / h_divisor) - 1))
	{
		v_enable = 1;
		if (debug_flag)
			printf("\nAssert v_enable when horizontal address value is %d.\n", h);
	}

	//
	// return a composite value for the horizontal ROM
	//
	return (ULONG) (v_enable << V_ENABLE_OFFSET | h_sync << H_SYNC_OFFSET | h_rgn << H_RGN_OFFSET | h_next);
}