//-----------------------------------------------------------------
// defs.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This include file must be included by every file in the cbgen program.
// It includes all necessary libraries, defines all constants and types,
// contains all function prototypes, and defines the types of all the
// global variables that are contained in the globals.c file.
//

//
// Include all necessary C libraries.
//
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

//
// Various constant definitions.
//
#define OK					0
#define FALSE				0
#define TRUE				1
#define MAX_STR				256
#define	VERSION				"Version 1.0"
#define MAX_NAME			128

//
// Video format definitions
//
#define	NTSC422				0
#define	PAL422				1
#define	NTSC_CMPST			2
#define	PAL_CMPST			3

//
// Synthesis tool definitions
//
#define	XST					0
#define	SYNOPSYS			1
#define	SYNPLIFY			2
#define	LEONARDO			3

//
// Language definitions
//
#define VERILOG				0
#define VHDL				1
#define XDL					2

//
// Video component width
//
#define WIDTH_9				0
#define WIDTH_8				1
#define WIDTH_10			2
#define WIDTH_12			3

//
// Color types
//
#define COLOR_TYPE_0		0		// Cb Y Cr
#define COLOR_TYPE_1		1		// Cb Y Cr Y
#define COLOR_TYPE_2		2		// Cb Y Cr Yinc

//
// Output file name defaults
//
#define DEF_VROM_FILENAME	"vert_rom"
#define	DEF_HROM_FILENAME	"horz_rom"
#define	DEF_CROM_FILENAME	"comp_rom"
#define DEF_VROM_INSTANCE	"VROM"
#define DEF_HROM_INSTANCE	"HROM"
#define DEF_CROM_INSTANCE	"CROM"

//
// This is the default horizontal count where the vertical line
// number increments.
//
#define DEF_V_INCREMENT		1440

//
// Define the horizontal region types.
//
#define BLANK				0
#define ACTIVE				1
#define EAV					2
#define SAV					3

//
// Define various maximums used throughout the program.
//
#define MAX_COMPONENTS		4					// Max number of color components per color
#define MAX_COLORS			256					// Max number of defined colors per palette
#define MAX_PALETTES		2					// Max number of color palettes
#define MAX_HREGIONS		256					// Max number of H_REGIONs that can be defined
#define MAX_ACTIVE_HREGIONS	(MAX_HREGIONS - 3)	// Max number of active H_REGIONs that can be defined
#define MAX_VREGIONS		256					// Max number of V_REGIONs that can be defined
#define MAX_FORMATS			32					// Max number of FORMATs that can be define
#define	MAX_H_STATES		1024				// Max number of states in horizontal state machine
#define MAX_V_STATES		1024				// Max number of states in vertical state machine
#define MAX_INIT_LINES		64					// Max number of INIT lines in RAM init files
#define MAX_INITP_LINES		8					// Max number of INITP lines in RAM init files
#define INPUT_BUF_SIZE		32768				// Max size of an input line
#define	MAX_NAME_SIZE		64					// Max size of a palette or color name

//
// Some various default values.
//
#define DEF_NUM_HREGIONS	16					// Must be binary number indicating range allocated to horz regions in crom
#define DEF_NUM_VREGIONS	16					// Must be binary number indicating range allocated to vert regions in crom
#define NUM_SAMPLES			4					// Must be binary number indicating range allocated to samples in crom
#define NUM_PATTERNS		2					// Must be binary number indicating range allocated to patterns in crom

//
// The block RAMs are all defined to use the READ_FIRST mode.
//
#define WRITE_MODE			"READ_FIRST"

//
// Define the states of the input state machine
//
#define	IN_STATE_ANY		0
#define IN_STATE_PALETTE	1
#define IN_STATE_HREGION	2
#define	IN_STATE_VREGION	3
#define	IN_STATE_FORMAT		4
#define IN_STATE_PALETTE_1	5

//
// Define the bit offsets for the various fields in the HROM output.
//
#define V_ENABLE_OFFSET		17					// Bit position in HROM output for v_enable bit
#define H_SYNC_OFFSET		16					// Bit position in HROM output for h_sync bit
#define H_RGN_OFFSET		10					// Bit position in HROM output for the h_rgn code

//
// Define the bit offsets for the various fields in the VROM output.
//
#define FIELD_OFFSET		17					// Bit position in VROM output for the field bit
#define V_SYNC_OFFSET		16					// Bit position in VROM output for the v_sync bit
#define V_RGN_OFFSET		10					// Bit position in VROM output for the v_rgn code

//
// Define the numerical codes for the various token keywords.
//
#define TKN_NONE			-1					// returned if nothing else on line by whitespace
#define TKN_NOT_A_KEYWORD	-2					// returned if something other than a keyword was found
#define TKN_COMMENT			0
#define TKN_COLOR_WIDTH		1
#define TKN_PALETTES		2
#define TKN_H_TOTAL			3
#define TKN_V_TOTAL			4
#define TKN_H_FILENAME		5
#define TKN_V_FILENAME		6
#define TKN_C_FILENAME		7
#define TKN_H_INSTANCE		8
#define TKN_V_INSTANCE		9
#define	TKN_C_INSTANCE		10
#define TKN_H_INIT_STATE	11
#define TKN_V_INIT_STATE	12
#define	TKN_PALETTE			13
#define TKN_END				14
#define TKN_BLANK			15
#define TKN_HREGIONS		16
#define TKN_FORMATS			17
#define TKN_VREGIONS		18
#define TKN_TYPE0			19
#define TKN_TYPE1			20
#define	TKN_TYPE2			21
#define TKN_TYPE3			22
#define TKN_TYPE4			23
#define TKN_IS				24
#define TKN_TO				25
#define TKN_IN				26
#define TKN_FIELD0			27
#define TKN_FIELD1			28
#define	TKN_ACTIVE			29
#define TKN_EAV				30
#define TKN_SAV				31
#define TKN_ASTERISK		32
#define TKN_V_INCREMENT		33
#define TKN_ARE				34
#define TKN_HBITS			35
#define TKN_VBITS			36


//
// Type definitions
//
typedef unsigned long ULONG;

//
// The COLOR structure is used in the PALETTEs to define each
// individual color. The structure store the string name of the
// color, its type, and the color component values that make up
// the color.
//
typedef struct color_struct {
	char			*name;							// Pointer to COLOR name string
	int				type;							// Color type
	ULONG			c[MAX_COMPONENTS];				// The components of the color
} COLOR;

//
// The PALETTE structure is used to hold all the colors of a palette.
// There may be either one or two palettes defined, depending on
// whether one or two different test patterns are being generated.
// The structure contains the name of the palette, an array of
// COLOR structures defining the colors of the palette, and an
// integer indicating how many colors are included in the palette.
//
typedef struct palette_struct {
	char			*name;							// Ponter to PALETTE name string
	COLOR			color[MAX_COLORS];				// Array of COLORs
	int				num_colors;						// Number of colors in palette
} PALETTE;

//
// The FORMAT struct holds a line format definition. A line format
// consists of a name string, a pointer to the PALETTE to be used,
// and array of pointers to COLOR structs, one pointer for each
// active video horizontal region on the line.
//
typedef struct format_struct {
	char			*name;							// Pointer to FORMAT name string
	PALETTE			*palette;						// Pointer to PALETTE to be used
	COLOR			*color[MAX_ACTIVE_HREGIONS];	// Pointer to COLOR to be used for each active h region
} FORMAT;

//
// The H_REGION struct holds the definition of a horizontal region.
// A horizontal region definition consists a pair of numbers indicating
// the starting and ending horizontal positions of the region, a type
// value, and the user assigned horizontal code assigned to the region.
//
typedef struct h_region_struct {
	int				start;							// Starting horizontal count of region
	int				end;							// Ending horizontal count of region
	ULONG			type;							// Horizontal region type
	int				code;							// User assigned code for the region
} H_REGION;

//
// The V_REGION struct holds the definition of a vertical region.
// A vertical region definition consits of a pair of numbers indicating
// the starting and ending line number of the region, a value indicating
// which field (odd or even) the region is in, the type of the region,
// the user assigned code for the region, and pointers to the FORMATs
// (one for each PALETTE) to be used for all lines in the region.
//
typedef struct v_region_struct {
	int				start;							// Starting line of region
	int				end;							// Ending line of region
	ULONG			field;							// Field
	ULONG			type;							// Region type
	int				code;							// User assigned code for region
	FORMAT			*format[MAX_PALETTES];			// Line format(s) for the region
} V_REGION;


//
// Function prototypes
//
extern char		*xmalloc(ULONG size);
extern char		*strsave(char *s);
extern int		getargv(char **what, char *argv[], int i, char *err);
extern char		*tolower_str(char *str);
extern void		do_args(int argc, char *argv[]);
extern void		test_init();
extern void		gen_hrom();
extern void		gen_vrom();
extern void		gen_crom(ULONG rom_size, int crom_width);
extern H_REGION *find_hregion(int hcount);
extern H_REGION *get_hregion(ULONG code);
extern V_REGION *find_vregion(int vcount);
extern V_REGION *get_vregion(ULONG code);
extern char		*make_filename(const char *user, const char *dflt, const char *type);
extern ULONG	hrom_entry(int h);
extern ULONG	vrom_entry(int v);
extern ULONG	crom_entry(ULONG pat, ULONG sample, ULONG v_rgn, ULONG h_rgn);
extern void		write_file(int width, char *sim_filename, char *syn_filename, char *instance_name, ULONG init_value, ULONG *rom, int define_attributes);
extern void		write_verilog(int width, char *sim_filename, char *syn_filename, char *instance_name, ULONG init_value, ULONG *rom, char *timedate);
extern void		write_vhdl(int width, char *sim_filename, char *syn_filename, char *instance_name, ULONG init_value, ULONG *rom, char *timedate, int define_attributes);
extern void		write_xdl(int width, char *filename, char *instance_name, ULONG init_value, ULONG *rom, char * timedate);
extern COLOR	*find_color(PALETTE *p, char *color_name);
extern ULONG	get_bits(ULONG size);
extern ULONG	get_mask(ULONG bits);
extern int		process_line();
extern void		do_any_line();
extern int		do_palette_line(int first);
extern void		do_hregion_line();
extern void		do_vregion_line();
extern void		do_format_line();
extern int		get_token(char *s);
extern char		*find_token(char *start);
extern int		do_number(int min, int max);
extern char		*do_string();
extern char		*do_name();
extern void		do_error(char *errstr);
extern void		do_unexpected_token(int token);
extern char		*token_name(int token);
extern void		new_palette(char *name);
extern PALETTE	*find_palette(char *name);
extern FORMAT	*parse_palt_frmt();
extern FORMAT	*find_format(PALETTE *palette, char *name);
extern COLOR	*find_color(PALETTE *palette, char *name);
extern int		check_token(char *name);
extern char		*get_next_char(char *s);
extern char		*get_syn_tool_name();

//
// Global variable type definitions.
//
extern int		synth_tool;
extern int		language;
extern int		debug_flag;
extern char		*input_filename;
extern char		*vrom_filename;
extern char		*hrom_filename;
extern char		*crom_filename;
extern char		*vrom_sim_filename;
extern char		*vrom_syn_filename;
extern char		*hrom_sim_filename;
extern char		*hrom_syn_filename;
extern char		*crom_sim_filename;
extern char		*crom_syn_filename;
extern char		*cromls_sim_filename;
extern char		*cromls_syn_filename;
extern int		color_width;
extern int		crom_width;
extern int		h_total;
extern int		h_divisor;
extern int		v_total;
extern int		v_divisor;
extern int		v_increment;
extern int		palettes;
extern PALETTE	*palt;
extern PALETTE	*current_palette;
extern FORMAT	*formats;
extern FORMAT	*current_format;
extern H_REGION *h_regions;
extern H_REGION *current_hregion;
extern V_REGION *v_regions;
extern V_REGION *current_vregion;
extern ULONG	hrom_init_state;
extern ULONG	vrom_init_state;
extern char		*hrom_instance;
extern char		*vrom_instance;
extern char		*crom_instance;
extern char		*cromls_instance;
extern FILE		*infd;
extern int		in_state;
extern char		*inbuf;
extern int		in_linenum;
extern int		max_num_hregions;
extern int		max_num_vregions;
extern int		num_formats;
extern int		max_hregion_code;
extern int		max_vregion_code;




