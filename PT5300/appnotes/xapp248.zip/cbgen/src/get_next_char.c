//-----------------------------------------------------------------
// get_next_char.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function returns a pointer to the next character in a string.
// Typically the string is input buffer containing a line read from the
// input file.
//
// A static character pointer is maintained by this function that points
// to the last character returned by the function.
//
// If the argument to the function is NULL, then the static character pointer
// is incremented to the next location in the string and the new value of
// the pointer is returned.
//
// If the argument to the function is -1, then the static character pointer
// is unchanged and the function simply returns the current value of the pointer.
//
// If the argument to the function is not NULL and not -1, then the static
// character pointer is set equal to the argument and the new value of the
// static pointer is returned.
//

#include "defs.h"

char *get_next_char(
	char *s
)
{
	static char *p = NULL;

	if (s == ((char *) -1))
		return p;
	else if (s != NULL)
		return p = s;
	else if (p == NULL)
		return NULL;
	else
		return ++p;
}
