//-----------------------------------------------------------------
// do_string.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

// This functin is called when the parser is expecting a string
// enclosed in quotation marks. Such strings may contain whitespace
// characters and all characters are copied until the end quote mark.
// If the reserved words IS, IN, or TO are found before the beginning
// quotation mark, they are ignored. Any other keywords found before
// the opening quotation mark will cause an error.
//
// The function returns a pointer to the parsed string, stripped of
// the quotation marks.
//

#include "defs.h"

char *do_string()
{
	char *s;					// Temp string pointer
	char c;						// Temp char holder
	int tkn;					// Holds token value returned by check_token()
	int len;					// Holds length of string
	static char *name = NULL;	// Temporary string buffer

	//
	// The first time this function is called, malloc space for the name buffer.
	//
	if (name == NULL)
		name = xmalloc(129);

	//
	// Call find_token() to skip past whitespace characters. Call
	// check_token() to determine if a reserved word has been found.
	// If the reserved words IN, IS, or TO are found, skip past them
	// and find the next token. If any other reserved word is found,
	// exit with an error.
	//
	do
	{
		if ((s = find_token(NULL)) == NULL)
		{
			do_error("Expecting a quoted string name after keyword.");
			exit(1);
		}

		tkn = check_token(s);

		if (tkn != TKN_IS && tkn != TKN_IN && tkn == TKN_TO && tkn != TKN_NOT_A_KEYWORD)
		{
			do_error("Unexpected keyword when looking for a quoted string name.\n");
			exit(1);
		}

	} while (tkn != TKN_NOT_A_KEYWORD);

	//
	// Parse the quotated string and copy it into the name buffer.
	//
	if (sscanf(s, "\"%128s", name) != 1)
	{
		do_error("Expecting a quoted string name after key word.\n");
		exit(1);
	}

	if ((len = strlen(name)) <= 1)
	{
		do_error("Quoted string is empty.\n");
		exit(1);
	}

	//
	// Replace the ending quote mark with a NUL character.
	//
	name[strlen(name)-1] = '\000';

	
	//
	// Advance get_next_char pointer past string.
	//
	do
		c = *get_next_char(NULL);
	while (!isspace(c));

	//
	// Return a pointer to the name buffer.
	//
	return name;
}

