//-----------------------------------------------------------------
// crom_entry.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called repeatedly by the gen_crom() function to
// create all the values for the CROM. Each time crom_entry() is called
// with a different set of parameters and returns the value that the
// CROM should output for that set of parameters.
//

#include "defs.h"

ULONG crom_entry(
	ULONG pat,					// the active pattern (palette)
	ULONG sample,				// the active sample (Cb, Y0, Cr, or Y1)
	ULONG v_rgn,				// the active vertical region
	ULONG h_rgn					// the active horizontal region
)
{
	PALETTE *p;					// palette pointer
	V_REGION *v;				// vertical region pointer
	H_REGION *h;				// horizontal region pointer
	FORMAT *f;					// format pointer
	COLOR *c;					// color pointer
	int h_rgn_num;				// index into array of H_REGION structs
	ULONG xyz;					// the TRS XYZ word
	ULONG f_bit, v_bit, h_bit;	// F, V, and H bits

	//
	// Search through the list of vertical regions to find the one with the
	// code corresponding to the v_rgn parameter. If no corresponding vertical
	// region can be found, then an error has occurred. If found, set the
	// v pointer to that vertical region's struct.
	//
	if (v_rgn >= (ULONG) max_num_vregions)
	{
		fprintf(stderr, "Invalid vertical region in crom_entry %d\n", v_rgn);
		exit(1);
	}
	
	if  ((v = get_vregion(v_rgn)) == NULL)
		return (ULONG) 0;


	//
	// Search through the list of horizontal regions to find the one with the
	// code corresponding to the h_rgn parameter. If no corresponding horizontal
	// region can be found, then an error has occurred. If found, set the
	// h pointer to that horizontal region's struct. Also set h_rgn_num the
	// numerical index into the array of H_REGION structs.
	//
	if (h_rgn >= (ULONG) max_num_hregions)
	{
		fprintf(stderr, "Invalid horiztonal region in crom_entry %d\n", h_rgn);
		exit(1);
	}
	
	if ((h = get_hregion(h_rgn)) == NULL)
		return (ULONG) 0;

	h_rgn_num = (int) (h - h_regions);

	//
	// Set the p pointer to point to the PALETTE struct corresponding to the
	// active paletted as defined by the pat argument.
	//
	if (pat >= NUM_PATTERNS)
	{
		fprintf(stderr, "Invalid pattern number in crom_entry %d\n", pat);
		exit(1);
	} else
		p = palt + pat;

	//
	// Verify that the sample argument is in range.
	//
	if (sample >= NUM_SAMPLES)
	{
		fprintf(stderr, "Invalid sample number in crom_entry %d\n", sample);
		exit(1);
	}

	//
	// Using the v pointer and the pat argument, set the f pointer to the
	// FORMAT struct corresponding to the line format to be used.
	//
	f = v->format[pat];
	
	//
	// If we are in the horizontal or verical blanking region then set the
	// color pointer to the BLANK color for the current palette. For safety
	// reasons also check to make sure the format pointer is not NULL. If it
	// is, then use the blank color.
	//
	if (v->type == BLANK || h->type == BLANK || f == NULL)
		c = &(p->color[0]);
	else
		c = f->color[h_rgn_num];

	//
	// If the horizontal region is active video, check the color pointer to
	// make sure it is not NULL then use the color pointer and the sample
	// value to generate the proper ROM contents value. If we are in the
	// blanking region, we've already forced the color pointer to point to
	// the blank color.
	//
	if (h->type == ACTIVE || h->type == BLANK)
	{
		if (c == NULL)
		{
			fprintf(stderr, "Color pointer is NULL in crom_entry.\n");
			exit(1);
		}

		// Based on the color type and the sample number, return the proper component value.
		switch (c->type)
		{
		case COLOR_TYPE_0:
			if (sample == 3)
				sample = 1;
			return c->c[sample];
			break;

		case COLOR_TYPE_2:
		case COLOR_TYPE_1:
			return c->c[sample];
			break;
		}
	} 
	//
	// If we are in a TRS region, generate the ROM value for the EAV or SAV.
	// If sample is zero, the value should be all ones. If the sample is one
	// or two, the value should be all zeros. If the sample is three the
	// value is the XYZ word.
	//
	else if (h->type == EAV || h->type == SAV)
	{
		if (sample == 0)
			return 0x3ff;
		else if (sample == 1 || sample == 2)
			return 0;
		else
		{
			xyz = 0x200;

			if (h->type == EAV)
				h_bit = 1;
			else
				h_bit = 0;

			if (v->field == 1)
				f_bit = 1;
			else
				f_bit = 0;

			if (v->type == BLANK)
				v_bit = 1;
			else
				v_bit = 0;

			xyz |= (f_bit << 8);
			xyz |= (v_bit << 7);
			xyz |= (h_bit << 6);

			if (v_bit ^ h_bit)
				xyz |= 0x020;

			if (f_bit ^ h_bit)
				xyz |= 0x010;

			if (f_bit ^ v_bit)
				xyz |= 0x008;

			if (f_bit ^ v_bit ^ h_bit)
				xyz |= 0x004;

			if (color_width < 10)
				xyz >>= (10 - color_width);

			return xyz;
		}

	}
}
