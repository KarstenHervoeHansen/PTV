//-----------------------------------------------------------------
// do_hregion_line.c
//
// name of module
//
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called by process_line() when the parser is parsing
// the lines of the HORIZONTAL_REGIONS block. There are three valid types
// of lines in this block: blank or comment lines, the END command line,
// and a horizontal region definition.
//
// A blank or comment line is ignored.
//
// A END command line causes the parser state to be set to IN_STATE_ANY
// so that the parser will exit the HORIZONTAL_REGIONS parser.
//
// A horizontal region definition line has the following format:
//
// <h_rgn_code> IS <start> TO <end> <type>
//

#include "defs.h"

void do_hregion_line()
{
	int tkn;				// Holds keyword token code returned by get_token()
	H_REGION *p;			// H_REGION pointer 

	//
	// Scan for the next token on the line
	//
	tkn = get_token(inbuf);

	//
	// If there are no tokens on the line or the next token is the
	// comment character, then ignore the line.
	//
	if (tkn == TKN_NONE || tkn == TKN_COMMENT)
		return;

	//
	// If the next token is END, then we are done processing the h_regions.
	//
	if (tkn == TKN_END)
	{
		in_state = IN_STATE_ANY;
		return;
	}

	//
	// Not blank and not END, so it must be a h_region definition. Check that the
	// number of h_regions doesn't exceed the maximum then assign the current_hregion
	// pointer to the h_region struct to be defined.
	//
	if (current_hregion == NULL)
		current_hregion = h_regions;
	else
		current_hregion++;

	p = current_hregion;

	if (p - h_regions >= MAX_HREGIONS)
	{
		do_error("Attempt to define too many horizontal regions.\n");
		exit(1);
	}

	//
	// Get the code value for the h_region.
	//
	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected a horizontal region code value.");
		exit(1);
	}

	p->code = do_number(0, max_hregion_code);

	//
	// Get the next token. If it is IS, discard. Otherwise, we are expecting
	// a number that is the starting sample number of the region.
	tkn = get_token(NULL);

	if (tkn == TKN_IS)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected the starting position of the horizontal region.");
		exit(1);
	}

	p->start = do_number(0, h_total - 1);

	//
	// Consume an optional TO token then get the ending sample number.
	//
	tkn = get_token(NULL);

	if (tkn == TKN_TO)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected the starting position of the horizontal region.");
		exit(1);
	}

	p->end = do_number(0, h_total - 1);

	//
	// Next thing should be ACTIVE, BLANK, EAV, or SAV
	//
	tkn = get_token(NULL);

	switch (tkn)
	{
		case TKN_ACTIVE:
			p->type = ACTIVE;
			break;

		case TKN_BLANK:
			p->type = BLANK;
			break;

		case TKN_EAV:
			p->type = EAV;
			break;

		case TKN_SAV:
			p->type = SAV;
			break;

		default:
			do_error("Expecting a region type [ACTIVE/BLANK/SAV/EAV].\n");
			exit(1);
			break;

	}


	if (debug_flag)
	{
		printf("  set hregion code %d: start %d, end %d, ", p->code, p->start, p->end);
		switch (p->type)
		{
		case ACTIVE:
			printf("ACTIVE\n");
			break;
		case BLANK:
			printf("BLANK\n");
			break;
		case EAV:
			printf("EAV\n");
			break;
		case SAV:
			printf("SAV\n");
			break;
		}
	}
}
