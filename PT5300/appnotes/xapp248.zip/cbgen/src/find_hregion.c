//-----------------------------------------------------------------
// find_hregion.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function scans the list of horizontal region definitions to
// find the one that contains the supplied horizontal count value.
// The function returns a pointer to the matching H_REGION struct
// or NULL if not match is found.
//

#include "defs.h"

H_REGION *find_hregion(
	int hcount				// horizontal count to match
)
{
	H_REGION *p, *t;		// temporary pointers

	//
	// Init the pointers
	//
	p = h_regions;
	t = NULL;

	//
	// Scan through the list of horizontal regions to find the one that
	// contains the hcount samples. Note that hcount is already divided
	// by the h_divisor value so it must be compared to the horizontal
	// regions starting and ending values divided by h_divisor.
	//
	while ((p - h_regions) < MAX_HREGIONS && p->code != -1 && t == NULL)
		if (hcount < (p->start / h_divisor) || hcount > (p->end / h_divisor))
			p++;
		else
			t = p;

	//
	// If a match was not found, then print an error message and return a NULL pointer.
	//
	if (t == NULL)
	{
		fprintf(stderr, "Horizontal count %d didn't match a defined region.\n", hcount * h_divisor);
		return NULL;
	}

	//
	// A match was found, so return the pointer to the H_REGION struct.
	//
	return t;
}