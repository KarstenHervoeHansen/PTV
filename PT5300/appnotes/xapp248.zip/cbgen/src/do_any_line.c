//-----------------------------------------------------------------
// do_any_line.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called by process_line() to parse a line from the
// input file when the parser is not expecting a specific type of line.
// The parser expects certain types of lines when it is in a command
// block, such as a HORIZONTAL_REGIONS definition block.
//
// This function calls get_token() to find the code of the first token
// on the line. Based on that first token, the routine will decide how
// to further process the line. Simple command lines with a single
// argument are handled directly by getting and interpretting the
// argument. Lines that begin blocks cause the in_state variable to
// be changed so that process_line() will vector directly to the the
// appropriate line processing code for the expected type of line.
//

#include "defs.h"

void do_any_line()
{
	int	cmd;						// Gets assigned to the token value for first keyword found on the line
	char *name;						// Used to hold pointer to user name of a palette definition
	int h_rgn_bits, v_rgn_bits;		// Used to process the HBITS and VBITS commands

	//
	// get_token() will scan the input buffer for the first whitespace
	// delimited token then compare that token to all defined keywords
	// and return the token code associated with the matched keyword.
	//
	cmd = get_token(inbuf);

	//
	// Based on the token value returned by get_token() process the line.
	//
	switch (cmd)
	{
	//
	// Blank lines or lines containing only a comment are ignored.
	//
	case TKN_NONE:
	case TKN_COMMENT:
		return;

	//
	// COLOR_WIDTH command: Get a number argument from the input buffer
	// indicating the number of bits to use for the color components.
	//
	case TKN_COLOR_WIDTH:
		color_width = do_number(8, 10);
		if (debug_flag)
			printf("  set color width to %d\n", color_width);
		break;

	//
	// PALETTES command: Get a number indicating how many palettes will
	// be defined in the input file, 1 or 2.
	//
	case TKN_PALETTES:
		palettes = do_number(1, 2);
		if (debug_flag)
			printf("  set number of palettes to %d.\n", palettes);
		break;

	//
	// H_TOTAL command: Get a number indicating the total number of counts
	// are on a horizontal video line.
	//
	case TKN_H_TOTAL:
		h_total = do_number(0, MAX_H_STATES * h_divisor - 1);
		if (debug_flag)
			printf("  set h_total to %d.\n", h_total);
		break;

	//
	// V_TOTAL command: Get a number indicating how many vertical video lines
	// make up a field of video.
	//
	case TKN_V_TOTAL:
		v_total = do_number(1, MAX_V_STATES);
		if (debug_flag)
			printf("  set v_total to %d.\n", v_total);
		break;

	//
	// V_INCREMENT command: Get a number indicating the horizontal count value
	// on which the vertical line number is incremented.
	//
	case TKN_V_INCREMENT:
		v_increment = do_number(0, h_total);
		if (debug_flag)
			printf("  set v_increment to %d.\n", v_increment);
		break;

	//
	// HBITS command: Get a number (4 or 5) indicating how many bits to use
	// to encode the horizontal region value.
	//
	case TKN_HBITS:
		h_rgn_bits = do_number(4, 5);
		if (debug_flag)
			printf("  set hregion_bits to %d.\n", h_rgn_bits);
		if (h_rgn_bits == 4)
		{
			max_hregion_code = 15;
			max_num_hregions = 16;
		}
		else
		{
			max_hregion_code = 31;
			max_num_hregions = 32;
		}
		break;

	//
	// VBITS command: Get a number (4 or 5) indicating how many bits to use
	// to encode the vertical region value.
	//
	case TKN_VBITS:
		v_rgn_bits = do_number(4, 5);
		if (debug_flag)
			printf("  set vregion_bits to %d.\n", v_rgn_bits);
		if (v_rgn_bits == 4)
		{
			max_vregion_code = 15;
			max_num_vregions = 16;
		}
		else
		{
			max_vregion_code = 31;
			max_num_vregions = 32;
		}
		break;

	//
	// H_FILENAME command: Get the base name to be used for the HROM
	// output files.
	//
	case TKN_H_FILENAME:
		hrom_filename = strsave(do_string());
		if (debug_flag)
			printf("  set hrom_filename to %s\n", hrom_filename);
		break;

	//
	// V_FILENAME command: Get the base name to be used for the VROM
	// output files.
	//
	case TKN_V_FILENAME:
		vrom_filename = strsave(do_string());
		if (debug_flag)
			printf("  set vrom_filename to %s\n", vrom_filename);
		break;

	//
	// C_FILENAME command: Get the base name to be used for the CROM
	// output files.
	//
	case TKN_C_FILENAME:
		crom_filename = strsave(do_string());
		if (debug_flag)
			printf("  set crom_filename to %s\n", crom_filename);
		break;

	//
	// H_INSTANCE command: Get the instance name of the HROM.
	//
	case TKN_H_INSTANCE:
		hrom_instance = strsave(do_string());
		if (debug_flag)
			printf("  set hrom_instance to %s\n", hrom_instance);
		break;

	//
	// V_INSTANCE command: Get the instance name of the VROM.
	//
	case TKN_V_INSTANCE:
		vrom_instance = strsave(do_string());
		if (debug_flag)
			printf("  set vrom_instance to %s\n", vrom_instance);
		break;

	//
	// C_INSTANCE command: Get the instance name of the CROM.
	//
	case TKN_C_INSTANCE:
		crom_instance = strsave(do_string());
		if (debug_flag)
			printf("  set crom_instance to %s\n", crom_instance);
		break;

	//
	// H_INIT_STATE command: Get a number indicating the horizontal state
	// value that will be entered by the h state machine immediately after reset.
	//
	case TKN_H_INIT_STATE:
		hrom_init_state = do_number(0, 2047);
		if (debug_flag)
			printf("  set hrom_init_state to %d\n", hrom_init_state);
		break;

	//
	// V_INIT_STATE command: Get a number indicating the vertical state
	// value that will be entered by the v state machine immediately after reset.
	//
	case TKN_V_INIT_STATE:
		vrom_init_state = do_number(0, 1024);
		if (debug_flag)
			printf("  set vrom_init_state to %d\n", vrom_init_state);
		break;
	
	//
	// PALETTE command: Marks the beginning of a palette definition block.
	// Get the name of the palette from the input buffer and then set
	// the parser state to IN_STATE_PALETTE_1 indicating that the next line
	// in the file should be the first line of a PALETTE definition which
	// must define the BLANK color for the palette.
	//
	case TKN_PALETTE:
		name = do_name();
		in_state = IN_STATE_PALETTE_1;
		new_palette(name);
		if (debug_flag)
			printf("  defining new palette named %s\n", name);
		break;

	//
	// END command: Marks the end of one of the various block definitions.
	// This command should not ever be encountered by this function. It should
	// only be encountered in the functions that are called to handle parsing
	// of the various types of blocks.
	//
	case TKN_END:
		do_error("Unexpected END encountered.\n");
		exit(1);
		break;

	//
	// HORIZONTAL_REGIONS command: This command marks the beginning of the
	// block of code that defines the horizontal regions. Set the parser
	// state to IN_STATE_HREGION so that the do_hregion_line() function
	// will be called for each line of the block.
	//
	case TKN_HREGIONS:
		in_state = IN_STATE_HREGION;
		if (debug_flag)
			printf("beginning horizontal region definitions.\n");
		break;

	//
	// VERTICAL_REGIONS command: This command marks the beginning of the
	// block of code that defines the vertical regions. Set the parser
	// state to IN_STATE_VREGION so that the do_vregion_line() function
	// will be called for each line of the block.
	//
	case TKN_VREGIONS:
		in_state = IN_STATE_VREGION;
		if (debug_flag)
			printf("beginning vertical region definitions.\n");
		break;

	//
	// LINE_FORMATS command: This command marks the beginning of the block
	// of code that defines the line formats. Set the parser state to
	// IN_STATE_FORMAT so that the do_format_line() function will be called
	// for each line of the block.
	//
	case TKN_FORMATS:
		in_state = IN_STATE_FORMAT;
		if (debug_flag)
			printf("beginning line format definitions.\n");
		break;

	//
	// Any other tokens are errors.
	//
	default:
		do_unexpected_token(cmd);
		exit(1);
		break;
	}
}
