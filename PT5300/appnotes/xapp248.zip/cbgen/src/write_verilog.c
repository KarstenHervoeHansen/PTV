//-----------------------------------------------------------------
// write_verilog.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function writes the Verilog-specific output files for the specified ROM.
// Two output files are created, one containing the block RAM initialization code
// for simulation and one containing the block RAM initialization code for synthesis.
//

#include "defs.h"

void write_verilog(
	int width,						// the width, in bits, of the ROM's output
	char *sim_filename,				// simulation file name
	char *syn_filename,				// synthesis file name
	char *instance_name,			// instance name of the ROM in the Verilog code
	ULONG init_value,				// init value for the ROM
	ULONG *rom,						// pointer to an array defining the ROM's contents
	char *timedate					// pointer to time and date string to be printed
)
{
	FILE	*f1, *f2;				// pointers to the two output files
	int		lines, words;			// counters
	int		init_fw;				// number of digits in the ROM INIT value
	int		val_fw;					// number of digits in the ROM SRVAL value
	int		words_per_line;			// number of words in each INIT line
	int		words_per_line_parity;	// number of words in each INITP line
	ULONG	parity;					// temp variable used to generate INITP lines
	int		bits;					// bit counter
	ULONG	mask;					// mask variable
	int		hrgn_bits, vrgn_bits;	// used to generate comment lines
	char	*syn_tool_name;			// name of synthesis tool


	//
	// Get the synthesis tool name for the file comment header.
	//
	syn_tool_name = get_syn_tool_name();

	//
	// Calculate the number of h_rgn code and v_rgn code bits so they can
	// be reported in the file comment header.
	//
	hrgn_bits = get_bits(max_num_hregions);
	vrgn_bits = get_bits(max_num_vregions);

	//
	// Based on the ROM output width, define these parameters that affect
	// the formatting of the initialization code.
	//
	if (width == 18)
	{
		init_fw = 5;
		val_fw = 4;
		words_per_line = 16;
		words_per_line_parity = 128;
		mask = 0x0000ffff;
	} else if (width == 9)
	{
		init_fw = 3;
		val_fw = 2;
		words_per_line = 32;
		words_per_line_parity = 256;
		mask = 0x000000ff;
	}
	else
	{
		fprintf(stderr, "Invalid width specified to write_file.\n");
		exit(1);
	}

	//
	// Open the output files
	//
	if ((f1 = fopen(sim_filename, "w")) == NULL)
	{
		fprintf(stderr, "Unable to open output file %s\n", sim_filename);
		exit(1);
	}

	if ((f2 = fopen(syn_filename, "w")) == NULL)
	{
		fprintf(stderr, "Unable to open output file %s\n", syn_filename);
		exit(1);
	}

	//
	// Write the Header, WRITE_MODE, INIT, and SRVAL parameters for the simulation file
	//
	fprintf(f1, "//\n");
	fprintf(f1, "// Initialize %s for simulation\n", instance_name);
	fprintf(f1, "// Created from input file %s on %s\n", input_filename, timedate);
	fprintf(f1, "// Number of patterns = %d, number of hregion bits = %d, number of vregion bits = %d\n",
			palettes, hrgn_bits, vrgn_bits);
	fprintf(f1, "// synopsys translate_off\n");
	fprintf(f1, "//\n");
	fprintf(f1, "defparam\n");
	fprintf(f1, "\t%s.WRITE_MODE_A = \"READ_FIRST\",\n",instance_name);
	fprintf(f1, "\t%s.WRITE_MODE_B = \"READ_FIRST\",\n",instance_name);
	fprintf(f1, "\t%s.INIT_A = %d'h%0*X,\n", instance_name, width, init_fw, init_value);
	fprintf(f1, "\t%s.INIT_B = %d'h%0*X,\n", instance_name, width, init_fw, init_value);
	fprintf(f1, "\t%s.SRVAL_A = %d'h%0*X,\n", instance_name, width, init_fw, init_value);
	fprintf(f1, "\t%s.SRVAL_B = %d'h%0*X,\n", instance_name, width, init_fw, init_value);

	//
	// Write the Header for the synthesis file
	//
	fprintf(f2, "//\n");
	fprintf(f2, "// %s initialization values for synthesis\n", instance_name);
	fprintf(f2, "// Created from input file %s on %s\n", input_filename, timedate);
	fprintf(f2, "// Formatted for %s synthesis tool.\n", syn_tool_name);
	fprintf(f2, "//\n");

	//
	// Write the synthesis tool specific WRITE_MODE, INIT, and SRVAL lines to the synthesis file
	//
	switch (synth_tool)
	{
	case XST:
		fprintf(f2, "// synthesis attribute WRITE_MODE_A of %s is \"%s\"\n", instance_name, WRITE_MODE);
		fprintf(f2, "// synthesis attribute WRITE_MODE_B of %s is \"%s\"\n", instance_name, WRITE_MODE);
		fprintf(f2, "// synthesis attribute INIT_A of %s is \"%0*X\"\n", instance_name, init_fw, init_value);
		fprintf(f2, "// synthesis attribute INIT_B of %s is \"%0*X\"\n", instance_name, init_fw, init_value);
		fprintf(f2, "// synthesis attribute SRVAL_A of %s is \"%0*X\"\n", instance_name, init_fw, init_value);
		fprintf(f2, "// synthesis attribute SRVAL_B of %s is \"%0*X\"\n", instance_name, init_fw, init_value);
		break;
	case LEONARDO:
		fprintf(f2, "// exemplar attribute %s WRITE_MODE_A %s\n", instance_name, WRITE_MODE);
		fprintf(f2, "// exemplar attribute %s WRITE_MODE_B %s\n", instance_name, WRITE_MODE);
		fprintf(f2, "// exemplar attribute %s INIT_A %0*X\n", instance_name, init_fw, init_value);
		fprintf(f2, "// exemplar attribute %s INIT_B %0*X\n", instance_name, init_fw, init_value);
		fprintf(f2, "// exemplar attribute %s SRVAL_A %0*X\n", instance_name, init_fw, init_value);
		fprintf(f2, "// exemplar attribute %s SRVAL_B %0*X\n", instance_name, init_fw, init_value);
		break;
	case SYNOPSYS:
		fprintf(f2, "/* synopsys attribute\n");
		fprintf(f2, "WRITE_MODE_A \"%s\"\n", WRITE_MODE);
		fprintf(f2, "WRITE_MODE_B \"%s\"\n", WRITE_MODE);
		fprintf(f2, "INIT_A \"%0*X\"\n", init_fw, init_value);
		fprintf(f2, "INIT_B \"%0*X\"\n", init_fw, init_value);
		fprintf(f2, "SRVAL_A \"%0*X\"\n", init_fw, init_value);
		fprintf(f2, "SRVAL_B \"%0*X\"\n", init_fw, init_value);
		break;
	case SYNPLIFY:
		fprintf(f2, "/* synthesis\n");
		fprintf(f2, "xc_props=\"WRITE_MODE_A=%s,\n", WRITE_MODE);
		fprintf(f2, "WRITE_MODE_B=%s,\n", WRITE_MODE);
		fprintf(f2, "INIT_A=%0*X,\n", init_fw, init_value);
		fprintf(f2, "INIT_B=%0*X,\n", init_fw, init_value);
		fprintf(f2, "SRVAL_A=%0*X,\n", init_fw, init_value);
		fprintf(f2, "SRVAL_B=%0*X,\n", init_fw, init_value);
		break;
	default:
		fprintf(stderr, "Unknown synthesis tool.\n");
		exit(1);
	}

	//
	// Write all the INITP_XX lines to initialize the parity bits.
	//
	for (lines = 0; lines < MAX_INITP_LINES; lines++)
	{
		// Write the line beginning for the simulation file
		fprintf(f1, "\t%s.INITP_%02X = 256'h", instance_name, lines);
		
		// Write the synthesis tool specific line beginning to the synthesis file
		switch (synth_tool)
		{
		case XST:
			fprintf(f2, "// synthesis attribute INITP_%02X of %s is \"", lines, instance_name);
			break;
		case LEONARDO:
			fprintf(f2, "// exemplar attribute %s INITP_%02X ", instance_name, lines);
			break;
		case SYNOPSYS:
			fprintf(f2, "INITP_%02X \"", lines);
			break;
		case SYNPLIFY:
			fprintf(f2, "INITP_%02X=", lines);
			break;
		}

		bits = 31;
		parity = 0;

		// Generate the parity lines in 32-bit chunks and write each chunk when completed
		for (words = (words_per_line_parity - 1); words >= 0; words--)
		{
			if (width == 9)
			{
				parity |= (((rom[lines * words_per_line_parity + words] >> 8) & 1) << bits);
				bits--;
			} else if (width == 18)
			{
				parity |= (((rom[lines * words_per_line_parity + words] >> 16) & 3) << (bits - 1));
				bits -= 2;
			}

			if (bits < 0)
			{
				fprintf(f1, "%08X", parity);
				fprintf(f2, "%08X", parity);
				bits = 31;
				parity = 0;
			}
		}

		fprintf(f1, ",\n");

		// Write the synthesis tool specific end of line information to the synthesis file
		switch (synth_tool)
		{
		case XST:
			fprintf(f2, "\"\n");
			break;
		case LEONARDO:
			fprintf(f2, "\n");
			break;
		case SYNOPSYS:
			fprintf(f2, "\"\n");
			break;
		case SYNPLIFY:
			fprintf(f2, ",\n");
			break;
		}
	}


	//
	// Write all the INIT_XX lines
	//
	for (lines = 0; lines < MAX_INIT_LINES; lines++)
	{
		// Write the line beginning for the simulation file
		fprintf(f1, "\t%s.INIT_%02X = 256'h", instance_name, lines);
		
		// Write the synthesis tool specific line beginning to the synthesis file
		switch (synth_tool)
		{
		case XST:
			fprintf(f2, "// synthesis attribute INIT_%02X of %s is \"", lines, instance_name);
			break;
		case LEONARDO:
			fprintf(f2, "// exemplar attribute %s INIT_%02X ", instance_name, lines);
			break;
		case SYNOPSYS:
			fprintf(f2, "INIT_%02X \"", lines);
			break;
		case SYNPLIFY:
			fprintf(f2, "INIT_%02X=", lines);
			break;
		}

		// Write all words of a line to the simulation and synthesis files
		for (words = (words_per_line - 1); words >= 0; words--)
		{
			fprintf(f1, "%0*X", val_fw, rom[lines * words_per_line + words] & mask);
			fprintf(f2, "%0*X", val_fw, rom[lines * words_per_line + words] & mask);
		}

		// In the simulation file, lines end with a comma except the last one which ends in a semi-colon
		fprintf(f1, "%c\n", (lines == (MAX_INIT_LINES - 1)) ? ';' : ',');

		// Write the synthesis tool specific end of line information to the synthesis file
		switch (synth_tool)
		{
		case XST:
			fprintf(f2, "\"\n");
			break;
		case LEONARDO:
			fprintf(f2, "\n");
			break;
		case SYNOPSYS:
			fprintf(f2, "\"\n");
			break;
		case SYNPLIFY:
			fprintf(f2, "%c\n", (lines == (MAX_INIT_LINES - 1)) ? '"' : ',');
			break;
		}
	}

	//
	// For the simulation file, write this line to turn translation back on
	//
	fprintf(f1, "// synopsys translate_on\n");

	//
	// Write the synthesis tool specific last line
	//
	switch (synth_tool)
	{
	case XST:
		break;
	case LEONARDO:
		break;
	case SYNOPSYS:
		fprintf(f2, "*/\n");
		break;
	case SYNPLIFY:
		fprintf(f2, "*/\n");
		break;
	}

	//
	// Close the output files.
	//
	fclose(f1);
	fclose(f2);
}