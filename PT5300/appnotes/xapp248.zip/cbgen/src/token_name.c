//-----------------------------------------------------------------
// token_name.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called with the token argument set to token
// code. The function returns a pointer to string containing the
// ASCII representation of the matching token.
//

#include "defs.h"

char *token_name(
	int token			// code for token to be found
)
{
	switch(token)
	{
	case TKN_NONE:
	case TKN_COMMENT: 
		return NULL;
		break;

	case TKN_COLOR_WIDTH:
		return "COLOR_WIDTH";
		break;

	case TKN_PALETTES:
		return "PALETTES";
		break;

	case TKN_H_TOTAL:
		return "H_TOTAL";
		break;

	case TKN_V_TOTAL:
		return "V_TOTAL";
		break;

	case TKN_H_FILENAME:
		return "HROM_FILENAME";
		break;

	case TKN_V_FILENAME:
		return "VROM_FILENAME";
		break;

	case TKN_C_FILENAME:
		return "CROM_FILENAME";
		break;

	case TKN_H_INSTANCE:
		return "HROM_INSTANCE";
		break;

	case TKN_V_INSTANCE:
		return "VROM_INSTANCE";
		break;

	case TKN_C_INSTANCE:
		return "CROM_INSTANCE";
		break;

	case TKN_H_INIT_STATE:
		return "HROM_INIT_STATE";
		break;

	case TKN_V_INIT_STATE:
		return "VROM_INIT_STATE";
		break;

	case TKN_PALETTE:
		return "PALETTE";
		break;

	case TKN_END:
		return "END";
		break;

	case TKN_BLANK:
		return "BLANK";
		break;

	case TKN_HREGIONS:
		return "HORIZONTAL_REGIONS";
		break;

	case TKN_VREGIONS:
		return "VERTICAL_REGIONS";
		break;

	case TKN_FORMATS:
		return "LINE_FORMATS";
		break;

	case TKN_TYPE0:
		return "TYPE0";
		break;

	case TKN_TYPE1:
		return "TYPE1";
		break;

	case TKN_TYPE2:
		return "TYPE2";
		break;

	case TKN_TYPE3:
		return "TYPE3";
		break;

	case TKN_TYPE4:
		return "TYPE4";
		break;

	case TKN_IS:
		return "IS";
		break;

	case TKN_TO:
		return "TO";
		break;

	case TKN_IN:
		return "IN";
		break;

	case TKN_FIELD0:
		return "FIELD0";
		break;

	case TKN_FIELD1:
		return "FIELD1";
		break;

	case TKN_ACTIVE:
		return "ACTIVE";
		break;

	case TKN_EAV:
		return "EAV";
		break;

	case TKN_SAV:
		return "SAV";
		break;

	case TKN_ASTERISK:
		return "*";
		break;

	case TKN_V_INCREMENT:
		return "V_INCREMENT";
		break;

	case TKN_ARE:
		return "ARE";
		break;

	case TKN_HBITS:
		return "HREGION_BITS";
		break;

	case TKN_VBITS:
		return "VREGION_BITS";
		break;
	}
}

