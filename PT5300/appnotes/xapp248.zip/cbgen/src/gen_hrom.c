//-----------------------------------------------------------------
// gen_hrom.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function creates the output files for the HROM. First, an
// array corresponding to the contents of the HROM is created by
// repeatedly calling hrom_entry() for each possible address in the
// HROM. Once the array has been initialized, the write_file() function
// is called to generate the HROM output files.
//

#include "defs.h"

void gen_hrom()
{
	int h;					// for loop variable
	ULONG *rom;				// pointer to the rom array
	ULONG hrom_init_value;	// default init value for HROM
	int temp;				// temporary variable


	//
	// Allocate storage for the rom array
	//
	rom = (ULONG *) xmalloc((ULONG) (MAX_H_STATES * sizeof(ULONG)));

	//
	// compute the hrom_init_state value
	//
	temp = hrom_init_state / h_divisor - 1;
	if (temp < 0)
		temp = h_total / h_divisor;

	hrom_init_value = hrom_entry(temp);

	//
	// init the entire rom array to the h_init state
	//
	for (h = 0; h < MAX_H_STATES; h++)
		*(rom + h) = hrom_init_value;

	//
	// create the contents of the HROM by calling hrom_entry() for each
	// possible address in the HROM.
	//
	for (h = 0; h < h_total / h_divisor; h++)
		*(rom + h) = hrom_entry(h);

	//
	// Call write_file() to write the HROM output files
	//
	write_file(18, hrom_sim_filename, hrom_syn_filename, hrom_instance, hrom_init_value, rom, TRUE);

	//
	// Deallocate the rom array
	//
	free(rom);

	if (debug_flag)
		printf("Done generating horizontal ROM files.\n");
}