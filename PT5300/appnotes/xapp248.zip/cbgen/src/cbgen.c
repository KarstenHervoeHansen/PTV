//-----------------------------------------------------------------
// cbgen.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This is the main routine for the cbgen utility. It performs the
// following steps:
//
// 1. Calls do_args() to parse and verify the command line arguments.
//
// 2. Initializes the parameters that control the format of the
// output files to default values in case the pattern definition
// file doesn't supply them.
//
// 3. Allocates memory for the various global structures.
//
// 4. Opens the input file.
//
// 5. Calls process_line() to read and process each line of the
// input file.
//
// 6. Generates the output file names depending on the target
// output language and format.
//
// 7. Calls gen_hrom() to create the horizontal ROM output file.
//
// 8. Calls gen_vrom() to create the vertical ROM output file.
//
// 9. Calls gen_crom() to create the component ROM output file.
//

#include "defs.h"

void main(
	int argc, 
	char *argv[]
)
{	
	PALETTE *p;				// Used to init PALETTE structures
	V_REGION *v;			// Used to init V_REGION structures
	H_REGION *h;			// Used to init H_REGION structures
	FORMAT *f;				// Used to init FORMAT structures

	int i;					// For loop variable


	//
	// Parse the command line arguments
	//

	do_args(argc, argv);

	//
	// Initialization section
	//

	inbuf = xmalloc(INPUT_BUF_SIZE);		// malloc storage for input file line buffer
	in_state = IN_STATE_ANY;				// expect any type of input line

	//
	// Set default values for parameters in case they are omitted
	// from the input file.
	//
	crom_width = 9;
	h_divisor = 4;
	v_divisor = 1;
	v_increment = DEF_V_INCREMENT;
	hrom_instance = DEF_HROM_INSTANCE;
	vrom_instance = DEF_VROM_INSTANCE;
	crom_instance = DEF_CROM_INSTANCE;
	vrom_filename = NULL;
	hrom_filename = NULL;
	crom_filename = NULL;
	color_width = 10;
	palettes = 1;
	h_total = 1716;
	v_total = 525;
	hrom_init_state = 0;
	vrom_init_state = v_total;
	max_num_hregions = DEF_NUM_HREGIONS;
	max_num_vregions = DEF_NUM_VREGIONS;
	max_hregion_code = 15;
	max_vregion_code = 15;

	in_linenum = 0;			// Init input file line counter to zero

	if (debug_flag)
		printf("Done parsing input arguments, initializing data structures.\n");

	//
	// Allocate memory for, initialize, and init pointers to the structures
	//
	palt = (PALETTE *) xmalloc((ULONG) sizeof(PALETTE) * MAX_PALETTES);
	for (p = palt; p < palt + MAX_PALETTES; p++)
	{
		p->name = NULL;
		p->num_colors = 0;
		for (i = 0; i < MAX_COLORS; i++)
			p->color[i].name = NULL;
	}
	current_palette = NULL;

	v_regions = (V_REGION *) xmalloc((ULONG) sizeof (V_REGION) * MAX_VREGIONS);
	for (v = v_regions; v < v_regions + MAX_VREGIONS; v++)
	{
		v->code = -1;
		for (i = 0; i < MAX_PALETTES; i++)
			v->format[i] = NULL;
	}
	current_vregion = NULL;

	h_regions = (H_REGION *) xmalloc((ULONG) sizeof (H_REGION) * MAX_HREGIONS);
	for (h = h_regions; h < h_regions + MAX_HREGIONS; h++)
		h->code = -1;
	current_hregion = NULL;

	formats = (FORMAT *) xmalloc((ULONG) sizeof (FORMAT) * MAX_FORMATS);
	for (f = formats; f < formats + MAX_FORMATS; f++)
	{
		f->name = NULL;
		f->palette = NULL;
		for (i = 0; i < (MAX_ACTIVE_HREGIONS); i++)
			f->color[i] = NULL;
	}
	current_format = NULL;

	if (debug_flag)
		printf("Done initing data structures, opening input file.\n");

	//
	// Open the input file.
	//
	if ((infd = fopen(input_filename, "r")) == NULL)
	{
		fprintf(stderr, "Error opening input file %s\n", input_filename);
		exit(1);
	}

	if (debug_flag)
		printf("Opened input file.\n");

	//
	// Call process_line() for each line of the input file until the
	// end of the file is reached.
	//
	while(process_line() != EOF);

	fclose(infd);

	//
	// Generate the output file names.
	//
	if (language == VERILOG || language == VHDL)
	{
		vrom_sim_filename = make_filename(vrom_filename, DEF_VROM_FILENAME, "_sim");
		vrom_syn_filename = make_filename(vrom_filename, DEF_VROM_FILENAME, "_syn");
		hrom_sim_filename = make_filename(hrom_filename, DEF_HROM_FILENAME, "_sim");
		hrom_syn_filename = make_filename(hrom_filename, DEF_HROM_FILENAME, "_syn");
		crom_sim_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "_sim");
		crom_syn_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "_syn");
		cromls_sim_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "_ls_sim");
		cromls_syn_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "_ls_syn");
	}
	else if (language == XDL)
	{
		vrom_syn_filename = make_filename(vrom_filename, DEF_VROM_FILENAME, "");
		hrom_syn_filename = make_filename(hrom_filename, DEF_HROM_FILENAME, "");
		crom_syn_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "");
		cromls_syn_filename = make_filename(crom_filename, DEF_CROM_FILENAME, "_ls");
	}

	//
	// Create the output files.
	//
	gen_hrom();
	gen_vrom();
	gen_crom((ULONG) (max_num_hregions * max_num_vregions * NUM_SAMPLES * palettes), crom_width);

	printf("cbgen successfully created all ROM files.\n\n");
}


