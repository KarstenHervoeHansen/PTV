//-----------------------------------------------------------------
// do_name.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called when the parser is expecting a user supplied
// name. The function called find_token() to skip past all whitespace
// characters. Then, check_token() is called to determine if the token
// matches a reserved keyword. If the keyword IS, IN, or TO is found
// it is ignored and the next keyword is found. Any other reserved
// keywords cause an error.
//
// If a non keyword string is found, it is will be copied into a
// temporary buffer, the current parser position in the input buffer
// will be advanced to the first whitespace character after the name
// string, and a pointer to the temporary name buffer will be returned
// by the function.
//

#include "defs.h"

char *do_name()
{
	char *s;					// temp string pointer
	char c;						// temp char storage
	int tkn;					// holds value returned by check_token()
	static char *name = NULL;	// temporary buffer to hold parsed name string

	//
	// The first time this function is called, malloc memory for the name
	// buffer.
	//

	if (name == NULL)
		name = xmalloc(129);

	//
	// Call find_token() to skip past all whitespace characters then call
	// check_token() to see if the token is a reserved word. If the token
	// is IS, IN, or TO, ignore it and repeat the above process. If any
	// other reserved word is found, exit with an error. Otherwise, we
	// have found a name string.
	//
	do
	{
		if ((s = find_token(NULL)) == NULL)
		{
			do_error("Expecting a name after keyword.");
			exit(1);
		}

		tkn = check_token(s);

		if (tkn != TKN_IS && tkn != TKN_IN && tkn == TKN_TO && tkn != TKN_NOT_A_KEYWORD)
		{
			do_error("Unexpected keyword when looking for a name.\n");
			exit(1);
		}

	} while (tkn != TKN_NOT_A_KEYWORD);

	//
	// Copy the string to the name buffer. End of the name is the first whitespace
	// character encountered.
	//
	if (sscanf(s, "%128s", name) != 1)
	{
		do_error("Expecting a name after key word.\n");
		exit(1);
	}

	//
	// Advance get_next_char pointer past string.
	//
	do
		c = *get_next_char(NULL);
	while (!isspace(c));

	//
	// Return a pointer to the name buffer.
	//
	return name;
}
