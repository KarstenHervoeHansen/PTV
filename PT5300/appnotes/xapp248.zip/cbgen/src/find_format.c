//-----------------------------------------------------------------
// find_format.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This functin searches through the list of line formats for
// one that matches the supplied name in the indicated palette.
// Returns a pointer to the matching FORMAT struct if found,
// otherwise returns a value of NULL.
//

#include "defs.h"

FORMAT *find_format(
	PALETTE *palette,		// Palette to match
	char *name				// Name of format to match
)
{
	FORMAT *p;				// Temp FORMAT pointer

	//
	// Look sequentially through all the FORMAT structs to find
	// a match.
	//
	for (p = formats; p < formats + num_formats; p++)
	{
		if (p != NULL && (strcmp(name, p->name) == 0) && p->palette == palette)
			return p;
	}

	//
	// No match found, so return NULL.
	//
	return NULL;
}

