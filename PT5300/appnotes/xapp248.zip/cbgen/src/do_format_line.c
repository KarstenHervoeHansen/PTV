//-----------------------------------------------------------------
// do_format_line.c
//
// name of module
//
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called by process_line() when the parser is expecting
// the input buffer to contain a line in the LINE_FORMATS block. There are
// only three valid types of lines inside of a LINE_FORMATS block: a blank
// or comment line, and END command line to end the block, or a line format
// defintion.
//
// Blank or comment only lines are ignored.
//
// An END command line will cause the parser state to be set to IN_STATE_ANY
// indicating that the parser is no longer in the LINE_FORMATS block.
//
// A line format definition must begin with the name of the format followed
// by an (optional) IN token and a the name of the paletted to be used. Following
// the palette name comes a series of color assignments in which each horizontal
// region code is assigned to a color. Each active horizontal region code must
// be assigned to a valid color in the palette. The syntax for each horizontal
// region code color assignment is:
//
// <h_rgn_code> IS <color_name>
//
// Multiple consecutive codes can be assigned to the same color with this
// alternate syntax:
//
// <h_rgn_code> TO <h_rgn_code> ARE <color_name>
//

#include "defs.h"

void do_format_line()
{
	int tkn;						// Holds the token value returned by get_token()
	FORMAT *p;						// Pointer to FORMAT struct to be defined
	char *s;						// Temp string pointer
	PALETTE *palette;				// Pointer to the PALETTE referenced by format definition
	COLOR *color;					// Pointer to the COLOR referenced by format defintion
	H_REGION *hregion;				// Ponter to the H_REGION referened by format definition
	int clr;						// Index into COLOR array in PALETTE
	int iterations;					// Number of consecutive h_regions with the same color
	int i;							// For loop variable
	int start, end;					// Starting and ending region codes for multiple code assignment

	//
	// Scan for the next token on the line
	//
	tkn = get_token(inbuf);

	//
	// If there are no tokens on the line or the next token is the
	// comment character, then ignore the line.
	//
	if (tkn == TKN_NONE || tkn == TKN_COMMENT)
		return;

	//
	// If the next token is END, then we are done processing the formats.
	//
	if (tkn == TKN_END)
	{
		in_state = IN_STATE_ANY;
		num_formats = (current_format - formats) + 1;
		return;
	}

	//
	// Not blank and not END, so it must be a format definition. Check that the
	// number of formats doesn't exceed the maximum then assign the current_format
	// pointer to the format struct to be defined.
	//
	if (current_format == NULL)
		current_format = formats;
	else
		current_format++;

	p = current_format;

	if (p - formats >= MAX_FORMATS)
	{
		do_error("Attempt to define too many line formats.\n");
		exit(1);
	}

	if (debug_flag)
		printf("  line format ");

	//
	// Get the name string from the input buffer.
	//
	if (tkn == TKN_NOT_A_KEYWORD)
		p->name = strsave(do_name());

	//
	// Get the next token. If it is IN, discard. Otherwise, we are expecting
	// a name of a palette. Get that name and find the matching palette struct.
	tkn = get_token(NULL);

	if (tkn == TKN_IN)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD || (s = do_name()) == NULL)
	{
		do_error("Expected a palette name.");
		exit(1);
	}

	if ((palette = find_palette(s)) == NULL)
	{
		do_error("Palette name doesn't match a defined palette.");
		exit(1);
	}

	p->palette = palette;

	if (debug_flag)
		printf("%s in %s is ", p->name, palette->name);

	clr = 0;

	//
	// Color formats are:
	//
	// h_region_code IS color_name
	// h_region_code TO h_region_code ARE color_name
	//
	do {

		//
		// Get the horizontal region code
		//
		if (tkn != TKN_NOT_A_KEYWORD)
			break;

		start = do_number(0, max_hregion_code);

		if ((hregion = get_hregion((int) start)) == NULL)
		{
			do_error("Undefined horizontal region code.\n");
			exit(1);
		}

		end = start;

		//
		// If the next token is TO, then we need to get the range value
		//
		tkn = get_token(NULL);

		if (tkn == TKN_TO)
		{
			tkn = get_token(NULL);

			if (tkn != TKN_NOT_A_KEYWORD)
			{
				do_error("Expecting a horizontal region code number after keyword TO.\n");
				exit(1);
			}

			end = do_number(0, max_hregion_code);

			if ((hregion = get_hregion((int) end)) == NULL)
			{
				do_error("Undefined horizontal region code.\n");
				exit(1);
			}
		}
		

		//
		// Consume an optional IS or ARE token.
		//
		tkn = get_token(NULL);

		if (tkn == TKN_IS || tkn == TKN_ARE)
			tkn = get_token(NULL);


		//
		// Next should be the color name
		//
		if ((s = do_name()) == NULL)
		{
			do_error("Expecting color name.");
			exit(1);
		}
		
		if ((color = find_color(palette, s)) == NULL)
		{
			fprintf(stderr, "Undefined color name %s\n", s);
			do_error("Color name is not the name of a defined color.");
			exit(1);
		}

		iterations = end - start + 1;
		
		for (i = 0; i < iterations; i++)
		{
			if (debug_flag)
				printf("%s ", color->name);
			p->color[clr++] = color;
		}

		tkn = get_token(NULL);
		
	} while (clr < (max_num_hregions - 3));

	if (debug_flag)
	{
		printf("\n");
	}
}
