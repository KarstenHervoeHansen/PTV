//-----------------------------------------------------------------
// gen_vrom.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function creates the output files for the VROM. First, an
// array is created that matches the contents of the VROM by repeatedly
// calling the vrom_entry() function to calculate the contents for each
// location in the VROM. Then, the write_file() function is called to
// write the VROM output files.
//

#include "defs.h"

void gen_vrom()
{
	int v;					// for loop variable
	ULONG *rom;				// pointer to the rom array
	ULONG vrom_init_value;	// default init value for VROM
	int init_state;			// used to calculate vrom_init_state

	//
	// vrom_init_state specifies the state that the user wishes to reset to.
	// When calling vrom_entry to determine the rom value for that state, we
	// must supply the preceeded state number. Subtract one from the state
	// number and wrap back v_total if we underflow the starting state.
	//
	init_state = vrom_init_state - 1;
	if (init_state <= 0)
		init_state = v_total;

	vrom_init_value = vrom_entry(init_state);

	//
	// allocate space for the ROM array
	//
	rom = (ULONG *) xmalloc((ULONG) (MAX_V_STATES * sizeof(ULONG)));

	//
	// init the entire rom to the v_init state
	//
	for (v = 0; v < MAX_V_STATES; v++)
		*(rom + v) = vrom_init_value;

	//
	// create the contents of the ROM
	//
	for (v = 1; v <= v_total / v_divisor; v++)
		*(rom + v) = vrom_entry(v);

	//
	// write the files
	//
	write_file(18, vrom_sim_filename, vrom_syn_filename, vrom_instance, vrom_init_value, rom, FALSE);

	//
	// deallocate storage for the rom array
	//
	free(rom);

	if (debug_flag)
		printf("Done generating vertical ROM files.\n");
}