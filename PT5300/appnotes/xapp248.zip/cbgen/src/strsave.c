//-----------------------------------------------------------------
// strsave.c
//
//
// This function is from UNIX Tool Building by Kenneth Ingham. The
// code may be freely copied , as long as it is not sold for profit
// and the copyright and author notices remain intact.
//
// Kenneth Ingham
// Copyright (c) 1988 The University of New Mexico
//
//
//

//
// This function allocates memory to store a string, copies the string
// to the allocated memory, and returns a pointer to the new copy of the
// string.
//

#include "defs.h"

char *strsave(
	char *s
)
{
	if (s == NULL)
		return NULL;
	else 
		return strcpy(xmalloc((unsigned)strlen(s)+1),s);
}


