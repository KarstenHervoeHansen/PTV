//-----------------------------------------------------------------
// do_vregion_line.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function is called by the parser to parse a line in the
// VERTICAL_REGIONS block. Three line types are allowed: blank
// or comment lines which are ignored, the END command line which
// ends the VERTICAL_REGIONS block, and vertical region definition
// lines.
//
// A vertical region definition line has the following format:
//
// <vrgn_code> IS <start> TO <end> IN <field> <type> <palette_name> IS <format_name>
//
// If two palettes have been defined, then there must be two palette_name to format_name
// assignments.
//

#include "defs.h"

void do_vregion_line()
{
	int tkn;			// Contains the token code returned by get_token()
	V_REGION *p;		// Points to V_REGION being defined

	//
	// Scan for the next token on the line
	//
	tkn = get_token(inbuf);

	//
	// If there are no tokens on the line or the next token is the
	// comment character, then ignore the line.
	//
	if (tkn == TKN_NONE || tkn == TKN_COMMENT)
		return;

	//
	// If the next token is END, then we are done processing the v_regions.
	//
	if (tkn == TKN_END)
	{
		in_state = IN_STATE_ANY;
//		num_vregions = (current_vregion - v_regions) + 1;
		return;
	}

	//
	// Not blank and not END, so it must be a v_region definition. Check that the
	// number of formats doesn't exceed the maximum then assign the current_vregion
	// pointer to the v_region struct to be defined.
	//
	if (current_vregion == NULL)
		current_vregion = v_regions;
	else
		current_vregion++;

	p = current_vregion;

	if (p - v_regions >= MAX_VREGIONS)
	{
		do_error("Attempt to define too many vertical regions.\n");
		exit(1);
	}


	//
	// Get the region code value from the input buffer
	//
	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected a vertical region code value.");
		exit(1);
	}

	p->code = do_number(0, max_vregion_code);


	//
	// Get the next token. If it is IS, discard. Otherwise, we are expecting
	// a number that is the starting sample number of the region.
	tkn = get_token(NULL);

	if (tkn == TKN_IS)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected the starting position of the horizontal region.");
		exit(1);
	}

	p->start = do_number(1, v_total);

	//
	// Consume an optional TO token then get the ending sample number.
	//
	tkn = get_token(NULL);

	if (tkn == TKN_TO)
		tkn = get_token(NULL);

	if (tkn != TKN_NOT_A_KEYWORD)
	{
		do_error("Expected the starting position of the horizontal region.");
		exit(1);
	}

	p->end = do_number(1, v_total);

	//
	// Consume an optional IN then get the FIELD number token.
	//
	tkn = get_token(NULL);

	if (tkn == TKN_IN)
		tkn = get_token(NULL);

	if (tkn == TKN_FIELD0)
		p->field = 0;
	else if (tkn == TKN_FIELD1)
		p->field = 1;
	else
	{
		do_error("Expected a FIELDn value.");
		exit(1);
	}

	//
	// Next thing should be ACTIVE or BLANK
	//
	tkn = get_token(NULL);

	switch (tkn)
	{
		case TKN_ACTIVE:
			p->type = ACTIVE;
			break;

		case TKN_BLANK:
			p->type = BLANK;
			break;

		default:
			do_error("Expecting a vertical region type [ACTIVE or BLANK].\n");
			exit(1);
			break;
	}

	//
	// If vregion is not a BLANK region, then parse one or two format descriptions, 
	// depending on how many palettes are in use.
	//
	p->format[0] = NULL;
	p->format[1] = NULL;

	if (p->type == ACTIVE)
	{
		p->format[0] = parse_palt_frmt();

		if (palettes == 2)
			p->format[1] = parse_palt_frmt();
	
	}
	
	if (debug_flag)
	{
		printf("  set vregion code %d: start %d, end %d, ", p->code, p->start, p->end);
		switch (p->type)
		{
		case ACTIVE:
			printf("ACTIVE");
			break;
		case BLANK:
			printf("BLANK");
			break;
		}
		if (p->type == ACTIVE)
		{
			printf(", %s format is %s", p->format[0]->palette->name, p->format[0]->name);
			if (palettes == 2)
				printf(",  %s format is %s", p->format[1]->palette->name, p->format[1]->name);
		}
		printf("\n");
	}

}
