//-----------------------------------------------------------------
// find_color.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function will search through the list of COLORs defined in a
// PALETTE for one whose name matches the string pointed to by the
// name argument. It will return a pointer to the matching COLOR
// struct or NULL if no match is found.


#include "defs.h"

COLOR *find_color(
	PALETTE *palette,		// PALETTE to search for matching color
	char *name				// Name of color to search for
)
{
	int i;					// for loop variable

	//
	// If the PALETTE pointer is NULL, then just return NULL.
	//
	if (palette == NULL)
		return NULL;

	//
	// Search through all the defined COLOR structs in the PALETTE
	// for a match. Return a pointer to the matching COLOR struct if
	// found.
	for (i = 0; i < palette->num_colors; i++)
		if (palette->color[i].name != NULL && strcmp(name, palette->color[i].name) == 0)
			return &(palette->color[i]);

	//
	// No match found, so return NULL.
	//
	return NULL;
}
