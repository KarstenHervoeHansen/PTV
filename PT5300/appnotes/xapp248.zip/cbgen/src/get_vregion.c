//-----------------------------------------------------------------
// get_vregion.c
//
//
//                  Author: John F. Snow
//                  Staff Applications Engineer
//
//                  Video Applications
//                  Advanced Products Group
//                  Xilinx, Inc.
//
//                  Copyright (c) 2001 Xilinx, Inc.
//                  All rights reserved
//
//                  Date:   Nov. 20, 2001
//
//                  RESTRICTED RIGHTS LEGEND
//
//      This software has not been published by the author, and 
//      has been disclosed to others for the purpose of enhancing 
//      and promoting design productivity in Xilinx products.
//
//      Therefore use, duplication or disclosure, now and in the 
//      future should give consideration to the productivity 
//      enhancements afforded the user of this code by the author's 
//      efforts.  Thank you for using our products !
//
// Disclaimer:  THESE DESIGNS ARE PROVIDED "AS IS" WITH NO WARRANTY 
//              WHATSOEVER AND XILINX SPECIFICALLY DISCLAIMS ANY 
//              IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
//              A PARTICULAR PURPOSE, OR AGAINST INFRINGEMENT.
//
// Revision:
//          Nov. 20, 2001     Version 1.0 Released
//
//

//
// This function scans the array of V_REGION structs to find the first
// one that has a vertical region code matching the supplied argument.
// It returns a pointer to the matching V_REGION or NULL if no match
// was found.
//
// This function should not be confused with the similar function
// find_vregion() which searches the array of V_REGION structs for a
// vertical region containing a specified vertical line number.
//

#include "defs.h"

V_REGION *get_vregion(
	ULONG code				// vertical region code to be matched
)
{
	V_REGION *p, *t;		// temp pointers

	p = v_regions;
	t = NULL;

	while ((p - v_regions) < MAX_VREGIONS && p->code != -1 && t == NULL)
		if (p->code == (int) code)
			t = p;
		else
			p++;

	return t;
}