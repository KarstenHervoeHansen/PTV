/***************************************************************************/
/*  Copyright   ProTeleVision Technologies A/S, BRONDBY 1998               */
/*  Project:    PT5230 Digital Video Generator                             */
/*  Module:     MENUB.C                                                    */
/*  Author:     Kim Engedahl, DEV                                          */
/*  Org. date:  27.07.2005: JK                                             */
/*  Rev. date:                                                             */
/*  Status:     Version xx                                                 */
/*                                                                         */
/*  This was introduced because of too big size of module menu.c, which   */
/*  was increased due to new menu intems introduced (TLG and HDTPG).       */
/*  Linker gave an error due to too big module.                            */
/***************************************************************************/
#include <xa.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mas.h"

#include "menutree.h"
#include "menu.h"
#include "menuhlp.h"
#include "message.h"
#include "timing.h"
#include "disp_drv.h"
#include "cont_drv.h"
#include "keyb_drv.h"
#include "text.h"
#include "tables.h"
#include "util.h"
#include "serial1.h"
#include "unit_drv.h"
#include "iic.h"
#include "rs232par.h"
#include "rs232err.h"
#include "xaexprt.h"
#include "xadrivr.h"

static char tbuff[80];     /* temporary buffer used for printing messages */
                           /* for test purposes                           */
near UC DLTPGNoNdx;                         //     -"-     DLTPG sub menu item
near UC DLTPGsubmenuNdx[MaxDLTPGUnits];     //     -"-     DLTPG menu item

near UC DLTPGTextMenuNdx[MaxDLTPGUnits];    //     -"-     DLTPG text 2ndmenu item
near UC DLTPGAudioMenuNdx[MaxDLTPGUnits];   //     -"-     DLTPG audio 2ndmenu item

// Temporary variables PRIVATE NOT overlayable

extern char TextBuffer[17];      // Temp. text buffers

extern UC ErrorCode;             // Temporary error code, 8 BIT
                                 //  ErrorType + ErrorNo

extern near UC UcharVal;                // Temp. unsigned char value
extern near UC UcharVal1;        //  do.
extern near UC UcharVal2;        //  do.
extern near UC UcharVal3;        //  do.

extern near UI UintVal;          // Temp. unsigned integer value

extern near int IntVal;          // Temp. integer value

extern near UL UlongVal;         // Temp. unsigned long value

extern UC* near UcharPtr;        // Temp. pointer to unsigned char

extern code char* near CodePtr;  // Temp. pointer to text arrays in CODE
extern char* near TxtPtr;        // Temp. pointer to text arrays in DATA


UC   FindNextDL(char, char *);



/***************************** PT8603 **************************************/
/***************************************************************************/
/*  PT8603SDITPGTextDown                                           MENU.C  */
/*                                                                         */
/* Author:   JK                                                            */
/* Revised:  20.11.2006                                                    */
/*                                                                         */
/* Purpose:  Go to the selected item in the SDI-TPGx/TEXT submenu in case  */
/*           of PT8603 (this is PT8603 specific function)                  */
/*                                                                         */
/* Remarks:  This function in enterd each time user has selected TEXT on   */
/*           SDITPG menu and board is PT8603.                              */
/* Returns:  Nothing.                                                      */
/* Updates:  TBD                                                           */
/***************************************************************************/
void PT8603SDITPGTextDown()
  {
  UC ndx = BaseNdx - SDITPG1Item, itemNdx = SDITPGTextNdx[ndx];

  WriteCodeLN1(0, SecondmnuHdrTxt);      // Write second menu header
  WriteCode1(SlashDotHdrTxt);            //  on line 1 = "../";

  WriteCode1(PT8603TPGtext_menu[itemNdx].ItemTxt);

  ClearRestLN1();

  switch (itemNdx)
    {
    case PT8603EditItem:                  // Prepare for text editing
      UcharVal1 = 0;
      UcharVal2 = 2;
      UcharVal  = UcharVal1;
      // Copy first string to temp. buffer
      strcpy(TextBuffer, SDITPGConfig[ndx].Text[UcharVal]);

      if (UintVal = strlen(TextBuffer))  // Position in Text string
        UintVal--;
      break;
    case PT8603OnOffItem:
      UcharVal = SDITPGConfig[ndx].TextEnable;     // Get text ON/OFF 
      break;
    case PT8603MovementItem:
      UcharVal = SDITPGConfig[ndx].TextMovement;   // Get SDI text movement
      break;
    case PT8603TextPosItem:
      UcharVal  = SDITPGConfig[ndx].TextPos[0][0];   // Get SDI text X pos
      UcharVal1 = SDITPGConfig[ndx].TextPos[0][1];   // Get SDI text Y pos
      break;
    }
  PrevPtr      = Ptr;                          // Store old menu-pointer
  Ptr          = &PT8603TPG_submenu[itemNdx];  // Point to selected item
  FuncState    = 1;                            // Prepare for item statemachine
  FuncTriggers = 0;
  FuncSave     = FuncEscape = FALSE;
  SelectModeOn = TRUE;
  }

/***************************************************************************/
/*  PT8603TextEditSelect                                           MENU.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 980224                                    */
/* Revised:   990305                                                       */
/*                                                                         */
/*  Function: Edit a text in a SDI-TPG.                                    */
/*  Remarks:  SDI-TPGx/TEXT MENU function.                                 */
/*          Cursor position on line 2 is updated.                          */
/*          UcharVal     LineNumber 0-2                                    */
/*          UcharVal1    Min. LineNumber                                   */
/*          UcharVal2    Max. LineNumber                                   */
/*          UcharVal3    Text Enable ON/OFF (Not used here)                */
/*          UintVal      Position in text buffer                           */
/*  Returns:    --                                                         */
/*  Updates:    TBD                                                        */
/*  This function is taken from PT5230 Master and modified                 */
/***************************************************************************/
void PT8603TextEditSelect()
  {
  UC tmp;
  UC ndx = BaseNdx - SDITPG1Item;


#if 0
   sprintf(tbuff, "PT8603TextEditSelect: UcharVal = %d\n", (int)UcharVal);
   Udr_PutNChar(tbuff);
#endif

  if (FuncEscape)
    {
    CharBlinkLN2(0, OFF);           // Switch off possible blinking

    SelectModeOn = FALSE;           // Clear select-mode

    Ptr = PrevPtr;                  // Set pointer to previous menu
    Ptr->DispFunct();               // Display previous menu
    return;
    }

  if (FuncSave)
    {                         // If textinfo has changed..
    FuncSave = FALSE;
    ActivePresetNo = 0;       // Clear possible preset
                              // Save the new text
    strcpy(SDITPGConfig[ndx].Text[UcharVal], TextBuffer);

    // Save text enable information
    //SDIConfig.TextOn &= ~(1 << UcharVal);
    //SDIConfig.TextOn |= (UcharVal3 << UcharVal);

    tmp = (UcharVal % 3) + 1;          // Calculate line number

    // Transmit text line enable
    //ErrorCode = TrxSDITPGTextLineEnable(ndx, tmp, UcharVal3);

    // Transmit text line string
    ErrorCode = TrxSDITPGText(ndx, tmp, TextBuffer);

    if (ErrorCode)
      {
      GotoErrorStatus(ErrorCode);
      return;
      }
    }
                              // Select line to edit
  if (FuncTriggers & 0x03)
    {                                  // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                                // If button pressed is UP..
      if (UcharVal-- == UcharVal1 )
        UcharVal = UcharVal2;
      }                                // ..button pressed is DOWN
    else
      {
      if (UcharVal++ == UcharVal2)
        UcharVal = UcharVal1;
      }                          // Copy selected text to temp.
                                 //  text buffer
    strcpy(TextBuffer, SDITPGConfig[ndx].Text[UcharVal]);

    if (UintVal = strlen(TextBuffer))    // Find position in string
      UintVal--;
    FuncState = 1;
    }
                              // Select position in TextBuffer
  if (FuncTriggers & 0xC0)
    {                         // If LEFT/RIGHT button pressed..
    if (FuncTriggers & 0x40)
      {                       // If button pressed is LEFT..
      TextBuffer[UintVal] = 0;// Delete character

      if (UintVal)            // Decrement pointer to last
        UintVal--;            //  character
      }
    else
      {                       // ..button pressed is RIGHT
      tmp = 31;               // Max. 32 characters in PT8602/3; 15 orig

      if ((UintVal < tmp) && (UintVal < strlen(TextBuffer)))
        UintVal++;
      }
    }
  // Select character in TextBuffer
  if (FuncTriggers & 0x30)
    {                             // If UP/DOWN button pressed..
    if (TextBuffer[UintVal] == 0) // if we are at the end of string....
      {                           // If text insert..
      TextBuffer[UintVal]   = TextBuffer[UintVal-1]; //  set new character = previous
      TextBuffer[UintVal+1] = 0;
      }

    if (TextBuffer[UintVal] == 0)
      TextBuffer[UintVal] = '-';

                       /* FindNextASCII(UC Direction,   UC LimitedType, char ASCIIChar) */
    TextBuffer[UintVal] = FindNextASCII((FuncTriggers & 0x10), TRUE, TextBuffer[UintVal]);
    }

  CodePtr = PT8603TextEditArrTxt[UcharVal % 3]; /* L1, L2 or L3 */

  WriteCodeLN2(0, CodePtr);        // Write PT8603 text on line 2
  ClearRestLN2();

  WriteTxtLN2(2, ": ");            // 5 orig

  /* As we now have text with max length of 32 chars, we must implement horizontal */
  /* scroll of text displayed on the second line, otherwise there is no place for  */
  /* all <SAVE><ESC>.  Displayed text will have max 24 chars visible, if user      */
  /* enters more chars, text will be scrolled left, so that last visible char is   */
  /* at position (24+4).  Variable tmp is used to hold character number which is   */
  /* visible on the left side of displayed text.                                   */

  if (strlen(TextBuffer) > 24)    /* if text is longer than 24 chars....           */
    tmp = strlen(TextBuffer) - 24;/* displayed char on left side is tmp            */
  else
    tmp = 0;                      /* otherwise, 0-th char is displayed on left side*/


  /**********  Display text  **************************************/
  WriteTxtLN2(4, &TextBuffer[tmp]);
  /****************************************************************/

  WriteTypeDK_SAVE_ESC(FuncState);         // Write the SAVE ESC text

#if 0
   sprintf(tbuff, "FuncState = %d\n", (int)FuncState);
   Udr_PutNChar(tbuff);
#endif

  switch (FuncState)
    {
    case 1:
    case 3:
      WriteItemArrows(4, strlen(&TextBuffer[tmp])); // 7 orig
      CharBlinkLN2(0, OFF);          // Switch OFF blinking
      break;

    case 7:
    case 8:
      WriteItemBrackets(4, strlen(&TextBuffer[tmp])); // 7 orig
      CharBlinkLN2(4 + UintVal - tmp, ON); // Switch ON blinking at; 7 orig
      break;                               // edited character
    }
  FuncTriggers = 0;                  // Reset the button-selection
  }


/***************************************************************************/
/* PT8603TextOnOffSelect                                           MENU.C  */
/*                                                                         */
/* Author:    JK                                                           */
/* Revised:   05.10.2004                                                   */
/*                                                                         */
/*  Function:                                                              */
/*                                                                         */
/***************************************************************************/
void PT8603TextOnOffSelect()
  {
  UC ndx = BaseNdx - SDITPG1Item;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;

      SDITPGConfig[ndx].TextEnable = UcharVal;

      if (ErrorCode = TrxSDITPGTextLineEnable(ndx, 1, UcharVal))
        {
        GotoErrorStatus(ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;             // Clear select-mode

    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                              // If UP/DOWN button pressed..
    if (UcharVal == ON)        //  toggle between ON & OFF
      UcharVal = OFF;
    else
      UcharVal = ON;

    if (UcharVal == SDITPGConfig[ndx].TextEnable)  // If actual TextOn..
      FuncState = 1;                   //  remove SAVE option
    }

  WriteCodeLN2(0, SelectHdrTxt);

  CodePtr = OffOnArrTxt[UcharVal];    // Get text for on/off selection...
  WriteCode2(CodePtr);

  ClearRestLN2();

  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));  // Mark selected item

  FuncTriggers = 0;                  // Reset the button-selection
  }

/***************************************************************************/
/* PT8603TextMovementSelect                                        MENU.C  */
/*                                                                         */
/* Author:    JK                                                           */
/* Revised:   05.10.2004                                                   */
/*                                                                         */
/*  Function:                                                              */
/*                                                                         */
/***************************************************************************/
void PT8603TextMovementSelect()
  {
  UC ndx = BaseNdx - SDITPG1Item;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;

      SDITPGConfig[ndx].TextMovement = UcharVal;

      ErrorCode = SndInt(SDITPGUnit[ndx].Address, "SH", SDITPGConfig[ndx].TextMovement);  // new for 8603: text move

      if (ErrorCode)
        {
        GotoErrorStatus(ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;             // Clear select-mode

    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                              // If UP/DOWN button pressed..
    if (UcharVal == ON)        //  toggle between ON & OFF
      UcharVal = OFF;
    else
      UcharVal = ON;

    if (UcharVal == SDITPGConfig[ndx].TextMovement)  // If actual mov..
      FuncState = 1;                   //  remove SAVE option
    }

  WriteCodeLN2(0, SelectHdrTxt);

  CodePtr = OffOnArrTxt[UcharVal];    // Get text for selected system
  WriteCode2(CodePtr);

  ClearRestLN2();

  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));  // Mark selected item

  FuncTriggers = 0;                  // Reset the button-selection
  }


/***************************************************************************/
/*  PT8603TextPosSelect                                            MENU.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 000508                                    */
/* Revised:    000608                                                      */
/*                                                                         */
/*  Function:  Select the text positioning in a SDI-TPG.                   */
/*  Remarks:    SDI-TPGx/TEXT MENU function.                               */
/*          Cursor position on line 2 is updated.                          */
/*  Returns:    --                                                         */
/*  Updates:    TBD                                                        */
/*  UcharVal  = SDITPGConfig[ndx].TextPos[0][0];   // Get SDI text X pos   */
/*  UcharVal1 = SDITPGConfig[ndx].TextPos[0][1];   // Get SDI text Y pos   */
/*                                                                         */
/***************************************************************************/
void PT8603TextPosSelect()
  {
  UC patternType;
  UC ndx = BaseNdx - SDITPG1Item;
  UC Xpos, Ypos, tmp;


  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If text position has changed..
      ActivePresetNo = 0;
                              // Save new text positioning
      SDITPGConfig[ndx].TextPos[0][0] = UcharVal;
      SDITPGConfig[ndx].TextPos[0][1] = UcharVal1;
      }
    else
      {                      // ..restore text style
      if ((UcharVal != SDITPGConfig[ndx].TextPos[0][0]) ||
         (UcharVal1 != SDITPGConfig[ndx].TextPos[0][1]))
        {
        Xpos = SDITPGConfig[ndx].TextPos[0][0];
        Ypos = SDITPGConfig[ndx].TextPos[0][1];

        if (SDITPGConfig[ndx].System == SDI625)
          tmp = 22*Ypos+8;
        else
          tmp = 18*Ypos+6;

        ErrorCode = SndInt3(SDITPGUnit[ndx].Address, "SJ", (UI)1, (UI)(4 + Xpos * 2), (UI)tmp);

        if (ErrorCode)
          {
          GotoErrorStatus(ErrorCode);
          return;
          }
        }
      }
    SelectModeOn = FALSE;            // Clear select-mode

    Ptr = PrevPtr;                  // Set pointer to previous menu
    Ptr->DispFunct();                // Display previous menu
    return;
    }

  if (FuncTriggers & 0x03)
    {          // If button pressed is UP/DOWN..
    if (FuncTriggers & 0x01)
      {        // If button pressed is UP..
      if (UcharVal++ == PT8603XPosMax)
        UcharVal = PT8603XPosMin;
      }
    else
      {                      // ..button pressed is DOWN
      if (UcharVal-- == PT8603XPosMin)
        UcharVal = PT8603XPosMax;
      }
                              // Save new text positioning
    if ((UcharVal == SDITPGConfig[ndx].TextPos[0][0]) &&
       (UcharVal1 == SDITPGConfig[ndx].TextPos[0][0]))
      FuncState = 1; // if unchanged, remove SAVE option...

    Xpos = UcharVal;
    Ypos = UcharVal1;

        if (SDITPGConfig[ndx].System == SDI625)
          tmp = 22*Ypos+8;
        else
          tmp = 18*Ypos+6;

        ErrorCode = SndInt3(SDITPGUnit[ndx].Address, "SJ", (UI)1, (UI)(4 + Xpos * 2), (UI)tmp);

        if (ErrorCode)
          {
          GotoErrorStatus(ErrorCode);
          return;
          }
    }

  if (FuncTriggers & 0x0C)
    {                                // If button UP/DOWN pressed..
    if (FuncTriggers & 0x04)
      {                              // If button pressed is UP..
      if (UcharVal1++ == PT8603YPosMax)
        UcharVal1 = PT8603YPosMin;
      }
    else
      {                      // ..button pressed is DOWN
      if (UcharVal1-- == PT8603YPosMin)
        UcharVal1 = PT8603YPosMax;
      }
                              // Save new text positioning
    if ((UcharVal == SDITPGConfig[ndx].TextPos[0][0]) &&
       (UcharVal1 == SDITPGConfig[ndx].TextPos[0][1]))
      FuncState = 2;

    Xpos = UcharVal;
    Ypos = UcharVal1;

    if (SDITPGConfig[ndx].System == SDI625)
      tmp = 22*Ypos+8;
    else
      tmp = 18*Ypos+6;

    ErrorCode = SndInt3(SDITPGUnit[ndx].Address, "SJ", (UI)1, (UI)(4 + Xpos * 2), (UI)tmp);

    if (ErrorCode)
      {
      GotoErrorStatus(ErrorCode);
      return;
      }
    }

  WriteTxtLN2(0, "X: ");              // Write line 2 header
  sprintf(TextBuffer, "%+3d", UcharVal);  // Convert coordinate to ascii
  WriteTxt2(TextBuffer);              // Write coordinate

  ClearToPosLN2(10);

  WriteTxt2("Y: ");                       // Convert coordinate to ascii
  sprintf(TextBuffer, "%+3d", UcharVal1);
  WriteTxt2(TextBuffer);              // Write coordinate

  ClearRestLN2();

  WriteType2_SAVE_ESC(FuncState);

  switch (FuncState)
    {
    case 1:
    case 5:
      WriteItemArrows(3, 3);        // Mark selected item
      break;

    case 2:
    case 4:                        // Mark selected item
      WriteItemArrows(13, 3);
      break;
    }
  FuncTriggers = 0;               // Reset button-selection
  }
/************************** PT8603 *****************************/


/***************************************************************************/
/*  AnlBlkMenuShow                                    MENU.C  */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 980119                          */
/* Revised:    980508                                       */
/*                                                  */
/*  Function:  Display the items in the BLACK-BURST menu.            */
/*  Remarks:    Cursor position on line 1 & 2 are updated.            */
/*  Returns:    --                                        */
/*  Updates:    AnlBlkNdx                                  */
/***************************************************************************/
void AnlBlkMenuShow()
  {
  register int i, j, last, NoOfBBs;

  WriteCodeLN1(0, MenuHdrTxt);
  WriteCode1(base_menu[BaseNdx].ItemTxt);
  WriteCode1(CoConfigureTxt);           // Write menu headline
  ClearRestLN1();                  // Clear rest of line 1

  AnlBlkNdx = Ptr->ItemNumber;          // Update BB unit index, ie. no.

  WriteCodeLN2(0, SubmnuHdrTxt);        // Write header for sub-menu line
                              // Calculate no. of BB units
  for (NoOfBBs=0, i=BB1Item; i < BB8Item+1; i++)
    if (AnlBlkUnit[i].Present)
      NoOfBBs++;

  if (NoOfBBs > 6)
    {                  // If 6 or more BB units..
    i = last = BB7Item;                //  two screens are required
    (AnlBlkNdx > BB6Item) ? (last = BB8Item+1) : (i = BB1Item);
    }
  else
    {                          // ..otherwise only 1 screen
    i = 0;
    last = BB8Item+1;
    }

  for (j=0;  i < last; i++)
    {                              // Display active screen
    if (AnlBlkUnit[i].Present)
      {
      if ((i == BB2Item) && (AnlBlkUnit[BB2Item].HWType == PT8604))
        {
        WriteCode2(BBMulTxt);          // Write item text
        WriteTxt2("  ");               // Jump to next position

        if (i < AnlBlkNdx)            // Calculate item marker
          j += (Cstrlen(BBMulTxt) + 2);
        }
      else
        {
        WriteCode2(anlblk_menu[i].ItemTxt);// Write item text
        WriteTxt2("  ");                   // Jump to next position

        if (i < AnlBlkNdx)               // Calculate item marker
          j += (Cstrlen(anlblk_menu[i].ItemTxt) + 2);
        }
      }
    }
  ClearRestLN2();                  // Clear reset of line 2

  i = Ptr->ItemConfig;                // Get line1&2 icons/dots info

  if (NoOfBBs > 6 )                // If 6 or more BB units..
    i += MORE_;                    //  add 'more' dots to line 2

  WriteArrowsField(i);              // Write line 1&2 icons/dots

                              // Get length of text to mark
  if ((AnlBlkNdx == BB2Item) && (AnlBlkUnit[BB2Item].HWType == PT8604))
    i = Cstrlen(BBMulTxt);
  else
    i = Cstrlen(Ptr->ItemTxt);

  WriteItemArrows(j+8, (UC) i);        // Mark selected item
  }

/***************************************************************************/
/* DLTPGMenuShow                                                    menu.C */
/*                                                                         */
/* Author:   Janusz Kuzminski, DEV, 15.02.2005                             */
/* Revised:  21.02.2005                                                    */
/*           26.07.2005                                                    */
/*                                                                         */
/* Function: To display DLTPG menu, according to number of generators      */
/*           present in PT5230, which may be up to 6.                      */
/* Params:   None                                                          */
/* Remarks:  This function displays menu in form:                          */
/*           MENU   : DLTPG, configure                                     */
/*           SUBMENU: <DL1>  <DL2>  <DL3>  <DL4>  <DL5>  <DL6>             */
/*           At present there may be up to 3 DLTPG boards mounted,         */
/*           each containing 4 independent generators                      */
/*           New specification:                                            */
/*           Board mounted at bbu1_addr has generators 1 and 2.            */
/*           Board mounted at bbu3_addr has generators 3 and 4.            */
/*           Board mounted at bbu2_addr has generators 5 and 6      .      */
/*           Upon entry we have:                                           */
/*                              Ptr = &DLTPG_menu[DLTPGNoNdx];             */
/*           While this menu is displayed:                                 */
/*           When we move LEF : Ptr = Ptr->PrevItem;                       */
/*           When we move RGHT: Ptr = Ptr->NextItem;                       */
/*           This function updates:   DLTPGNoNdx = Ptr->ItemNumber;        */
/*           When we move DOWN, DLTPGNoNdx contains number of selecerd     */
/*           generator.                                                    */
/*                                                                         */
/* Returns:  Nothing                                                       */
/***************************************************************************/
void DLTPGMenuShow()
  {
  register int i, j, last, first, NoOfDLTPGs;
  UC first_board;
  UC second_board = 0;

  WriteCodeLN1(0, MenuHdrTxt);
  WriteCode1(base_menu[BaseNdx].ItemTxt);
  WriteCode1(CoConfigureTxt);           // Write menu headline
  ClearRestLN1();

  DLTPGNoNdx = Ptr->ItemNumber;          // Update DLTPG unit index, ie. no.

  WriteCodeLN2(0, SubmnuHdrTxt);

  for (NoOfDLTPGs = 0, i = DLTPG1Item; i < DLTPG6Item + 1; i++)
    if (DLTPGUnit[i].Present)
      NoOfDLTPGs++;              // Calculate no. of DLTPG units

#if 0
   for (i = 0; i < MaxDLTPGUnits; i++)
      {
       sprintf(tbuff, "DLTPGUnit[%d] = %d\n", (int)i, DLTPGUnit[i].Present);
       Udr_PutNChar(tbuff);
      }
#endif



    if (DLTPGUnit[0].Present)
      {
      first_board = 1;
      if (DLTPGUnit[2].Present)
        second_board = 2;
      else
        if (DLTPGUnit[2].Present)
          second_board = 3;
      }
    else
      if (DLTPGUnit[2].Present)
        {
        first_board = 2;
          if (DLTPGUnit[4].Present)
            second_board = 3;
        }
      else
        if (DLTPGUnit[4].Present)
          first_board = 3;

  switch (NoOfDLTPGs)
    {
    case 2:
      switch (first_board)
        {
        case 1:
          first = DLTPG1Item;
          last  = DLTPG2Item + 1;
          break;
        case 2:
          first = DLTPG3Item;
          last  = DLTPG4Item + 1;
          break;
        case 3:
          first = DLTPG5Item;
          last  = DLTPG6Item + 1;
          break;
        }
      break;
    case 4:
      switch (first_board)
        {
        case 1:                  // second board can be 2 or 3....
          if (second_board == 2)
              {
              first = DLTPG1Item;
              last  = DLTPG4Item + 1;
              }
           else
              {
              first = DLTPG1Item;     
              last  = DLTPG6Item + 1;
              }
          break;
        case 2:                  // second board can only be 3....
            first = DLTPG3Item;
            last  = DLTPG6Item + 1;
          break;
        }
      break;
    case 6:
        first = DLTPG1Item;
        last  = DLTPG6Item + 1;
      break;
    default:
      break;
    }
  j = 0;

#if 0
   sprintf(tbuff, "NoOfDLTPGs= %d, fboard= %d, first = %d\n", (int)NoOfDLTPGs, (int)first_board, (int)first);
   Udr_PutNChar(tbuff);
   sprintf(tbuff, "last= %d\n", (int)last);
   Udr_PutNChar(tbuff);
#endif

  for (i = first;  i < last; i++)
    {                              // Display active screen
    if (DLTPGUnit[i].Present)
      {
      WriteCode2(DLTPG_menu[i].ItemTxt);// Write item text
      WriteTxt2("  ");                  // Jump to next position

      if (i < DLTPGNoNdx)               // Calculate item marker
        j += (Cstrlen(DLTPG_menu[i].ItemTxt) + 2);
      }
    }
  ClearRestLN2();               // Clear reset of line 2

  i = Ptr->ItemConfig;          // Get line1&2 icons/dots info

  //if (NoOfDLTPGs > 4 )          // If 4 or more DLTPG units..
    //i += MORE_;                 //  add 'more' dots to line 2

  WriteArrowsField(i);             // Write line 1&2 icons/dots
  i = Cstrlen(Ptr->ItemTxt);       // Get length of text to mark
  WriteItemArrows(j + 8, (UC) i);  // Mark selected item
  }

/***************************************************************************/
/* DLTPGDown                                                        menu.C */
/*                                                                         */
/* Author:   Janusz Kuzminski, DEV, 15.02.2005                             */
/* Revised:  21.02.2005                                                    */
/*                                                                         */
/* Function: To set Ptr to apropriate member of DLTPG_submenu[] using      */
/*           DLTPGsubmenuNdx[DLTPGNoNdx]                                   */
/*                                                                         */
/* Params:   None                                                          */
/* Remarks:  This function is entered when user presses DOWN key in while  */
/*           in DLTPGMenuShow(), thus selecting desired generator          */
/*                                                                         */
/* Returns:  Nothing                                                       */
/***************************************************************************/
void DLTPGDown()
  {
  Ptr = &DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];
  }

void UpToDLTPG()
  {
  Ptr = &DLTPG_menu[DLTPGNoNdx];    // Restore selected DLTPG item i.e.
  }                                 // generator number.

void UpToDLTPGsub()
  {
  Ptr = &DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];    // Restore selected DLTPG item i.e.
  }

/***************************************************************************/
/* void DLTPGSubMenuShow(void)                                     MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 21.02.2005                                                     */
/*                                                                         */
/* Function: To display DLTPG submenu, which is as follows:                */
/*           2NDMNU: <PATT>  SYSTEM  AUDIO  TIMING                         */
/* Remarks:                                                                */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Updates:     TBD                                                        */
/***************************************************************************/
void DLTPGSubMenuShow()
  {
  register int i, j;

  WriteCodeLN1(0, SubmnuHdrTxt);
  WriteCode1(base_menu[BaseNdx].ItemTxt);
  WriteChar1('/');

  CodePtr = DLTPG_menu[DLTPGNoNdx].ItemTxt;
  WriteCode1(CodePtr);
  WriteCode1(CoSelectTxt);
  ClearRestLN1();
  WriteCodeLN2(0, SecondmnuHdrTxt);

  DLTPGsubmenuNdx[DLTPGNoNdx] = Ptr->ItemNumber;

  i = j = DLTPGAudioItem;              // Find window

  if (DLTPGsubmenuNdx[DLTPGNoNdx] < DLTPGAudioItem)   // If item < AUDIO..
    i = DLTPGPatternItem;              //  Pattern, Text & System
  else
    j = DLTPGTextItem+1;               //  EMB.Audio, Timing & Text

  for (; i < j; i++)
    {
    ClearToPosLN2(DLTPG_submenu[i].ItemPos); // Write item position
    WriteCode2(DLTPG_submenu[i].ItemTxt);    // Write item text
    }

  ClearRestLN2();
  i = Ptr->ItemConfig;                  // Get line 1&2 icons/dots
  if (Flags.NormalLockOn)               // If normal LOCK is enabled..
    if (DLTPGsubmenuNdx[DLTPGNoNdx] != DLTPGPatternItem)  // If not pattern menu..
      i = (i | P_) & ~D_;             //  add padlock, remove down  arrow.
  WriteArrowsField(i);                // Write line 1&2 icons/dots
  WriteItemArrows(Ptr->ItemPos, Cstrlen(Ptr->ItemTxt));  // Mark selected item
  }

/*
enum DLTPGItems 
  {
  DLTPGPatternItem = 0, DLTPGSystemItem, DLTPGTimingItem \
  DLTPGAudioItem, DLTPGTextItem
  };
*/
/***************************************************************************/
/* void DLTPGSubDown(void)                                         MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 21.02.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU: <PATT> SYSTEM  TIMING TEXT   AUDIO                    */
/*                                                                         */
/* Remarks: For current generator (DLTPGNoNdx), DLTPGsubmenuNdx[DLTPGNoNdx]*/
/*          holds the  highlighted item nr, i.e. PATT, TIMING, etc         */
/*          and preparations are made accordingly,                         */
/*          before DLTPG_sub_submenu  is entered.                          */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGSubDown()
  {
  WriteCodeLN1(0, SecondmnuHdrTxt);
  WriteCode1(SlashDotHdrTxt);
  WriteCode1(DLTPG_menu[DLTPGNoNdx].ItemTxt);
  WriteChar1('/');
  WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);

  PrevPtr = Ptr;
  //Ptr     = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];

  switch (DLTPGsubmenuNdx[DLTPGNoNdx])
    {
    case DLTPGPatternItem:
      WriteCode1(CoSelectTxt);
      UcharVal = DLTPGConfig[DLTPGNoNdx].Pattern;
      Ptr      = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];// Point to selected item
      break;
    case DLTPGTimingItem:
      WriteCode1(CoEditDelayTxt);
      UcharVal    = DLTPGConfig[DLTPGNoNdx].System;
      tlg_samples = DLTPGConfig[DLTPGNoNdx].Delay;
      stepNdx     = stepNdxTLGMin;
      stepVal     = stepsizeTLGTable[dltpg_fmt_table[UcharVal].sys_clk][stepNdx];
      Ptr         = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];
      break;
    case DLTPGTextItem:
      /* Point to TextMenu: Edit, Style, Pos, Clock for current DL generator number */
      Ptr = &DLTPGtext_menu[DLTPGTextMenuNdx[DLTPGNoNdx]];
      break;
    case DLTPGSystemItem:
      WriteCode1(CoSelectTxt);
      UcharVal  = DLTPGConfig[DLTPGNoNdx].System;
#if 0
    sprintf(tbuff, "Sys down:system = 0x%x\n", (int)UcharVal);
    Udr_PutNChar(tbuff);
#endif
      Ptr = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];// Point to selected item
      break;
    case DLTPGAudioItem:
      /* Point to AudioMenu: Signal  Level  Group for current DL generator number */
      Ptr = &DLTPGaudio_menu[DLTPGAudioMenuNdx[DLTPGNoNdx]];
      break;
    }
  ClearRestLN1();
  FuncState    = 1;
  FuncTriggers = 0;
  FuncSave     = FuncEscape = FALSE;
  SelectModeOn = TRUE;
  }

/***************************************************************************/
/* void DLTPGPatternSelect()                                       MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 03.03.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU: <PATT> SYSTEM TIMING                                  */
/*           having PATT selected.                                         */
/*                                                                         */
/*           This function writes Line 2 menu:                             */
/*           <PAT0>                      ESC         OR                    */
/*           <PAT1>      LEVELS          ESC                               */
/*           Only PATs 0 - 4 have attributes which may be modified.        */
/* Remarks:  On entry:                                                     */
/*           UcharVal = DLTPGConfig[DLTPGNoNdx].Pattern;                   */
/*                Ptr = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];   */
/* Returns: Nothing                                                        */
/* Notes:                                                                  */
/*
    first 5 have attributes, others do not.
enum HDPatterns
  {
  HDColorbar = 0, HDCombination, HDWindow, HDWhite,  HDCrosshatch,
  HDCheckField,   HDPluge,       HDLumRamp, HDClapBoard,
  HDBlack
  };
 */
/***************************************************************************/
void DLTPGPatternSelect()
  {
  UC board;

  if (FuncState == 13) // FuncState = 13 means that MODIFY item selected..
    {                  // See comments below ....
    WriteCodeLN1(0, SecondmnuHdrTxt);   // Write menu header on line 1
    WriteCode1(SlashDotHdrTxt);
    WriteCode1(LevelsTxt);
    WriteTxt1(", ");
    CodePtr = HDTPGPattArrTxt[UcharVal];// Get text for selected pattern
    WriteCode1(CodePtr);                // Write pattern text on line 1
    ClearRestLN1();                     // Clear rest of line 1
                                        //     UcharVal = Pattern
    UcharVal2 = DLTPGConfig[DLTPGNoNdx].Attrib[UcharVal]; // Get pattern attribute to UcharVal2

    FuncState    = 1;
    FuncTriggers = 0;
    FuncSave     = FuncEscape = FALSE;

    Ptr = &DLTPGpattern_modify_menu;   // Set pointer to MODIFY menu 
    Ptr->DispFunct();                  // Display HDTPGPatternModify() menu
    return;                            // execute function HDTPGPatternModify()
    }

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].Pattern = UcharVal;
      }
    else   // is ESC ..restore HDTPG pattern
      {
      /* If pattern has attributes, they are taken from HDTPGConfig and */
      /* transmitted, otherwise attribute = 0 is transmitted.           */
      ErrorCode = TrxDLTPGPattern(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].Pattern);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }
  /*************** PATTERN UP/DOWN ********************/
  if (FuncTriggers & 0x03)
    {                             // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                           // If button pressed is UP..
      if (UcharVal++ == HDBlack)
        UcharVal = HDColorbar;
      }
    else
      {                         // ..else previous pattern
      if (UcharVal-- == HDColorbar)
        UcharVal = HDBlack;
      }

    if (UcharVal == DLTPGConfig[DLTPGNoNdx].Pattern)
      {                                   // If current pattern..
      if (FuncState > 5)                  //  remove SAVE option
        FuncState = 6;
      else
        FuncState = 1;
      }
  /************************* UP/DOWN ***************************/

    /* If pattern has attributes, they are taken from HDTPGConfig and */
    /* transmitted, otherwise attribute = 0 is transmitted.           */
    ErrorCode = TrxDLTPGPattern(DLTPGNoNdx, UcharVal);
    if (ErrorCode)
      {
      board = FindDLTPGBoard(DLTPGNoNdx);
  
      GotoErrorStatus(256*board + ErrorCode);
      return;
      }
    } // if PATTERN UP/DOWN

  /* If HAS ATTRIBS (= "COLOURBAR", OR COMBINATION...etc    */
  /* Code below decides which Patterns will have attributes */
  /* i.e. which will have <MODIFY> option.                  */
  if ((UcharVal >= HDColorbar) && (UcharVal < HDCrosshatch))
    {
    if (FuncState == 1)
      FuncState = 6;
    if (FuncState == 3)
      FuncState = 9;
    }
  else
    {
    if (FuncState == 6)
      FuncState = 1;
    if (FuncState == 9)
      FuncState = 3;
    }
  CodePtr = HDTPGPattArrTxt[UcharVal];    // Get text for selected pattern
  WriteCharLN2(0, ' '  );                 // No header for line 2
  WriteCode2(CodePtr);                    // Write the selected pattern
  ClearRestLN2();                         // Clear rest of line 2
  WriteType7b_SAVE_ESC(FuncState);        // Write the SAVE ESC texct
  switch (FuncState )
    {
    case 1:
    case 3:
    case 6:
    case 9:                      // Mark selected item
      WriteItemArrows(1, Cstrlen(CodePtr));
      break;
    }
  FuncTriggers = 0;
  }

/***************************************************************************/
/* void DLTPGPatternModify()                                       MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 03.03.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in pattern select submenu, which is as follows:*/
/*            WINDOW       <LEVELS>         ESC                            */
/*           having MODIFY selected and then on subsequent UP/DOWN key     */
/*           presses.                                                      */
/*                                                                         */
/* Remarks:                                                                */
/*           When this function is invoked, the first line on display has  */
/*           already been written.                                         */
/*                                                                         */
/*           UcharVal2 holds current attributes                            */
/*           UcharVal  halds current pattern                               */
/*           When SAVE, this function saves Pattern in DLTPGConfig.        */
/* Returns:  Nothing                                                       */
/* Notes:    When this function saves or escapes, we must return to        */
/*           displaying patterns,(DLTPGPatternSelect),                     */
/*           and not to DLTPGSubMenuShow()                                 */
/***************************************************************************/
void DLTPGPatternModify()
  {
  UC board;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If interface has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].Attrib[UcharVal]  = UcharVal2;
      DLTPGConfig[DLTPGNoNdx].Pattern           = UcharVal; // save also pattern in Config

      ErrorCode = TrxDLTPGPattern(DLTPGNoNdx, UcharVal);

      ErrorCode = TrxDLTPGAttributes(DLTPGNoNdx, UcharVal2);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      SelectModeOn = FALSE;
      Ptr = PrevPtr;
      Ptr->DispFunct();       // rerutn to DLTPG_submenu
      return;
      }
    else                      // If escape ..restore old attribs.....
      {
      ErrorCode = TrxDLTPGAttributes(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].Attrib[UcharVal]);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      WriteCodeLN1(0, SecondmnuHdrTxt);
      WriteCode1(SlashDotHdrTxt);
      WriteCode1(DLTPG_menu[DLTPGNoNdx].ItemTxt);
      WriteChar1('/');
      WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);
      ClearRestLN1();                       // Clear rest of line 1
  
      if (UcharVal == DLTPGConfig[DLTPGNoNdx].Pattern) // If current system..
        FuncState = 7;                                //  remove SAVE option
      else
        FuncState = 10;
  
      FuncTriggers = 0;
      FuncSave     = FuncEscape = FALSE;
  
      Ptr   = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];
      Ptr->DispFunct();
      return;              // return to SYSTEM menu
      }
    } // if (FuncSave || FuncEscape)

  if (FuncTriggers & 0x03)    // If UP/DOWN button pressed..
    {
    UcharVal2 = FindHDAttribute(FuncTriggers, UcharVal, UcharVal2);

    if (UcharVal2 == DLTPGConfig[DLTPGNoNdx].Attrib[UcharVal])  // If current attrib
      FuncState = 1;                                            //  remove SAVE option

    ErrorCode = TrxDLTPGAttributes(DLTPGNoNdx, UcharVal2);
    if (ErrorCode)
      {
      board = FindDLTPGBoard(DLTPGNoNdx);
  
      GotoErrorStatus(256*board + ErrorCode);
      return;
      }
    }

  ClearRestLN2();
  WriteType2_SAVE_ESC(FuncState);                   // Write the ESC text
  /* Point tot the right table with attrib text */
  switch (UcharVal)
    {
    case HDColorbar:
    case HDCombination:
      CodePtr = HDTPGACBttribArrTxt[UcharVal2];     // Get attribute text
      break;
    case HDWhite:
    case HDWindow:
      CodePtr = HDTPGAWindowttribArrTxt[UcharVal2]; // Get attribute text
      break;
    case HDCrosshatch: /* This is not necessary, HDCrosshatch: no attrib */
      CodePtr = HDTPGAChttribArrTxt[UcharVal2];     // Get attribute text
      break;
    }
  WriteCodeLN2(1, CodePtr);                 // Write attribute

  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);        // Write the SAVE ESC text
  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(1, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;                      // Reset the button-selection
  }

/***************************************************************************/
/* void DLTPGTimingSelect()                                        MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 03.03.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU:  PATT  TEXT  SYSTEM  EDH  AUDIO  <TIMING>             */
/*           having TIMING selected.                                       */
/*                                                                         */
/* Remarks:  UcharVal contains System here                                 */
/*                                                                         */
/* Returns: Nothing                                                        */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTimingSelect()
  {
  UC board;

  /* if system is OFF... do nothing. */
  if (DLTPGConfig[DLTPGNoNdx].System == 0)
    {
    CharBlinkLN2(0, OFF);
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                          // If delay has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].Delay = tlg_samples;  // Save new DL delay
      }
    /* If ESC, transmit DLTPGConfig[DLTPGNoNdx].Delay */
    ErrorCode = TrxDLTPGSystem(DLTPGNoNdx, 
                               DLTPGConfig[DLTPGNoNdx].System,
                               DLTPGConfig[DLTPGNoNdx].Delay,
                               GenlockConfig[ActiveGenlockNo].Delay);
  if (ErrorCode)
    {
    board = FindDLTPGBoard(DLTPGNoNdx);

    GotoErrorStatus(256*board + ErrorCode);
    return;
    }

    CharBlinkLN2(0, OFF);
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }
  /* HDTPGTimeAdjust() transmits delay */
  HDTPGTimeAdjust(DLTPGNoNdx, UcharVal, DLTPGConfig[DLTPGNoNdx].Delay, 1);
  FuncTriggers = 0;
  }

/***************************************************************************/
/* void DLTPGSystemSelect()                                        MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 03.03.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU:  PATT  TEXT  <SYSTEM>  EDH  AUDIO  TIMING             */
/*           having SYSTEM selected.                                       */
/*                                                                         */
/* Remarks: When browsing systems, they are not transmitted to board.      */
/*          They are transmitted only when saved.                          */
/*                                                                         */
/* Returns: Nothing                                                        */
/* Notes:   FuncState = 13 means that consecutive Left or Right buttons    */
/*          will display System Attributes menu.                           */
/*          UcharVal  contains System                                      */
/***************************************************************************/
void DLTPGSystemSelect()
  {
  UC board;

  if (FuncState == 13) // FuncState = 13 means that Interface attribs are to be displayed..
    {                  // See comments below ....
    WriteCodeLN1(0, SecondmnuHdrTxt);   // Write menu header on line 1
    WriteCode1(SlashDotHdrTxt);
    WriteCode1(INTERFACETxt);
    WriteTxt1(", ");
    CodePtr = DLTPGSystemArrTxt[UcharVal];// Get text for selected system
    WriteCode1(CodePtr);                  // Write pattern text on line 1
    ClearRestLN1();                       // Clear rest of line 1
                                          //     UcharVal = Pattern
    UcharVal2 = DLTPGConfig[DLTPGNoNdx].Interface[UcharVal]; // Get system attribute to UcharVal2

    FuncState    = 1;
    FuncTriggers = 0;
    FuncSave     = FuncEscape = FALSE;

    Ptr = &DLTPGsystem_modify_menu;    // Set pointer to MODIFY menu 
    Ptr->DispFunct();                  // Display HDTPGPatternModify() menu
    return;                            // execute function HDTPGPatternModify()
    }

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                              // If System has changed..
      ActivePresetNo = 0;            // Clear possible preset
      DLTPGConfig[DLTPGNoNdx].System = UcharVal;    // Save new System

      ErrorCode = TrxDLTPGSystem(DLTPGNoNdx, 
                                 DLTPGConfig[DLTPGNoNdx].System,
                                 DLTPGConfig[DLTPGNoNdx].Delay,
                                 GenlockConfig[ActiveGenlockNo].Delay);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
    
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;          // Clear select-mode
    Ptr = PrevPtr;                 // Set pointer to previous menu
    Ptr->DispFunct();              // Display previous menu
    return;
    }
  if (FuncTriggers & 0x03)
    {                              // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                            // If button pressed is UP..
      if (UcharVal-- == 0)
        UcharVal = MAX_DL_SYSTEMS - 1;     
      }
    else
      {                            // ..button pressed is DOWN
      if (UcharVal++ == (MAX_DL_SYSTEMS - 1))
        UcharVal = 0;
      }
    if (UcharVal == DLTPGConfig[DLTPGNoNdx].System) // If actual format..
      FuncState = 1;                                //  remove SAVE option
    /* JK change, do NOT transmit System, only when saved... */
    }

  /* If HAS INTERF (= "1", OR 2...etc    */
  /* Code below decides which systems will have interfaces  */
  /* i.e. which will have the "..." option.                 */
  if ((UcharVal > 0) && (UcharVal < 14)) /* if have interface */
    {
    if (FuncState == 1)
      FuncState = 6;
    if (FuncState == 3)
      FuncState = 9;
    }
  else                                   /* if NOT have interface */
    {
    if (FuncState == 6)
      FuncState = 1;
    if (FuncState == 9)
      FuncState = 3;
    }

  CodePtr = DLTPGSystemArrTxt[UcharVal];     // Get text for selection
  WriteCharLN2(0, ' '  );                 // No header for line 2
  WriteCode2(CodePtr);                    // Write the selected pattern
  ClearRestLN2();                         // Clear rest of line 2
  WriteType7a_SAVE_ESC(FuncState);         // Write the SAVE ESC texct INTERFACETxt

  switch (FuncState )
    {
    case 1:
    case 3:
    case 6:
    case 9:                      // Mark selected item
      WriteItemArrows(1, Cstrlen(CodePtr));
      break;
    }
  FuncTriggers = 0;
  }

/***************************************************************************/
/* void DLTPGInterfaceModify()                                     MENU.C  */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 03.03.2005                                                     */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Left or Right key (+more), which is as follows:               */
/*            <XXX>   <INTERFACE>         ESC                              */
/*            <XXX>   <INTERFACE>  SAVE   ESC                              */
/*             XXX    <INTERFACE>        <ESC>                             */
/*             XXX    <INTERFACE>  SAVE  <ESC>                             */
/*                                                                         */
/* Remarks:                                                                */
/*           When this function is invoked, the first line on display has  */
/*           already been written.                                         */
/*                                                                         */
/*           UcharVal2 holds current interface                             */
/*           UcharVal  hOlds current system                                */
/*           When SAVE, this function saves System in DLTPGConfig.         */
/* Returns:  Nothing                                                       */
/* Notes:    When this function  escapes, we must return to                */
/*           displaying System,(DLTPGSystemSelect),                        */
/*           and not to DLTPGSubMenuShow()                                 */
/*           This function implements NON STANDARD BEHAVIOUR               */
/***************************************************************************/
void DLTPGInterfaceModify()
  {
  UC board;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If interface has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].Interface[UcharVal]  = UcharVal2;
      DLTPGConfig[DLTPGNoNdx].System               = UcharVal; // save also System in Config

      ErrorCode = TrxDLTPGSystem(DLTPGNoNdx, 
                                 UcharVal,
                                 DLTPGConfig[DLTPGNoNdx].Delay,
                                 GenlockConfig[ActiveGenlockNo].Delay);

      ErrorCode = TrxDLTPGInterface(DLTPGNoNdx, UcharVal2);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      SelectModeOn = FALSE;
      Ptr = PrevPtr;
      Ptr->DispFunct();       // rerutn to DLTPG_submenu
      return;
      }
    else                      // If escape ..restore old pattern and old attribs.....
      {    //  UC TrxDLTPGInterface(UC ndx, UC inter)
      ErrorCode = TrxDLTPGInterface(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].Interface[UcharVal]);
      if (ErrorCode)
        {
        board = FindDLTPGBoard(DLTPGNoNdx);
        GotoErrorStatus(256*board + ErrorCode);
        return;
        }
      WriteCodeLN1(0, SecondmnuHdrTxt);
      WriteCode1(SlashDotHdrTxt);
      WriteCode1(DLTPG_menu[DLTPGNoNdx].ItemTxt);
      WriteChar1('/');
      WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);
      ClearRestLN1();                       // Clear rest of line 1
  
      if (UcharVal == DLTPGConfig[DLTPGNoNdx].System) // If current system..
        FuncState = 7;                                //  remove SAVE option
      else
        FuncState = 10;
  
      FuncTriggers = 0;
      FuncSave     = FuncEscape = FALSE;
  
      Ptr   = &DLTPG_sub_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]];
      Ptr->DispFunct();
      return;              // return to SYSTEM menu
      }
    } // if (FuncSave || FuncEscape)

  if (FuncTriggers & 0x03)    // If UP/DOWN button pressed..
    {
    UcharVal2 = FindHDInterface(FuncTriggers, UcharVal, UcharVal2);

    if (UcharVal2 == DLTPGConfig[DLTPGNoNdx].Interface[UcharVal])  // If current interface
      FuncState = 1;                                               //  remove SAVE option
    }

  //WriteCodeLN2(0, ModifyHdrTxt);
  ClearRestLN2();
  WriteType2_SAVE_ESC(FuncState);                   // Write the ESC text

  /* Point to the right table with attrib text */
  CodePtr = DLTPGSystInterTxt[UcharVal2];           // Get interface text
  WriteCodeLN2(1, CodePtr);

  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);        // Write the SAVE ESC text
  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(1, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;                      // Reset the button-selection
  }

/***************************************************************************/
/* void DLTPGTextMenuShow(void)                                    MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU:  PATT  <TEXT>  SYSTEM  TIMING                         */
/*           having TEXT selected.                                         */
/*           This function displays text menu for current DL generator:    */
/*             <EDIT> STYLE POS COLOR                                      */
/*                                                                         */
/* Remarks:  For current generator DLTPGTextMenuNdx[DLTPGNoNdx]            */
/*           holds selected item nr, i.e. EDIT, STYLE, etc. in text menu.  */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextMenuShow()
  {
  UC tmp;
  register int i, j;

  WriteCodeLN1(0, SecondmnuHdrTxt);
  WriteCode1(SlashDotHdrTxt);
  WriteCode1(DLTPG_menu[DLTPGNoNdx].ItemTxt); // DL9
  WriteChar1('/');
  WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt); // TEXT
  WriteCode1(CoSelectTxt);                                        // , select
  ClearRestLN1();

  WriteCodeLN2(0, SecondmnuHdrTxt);

  DLTPGTextMenuNdx[DLTPGNoNdx] = Ptr->ItemNumber; // Update ../TEXT menu index

  i = j = ColorItem; // 4

  if (DLTPGtext_menu[DLTPGTextMenuNdx[DLTPGNoNdx]].ItemNumber < ColorItem)
    i = EditItem; // 0
  else
    j = BackgroundItem + 1; // 6

  for (; i < j; i++)
    {
    ClearToPosLN2(DLTPGtext_menu[i].ItemPos); // Find item column position
    WriteCode2(DLTPGtext_menu[i].ItemTxt);    // Write item texts
    }

  ClearRestLN2();

  i = Ptr->ItemConfig;

  WriteArrowsField(i);
  WriteItemArrows(Ptr->ItemPos, Cstrlen(Ptr->ItemTxt));
  }


/***************************************************************************/
/* void DLTPGTextDown(void)                                        MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu with one of the following:     */
/*           EDIT  STYLE  POS  COLOR selected                              */
/*           The selected item is in DLTPGTextMenuNdx[DLTPGNoNdx]          */
/*                                                                         */
/* Remarks:  This function prepares some global variables according to     */
/*           what was selected in the TEXT submenu for use by functions    */
/*           which actually perform required actions:                      */
/*                void DLTPGTextEditSelect()                               */
/*                void DLTPGTextStyleSelect()                              */
/*                void DLTPGTextPosSelect()                                */
/*                void DLTPGTextColorSelect()                              */
/*           In this function:                                             */
/*             Ptr = DLTPGtext_submenu[DLTPGTextMenuNdx[DLTPGNoNdx]]       */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextDown()
  {
  UC itemNdx = DLTPGTextMenuNdx[DLTPGNoNdx];

  WriteCodeLN1(0, SecondmnuHdrTxt);        // Write menu headline
  WriteCode1(SlashDotHdrTxt);
  WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);
  WriteChar1('/');
  WriteCode1(DLTPGtext_menu[itemNdx].ItemTxt);
  WriteCode1(CoSelectTxt);
  ClearRestLN1();

  switch (DLTPGTextMenuNdx[DLTPGNoNdx])
    {
    case HDTPGTextEditItem:                  // Prepare for text editing
      UcharVal  = 0;
      UcharVal1 = 0;
      UcharVal2 = 2;
      strcpy(TextBuffer, DLTPGConfig[DLTPGNoNdx].Text[UcharVal]);
                            // Find text enable information
      UcharVal3 = (DLTPGConfig[DLTPGNoNdx].TextEnable & (1 << UcharVal)) > 0;
      if (UintVal = strlen(TextBuffer))  // Position in Text string
        UintVal--;
      break;
    case HDTPGTextScaleItem:          // Prepare for scale selection
      UcharVal  = DLTPGConfig[DLTPGNoNdx].TextScale;
      UcharVal1 = 0;
      break;
    case HDTPGTextPosItem:            // Prepare for position selection
      UcharVal  = DLTPGConfig[DLTPGNoNdx].TextPos[0];
      UcharVal1 = DLTPGConfig[DLTPGNoNdx].TextPos[1];
      break;
    case HDTPGTextMovementItem:        // Prepare for MOV selection
      UcharVal  = DLTPGConfig[DLTPGNoNdx].TextMovement;
      UcharVal1 = 0;
      break;
    case HDTPGTextColorItem:          // Prepare for COLOR selection
      UcharVal  = DLTPGConfig[DLTPGNoNdx].TextColor & 0x0F;
      UcharVal1 = 0;
      break;
    case HDTPGTextBAckgroundItem:     // Prepare for BACKGROUND selection
      UcharVal  = DLTPGConfig[DLTPGNoNdx].TextColor >> 4;
      UcharVal1 = 0;
      break;
    }
  PrevPtr =  Ptr;
  Ptr     = &DLTPGtext_submenu[DLTPGTextMenuNdx[DLTPGNoNdx]]; // Point to selected item
  FuncState    = 1;
  FuncTriggers = 0;
  FuncSave     = FuncEscape = FALSE;
  SelectModeOn = TRUE;
  }

/***************************************************************************/
/* void DLTPGTextEditSelect(void)                                  MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              <EDIT>  STYLE   POS   CLOCK                                */
/*           with EDIT selected.                                           */
/*           This function writes Line 2 menu:                             */
/*           LINE1:<abc>            <Off>       ESC                        */
/*           This function is entered each time user presses UP or DOWN    */
/*           key or changs text, putting or removing SAVE  option as       */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  On entry:                                                     */
/*            UcharVal   = 0; Line nr                                      */
/*            UcharVal1  = 0; Min line                                     */
/*            UcharVal2  = 2; Max line (3 lines of text)                   */
/*            TextBuffer = DLTPGConfig[DLTPGNoNdx].Text[0]);               */
/*            UcharVal3  = Text enable info for line 0                     */
/*            UintVal    = strlen(TextBuffer)                              */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextEditSelect()
  {
  UC tmp;
  UC board;

  if (FuncEscape)
    {
    CharBlinkLN2(0, OFF);   // Switch off possible blinking
    SelectModeOn = FALSE;   // Clear select-mode
    Ptr = PrevPtr;          // Set pointer to previous menu
    Ptr->DispFunct();       // Display previous menu
    return;
    }

  if (FuncSave)
    {                         // If textinfo has changed..
    FuncSave       = FALSE;
    ActivePresetNo = 0;       // Clear possible preset
                              // Save the new text
    strcpy(DLTPGConfig[DLTPGNoNdx].Text[UcharVal], TextBuffer);
                              // Save text enable information
    DLTPGConfig[DLTPGNoNdx].TextEnable &= ~(1 << UcharVal);
    DLTPGConfig[DLTPGNoNdx].TextEnable |= (UcharVal3 << UcharVal);

    //tmp = (UcharVal % 3) + 1; // Calculate line number
                                // Transmit text line enable

    ErrorCode = TrxDLTPGText(DLTPGNoNdx, &DLTPGConfig[DLTPGNoNdx]);
/************************************************************************/
/* Note: It is impossible to develop proper communiction error handling */
/*       here as to do so would require having working DL board which   */
/*       does not give Level Error.                                     */
/*       A button must be pressed before we go to status!               */
/************************************************************************/
    if (ErrorCode)
          {
          board = FindDLTPGBoard(DLTPGNoNdx);
          ErrorStatus = 0;
          GotoErrorStatus(256*board + ErrorCode);
          //return;
          }
    }
                              // Select line to edit
  if (FuncTriggers & 0x03)
    {                                  // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                                // If button pressed is UP..
      if (UcharVal-- == UcharVal1 )
        UcharVal = UcharVal2;
      }                                // ..button pressed is DOWN
    else
      {
      if (UcharVal++ == UcharVal2)
        UcharVal = UcharVal1;
      }                          // Copy selected text to temp.
                                 //  text buffer
    strcpy(TextBuffer, DLTPGConfig[DLTPGNoNdx].Text[UcharVal]);
                                 // Find text enable information
    UcharVal3 = (DLTPGConfig[DLTPGNoNdx].TextEnable & (1 << UcharVal)) > 0;

    if (UintVal = strlen(TextBuffer))    // Find position in string
      UintVal--;

    FuncState = 1;
    }
                              // Select textline ON/OFF
  if (FuncTriggers & 0x0C)
    {                         // If UP/DOWN button pressed..
    UcharVal3 ^= ON;          // Toggle selection

    if (UcharVal3 == (DLTPGConfig[DLTPGNoNdx].TextEnable & (1 << UcharVal)) > 0)
      if (!strcmp(DLTPGConfig[DLTPGNoNdx].Text[UcharVal], TextBuffer))
        FuncState = 2;
    }
  // Select position in TextBuffer
  if (FuncTriggers & 0xC0)     // If LEFT/RIGHT button pressed..
    {
    if (FuncTriggers & 0x40)   // If button pressed is LEFT..
      {
      if (UintVal)        /* Algor is changed here compared to orig 8633 */
        {                 /***********************************************/
        TextBuffer[UintVal] = 0; // Delete character
        UintVal--;               // Decrement pointer to last character
        }
      }
    else
      {                         // ..button pressed is RIGHT
      tmp = 15;                 // Max. 16 characters in PT8632/3
      if ((UintVal < tmp) && (UintVal < strlen(TextBuffer)))
        UintVal++;
      }
    }
  if (FuncTriggers & 0x30)
    {                         // If UP/DOWN button pressed.. 
    if (TextBuffer[UintVal] == 0)
      {                       // If text insert..
      TextBuffer[UintVal] = TextBuffer[UintVal-1]; //  set new character = previous
      TextBuffer[UintVal+1] = 0;
      }
    tmp = GetNext((FuncTriggers & 0x10), TextBuffer[UintVal]);
    TextBuffer[UintVal] = tmp;

#if 0
  sprintf(tbuff, "UintVal = 0x%x\n", UintVal);
  Udr_PutNChar(tbuff);
  sprintf(tbuff, "GetNextTextASCII = 0x%x\n", (char)TextBuffer[UintVal]);
  Udr_PutNChar(tbuff);
#endif

    if (!strcmp(DLTPGConfig[DLTPGNoNdx].Text[UcharVal], TextBuffer))
      if (UcharVal3 == (DLTPGConfig[DLTPGNoNdx].TextEnable & (1 << UcharVal)) > 0)
        FuncState = 8;
    }
  CodePtr = TPGTextEditArrTxt[UcharVal % 3];
  WriteCodeLN2(0, CodePtr);        // Write header on line 2
  ClearRestLN2();                  // Clear rest of line 2
  WriteTxtLN2(5, ": ");
  WriteTxtLN2(7, TextBuffer);              // Write edited text on line 2
  WriteCodeLN2(25, OffOnArrTxt[UcharVal3]);// Write on/off on line 2
  WriteType12_SAVE_ESC(FuncState);         // Write the SAVE ESC text
  switch (FuncState)
    {
    case 1:
    case 4:                          // Mark selected item
      WriteItemArrows(7, strlen(TextBuffer));
      CharBlinkLN2(0, OFF);          // Switch OFF blinking
      break;
    case 2:
    case 5:                          // Mark selected item
      WriteItemArrows(25, Cstrlen(OffOnArrTxt[UcharVal3]));
      CharBlinkLN2(0, OFF);          // Switch OFF blinking
      break;
    case 8:
    case 9:                          // Mark selected item
      WriteItemBrackets(7, strlen(TextBuffer));
      CharBlinkLN2(7 + UintVal, ON); // Switch OFF blinking at
      break;                         //  editing character
    }
  FuncTriggers = 0;                  // Reset the button-selection
  }

/***************************************************************************/
/* void DLTPGTextStyleSelect(void)                                 MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              EDIT  <SCALE>  POS   COLOR                                 */
/*           with SCALE selected.                                          */
/*           This function writes Line 2 menu:                             */
/*           SELECT:<1>                      ESC                           */
/*           This function is entered each time user presses UP or DOWN    */
/*           key or changs text, putting or removing SAVE  option as       */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  ON entry:                                                     */
/*           UcharVal  = DLTPGConfig[DLTPGNoNdx].TextScale;                */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextScaleSelect()
  {
  UC ndx = DLTPGNoNdx;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;
      DLTPGConfig[ndx].TextScale = UcharVal;  // Save new text scale
      }
    else
      {                                       // ..restore text scale
      if (ErrorCode = TrxDLTPGTextScale(ndx, DLTPGConfig[ndx].TextScale))
        {
        GotoErrorStatus(256*ndx + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;

    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                          // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                            // If button pressed is UP..
      if (UcharVal-- == ScaleOne)
        UcharVal = ScaleFour;     
      }
    else
      {                            // ..button pressed is DOWN
      if (UcharVal++ == ScaleFour)
        UcharVal = ScaleOne;
      }
    if (DLTPGConfig[ndx].TextScale == UcharVal)
      FuncState = 1;               //  if current scale, remove SAVE option

    if (ErrorCode = TrxDLTPGTextScale(ndx, UcharVal))
      {
      GotoErrorStatus(256*ndx + ErrorCode);
      return;
      }
    }

  CodePtr = HDTextScaleArrTxt[UcharVal];  // Get text for selected level
  WriteCodeLN2(0, SelectHdrTxt);
  WriteCode2(CodePtr);
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;
  }


/***************************************************************************/
/* void DLTPGTextPosSelect(void)                                   MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              EDIT   STYLE   <POS>   COLOR                               */
/*           with POS selected.                                            */
/*           This function writes Line 2 menu:                             */
/*           X:< +0>   Y:  +0                   ESC                        */
/*           This function is entered each time user presses UP or DOWN    */
/*           key or changes position, putting or removing SAVE  option as  */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  On entry:                                                     */
/*           UcharVal  = DLTPGConfig[DLTPGNoNdx].TextPos[0];               */
/*           UcharVal1 = DLTPGConfig[DLTPGNoNdx].TextPos[1];               */
/*                                                                         */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextPosSelect()
  {

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If text position has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].TextPos[0] = UcharVal;
      DLTPGConfig[DLTPGNoNdx].TextPos[1] = UcharVal1;
      }
    else
      {                      // ..restore text style
      if (ErrorCode = TrxDLTPGTextPos(DLTPGNoNdx, 
                                      DLTPGConfig[DLTPGNoNdx].TextPos[0], 
                                      DLTPGConfig[DLTPGNoNdx].TextPos[1]))
        {
        GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;

    Ptr = PrevPtr;
    Ptr->DispFunct();  // Display previous menu
    return;
    }

  if (FuncTriggers & 0x03)
    {          // If button pressed is UP/DOWN..
    if (FuncTriggers & 0x01)
      {        // If button pressed is UP..
      if (UcharVal++ == HDXPosMax)
        UcharVal = HDXPosMin;
      }
    else
      {                      // ..button pressed is DOWN
      if (UcharVal-- == HDXPosMin)
        UcharVal = HDXPosMax;
      }
    if ((UcharVal == DLTPGConfig[DLTPGNoNdx].TextPos[0]) &&
       (UcharVal1 == DLTPGConfig[DLTPGNoNdx].TextPos[1]))
      FuncState = 1;
                                    // Transmit new X position
    if (ErrorCode = TrxDLTPGTextPos(DLTPGNoNdx, UcharVal, UcharVal1))
      {
      GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
      return;
      }
    }

  if (FuncTriggers & 0x0C)
    {      // If button UP/DOWN pressed..
    if (FuncTriggers & 0x04)
      {        // If button pressed is UP..
      if (UcharVal1++ == HDYPosMax)
        UcharVal1 = HDYPosMin;
      }
    else
      {                      // ..button pressed is DOWN
      if (UcharVal1-- == HDYPosMin)
        UcharVal1 = HDYPosMax;
      }
    if ((UcharVal == DLTPGConfig[DLTPGNoNdx].TextPos[0]) &&
       (UcharVal1 == DLTPGConfig[DLTPGNoNdx].TextPos[1]))
      FuncState = 2;
    if (ErrorCode = TrxDLTPGTextPos(DLTPGNoNdx, UcharVal, UcharVal1))
      {
      GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
      return;
      }
    }
  WriteTxtLN2(0, "X: ");                  // Write line 2 header
  sprintf(TextBuffer, "%+3d", UcharVal);  // Convert coordinate to ascii
  WriteTxt2(TextBuffer);
  ClearToPosLN2(10);
  WriteTxt2("Y: ");                       // Convert coordinate to ascii
  sprintf(TextBuffer, "%+3d", UcharVal1);
  WriteTxt2(TextBuffer);
  ClearRestLN2();
  WriteType2_SAVE_ESC(FuncState);        // Write the SAVE ESC text

  switch (FuncState)
    {
    case 1:
    case 5:
      WriteItemArrows(3, 3);
      break;
     case 2:
    case 4:
      WriteItemArrows(13, 3);
      break;
    }
  FuncTriggers = 0;                    // Reset button-selection
  }

/***************************************************************************/
/* void DLTPGTextColorSelect(void)                                 MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              EDIT  STYLE  POS <COLOR> BACKGROUND                        */
/*           with COLOR selected.                                          */
/*           This function writes Line 2 menu:                             */

/*           This function is entered each time user presses UP or DOWN    */
/*           key or changs text, putting or removing SAVE  option as       */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  On entry:                                                     */
/*                 UcharVal  = DLTPGConfig[DLTPGNoNdx].TextColor & 0x0F;   */
/*                 UcharVal1 = 0;                                          */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:    DLTPGConfig[DLTPGNoNdx].TextColor member carries text color   */
/*           and text background info in the following manner:             */
/*                                                                         */
/*           |X|R|G|B|X|R|G|B| .TextColor byte                             */
/*                                                                         */
/*           Bits 0-2 represent text RGB value, bits 4-6 represent         */
/*           background RGB value.                                         */
/***************************************************************************/
void DLTPGTextColorSelect()
  {
  UC ndx = DLTPGNoNdx;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;
      DLTPGConfig[ndx].TextColor &= 0xF0;      // Zero text color
      DLTPGConfig[ndx].TextColor |= UcharVal;  // Save new text color
      }
    else
      {                      // ..restore text color
      if (ErrorCode = TrxDLTPGTextColor(ndx, DLTPGConfig[ndx].TextColor))
        {
        GotoErrorStatus(256*ndx + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                          // If UP/DOWN button pressed..
      if (FuncTriggers & 0x01) // If button pressed is UP..
        {       
        if (UcharVal-- == ColorBlack)
          UcharVal = ColorWhite;
        }
      else
        {                      // ..button pressed is DOWN
        if (UcharVal++ == ColorWhite)
          UcharVal = ColorBlack;
        }
    if ((DLTPGConfig[ndx].TextColor & 0x0F) == UcharVal)
      FuncState = 1;               //  if current color, remove SAVE option

    UcharVal1  = DLTPGConfig[ndx].TextColor;
    UcharVal1 &= 0xF0;             // zero color part...
    UcharVal1 |= UcharVal;         // place new color....
    if (ErrorCode = TrxDLTPGTextColor(ndx, UcharVal1))
      {
      GotoErrorStatus(256*ndx + ErrorCode);
      return;
      }
    }

  CodePtr = HDTextColorArrTxt[UcharVal];  // Get text for selected color
  WriteCodeLN2(0, SelectHdrTxt);
  WriteCode2(CodePtr);
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;
  }

/***************************************************************************/
/* void DLTPGTextBackgroundSelect(void)                            MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              EDIT  STYLE  POS  COLOR <BACKGROUND>                       */
/*           with BACKGROUND selected.                                     */
/*           This function writes Line 2 menu:                             */

/*           This function is entered each time user presses UP or DOWN    */
/*           key or changs text, putting or removing SAVE  option as       */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  On entry:                                                     */
/*                 UcharVal  = DLTPGConfig[DLTPGNoNdx].TextColor >> 4;     */
/*                 UcharVal1 = 0;                                          */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:    DLTPGConfig[DLTPGNoNdx].TextColor member carries text color   */
/*           and text background info in the following manner:             */
/*                                                                         */
/*           |X|R|G|B|X|R|G|B| .TextColor byte                             */
/*                                                                         */
/*           Bits 0-2 represent text RGB value, bits 4-6 represent         */
/*           background RGB value.                                         */
/***************************************************************************/
void DLTPGTextBackgroundSelect()
  {
  UC ndx = DLTPGNoNdx;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;
      UcharVal = UcharVal << 4;
      DLTPGConfig[ndx].TextColor &= 0x0F;      // Zero background nibble
      DLTPGConfig[ndx].TextColor |= UcharVal;  // Save new text background
      }
    else
      {                      // ..restore text color
      if (ErrorCode = TrxDLTPGTextColor(ndx, DLTPGConfig[ndx].TextColor))
        {
        GotoErrorStatus(256*ndx + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                          // If UP/DOWN button pressed..
      if (FuncTriggers & 0x01) // If button pressed is UP..
        {       
        if (UcharVal-- == ColorBlack)
          UcharVal = ColorWhite;
        }
      else
        {                      // ..button pressed is DOWN
        if (UcharVal++ == ColorWhite)
          UcharVal = ColorBlack;
        }
    if ((DLTPGConfig[ndx].TextColor >> 4) == UcharVal)
      FuncState = 1;               //  if current color, remove SAVE option

    UcharVal1  = DLTPGConfig[ndx].TextColor;
    UcharVal1 &= 0x0F;             // zero background part...
    UcharVal1 |= UcharVal << 4;    // place new background....

    if (ErrorCode = TrxDLTPGTextColor(ndx, UcharVal1))
      {
      GotoErrorStatus(256*ndx + ErrorCode);
      return;
      }
    }

  CodePtr = HDTextColorArrTxt[UcharVal];  // Get text for selected level
  WriteCodeLN2(0, SelectHdrTxt);
  WriteCode2(CodePtr);
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;
  }




/***************************************************************************/
/* void DLTPGTextMovementSelect(void)                              MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  17.02.2006                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in TEXT submenu:                               */
/*              EDIT   STYLE    POS   COLOR  <MOVEMENT>                    */
/*           with MOVEMENT selected.                                       */
/*           This function writes Line 2 menu:                             */
/*                                                                         */
/*           This function is entered each time user presses UP or DOWN    */
/*           key or changs text, putting or removing SAVE  option as       */
/*           necessary.                                                    */
/*                                                                         */
/* Remarks:  On entry:                                                     */
/*                 UcharVal  = DLTPGConfig[DLTPGNoNdx].TextMOvement        */
/*                 UcharVal1 = 0;                                          */
/*                                                                         */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGTextMovementSelect()
  {
  UC ndx = DLTPGNoNdx;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {
      ActivePresetNo = 0;
      DLTPGConfig[ndx].TextMovement = UcharVal;  // Save new text movement
      }
    else
      {                      // ..restore text movement
      if (ErrorCode = TrxDLTPGTextMovement(ndx, DLTPGConfig[ndx].TextMovement))
        {
        GotoErrorStatus(256*ndx + ErrorCode);
        return;
        }
      }
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                          // If UP/DOWN button pressed..
      if (FuncTriggers & 0x01) // If button pressed is UP..
        {       
        if (UcharVal-- == TextMovementNone)
          UcharVal = TextMovementBoth;
        }
      else
        {                      // ..button pressed is DOWN
        if (UcharVal++ == TextMovementBoth)
          UcharVal = TextMovementNone;
        }
    if (DLTPGConfig[ndx].TextMovement == UcharVal)
      FuncState = 1;               //  if current color, remove SAVE option

    if (ErrorCode = TrxDLTPGTextMovement(ndx, UcharVal))
      {
      GotoErrorStatus(256*ndx + ErrorCode);
      return;
      }
    }

  CodePtr = HDTextMovArrTxt[UcharVal];  // Get text for selected level
  WriteCodeLN2(0, SelectHdrTxt);
  WriteCode2(CodePtr);
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;
  }

/***************************************************************************/
/* void DLTPGAudioMenuShow(void)                                   MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in DLTPG submenu, which is as follows:         */
/*           2NDMNU:  PATT  TEXT  SYSTEM  EDH  <AUDIO>  TIMING             */
/*           having AUDIO selected.                                        */
/*           This function displays audio menu for current DL generator:   */
/*             <SIGNAL>  LEVEL  GROUP                                      */
/*                                                                         */
/* Remarks:  For current generator DLTPGAudioMenuNdx[DLTPGNoNdx]           */
/*           holds selected item nr, i.e. SIGNAL, LEVEL, etc. in audio     */
/*           menu.                                                         */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGAudioMenuShow()
  {
  register int i, j;

  WriteCodeLN1(0, SecondmnuHdrTxt);
  WriteCode1(SlashDotHdrTxt);
  WriteCode1(DLTPG_menu[DLTPGNoNdx].ItemTxt);
  WriteChar1('/');
  WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);
  WriteCode1(CoSelectTxt);                 // Write sub-menu headline
  ClearRestLN1();

  DLTPGAudioMenuNdx[DLTPGNoNdx] = Ptr->ItemNumber; // Update ../EMB.AUDIO menu index
  WriteCodeLN2(0, SecondmnuHdrTxt);

  i = j = DLTPGAudioClickItem; // 3

  if (DLTPGaudio_menu[DLTPGAudioMenuNdx[DLTPGNoNdx]].ItemNumber < DLTPGAudioClickItem)
    i = DLTPGAudioSignalItem; // 0
  else
    j = DLTPGAudioClickItem + 1; // 5

  for (; i < j; i++)
    {
    ClearToPosLN2(DLTPGaudio_menu[i].ItemPos);  // Find item column position
    WriteCode2(DLTPGaudio_menu[i].ItemTxt);     // Write item texts
    }

  ClearRestLN2();
  i = Ptr->ItemConfig;

  WriteArrowsField(i);
  WriteItemArrows(Ptr->ItemPos, Cstrlen(Ptr->ItemTxt));
  }

#if 0
enum DLTPGAudioItems
  {
  DLTPGAudioSignalItem = 0, DLTPGAudioLevelItem, DLTPGAudioGroupItem,\
  DLTPGAudioClickItem, DLTPGAudioTimingItem
  };
#endif

/***************************************************************************/
/* void DLTPGAudioDown(void)                                       MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in AUDIO submenu with one of the following:    */
/*              SIGNAL  LEVEL  GROUP  CLICK OFFSET  TIMING                 */
/*           selected                                                      */
/*           The selected item is in DLTPGAudioMenuNdx[DLTPGNoNdx]         */
/*                                                                         */
/* Remarks:  This function prepares some global variables according to     */
/*           what was selected in the AUDIO submenu for use by functions   */
/*           which actually perform required actions:                      */
/*                void DLTPGAudioSignalSelect()                            */
/*                void DLTPGAudioLevelSelect()                             */
/*                void DLTPGAudioGroupSelect()                             */
/*           and writes Line 1 header according to                         */
/*           DLTPGAudioMenuNdx[DLTPGNoNdx]                                 */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGAudioDown()
  {
  UC itemNdx = DLTPGAudioMenuNdx[DLTPGNoNdx];

  WriteCodeLN1(0, SecondmnuHdrTxt);        // Write menu headline
  WriteCode1(SlashDotHdrTxt);
  WriteCode1(DLTPG_submenu[DLTPGsubmenuNdx[DLTPGNoNdx]].ItemTxt);
  WriteChar1('/');
  WriteCode1(DLTPGaudio_menu[itemNdx].ItemTxt);
  WriteCode1(CoSelectTxt);
  ClearRestLN1();

  switch (itemNdx)
    {
    case DLTPGAudioSignalItem:
      UcharVal = DLTPGConfig[DLTPGNoNdx].AudioSignal;
      break;
    case DLTPGAudioLevelItem:
      UcharVal = DLTPGConfig[DLTPGNoNdx].AudioLevel;
      break;
    case DLTPGAudioClickItem:
      IntVal = DLTPGConfig[DLTPGNoNdx].AudioClick;
      break;
    }
  PrevPtr = &DLTPGaudio_menu   [DLTPGAudioMenuNdx[DLTPGNoNdx]]; // Ptr; // Store old menu-pointer
  Ptr     = &DLTPGaudio_submenu[DLTPGAudioMenuNdx[DLTPGNoNdx]]; // Point to selected item

  FuncState    = 1;   // Prepare for item state-machine
  FuncTriggers = 0;
  FuncSave     = FuncEscape = FALSE;
  SelectModeOn = TRUE;
  }

/***************************************************************************/
/* void DLTPGAudioSignalSelect(void)                               MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in AUDIO submenu:                              */
/*             <SIGNAL> LEVEL  GROUP  CLICK OFFSET  TIMING                 */
/*           with SIGNAL selected.                                         */
/*           This function writes Line 2 menu:                             */
/*           SIGNAL: <Off>       ESC                                       */
/*           This function is entered each time user presses UP or DOWN    */
/*           key, putting or removing SAVE  option as necessary.           */
/*                                                                         */
/* Remarks:                                                                */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGAudioSignalSelect()
  {
  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If audio signal has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].AudioSignal = UcharVal;
      }
    else
      {                      // If escape ..restore audio signal
      if (UcharVal != DLTPGConfig[DLTPGNoNdx].AudioSignal)
        if (ErrorCode = TrxDLTPGAudioSignal(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].AudioSignal))
          {
          GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
          return;
          }
      }
    SelectModeOn = FALSE;
    Ptr = PrevPtr;
    Ptr->DispFunct();
    return;
    }

  if (FuncTriggers & 0x03)
    {                                // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                              // If button pressed is UP..
      if (UcharVal-- == HDSilence)
        UcharVal = HDAudioOff;
      }
    else 
      {                              // ..button pressed is DOWN
      if (UcharVal++ == HDAudioOff)
        UcharVal = HDSilence;
      }

    if (UcharVal == DLTPGConfig[DLTPGNoNdx].AudioSignal)  // If current signal
      FuncState = 1;                                      //  remove SAVE option
    if (ErrorCode = TrxDLTPGAudioSignal(DLTPGNoNdx, UcharVal))
      {
      GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
      return;
      }
    }
  CodePtr = HDAudioSignalArrTxt[UcharVal];   // Get text for selected signal
  WriteCodeLN2(0, SignalHdrTxt);             // Write header for line 2
  WriteCode2(CodePtr);                       // Write selected text
  ClearRestLN2();                            // Clear rest of line 2
  WriteType1_SAVE_ESC(FuncState);            // Write the SAVE ESC text
  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, Cstrlen(CodePtr));    // Mark selected item
  FuncTriggers = 0;                          // Reset the button-selection
  }

/***************************************************************************/
/* void DLTPGAudioLevelSelect(void)                                MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  22.02.2005                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in AUDIO submenu:                              */
/*              SIGNAL <LEVEL> GROUP  CLICK OFFSET  TIMING                 */
/*           with LEVEL selected.                                          */
/*           This function writes Line 2 menu:                             */
/*           LEVEL: <Silence>       ESC                                    */
/*           This function is entered each time user presses UP or DOWN    */
/*           key, putting or removing SAVE  option as necessary.           */
/*                                                                         */
/* Remarks:                                                                */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGAudioLevelSelect()
  {
  code UC* tablePtr;

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If audio level has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].AudioLevel = UcharVal;
      }
    else
      {                      // ..restore audio level
      if (UcharVal != DLTPGConfig[DLTPGNoNdx].AudioLevel)
        if (ErrorCode = TrxDLTPGAudioLevel(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].AudioLevel))
          {
          GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
          return;
          }
      }
    SelectModeOn = FALSE;  // Clear select-mode
    Ptr = PrevPtr;         // Set pointer to previous menu
    Ptr->DispFunct();      // Display previous menu
    return;
    }
  tablePtr = PT8641AudioLevelTable;

  if (FuncTriggers & 0x03)
    {                        // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                      // If button pressed is UP..
        if (UcharVal-- == HDLevel0)
          UcharVal = HDLevel24;
      }
    else
      {                      // ..button pressed is DOWN
      if (UcharVal++ == HDLevel24)
        UcharVal = HDLevel0;
      }
    if (UcharVal == DLTPGConfig[DLTPGNoNdx].AudioLevel)  // If current level
      FuncState = 1;                                     //  remove SAVE option
    if (ErrorCode = TrxDLTPGAudioLevel(DLTPGNoNdx, UcharVal))
      {
      GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
      return;
      }
    }
  CodePtr = HDAudioLevelArrTxt[UcharVal];  // Get text for selected level
  WriteCodeLN2(0, LevelHdrTxt);
  WriteCode2(CodePtr);
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);
  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(7, Cstrlen(CodePtr));// Mark selected item
  FuncTriggers = 0;
  }

  
/***************************************************************************/
/* void DLTPGAudioClickSelect(void)                                MENU.C  */
/*                                                                         */
/* Author:   Janusz Kuzminski                                              */
/* Revised:  23.03.2006                                                    */
/*                                                                         */
/* Function: This function is entered in response to user pressing the     */
/*           Down key while in AUDIO submenu:                              */
/*              SIGNAL  LEVEL  GROUP <CLICK OFFSET> TIMING                 */
/*           with CLICK OFFSET selected.                                   */
/*           This function writes Line 2 menu:                             */
/*           OFFSET: <000>       ESC                                       */
/*           This function is entered each time user presses UP or DOWN    */
/*           key, putting or removing SAVE  option as necessary.           */
/*                                                                         */
/* Remarks:                                                                */
/*                                                                         */
/* Returns:  Nothing                                                       */
/* Notes:                                                                  */
/***************************************************************************/
void DLTPGAudioClickSelect()
  {

  if (FuncSave || FuncEscape)
    {
    if (FuncSave)
      {                       // If Click has changed..
      ActivePresetNo = 0;
      DLTPGConfig[DLTPGNoNdx].AudioClick = IntVal;
      }
    else
      {
      if (IntVal != DLTPGConfig[DLTPGNoNdx].AudioClick)
        if (ErrorCode = TrxDLTPGAudioClick(DLTPGNoNdx, DLTPGConfig[DLTPGNoNdx].AudioClick))
          {
          GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
          return;
          }
      }
    SelectModeOn = FALSE;

    Ptr = PrevPtr;
    Ptr->DispFunct();     // Display previous menu
    return;
    }

  if (FuncTriggers & 0x03)
    {                                // If UP/DOWN button pressed..
    if (FuncTriggers & 0x01)
      {                              // If button pressed is UP..
      if (++IntVal > ClickHigh)      // If max. click reached..
        IntVal = ClickLow;           //  .. roll-over to min. value
      }
    else
      {                              // ..button pressed is DOWN
      if (--IntVal < ClickLow)       // If min. click reached..
        IntVal = ClickHigh;          //  .. roll-over to max. value
      }

    if (IntVal == DLTPGConfig[DLTPGNoNdx].AudioClick)   // If current click
      FuncState = 1;                                    //  remove SAVE option

    if (ErrorCode = TrxDLTPGAudioClick(DLTPGNoNdx, IntVal))
      {
      GotoErrorStatus(256*DLTPGNoNdx + ErrorCode);
      return;
      }
    }

  WriteCodeLN2(0, OffsetHdrTxt);        // Write line 2 header
  sprintf(TextBuffer, "%+4d", IntVal);  // Convert click to ascii
  Cstrcat(TextBuffer, mSTxt);           // Add prefix mS
  WriteTxt2(TextBuffer);                // Write click value
  ClearRestLN2();
  WriteType1_SAVE_ESC(FuncState);       // Write the SAVE ESC text

  if ((FuncState == 1) || (FuncState == 3))
    WriteItemArrows(8, strlen(TextBuffer));  // Mark selected item

  FuncTriggers = 0;     // Reset button selectors
  }

UC FindNextDL(char present, char * next)
  {
  UC i;

  for (i = present; i < MaxDLTPGUnits; i++)
    {
    if (DLTPGUnit[i].Present)
      {
      *next = i;
      return (1);
      }
    }
  return (0);
  }

/***************************************************************************/
/* UC FindHDInterface(UC Triggers, UC system, UC interface)                */
/*                                                                         */
/* Author:  Janusz Kuzminski                                               */
/* Revised: 27.03.2006                                                     */
/*                                                                         */
/* Function: This function returns next value of interface based on which  */
/*           key (UP or DOWN) is pressed.                                  */
/*                                                                         */
/* Args:     UC Triggers: function triggers, indicating which (UP/DOWN)    */
/*                        button was pressed.                              */
/*           UC system :  system for which next interface is to be found.  */
/*           UC pattern:  current interface                                */
/* Remarks:                                                                */
/*                                                                         */
/*                                                                         */
/* Returns: Valid interface or 0xFF.                                       */
/* Notes:                                                                  */
/***************************************************************************/
UC FindHDInterface(UC Triggers, UC system, UC interface)
  {

  if ((system > 0) && (system < 14))
    {
    if (Triggers & 0x01)         // If button pressed is UP..
      {
      if (interface++ == 5)      // check if equal and then increment...
        interface = 0;
      }
    else                         // ..button pressed is DOWN
      {
      if (interface-- == 0)
        interface = 5;
      }
    return (interface);
    }
  return (0);
  }

