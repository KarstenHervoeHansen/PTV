/***************************************************************************/
/*  Copyright   ProTeleVision Technologies A/S, BRONDBY 1998               */
/*  Project:    PT5230 Digital Video Generator                             */
/*  Module:     MENUB.C                                                    */
/*  Author:     Kim Engedahl, DEV                                          */
/*  Org. date:  27.07.2005: JK                                             */
/*  Rev. date:                                                             */
/*  Status:     Version xx                                                 */
/*                                                                         */
/*  This was introduced because of too big size of module menua.c, which   */
/*  was increased due to new menu intems introduced (TLG and HDTPG).       */
/*  Linker gave an error due to too big module.                            */
/***************************************************************************/
#include <xa.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "mas.h"

#include "menutree.h"
#include "menu.h"
#include "menuhlp.h"
#include "message.h"
#include "timing.h"
#include "disp_drv.h"
#include "cont_drv.h"
#include "keyb_drv.h"
#include "text.h"
#include "tables.h"
#include "util.h"
#include "serial1.h"
#include "unit_drv.h"
#include "iic.h"
#include "rs232par.h"
#include "rs232err.h"
#include "xaexprt.h"
#include "xadrivr.h"

static char tbuff[80];     /* temporary buffer used for printing messages */
                           /* for test purposes                           */

/***************************************************************************/
/*  BaseMenuShow                                                   MENU.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 980119                                    */
/* Revised:   12.12.2003, JK                                               */
/*                                                                         */
/*  Function: Display the items in the BASE menu.                          */
/*  Remarks:  Modified to incorporate TLG unit (if present) into base      */
/*            menu.  This function is based on earlier version of PT5230   */
/*            master, which had mix sync unit                              */
/*  Returns:  Nothing                                                      */
/*  Updates:    TBD                                                        */
/* 12.12.2003: Modified in order to incorporate TriLevel PT8640 board      */
/*             into menu system.  Function BaseMenuShow() has been         */
/*             modified to correctly display TriLevel generator in the     */
/*             main menu (if present).  This function uses a set of        */
/*             DisplayType values which are desctibed in Display_types.doc */
/* Remarks:  This function is entered each time base menu is to be         */
/*           displayed.  It finds out which generators are installed and   */
/*           controls contents of display second line according to number  */
/*           of generators installed (NoOfTXGs).  In case of several       */
/*           generators of the same type installed, it uses function       */
/*           HDTPG().  Variable DisplayType is used for item display */
/*           as specified in display_types.doc.                            */
/*                                                                         */
/*           This function displays base menu in form:                     */
/*           ...                                                           */
/*           MENU: <BLACK-BURST>  <AES-EBU>                                */
/*           This function has to be modified each time a new generataor   */
/*           is to be added.                                               */
/* 04.04.2005: Modified to acommodate one HDTPG board                      */
/*             As this board may only be mounted at the place where        */
/*             a TLG board may reside, no changes were necessary in        */
/*             display_types.doc.                                          */
/***************************************************************************/
/* this is taken from earlier version with MixSyncUnit */

void BaseMenuShow()
  {
  UC NoOfTXGs, NoOfSDITXGs, NoOfAnlTPGs; /* NoOfTLGs; */
  UC AESEBUPresent;
  UC DisplayType, spacing;

  code struct MENU_ITEM* tmpPtr;

  register int i, j;
  int number, start;

#if 0
/**************************************/

  AnlTPGUnit[0].Present = 0;

  SDITSGUnit[0].Present = 0;
  SDITSGUnit[1].Present = 0;

  SDITPGUnit[0].Present = 0; // 8632
  SDITPGUnit[1].Present = 0;
  SDITPGUnit[2].Present = 0;
/**************************************/
#endif

  WriteCodeLN1(0, PT5230HeadlineTxt);
  ClearRestLN1();

  BaseNdx = Ptr->ItemNumber;              // Save Base Menu index

  WriteCodeLN2(0, MenuHdrTxt);            // Write header for menu line

  AESEBUPresent = AESEBUUnit.Present;

  for (NoOfAnlTPGs = i = 0; i < 2; i++)
    NoOfAnlTPGs += AnlTPGUnit[i].Present;

  for (NoOfSDITXGs = i = 0; i < 3; i++)
    NoOfSDITXGs += SDITSGUnit[i].Present + SDITPGUnit[i].Present;

/***************************************************************************/
/***************************************************************************/
  NoOfTXGs = NoOfAnlTPGs + NoOfSDITXGs;  /* + TLGUnit.Present;    JK  */

  /* Possible Failure below ! */
  if (TLGUnit[0].Present || TLGUnit[4].Present || TLGUnit[8].Present)
    NoOfTXGs++;

  if (HDTPGUnit[0].Present || HDTPGUnit[4].Present || HDTPGUnit[8].Present)
    NoOfTXGs++;
/***************************************************************************/
#if 0
  sprintf(tbuff, "NoOfTXGs = %d\n", (int)NoOfTXGs);
  Udr_PutNChar(tbuff);
#endif
/***************************************************************************/

  tmpPtr = Ptr;            // Save menu pointer temporarily

                      // The following DisplayType settings are
                      //  based on the display_types.doc
  switch (NoOfTXGs)
    {
    case 0:
    case 1:
      switch (NoOfTXGs + AESEBUPresent)
        {
        case 0: // (no Gen no AESEBU)
          if (BaseNdx < PresetItem)
            DisplayType = 1;
          else
            DisplayType = 2;
          break;
        case 1: // (one Gen no AESEBU) or (no Gen and AESEBU)
          if (BaseNdx < GenlockItem)
            DisplayType = 1;
          else
            if (BaseNdx < TestItem)
              DisplayType = 3;
          break;
        case 2: // (one Gen and AESEBU)
          if (BaseNdx < AESEBUItem)
            DisplayType = 1;
          else
            if (BaseNdx < ConfigItem)
              DisplayType = 5;
            else
              DisplayType = 4;
          break;
        }
      break;
    case 2:                    //(NoOfTXGs = 2)
      if (NoOfAnlTPGs == 2)    // two Ana generators...
        {
        if (BaseNdx < AnlTPG5Item)
          DisplayType = 1;
        else
          {
          if (!AESEBUPresent)  // no AESEBU
            {
            if (BaseNdx < PresetItem)
              DisplayType = 6;
            else
              DisplayType = 2;
            }
          else
            {
            if (BaseNdx < GenlockItem)
              DisplayType = 6;
            else
              DisplayType = 3;
            }
          }
        }
      else
        if (NoOfAnlTPGs) // if one Ana generator... (NoOfTXGs = 2)
          {              // and one TRI or HD...
          if (TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present   ||
              HDTPGUnit[0].Present || HDTPGUnit[0].Present || HDTPGUnit[0].Present)
            {
            if (BaseNdx < AnlTPG2Item)
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < PresetItem)
                  DisplayType = 7;
                else
                  DisplayType = 2;
                }
              else
                {
                if (BaseNdx < GenlockItem)
                  DisplayType = 7;
                else
                  DisplayType = 3;
                }
              }
            }
          else  // if one Ana generator no TRI nor HD (NoOfTXGs = 2)
            {
            if (BaseNdx < AnlTPG5Item+1)
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < ConfigItem)
                  DisplayType = 8;
                else
                  DisplayType = 4;
                }
              else
                {
                if (BaseNdx < PresetItem)
                  DisplayType = 8;
                else
                  DisplayType = 2;
                }
              }
            }
        }
      else                     // if no Ana generator... (NoOfTXGs = 2)
        if (NoOfSDITXGs == 2)  // two SDI...
          {
          if (BaseNdx < FindSDIUnit(2))
            DisplayType = 1;
          else
            {
            if (!AESEBUPresent)
              {
              if (BaseNdx < ConfigItem)
                DisplayType = 9;
              else
                DisplayType = 4;
              }
            else
              {
              if (BaseNdx < PresetItem)
                DisplayType = 9;
              else
                DisplayType = 2;
              }
            }
          }
        else  // (NoOfSDITXGs == 1) (NoOfTXGs = 2) no Ana, (SDI/TRI, SDI/HD, TRI/HD)
          {
          if (NoOfSDITXGs == 1)  // one SDI...(SDI/TRI, SDI/HD)
            {
            if (TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present)
              {                  // SDI TRI
              if (BaseNdx < HDTPGItem) // AnlTPG2Item   ****HERE****
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < ConfigItem)
                    DisplayType = 8;
                  else
                    DisplayType = 4;
                  }
                else
                  {
                  if (BaseNdx < PresetItem)
                    DisplayType = 8;
                  else
                    DisplayType = 2;
                  }
                }
              }
            else
              {                  // SDI HD
              if (BaseNdx < AnlTPG2Item)
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < ConfigItem)
                    DisplayType = 8;
                  else
                    DisplayType = 4;
                  }
                else
                  {
                  if (BaseNdx < PresetItem)
                    DisplayType = 8;
                  else
                    DisplayType = 2;
                  }
                }
              }
            }
          else  // no SDI, (TRI/HD)...
            if (BaseNdx < HDTPGItem)
              DisplayType = 1;
            else
              if (!AESEBUPresent)
                {
                if (BaseNdx < ConfigItem)
                  DisplayType = 12;
                else
                  DisplayType = 4;
                }
              else
                {
                if (BaseNdx < PresetItem)
                  DisplayType = 12;
                else
                  DisplayType = 2;
                }
          }
      break;
    case 3:                  // ******(NoOfTXGs = 3)*******
      if (NoOfAnlTPGs == 2)  // ANA ANA SDI or ANA ANA HD
        {
        if (NoOfSDITXGs)     // ANA ANA SDI
          {
          if (BaseNdx < AnlTPG5Item)
            DisplayType = 1;
          else
            {
            if (!AESEBUPresent)
              {
              if (BaseNdx < GenlockItem)
                DisplayType = 6;
              else
                if (BaseNdx < TestItem)
                  DisplayType = 3;
              }
            else
              {
              if (BaseNdx < AESEBUItem)
                DisplayType = 6;
              else
                if (BaseNdx < ConfigItem)
                  DisplayType = 5;
              else
                DisplayType = 4;
              }
            }
          }
        else
          {                   // ANA ANA HD
          if (BaseNdx < AnlTPG2Item)  // ******* !!!!! ******
            DisplayType = 1;
          else
            {
            if (!AESEBUPresent)
              {
              if (BaseNdx < GenlockItem)
                DisplayType = 7;
              else
                if (BaseNdx < TestItem)
                  DisplayType = 3;
              }
            else
              {
              if (BaseNdx < AESEBUItem)
                DisplayType = 7;
              else
                if (BaseNdx < ConfigItem)
                  DisplayType = 5;
              else
                DisplayType = 4;
              }
            }
          }
        }
      else
        if (NoOfAnlTPGs)  // (NoOfAnlTPGs == 1)
          {
          if ((TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present) &&
              (HDTPGUnit[0].Present || HDTPGUnit[4].Present || HDTPGUnit[8].Present))
            {                            // ANA TRI HD
            if (BaseNdx < HDTPGItem)
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < GenlockItem)
                  DisplayType = 13;
                else
                  DisplayType = 3;
                }
              else
                {
                if (BaseNdx < AESEBUItem)
                  DisplayType = 13;
                else
                  if (BaseNdx < ConfigItem)
                    DisplayType = 5;
                  else
                    DisplayType = 4;
                }
              }
            }
          else
            {
            if (NoOfSDITXGs == 2)   // ANA SDI SDI
              {
              if (BaseNdx < AnlTPG5Item+1)
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < PresetItem)
                    DisplayType = 10;
                  else
                    DisplayType = 2;
                  }
                else
                  {
                  if (BaseNdx < GenlockItem)
                    DisplayType = 10;
                  else
                    if (BaseNdx < TestItem)
                      DisplayType = 3;
                  }
                }
              }
            else
              {
              if ((NoOfSDITXGs == 1) && 
                  (TLGUnit[0].Present   || 
                   TLGUnit[4].Present   || 
                   TLGUnit[8].Present))   // ANA SDI TRI
                {
                if (BaseNdx < HDTPGItem)  // ANA SDI TRI
                  DisplayType = 1;
                else
                  {
                  if (!AESEBUPresent)
                    {
                    if (BaseNdx < GenlockItem)
                      DisplayType = 7;
                    else
                      DisplayType = 3;
                    }
                  else
                    {
                    if (BaseNdx < AESEBUItem)
                      DisplayType = 7;
                    else
                      if (BaseNdx < ConfigItem)
                        DisplayType = 5;
                      else
                        DisplayType = 4;
                    }
                  }
                }
              else
                {                           // must be ANA SDI HD
                if (BaseNdx < AnlTPG2Item)  // ANA SDI HD
                  DisplayType = 1;
                else
                  {
                  if (!AESEBUPresent)
                    {
                    if (BaseNdx < GenlockItem)
                      DisplayType = 7;
                    else
                      DisplayType = 3;
                    }
                  else
                    {
                    if (BaseNdx < AESEBUItem)
                      DisplayType = 7;
                    else
                      if (BaseNdx < ConfigItem)
                        DisplayType = 5;
                      else
                        DisplayType = 4;
                    }
                  }
                }
              }
            }
          }
        else                     // (NoOfAnlTPGs == 0) ***(NoOfTXGs = 3)***
          {
          switch (NoOfSDITXGs)
            {
            case 3:              // SDI SDI SDI 
              if (BaseNdx < FindSDIUnit(2))
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < PresetItem)
                    DisplayType = 11;
                  else
                    DisplayType = 2;
                  }
                else
                  {
                  if (BaseNdx < GenlockItem)
                    DisplayType = 11;
                  else
                    if (BaseNdx < TestItem)
                      DisplayType = 3;
                  }
                }
              break;
            case 2:              // SDI SDI TRI or SDI SDI HD
              if (TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present)
                {                // SDI SDI TRI
                if (BaseNdx < HDTPGItem)
                  DisplayType = 1;
                else
                  {
                  if (!AESEBUPresent)
                    {
                    if (BaseNdx < PresetItem)
                      DisplayType = 10;
                    else
                      DisplayType = 2;
                    }
                  else
                    {
                    if (BaseNdx < GenlockItem)
                      DisplayType = 10;
                    else
                      if (BaseNdx < TestItem)
                        DisplayType = 3;
                    }
                  }
                }
              else
                {                 // must be SDI SDI HD
                if (BaseNdx < AnlTPG2Item)
                  DisplayType = 1;
                else
                  {
                  if (!AESEBUPresent)
                    {
                    if (BaseNdx < PresetItem)
                      DisplayType = 11;
                    else
                      DisplayType = 2;
                    }
                  else
                    {
                    if (BaseNdx < GenlockItem)
                      DisplayType = 10;
                    else
                      if (BaseNdx < TestItem)
                        DisplayType = 3;
                    }
                  }
                }
              break;
            case 1:               // must be SDI TRI HD
              if (BaseNdx < HDTPGItem)
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < PresetItem)
                    DisplayType = 12;
                  else
                    DisplayType = 2;
                  }
                else
                  {
                  if (BaseNdx < GenlockItem)
                    DisplayType = 12;
                  else
                    if (BaseNdx < TestItem)
                      DisplayType = 3;
                  }
                }
              break;
            } // switch (NoOfSDITXGs)
          }   // else
      break;
    case 4:                  // ******(NoOfTXGs = 4)*******
      if (NoOfAnlTPGs)       // one ANA
        {
        if ((TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present) &&
            (HDTPGUnit[0].Present || HDTPGUnit[4].Present || HDTPGUnit[8].Present))
          {                  // ANA SDI HD TRI
          if (BaseNdx < HDTPGItem)
            DisplayType = 1;
          else
            {
            if (!AESEBUPresent)
              {
              if (BaseNdx < SDITSG3Item)
                DisplayType = 13;
              else
                if (BaseNdx < ConfigItem)
                  DisplayType = 8;
                else
                  DisplayType = 4;
              }
            else
              {
              if (BaseNdx < SDITSG3Item)
                DisplayType = 13;
              else
                if (BaseNdx < PresetItem)
                  DisplayType = 8;
                else
                  DisplayType = 2;
              }
            }
          }
        else
          if (TLGUnit[0].Present || TLGUnit[4].Present || TLGUnit[8].Present)
            {                  // ANA SDI SDI TRI
            if (BaseNdx < AnlTPG2Item)
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < SDITPG1Item)
                  DisplayType = 7;
                else
                  if (BaseNdx < ConfigItem)
                    DisplayType = 9;
                  else
                    DisplayType = 4;
                }
              else
                {
                if (BaseNdx < SDITPG1Item)
                  DisplayType = 7;
                else
                  if (BaseNdx < PresetItem)
                    DisplayType = 9;
                  else
                    DisplayType = 2;
                }
              }
            }
          else
            {                  // ANA SDI SDI SDI
            if (BaseNdx < FindSDIUnit(1))
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < GenlockItem)
                  DisplayType = 10;
                else
                  DisplayType = 3;
                }
              else
                {
                if (BaseNdx < AESEBUItem)
                  DisplayType = 10;
                else
                  if (BaseNdx < ConfigItem)
                    DisplayType = 5;
                else
                  DisplayType = 4;
                }
              }
            }
        }   // if (NoOfAnlTPGs)
      else
        {
        if ((TLGUnit[0].Present   || TLGUnit[4].Present   || TLGUnit[8].Present) &&
            (HDTPGUnit[0].Present || HDTPGUnit[4].Present || HDTPGUnit[8].Present))
          {                  // SDI SDI HD TRI
          if (BaseNdx < HDTPGItem)
            DisplayType = 1;
          else
            {
            if (!AESEBUPresent)
              {
              if (BaseNdx < GenlockItem)
                DisplayType = 12;
              else
                DisplayType = 3;
              }
            else
              {
              if (BaseNdx < AESEBUItem)
                DisplayType = 12;
              else
                if (BaseNdx < ConfigItem)
                  DisplayType = 5;
                else
                  DisplayType = 4;
              }
            }
          }
        else
          if (HDTPGUnit[0].Present || HDTPGUnit[4].Present || HDTPGUnit[8].Present) 
            {                  // SDI SDI SDI HD
            if (BaseNdx < AnlTPG2Item)
              DisplayType = 1;
            else
              {
              if (!AESEBUPresent)
                {
                if (BaseNdx < GenlockItem)
                  DisplayType = 10;
                else
                  DisplayType = 3;
                }
              else
                {
                if (BaseNdx < AESEBUItem)
                  DisplayType = 10;
                else
                  if (BaseNdx < ConfigItem)
                    DisplayType = 5;
                  else
                    DisplayType = 4;
                }
              }
            }
          else
            if (TLGUnit[0].Present || TLGUnit[4].Present || TLGUnit[8].Present)
              {                  // SDI SDI SDI TRI
              if (BaseNdx < FindSDIUnit(1))
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < GenlockItem)
                    DisplayType = 10;
                  else
                    DisplayType = 3;
                  }
                else
                  {
                  if (BaseNdx < AESEBUItem)
                    DisplayType = 10;
                  else
                    if (BaseNdx < ConfigItem)
                      DisplayType = 5;
                  else
                    DisplayType = 4;
                  }
                }
              }
            else
              {                  // SDI SDI SDI SDI
              if (BaseNdx < FindSDIUnit(2))
                DisplayType = 1;
              else
                {
                if (!AESEBUPresent)
                  {
                  if (BaseNdx < GenlockItem)
                    DisplayType = 11;
                  else
                    DisplayType = 3;
                  }
                else
                  {
                  if (BaseNdx < AESEBUItem)
                    DisplayType = 11;
                  else
                    if (BaseNdx < ConfigItem)
                      DisplayType = 5;
                  else
                    DisplayType = 4;
                  }
                }
              }
            }
      break;
    } // switch (NoOfTXGs)

  spacing = 3;                // Normal spacing between items is 3

  switch (DisplayType)
    {
    case 1:
      Ptr = &base_menu[start = AnlBlkItem];
      number = 2;
      break;
    case 2:
      Ptr = &base_menu[start = PresetItem];
      number = 2;
      break;
    case 3:
      Ptr = &base_menu[start = GenlockItem];
      number = 3;
      break;
    case 4:
      Ptr = &base_menu[start = ConfigItem];
      number = 1;
      break;
    case 5:
      Ptr = &base_menu[start = AESEBUItem];
      number = 3;
      break;
    case 6:
      Ptr = &base_menu[start = AnlTPG5Item];
      number = 2;
      break;
    case 7:
      Ptr = &base_menu[start = AnlTPG2Item];
      number = 2;
      break;
    case 8:
    case 9:
      Ptr = &base_menu[start = FindSDIUnit(DisplayType-7)];
      number = 3;
      break;
    case 10:
    case 11:
      Ptr = &base_menu[start = FindSDIUnit(DisplayType-9)];
      spacing = 2;
      number = 3;
      break;
    case 12:
      Ptr = &base_menu[start = HDTPGItem];
      number = 3;
      break;
    case 13:
      Ptr = &base_menu[start = HDTPGItem];
      number = 2;
      break;
    }

#if 0
    sprintf(tbuff, "DisplayType = %d, NoOfAnlTPGs = %d, NoOfTXGs = %d\r\n", DisplayType, NoOfAnlTPGs, NoOfTXGs);
    Udr_PutNChar(tbuff);
    sprintf(tbuff, "BaseNdx = %d, start = %d, number = %d\r\n", BaseNdx, start, number);
    Udr_PutNChar(tbuff);
#endif

  for (j = 8, i = start; i < start+number; i++)
    {
    WriteCode2(Ptr->ItemTxt);

    if (spacing == 2)
      WriteTxt2("  ");
    else
      WriteTxt2("   ");

    if (Ptr->ItemNumber < BaseNdx )
      j += (spacing + Cstrlen(Ptr->ItemTxt));

    BaseItemRight(); /* finds if gen[x] is present */
    }

  ClearRestLN2();
  Ptr = tmpPtr;         // Restore menu pointer
  i = Ptr->ItemConfig;  // Get info on line 1&2 icons/dots

                      // If PANEL LOCK enabled..
                      //  include a pad-lock and remove the
                      //  down arrow except for the CONFIG menu.
  if ((Flags.PanelLockOn || Flags.NormalLockOn ) && (BaseNdx != ConfigItem))
    {
    if (Flags.PanelLockOn)
      i = (i | P_) & ~D_;
    else
      {
      switch (BaseNdx)
        {
        case AnlBlkItem:
        case GenlockItem:
          i = (i | P_) & ~D_;
          break;
        }
      }
    }
  WriteArrowsField(i);                // Write line 1&2 icons/dots
  WriteItemArrows(j, Cstrlen(Ptr->ItemTxt));  // Mark selected item
  }

/***************************************************************************/
/*  AnlBlkMenuShow                                    MENU.C  */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 980119                          */
/* Revised:    980508                                       */
/*                                                  */
/*  Function:  Display the items in the BLACK-BURST menu.            */
/*  Remarks:    Cursor position on line 1 & 2 are updated.            */
/*  Returns:    --                                        */
/*  Updates:    AnlBlkNdx                                  */
/***************************************************************************/
void AnlBlkMenuShow()
  {
  register int i, j, last, NoOfBBs;

  WriteCodeLN1(0, MenuHdrTxt);
  WriteCode1(base_menu[BaseNdx].ItemTxt);
  WriteCode1(CoConfigureTxt);           // Write menu headline
  ClearRestLN1();                  // Clear rest of line 1

  AnlBlkNdx = Ptr->ItemNumber;          // Update BB unit index, ie. no.

  WriteCodeLN2(0, SubmnuHdrTxt);        // Write header for sub-menu line
                              // Calculate no. of BB units
  for (NoOfBBs=0, i=BB1Item; i < BB8Item+1; i++)
    if (AnlBlkUnit[i].Present)
      NoOfBBs++;

  if (NoOfBBs > 6)
    {                  // If 6 or more BB units..
    i = last = BB7Item;                //  two screens are required
    (AnlBlkNdx > BB6Item) ? (last = BB8Item+1) : (i = BB1Item);
    }
  else
    {                          // ..otherwise only 1 screen
    i = 0;
    last = BB8Item+1;
    }

  for (j=0;  i < last; i++)
    {                              // Display active screen
    if (AnlBlkUnit[i].Present)
      {
      if ((i == BB2Item) && (AnlBlkUnit[BB2Item].HWType == PT8604))
        {
        WriteCode2(BBMulTxt);          // Write item text
        WriteTxt2("  ");               // Jump to next position

        if (i < AnlBlkNdx)            // Calculate item marker
          j += (Cstrlen(BBMulTxt) + 2);
        }
      else
        {
        WriteCode2(anlblk_menu[i].ItemTxt);// Write item text
        WriteTxt2("  ");                   // Jump to next position

        if (i < AnlBlkNdx)               // Calculate item marker
          j += (Cstrlen(anlblk_menu[i].ItemTxt) + 2);
        }
      }
    }
  ClearRestLN2();                  // Clear reset of line 2

  i = Ptr->ItemConfig;                // Get line1&2 icons/dots info

  if (NoOfBBs > 6 )                // If 6 or more BB units..
    i += MORE_;                    //  add 'more' dots to line 2

  WriteArrowsField(i);              // Write line 1&2 icons/dots

                              // Get length of text to mark
  if ((AnlBlkNdx == BB2Item) && (AnlBlkUnit[BB2Item].HWType == PT8604))
    i = Cstrlen(BBMulTxt);
  else
    i = Cstrlen(Ptr->ItemTxt);

  WriteItemArrows(j+8, (UC) i);        // Mark selected item
  }

