
void SDITimeAdjust(UC item, UC system, long delay)
  {
  if (T_SEL)
    {                        // If button pressed is UP/DOWN..
    if (T_UP)                  // If button pressed is UP ..
      tlg_samples += stepVal;
    else
      tlg_samples -= stepVal;
    }

  if (H_SEL)                          // Line, ie. H, adjstement..
    {                             // If button pressed is UP/DOWN..
    if (H_UP)                       // If button pressed is UP..
      tlg_samples += (long) spl;
    else
      tlg_samples -= (long) spl;
    }

  if (V_SEL)                          // Field, ie. V, adjustement ..
    {                             // If button pressed is UP/DOWN..
    lines_over_field = (tlg_samples / ((long) spl)) % lpf;
    if V_UP)
      {                           // If button pressed is UP..
      if (lines_over_field < 3)
        tlg_samples += (long) 3*spl;
      else
        tlg_samples += (long) 4*spl;
      }
    else
      {
      if (lines_over_field < 3)
        tlg_samples -= (long) 4*spl;
      else
        tlg_samples -= (long) 3*spl;
      }
    }

  if (tlg_samples < 0)
    tlg_samples += (long) lpf*spl;
  else
    tlg_samples %= (long) lpf*spl;

  SDISamplesToFLT(system, tlg_samples, &sign, &field, &line, &time);
  WriteTimingFLT(sign, field, line, time);
  }

void SDISamplesToFLT(UC system, long samps, char* sign, char* F, int* L, float* T)
  {
  *sign = '+';
  if (samps >=  ((long) 3*spl))
    {
    samps--;
    line    = (samps % ((long) lpf*spl)) / ((long) spl);
    samps   = (samps % ((long) lpf*spl)) % ((long) spl);
    field   = 0;
    if (line > 2)
      {
      field++;
      line = lpf - 1 -line;
      }
    else
      line  = 2-line;
    samps = ((long) spl) - 1 - samps;
    field   = 1 - field;
    if (field != 1)
      *sign = '-';
    }
  else
    {
    line    = (samps % ((long) lpf*spl)) / ((long) spl);
    samps = (samps % ((long) lpf*spl)) % ((long) spl);
    field   = 0;
    if (line > 2)
      {
      field++;
      line -= 3;
      }
    }
