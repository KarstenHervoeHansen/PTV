/* table.c : profram to calculate def_delay for HDTV project */

#include <stdio.h>

#define UL unsigned long
#define UC unsigned char

#define DEF_DELAY(x) (long)(2 * (tab.members[x].samples_per_line * tab.members[x].lines_per_frame) - 20)
#define FRA_DELAY(x) (long)((tab.members[x].samples_per_line * tab.members[x].lines_per_frame) - 20)

typedef struct aa
  {
  UL samples_per_line;
  UL lines_per_frame;
  UC sys_clk;
  }  INDIVID;

typedef struct bb
  {
  INDIVID members[21];
  } TLG_FORMATS;

TLG_FORMATS tab = 
  {
  2200,      1125,      0,
  2200,      1125,      1,
  2640,      1125,      0,
  4400,      1125,      0,
  4400,      1125,      1,
  5280,      1125,      0,
  4400,      1125,      0,
  4400,      1125,      1,
  5280,      1125,      0,
  5500,      1125,      0,
  5500,      1125,      1,
  4400,      1125,      0,
  4400,      1125,      1,
  3300,       750,      0,
  3300,       750,      1,
  3960,       750,      0,
  6600,       750,      0,
  6600,       750,      1,
  7920,       750,      0,
  8250,       750,      0,
  8250,       750,      1
  };

char *names [21] =
  {
  "1920x1080/60/P",
  "1920x1080/59.94/P",
  "1920x1080/50/P",
  "1920x1080/60/I",
  "1920x1080/59.94/I",
  "1920x1080/50/I",
  "1920x1080/30/P",
  "1920x1080/29.97/P",
  "1920x1080/25/P",
  "1920x1080/24/P",
  "1920x1080/23.98/P",
  "1920x1035/60/I",
  "1920x1035/59.94/I",
  "1280x720/60/P",
  "1280x720/59.94/P",
  "1280x720/50/P",
  "1280x720/30/P",
  "1280x720/29.97/P",
  "1280x720/25/P",
  "1280x720/24/P",
  "1280x720/23.98/P"
  };



int main(void)
  {
  UL  new_table[21];
  UL  fra_table[21];
  int i;

  for (i = 0; i < 21; i++)
    {
    new_table[i]= DEF_DELAY(i);
    }
  for (i = 0; i < 21; i++)
    {
    fra_table[i]= FRA_DELAY(i);
    }

  printf("code TLG_FORMATS tab =\n");
  printf("  {\n");
  for (i = 0; i < 21; i++)
    printf("%ld, %ld, %d, %ld, %ld\n",
           tab.members[i].samples_per_line,
           tab.members[i].lines_per_frame,
           tab.members[i].sys_clk,
           new_table[i],
           fra_table[i]);


  }