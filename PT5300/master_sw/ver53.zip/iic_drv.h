/* iic_drv.h */

int trmDA8591(int, UC);
int read8574(int, int, UC *);
int trmAD8591(int, int, UC);
int read8591(int, int, UC *);
int trm8574(int, UC);
int init_iic(int);
