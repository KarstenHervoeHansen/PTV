/************************************************************************
 * FILE NAME  pt5300.c
 * PURPOSE    To transfer a .bin file containing new software via RS232
 *            to PT5300 main board
 *            
 * SPEC       Janusz Kuzminski
 * DESIGN     Janusz Kuzminski
 * CODING     Janusz Kuzminski
 * CODE INSP. 
 * TEST       
 *            
 * LAST UPDT: 19.01.2007
 *            
 * NOTES:     This module is to be linked with xcom, Windows 
 *            RS232 comms module.
 *            Invocation:
 *            PT5300 port bin_file
 *              port: comport
 *              bin_file: file containing new progarm for PT5300 master
 *                        microprocessor.
 *            This program works as follows:
 *            Using SCPI command 'System Upload' as follows:
 *             :SYST:UPL 32768;
 *            a download/program function in 5300 Master software is invoked
 *            (update_sw() in mas.c).  The Baud Rate is changed to 115200
 *            and the do_bin_file() function is invoked, which reads the 
 *            binary file and sends the data to PT5300.  If the transfer
 *            and programming is successful, the PT5300 must be restarted for
 *            the new software to run.

 *            Data transfer is binary.  This program reads data from file and
 *            sends RX_SERBUFLEN bytes of it.  It then waits for reception of
 *            the following codes from PT5300 Master:
 *           
 *             START   - start transmitting data from file,
 *             ERR     - print failure message and exit,
 *             SUCCESS - print success message and exit.
 *            
 ************************************************************************/
#define USE_WIN

#ifdef USE_WIN
#include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include <setjmp.h>
#include <math.h>
#include "xcom.h"

#define RX_SERBUFLEN  50 //64

#define UPLOADER 0x70000L /* address at which the uploader function resides */

#define PT5300VER    (int)47

#define VERSION (float)  1.0

#define MOVING_PIN_SPEED 160

#define START   (UC) 0x31
#define ERR     (UC) 0x20
#define SUCCESS (UC) 0x1B

#define  UL unsigned long
#define  UI unsigned short
#define  UC unsigned char

typedef union yy
  {
  UI   intval;
  UC   bytes[2];
  }  ui;


UC *rotating_pin[] =  /* rotating pin: one step per 20 lines sent */
  {
  "|",
  "/",
  "-",
  "\\",
  NULL
  };

/*        Prototypes                */
void give_info(void);
void do_exit(int, int, char *message);
void wait_4_any_key(void);
int  check_4_key(int place);
int  find_version(char *buff);
int  do_bin_file(int, HANDLE, long*);
int  put(int prt, UC c);

int main(int argc, char ** argv)
  {
  HANDLE   Bfile; /* .bin file */
  int      i, k;
  int      port;
  UC       c;
  UC       tmp;
  long     cnt;         /* count of bytes read from file */
  double   seconds;
  clock_t  startClock;
  clock_t  endClock;
  UC       strbuff[MAXSTRING];
  int      ver;
  UC       tmps[10];

  if (argc != 3)
    {
    give_info();
    return (1);
    }

  cnt = 0;         /* number of bytes sent */
  startClock = clock();


  printf("PT5300 for Windows Version %.2f.\n", VERSION);
  port = atoi(argv[1]);  /* first command line arg is comport */
  if ((port < 1) || (port > 2))
    {
    printf("main: Comport may be 1 or 2\n");
    return (1);
    }

  port -= 1;

  /* open .bin file specified in command line arg */

  Bfile = CreateFile(argv[2], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
  if (Bfile == INVALID_HANDLE_VALUE)
    {
    printf("main: Cannot open file %s.\r\n", argv[2]);
    return (1);
    }

  if (!Xcom_Init(port, 9600L, 8, MARKPARITY, 2, 2000L))
    {
    printf("main: Cannot open COM%d.\n", port);
    Xcom_Close(port);
    return (1);
    }

  strcpy(strbuff, "*IDN?;");
  Xcom_Putstring(strbuff, port);    /* Display PT5300 info */

  for (i = 0; i < MAXSTRING; i++)
    strbuff[0] = 0;

  if (!Xcom_Getstring(strbuff, port))
    {
    printf("main: Communication Error 1.\n");
    goto gracefull_exit;
    }
  else
    printf("Generator: %s", strbuff);

  /* Find PT5300 version */
  ver = find_version(strbuff);
  if (ver < PT5300VER)
    {
    printf("Wrong PT5300 version, must be bigger than %d\n", PT5300VER);
    goto gracefull_exit;
    }

  /* Set PT5300 password to OFF */
  strcpy(strbuff, ":FACT:PASS 'Marilyn';");
  Xcom_Putstring(strbuff, port);


  strcpy(strbuff, ":FACT:PASS?;");
  Xcom_Putstring(strbuff, port);

  /* check that password id OFF */
  if (!Xcom_Getstring(strbuff, port))
    {
    printf("main: Communication Error 2.\n");
    goto gracefull_exit;
    }
  else
    {
    if (!strcmp(strbuff, "OFF"))
      {
      printf("main: Communication Error 3.\n");
      goto gracefull_exit;
      }

    strcpy(strbuff, ":SYST:UPL 32768;"); /* PT5300 upload function with the  */
                                         /* proper argument meaning that     */
                                         /* Master Softwre update is to be   */
                                         /* done                             */
    Xcom_Putstring(strbuff, port);
    }
  /* Note: the delay below is necessary, as without it, the last character (;) */
  /* is sent corrupted, apparently because of Xcom_Close().                    */
  /* This is despite MSDN text on WriteFile states that WriteFile() does not   */
  /* return until the operation has been completed.                            */
  pass_time(3000);
  Xcom_Close(port);
/********************   BAUD RATE CHANGE   *******************************/

  if (!Xcom_Init(port, 115200L, 8, MARKPARITY, 2, 2000L))
    {
    printf("main: Cannot open COM%d.\n", port);
    Xcom_Close(port);
    return (1);
    }  


  Xcom_Flush(port);
  startClock = clock();

  cnt = 0;
  if (do_bin_file(port, Bfile, &cnt))
    printf("Error transferring %s file\n", argv[2]);
  else
  printf("File %s: SUCCESS\n", argv[2]);

gracefull_exit:
  endClock = clock();
  seconds = (double)((endClock - startClock) / CLOCKS_PER_SEC);
  printf("Execution Time = %.1f seconds\n", seconds);
  Xcom_Close(port);

  CloseHandle(Bfile);
  return (0);
  }

void give_info(void)
  {
  printf("pt5300.exe: transfers .bin file to PT5300.\n");
  printf("Version %.2f.\n", VERSION);
  printf("Invocation: pt5300 port bin_file\n");
  }

void do_exit(int code, int comport, char *message)
  {
  Xcom_Close(comport);
  printf("%s", message);
  exit (code);
  }

void wait_4_any_key(void)
  {
  printf("Press any key to continue....\n");
  while (!kbhit())
    ;
  getch();
  return;
  }

int check_4_key(int place)
  {
  if (kbhit())
    {
    getch();
    printf("User Break %d.\n", place);
    return (1);
    }
  else
    return (0);
  }

/* int find_version(char *buff)                                        */
/* Purpose: To find PT5300 Master software version from idn string     */
/* Returns: Software version as integer.                               */
/* Notes:   The ID string has the form:                                */
/*          PTV,PT5230,KU020694,05.7-00.0                              */
/*          where 05.7 is required software version.                   */
int find_version(char *buff)
  {
  int i;
  int j;
  char cb[10];

  i = 0;
  for (j = 0; j < 3; j++)
    while (buff[++i] != ',')
      ;
  i++;

  for (j = 0; j < 4; j++)
    {
    cb[j] = buff[i++];
    }
  cb[2] = cb[3];
  cb[3] = 0;

  i = atoi(cb);
  return (i);
  }


/******************************************************************
 * NAME       int do_bin_file(int port, HANDLE bfile, long *cnt)
 * PURPOSE    To transfer contents of a .BIN file to PT5300.  The 
 *            file contains program for F320 micro onboard HD or DL
 *            boards.
 * 
 * ARGUMENTS  int port     - comport to use
 *            HANDLE bfile - file handle to open .BIN file
 *            long *cnt    - pointer to a count variable, which at
 *                           exit will be filled with number of 
 *                           bytes transferred.
 *
 * RETURNS    0 - on success
 *            1 - on errors
 *
 * EXTERNS    None
 *
 * NOTES:     If size of .BIN file is bigger than UPLOADER, which 
 *            means that uploader would be overwritten, error is 
 *            reported and nothing is done.
 *            First this function sends length of data as 2 bytes
 *            then all binary data read from file and then waits 
 *            for single byte error code sent by board_kind.
 *            Before sending each character, this function waits
 *            for START from a board.
 ******************************************************************/
int do_bin_file(int port, HANDLE bfile, long *cnt)
  {
  UL       bytes_read;
  UC       c;
  UL       size;
  ui       tmp;
  int      i;
  int      rpndx;

  *cnt  = 0;
  rpndx = 0;

  size = GetFileSize(bfile, NULL);
  //printf("Filesize is %ld\n", size);
  if ((int)size > UPLOADER)
    {
    printf("do_bin_file: File is too long.\n");
    return (1);
    }
  tmp.intval = (int)size;


  /* Wait for START, then send LSB and MSB of size */
  if (put(port, tmp.bytes[0]))
    {
    printf("do_bin_file: Timeout.\n");
    return (1);
    }
  if (put(port, tmp.bytes[1]))
    {
    printf("do_bin_file: Timeout.\n");
    return (1);
    }

  for (i = 0; i < tmp.intval; i++)
    {
    if (check_4_key(10))
      {
      return (1);
      }
    if (!((*cnt) % MOVING_PIN_SPEED))
      {
      printf("%s\r", rotating_pin[rpndx++]);
      if (rotating_pin[rpndx] == NULL)
        rpndx = 0;
      }

    ReadFile(bfile, &c, 1, &bytes_read, NULL); /* read one char */
    if (bytes_read == 0) /* EOF reached, wait for SUCCESS */
      {
      break;
      }
    if (put(port, c))    /* Transmit char from file */
      {
      printf("do_bin_file: Timeout.\n");
      return (1);
      }
    (*cnt)++;
    }

  /* wait here for error code, sent as binary */
  if (Xcom_Getchar(&c, port))
    {
    //printf("Error code = %d\n", (int)c);
    return ((int)c);
    }
  else
    printf("do_bin_file: Timeout.\n");
  return (1);
  }

/*  Listen for start, then send character */
int put(int prt, UC c)
  {
  UC tmp;

  if (!Xcom_Getchar_wtimeout(&tmp, prt, 10000))
    return (1);
  Xcom_Putchar(c, prt);
  return (0);
  }


