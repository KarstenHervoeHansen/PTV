/***************************************************************************/
/*  Copyright DK-Audio A/S, 2005                                           */
/*  Project:  Programming PT5300 Master Flash via RS232.                   */
/*                                                                         */
/*  Module:   bload.C                                                      */
/*  Author:   Jnausz Kuzminski                                             */
/*  Date:     19.10.2007                                                   */
/*  Status:   Version 1.0                                                  */
/*  Purpose:  This module contains function update(), which receives 5300  */
/*            program in form of a bin data and programs the program memory*/
/*            which is of M29F040B type.                                   */
/*  Notes:                                                                 */
/*            There is no main in this program.                            */
/*            Function update() is to reside @0x50000L (see linker args)   */
/*            and ocupies less than one sector.  To load software          */
/*            including this function, combine program hex file with       */
/*            bload.hex, using a text editor.                              */
/*            See bloader.doc                                              */
/*            This program is complied and linked by b.bat                 */
/*            When this program is entered, the UART0 is already programmed*/
/*            as necessary.  This program does not use any interrypts.     */
/***************************************************************************/
/***************************************************************************/
#include <xa.h>
#include <stdio.h>
#include <stdlib.h>
#include "c1191.h"       /* Header file with global prototypes */
/***************************************************************************/
#define UC unsigned char
#define UI unsigned int

#define START   (UC) 0x31
#define STOP    (UC) 0x32
#define ERR     (UC) 0x20
#define SUCCESS (UC) 0x1B


/* unions for unsigned long and unsigned int */
/* to access these data types bytewise       */
/* Note that for Kiel C compiler, charval[0] */
/* carries MSB and charval[3] carries LSB.   */
/* This is the opposite of how TC does it.   */

typedef union yy
    {
    UI   intval;
    UC   bytes[2];
    }  ui;

UC Array[80] =
  {
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01
  };

void  update(void);
void  erase_flash(void);
UC    receive_code(void);
char  fetch (void);
void  put (UC);

/* We use main() here, as otherwise the linker reports error,
   in spite that it generates correct output file
*/
void main(void)
  {
  update();
  }

/******************************************************************
* NAME       void update(void)
* PURPOSE    To receive program data via UART and program processor
*            FLASH program memory.
* 
* ARGUMENTS  None
*
* RETURNS    Nothing
*
* EXTERNS    None
*
* NOTES:     This function first erases all FLASH memory where the
*            program is to be.  Then it receives all bytes and 
*            writes them into FLASH.
*            It then transmits result code via UART.  The result
*            code may be SUCCESS or checksum error.
******************************************************************/
void update(void)
  {
  UC input;


  EA = 0;             /* Disable interrupts (precautionary) */

  input = receive_code();
  put(input);
  }

/***************************************************************************/
/* erase_flash                                                             */
/*                                                                         */
/* This routine erases the first 30 pages of FLASH (0x0000 to 0x3BFF).     */
/* Last page erased is from 0x3B00 to 0x3BFF                               */
/***************************************************************************/
void erase_flash(void)
  {
  }

/********************************************************************************/
/* receive_code                                                                 */
/* This routine receives the new firmware through the UART as binary data       */
/*                                                                              */
/* Returns: 0 - on Success                                                      */
/*          3 - on checksum fail                                                */
/********************************************************************************/
UC receive_code(void)
  {
  FlashChipErase();
  FlashProgram(0x30000L, 50000, Array);

  }

/******************************************************************
* NAME       char fetch(void)
* PURPOSE    to fetch one char from UART
* 
* ARGUMENTS  None
*
* RETURNS    Received char
*
* EXTERNS    None
*
* NOTES:     This function first signals to the sender that it is
*            ready to receive by sending START.  It then waits 
*            for character and when received, returns it.
******************************************************************/
char fetch(void)
  {
  char c;

  put(START);

  while (!RI0)
    ;
  c   = S0BUF;
  RI0 = 0;
  return (c);
  }

#if 0
void put (UC c) /* This one is supplied by Silabs. It does not work */
  {
  while (!TI0)
    ;
  TI0   = 0;
  SBUF0 = c;
  }
#else
/******************************************************************
* NAME       void put(UC c)
* PURPOSE    To send one character via UART
* 
* ARGUMENTS  None
*
* RETURNS    Nothing
*
* EXTERNS    None
*
* NOTES:     
******************************************************************/
void put(UC c) /* This one is supplied by JK. It DOES work */
  {
  S0BUF = c;
  while (!TI0)
    ;
  TI0   = 0;
  }
#endif

