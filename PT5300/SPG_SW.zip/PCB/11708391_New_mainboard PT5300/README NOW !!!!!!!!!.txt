16/09-2005/GBg

�ndringer ift gammel job 4008 117 06265 og tilh�rende diagrammer:

- St�rre RMA indf�rt
- Gjort mulig at montere PSU spoler med 5 mm pitch
- Flyttet to spoler i BB udgange, s� de ikke s� let kommer til at kortslutte

�ndrede masterfiler:

PCB:
A06265.CDO f�et nyt nummer A08391.CDO

Diagrammer
D82904.CSD �ndret til D91391.csd
De �vrige sider har ikke f�et �ndret sidehoveder



