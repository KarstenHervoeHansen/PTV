extern unsigned char FPGA_system_control;

void pt5300_in_handle();
void pt5300_out_handle();