void EEPROM_write_byte(char bank, char adresse, char byte);
char EEPROM_read_byte(char bank, char adresse);