void putch(unsigned char c);
void serint0(void);
unsigned char getch(unsigned char * c);