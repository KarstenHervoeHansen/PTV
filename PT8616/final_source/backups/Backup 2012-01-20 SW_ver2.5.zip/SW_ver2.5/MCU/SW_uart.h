void TX_gen();
void setup_SW_uart();
void SW_putch(unsigned char out);
void SW_sendstr(unsigned char *str, unsigned char length);