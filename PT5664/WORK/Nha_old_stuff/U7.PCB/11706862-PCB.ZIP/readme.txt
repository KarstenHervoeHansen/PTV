




                       T I L   A L L E   B R U G E R E
                       _______________________________



                    af dokumentation og data genereret af:

                GHDsign Aps,   Bakkesvinget 12, DK 2880 Bagsv�rd.
                Tlf.: 4444 1482, Fax: 4449 0044  Email: ghd@ghd.dk



        Da vi gerne vil opdatere og forbedre vor dokumentationskvalitet,
        er det blevet besluttet, at  tage  det dramatiske skridt, at ud-
        vikle helt  ny  software til forbedret dokumentation p� elektro-
        nisk form. 
        I tiden indtil udviklingsarbejdet  et  f�rdigt,  kan vi desv�rre
        ikke levere den hidtidige dokumentation, som er kendt under nav-
        nene:

                         PCBDOC, ACMDOC og ICTDOC.

        Imidlertid fors�ger vi at generere og dokumentere data  og specs
        p� bedst mulig m�de. 
        Vi h�ber, at alle stadig kan ekstrakte  fyldestg�rende  data til
        diverse produktionsfaser.

        Skulle der v�re mangler eller fejl, vil vi bede om feedback, s�-
        ledes at dette kan indf�res og rettes hurtigst muligt.

        VI BEKLAGER MEGET FORSTYRRELSERNE VED DENNE OML�GNING, MEN H�BER
        P� JERES FORST�ELSE.
        
        Med venlig hilsen

        Gert Hansen                                  Email: gh@ghd.dk
        GHDsign                                      Phone: +45 44441482
        Bakkesvinget 12                              Fax  : +45 44490044
        DK-2880 Bagsvaerd                                
        DENMARK        
