SUPERMAX E-CAD drill version 7.0.5
WARNING - PCB is locked. user=jfb pid=165 display=:0.0
plated :
   num: 774 size:  15.8mill =   0.4mm
   num:   2 size:  27.6mill =   0.7mm
   num:  80 size:  31.5mill =   0.8mm
   num: 400 size:  35.4mill =   0.9mm
   num: 185 size:  39.4mill =     1mm
   num:  11 size:  43.3mill =   1.1mm
   num:   3 size:  47.2mill =   1.2mm
   num:  54 size:  51.2mill =   1.3mm
   num:   4 size:  78.7mill =     2mm
   num:  19 size:   126mill =   3.2mm
non plated :
   num:   5 size:  59.1mill =   1.5mm
   num:  24 size:  78.7mill =     2mm
   num:   2 size: 118.1mill =     3mm
first drilled hole x,y (13087.5, 1850) mill = (332.42, 46.99) mm
FILE 24813 BYTES 1137<x<13575 and 1100<y<5050 lay : 255
drill completed
