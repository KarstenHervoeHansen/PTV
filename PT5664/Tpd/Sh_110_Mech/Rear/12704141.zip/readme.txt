
�ndret:	fr 09-06-00 15:11
sh.110-1 10758781_110-1.pdf (m�ltegning)
         10758781.dxf   
sh.110-1 12704141_110-1.pdf
sh.115-1 12704141_115-1.pdf (layout)
sh.115-1 12704141_115-1.dxf (AutoCad 14)
    

                             postscript    windows
Fonte som bruges er: ariab - ariab.shx  -  Arial MT Bold                            

For farvespecifikation se 4008 140 00000