
�ndret:	fr 16-106-00
sh.110-1 12704151_110-1.pdf  
sh.110-2 12704151_110-2.pdf (m�ltegning)
sh.115-1 12704151_115-1.pdf (layout)
12704151.dwg (side 110-1, 110-2 m�ltegning samt 115-1 tekstlayout)

sh.115-1 12704141_115-1.dxf (AutoCad 2000)
    
                                 windows
Fonte som bruges er: arim  - Arial MT Medium      (PT nr. + tekst)
                     arie  - Arial MT Extra Bold  (ProTeleVision)
                     ariab - Arial MT Bold        (resten af teksten)
                                                   
For farvespecifikation se 4008 140 00000