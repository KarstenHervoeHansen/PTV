/*
*******************************************************************
* Project	: PT5220  AES generator PT86xx
* Filename	: AESGEN.H
* Version	: 1.0
* Purpose	: Port variable definitions
* Org.date	: 990803
* Author	: PF
********************************************************************
HISTORY:

*/


// I/O-PORT ADDRESSES   (16-bit registers)
volatile UI PortStatusreg @  0x80000;    // 6 x level detectors and PLL status
volatile UI PortTimreg_1 @  0x80100;     // Timing audio/video generator #1
volatile UI PortTimreg_2 @  0x80200;     // Timing audio/video generator #2
volatile UI PortContrreg_1 @  0x80102;
volatile UI PortContrreg_2 @  0x80202; 

// AudioRAM for generator #1 and #2
#define AudioRAM_1  0x20000
#define AudioRAM_2  0x40000



// PORT BITS **
static bit P3_0 @ 0x398;
static bit P3_1 @ 0x399;
static bit P3_2 @ 0x39a;
static bit P3_4 @ 0x39c;
static bit P3_5 @ 0x39d;


