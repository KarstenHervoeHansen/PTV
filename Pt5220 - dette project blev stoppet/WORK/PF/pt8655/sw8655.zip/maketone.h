/*
********************************************************************
* Project	: PT5220 AES generator
* Filename	: MAKETONE.H
* Version	: 1.0
* Purpose	: Header file
* Org.date	: 990803
* Author	: PF
********************************************************************
HISTORY:
*/
#include "equ.h"


#define  StereoMode           0
#define  DualMode             1
#define  MonoMode             2
#define  NonAudioMode         3
#define  NonAudioNonValidMode 4
#define  DefaultMode          5
#define  ChA                  0
#define  ChB                  1
#define  NoEmphasis           0
#define  Emphasis5015         1
#define  EmphasisJ17          2
#define  AudioWord           20            // set audio word length
#define  PALSystem            0
#define  NTSCSystem           1
#define  ClickPeriode1Sec     1
#define  ClickPeriode3Sec     3


extern int  LevelA;  // in 10*dBFS  (f.eks: -7.6 dBFS = 76)
extern int  LevelB;
extern int  AudioFreqA;
extern int  AudioFreqB;
extern int  AudioMode;
extern int  Emphasis;
extern int  UstartA;
extern UC   UstrA[];
extern int  UstartB;
extern UC   UstrB[];

extern int  ClickMode_1;       // generator #1
extern int  ClickPeriode_1;
extern int  TimingSystem_1;
extern int  TimingAudVideo_1;
extern int  PlayAudio_1;
extern int  ClickMode_2;       // generator #2
extern int  ClickPeriode_2;
extern int  TimingSystem_2;
extern int  TimingAudVideo_2;
extern int  PlayAudio_2;



extern code int defLevelA;  // in 10*dBFS  (f.eks: -20.0 dBFS = 200)
extern code int defLevelB;
extern code int defAudioFreqA;
extern code int defAudioFreqB;
extern code int defAudioMode;
extern code int defEmphasis;
extern code int defUstartA;
extern code UC defUstrA[];
extern code int defUstartB;
extern code UC defUstrB[];
extern code int defClickMode;
extern code int defClickPeriode;
extern code int defTimingSystem;
extern code int defTimingAudVideo;

extern far unsigned char RAMAudioData[];


extern void CalSound(void);

