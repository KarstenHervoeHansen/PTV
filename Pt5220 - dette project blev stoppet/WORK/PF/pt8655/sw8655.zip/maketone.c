/*
Program til generering af audiodata til PT5220 AES/EBU digital audio generator
Formatet overholder standarden AES3-1992

Se function 'stdimpl' vedr U-bit programmering.

Hver lyd specificeres med funktionen
	calsound(dBFS-level,Freq Ch-A, Freq Ch-B, SoundMode, Emphasis);
    hvor
      dBFS-level = 0 .. -140
      Freq Ch-A, Freq Ch-B = se filen 'sine.h'
      SoundMode = StereoMode, DualMode, MonoMode, DefaultMode,
			       NonAudioMode eller NonAudioNonValidMode
      Emphasis = NoEmphasis, Emphasis5015 eller EmphasisJ17

Silence (audio samples = 0) laves ved at s�tte Freq = 0
Audio samples genereres med 20 bit.


		           byte 0, bit 1 (C-bit)     V-bit
NonAudioMode               1                   0
NonAudioNonValidMode       1                   1


U-bit kan s�ttes ved funktionen
 dataimpl(channelno, byteno, data)


Peter Frederiksen, dec 1995, sept 1996, juni 1997, sept 1997, nov 1998, juni 1999
*/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "maketone.h"
#include "sine.h"
#include "dbfs.h"

void dataimpl(int channelno, int byteno, char data);
void setvbit(void);
void stdimpl(int AudioMode, int Emphasis);
int parity(int ch,int no);
int pow2(int y);
unsigned char invertbyte(unsigned char inb);
unsigned char bintobyte(char *binstr);
void calcrc(int ch);
void biphase(void);
char *strmove(char *instr, char *sout, int st, int no);


far unsigned char AudioData[2][3840];   // 2 channels (A and B)
                                        // 192 * 5 frames * 4 bytes/frame
                                        // = 3840 bytes/channel
                                        
far unsigned char RAMAudioData[15360];  // 5 * 192 = 960 frames
                                        // 960 * 64 bit = 122880 bits
                                        // 122880 / 8 = 15360 bytes

// global variables for sound calculations in function 'calsound'                                        
int  LevelA;  // in 10*dBFS  (f.eks: -7.6 dBFS = 76)
int  LevelB;
int  AudioFreqA;
int  AudioFreqB;
int  AudioMode;
int  Emphasis;
int  UstartA;
UC   UstrA[24];
int  UstartB;
UC   UstrB[24];

// global variables for controlling the AES-generator
int  ClickMode_1;       // generator #1
int  ClickPeriode_1;
int  TimingSystem_1;
int  TimingAudVideo_1;
int  PlayAudio_1;
int  ClickMode_2;       // generator #2
int  ClickPeriode_2;
int  TimingSystem_2;
int  TimingAudVideo_2;
int  PlayAudio_2;



// default values for sound calculations
code int defLevelA = 200;  // in 10*dBFS  (f.eks: -20.0 dBFS = 200)
code int defLevelB = 200;
code int defAudioFreqA = 1000;
code int defAudioFreqB = 1000;
code int defAudioMode = StereoMode;
code int defEmphasis = NoEmphasis;
code int defUstartA = 0;
code UC defUstrA[5] = {"CH A"};
code int defUstartB = 0;
code UC defUstrB[5] = {"CH B"};

code int defClickMode = 0;
code int defClickPeriode = ClickPeriode1Sec;
code int defTimingSystem = PALSystem;
code int defTimingAudVideo = 0;  // timing audio/video (0 - 20.8us)

                                        
                                        
                                        
                                        
                                        
				     



// ---------------------------------------------------------------
void CalSound(void){

unsigned char b0,b1,b2,b3;

int SampleNo,      // 0..959
    n,
    l,
    FreqNoA,
    FreqNoB;

long int ToneA,
         ToneB,
         dBFSmaxA,
         dBFSmaxB;



 // init audio array data
 for (n = 0; n < 3840; ++n) {
  AudioData[0][n] = 0;
  AudioData[1][n] = 0;
 }

 // search for channel A freq
 FreqNoA = 5;                    // default freq#5
 for (n = 0; n < maxaudiofreq; ++n)
  if (AudioFreqA == audiofreq[n])
   FreqNoA = n;

 // search for channel B freq
 FreqNoB = 5;                   // default freq#5
 for (n = 0; n < maxaudiofreq; ++n)
  if (AudioFreqB == audiofreq[n])
   FreqNoB = n;


 // check min/max level values channel A
 if (LevelA < MaxAudioLevel)
  LevelA =  MaxAudioLevel;
 if (LevelA > MinAudioLevel)
  LevelA =  MinAudioLevel;

 // check min/max level values channel B
 if (LevelB < MaxAudioLevel)
  LevelB =  MaxAudioLevel;
 if (LevelB > MinAudioLevel)
  LevelB =  MinAudioLevel;


 if (AudioWord == 20){                   // select max word sample (0 dBFS)
   dBFSmaxA = AudioLevel[LevelA][0];
   dBFSmaxB = AudioLevel[LevelB][0];
  }
  else{                                  // audio word = 24 bit
   dBFSmaxA = AudioLevel[LevelA][1];
   dBFSmaxB = AudioLevel[LevelB][1];
   }


 // calculate audio word in 5x192 frames ( = 960 samples )
 for (SampleNo = 0; SampleNo <= 959; ++SampleNo){
 // Channel A sine curve calculations
  if (AudioFreqA != 0)
    ToneA = (int)(dBFSmaxA * (float)(AudioSineVal[SampleNo][FreqNoA]) / 10000);
   else
    ToneA = 0;

  if (AudioWord == 20)
   {
     b0 = 0;
	  b1 = invertbyte((ToneA & 0xFF));
	  b2 = invertbyte((ToneA >> 8) & 0xFF);
	  b3 = invertbyte((ToneA >> 16) & 0xFF);
     b3 = b3 & 0xF0;
     AudioData[ChA][SampleNo*4+0] = b0;
     AudioData[ChA][SampleNo*4+1] = b1;
     AudioData[ChA][SampleNo*4+2] = b2;
     AudioData[ChA][SampleNo*4+3] = b3;
   }
  else
  if (AudioWord == 24)
   {
	  b0 = (invertbyte((ToneA & 0x0F)) >> 4);
	  b1 = invertbyte((ToneA >> 4) & 0xFF);
	  b2 = invertbyte((ToneA >> 12) & 0xFF);
	  b3 = invertbyte((ToneA >> 20) & 0xFF);
     b3 = b3 & 0xF0;
     AudioData[ChA][SampleNo*4+0] = b0;
     AudioData[ChA][SampleNo*4+1] = b1;
     AudioData[ChA][SampleNo*4+2] = b2;
     AudioData[ChA][SampleNo*4+3] = b3;
   }


 // Channel B sine curve calculations
  if (AudioFreqB != 0)
    ToneB = (int)(dBFSmaxB * (float)(AudioSineVal[SampleNo][FreqNoB]) / 10000);
   else
    ToneB = 0;

  if (AudioWord == 20)
   {
     b0 = 0;
	  b1 = invertbyte((ToneB & 0xFF));
	  b2 = invertbyte((ToneB >> 8) & 0xFF);
	  b3 = invertbyte((ToneB >> 16) & 0xFF);
     b3 = b3 & 0xF0;
     AudioData[ChB][SampleNo*4+0] = b0;
     AudioData[ChB][SampleNo*4+1] = b1;
     AudioData[ChB][SampleNo*4+2] = b2;
     AudioData[ChB][SampleNo*4+3] = b3;
   }

  if (AudioWord == 24)
   {
	  b0 = (invertbyte((ToneB & 0x0F)) >> 4);
	  b1 = invertbyte((ToneB >> 4) & 0xFF);
	  b2 = invertbyte((ToneB >> 12) & 0xFF);
	  b3 = invertbyte((ToneB >> 20) & 0xFF);
     b3 = b3 & 0xF0;
     AudioData[ChB][SampleNo*4+0] = b0;
	  AudioData[ChB][SampleNo*4+1] = b1;
     AudioData[ChB][SampleNo*4+2] = b2;
     AudioData[ChB][SampleNo*4+3] = b3;
   }


 }  // for


 stdimpl(AudioMode, Emphasis);

 
 
 // set user data bit (U-bit)
 l = strlen((char *)UstrA);
 for (n = 0; n < l; n++)
  dataimpl(ChA, n+UstartA, UstrA[n]);

 l = strlen((char *)UstrB);
 for (n = 0; n < l; n++)
  dataimpl(ChB, n+UstartB, UstrB[n]);



  
 // calculate CRC byte for each channel (byte #23)
 calcrc(ChA);
 calcrc(ChB);

 // set audio valid bit (V)
 if (AudioMode == NonAudioNonValidMode)
  setvbit();


 // set parity bit (P)
 for (SampleNo = 0; SampleNo <= 959; ++SampleNo)
  {
   if (parity(ChA, SampleNo) == 0)   // check even parity for ch A
     parity(ChA, SampleNo);          // set even parity for ch A
   if (parity(ChB, SampleNo) == 0)   // check even parity for ch B
	  parity(ChB, SampleNo);          // set even parity for ch B
  }


 // code audio data as biphase
 biphase();



}  // calsound





void dataimpl(int chno, int byteno, char data)
// ----------- Setting the U bit (bit #2)  see AES3  2.1.6 ------------
// 192 frames * 4 byte/frame = 768 bytes
// U bit s�ttes ved at l�gge 4 til yyy i AudioData[CHx][yyy]
// chno = ChA eller ChB
// byteno = en af de 24 bytes (byte #0-23)
// data = indhold i byteno

{
int     block,
	bitno,
	dd;

  for (block = 0; block < 5; block++){
     dd = data;
     for (bitno = 0; bitno < 8; bitno++){
       if ((dd & 0x0001) == 0x0001)                // set U-bit
	 AudioData[chno][block*768 + byteno*32 + bitno*4 + 3] =
	   AudioData[chno][block*768 + byteno*32 + bitno*4 + 3] + 4;
       dd = dd >> 1;                           // shift right one position
     } // for (bitno ...

  } // for (block..
}



void setvbit(void)
//  ----------- Setting the V bit (bit #3)  see AES3  2.1.4 --------------
// 192 frames * 4 byte/frame = 768 bytes
// V bit s�ttes ved at l�gge 8 til AudioData[CHx][xxx]
// byteno = en af de 24 bytes (byte #0-23)
// block = en af de 5 blocks (block #0-4)
{
int     block,
	byteno,
	bitno;

  for (block = 0; block < 5; block++)
   for (byteno = 0; byteno < 24; byteno++)
    for (bitno = 0; bitno < 8; bitno++){
       AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3] =
	AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3] + 8;

       AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3] =
	AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3] + 8;
     }
} // setvbit(void)




void stdimpl(int AudioMode, int Emphasis)
{
int     block,
	byteno,
	bitno;


//  ----------- Standard implementation, see AES3  5.2.2 --------------
// 192 frames * 4 byte/frame = 768 bytes

//   set channel status channel byte 0 bit 0 = 1  (professional mode)
  byteno = 0;
  bitno = 0;
  for (block = 0; block <= 4; ++block)
   {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

	 ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
   } // for


//   set channel status channel byte 0 bit 1 = 1  (NonAudio mode)
  byteno = 0;
  bitno = 1;
  if (AudioMode == NonAudioMode)
  for (block = 0; block <= 4; ++block)
   {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
   } // for



//   set channel status channel byte 0 bit 2,3,4 = 1   (emphasis = J17)

  if (Emphasis == EmphasisJ17){
   byteno = 0;
   bitno = 2;
    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
   byteno = 0;
   bitno = 3;
    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
   byteno = 0;
   bitno = 4;
    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
  } // if (Emphasis == EmphasisJ17)
  else

//   set channel status channel byte 0 bit 2,3 = 1       (emphasis = 50/15)
  if (Emphasis == Emphasis5015){
   byteno = 0;
   bitno = 2;
    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
   byteno = 0;
   bitno = 3;
    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
  } // if (Emphasis == Emphasis5015)
  else{


//   set channel status channel byte 0 bit 2 = 1   (no emphasis)
  byteno = 0;
  bitno = 2;

    for (block = 0; block <= 4; ++block)
     {
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
      ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     } // for
   } // else




//   set channel status channel byte 0 bit 7 = 1  (48 kHz sampling freq)
  byteno = 0;
  bitno = 7;
  for (block = 0; block <= 4; ++block)
   {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
   } // for



//   set channel status channel byte 1 bit 7 = 1   (192 bit block structure)
  byteno = 1;
  bitno = 7;
  for (block = 0; block <= 4; ++block)
   {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
   } // for

//   set channel status channel byte 1 bit 1 = 1   ( stereo )
  byteno = 1;
  bitno = 1;
  if (AudioMode == StereoMode)
   for (block = 0; block <= 4; ++block)
    {
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    } // for

//   set channel status channel byte 1 bit 3 = 1   ( dual / two channel )
  byteno = 1;
  bitno = 3;
  if (AudioMode == DualMode)
   for (block = 0; block <= 4; ++block)
    {
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    } // for

//   set channel status channel byte 1 bit 2 = 1   ( mono )
  byteno = 1;
  bitno = 2;
  if (AudioMode == MonoMode)
   for (block = 0; block <= 4; ++block)
    {
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    } // for

//   set channel status channel byte 2 bit 2 = 1   ( 24 bit audio word ) 
  byteno = 2;
  bitno = 2;
  if (AudioWord == 24)
   for (block = 0; block <= 4; ++block)
   {
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
     ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
   } // for 


//   set channel status channel byte 2 bit 3 = 1 and bit 5 = 1
//					    ( word length indicated ) 
  byteno = 2;
  bitno = 3;
  for (block = 0; block <= 4; ++block)
  {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
  } // for

  byteno = 2;
  bitno = 5;
  for (block = 0; block <= 4; ++block)
  {
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChA][block*768 + byteno*32 + bitno*4 + 3];

    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
    ++AudioData[ChB][block*768 + byteno*32 + bitno*4 + 3];
  } // for 

} //stdimpl





unsigned char bintobyte(char *binstr)
{
 //converts a 8 bit binary string to a byte }
 int n;
 unsigned char bb;

 bb = 0;
 for(n = 0; n < 8; ++n)
  {
   if ((binstr[n]-48) == 1)
    bb = bb + pow2(7-n);
  }

 return(bb);
}





void biphase(void)
// calculates each subframe as a binary string and then codes it into biphase.
// the biphase codes is written to a binary prom file.
{
const   noofframes = 960;   // 192 frames * 5

 int    ch,k,d,no,         // loop counter
	Fr,
	SubFrame,
	NoOf8Bytes;
 long int sf,
	  xx;
 char   Digit[3],       // 2 bit binary digits
	FrameStr[33],   // 32 bit binary subframe string
	BiPhStr[65],    // 64 bit biphase string for 1 subframe
	prev;
 char	ef[9];
 char	*ff = ef;

 char   *Z1 = "11101000";   // preambles
 char	*X1 = "11100010";
 char	*Y1 = "11100100";
 char	*Z0 = "00010111";
 char	*X0 = "00011101";
 char	*Y0 = "00011011";
 char	*Bp00 = "00";       // biphase codes
 char	*Bp01 = "01";
 char	*Bp10 = "10";
 char	*Bp11 = "11";


 prev = '0';
 Fr = 0;
 SubFrame = 1;
 NoOf8Bytes = 0;
 strcpy(Digit,"01");


 for(no = 0; no < noofframes; ++no)
  for(ch = 0; ch < 2; ++ch)        // channel A and B
  {
    strcpy(BiPhStr,"");

    // calculate the 32 bit sf from the 4 bytes
    xx = AudioData[ch][no*4+0];
	 sf = 0x1000000L * xx;
    xx = AudioData[ch][no*4+1];
	 sf = 0x10000L * xx + sf;
	 xx = AudioData[ch][no*4+2];
    sf = 0x100 * xx + sf;
    xx = AudioData[ch][no*4+3];
    sf = xx + sf;

    // make 32 bit binary string of sf subframe
      for(d = 31; d >= 0; --d)
       {
	FrameStr[d] = Digit[sf & 1];
	sf = sf >> 1;
       } // for
      FrameStr[32] = '\x0';



    // put biphase coding of the 8 bits X,Y or Z preamble into BiPhStr
    if (prev == '0')
       {
	if ((Fr == 0) && (SubFrame == 1))     //  Z
	 strcat(BiPhStr,Z1);
	if ((Fr > 0) && (SubFrame == 1))      //  X
	 strcat(BiPhStr,X1);
	if ((Fr > 0) && (SubFrame == 2))      //  Y
	 strcat(BiPhStr,Y1);
       }
      else
       {
	if ((Fr == 0) && (SubFrame == 1))     //  Z
	 strcat(BiPhStr,Z0);
	if ((Fr > 0) && (SubFrame == 1))      //  X
	 strcat(BiPhStr,X0);
	if ((Fr > 0) && (SubFrame == 2))      //  Y
	 strcat(BiPhStr,Y0);
       } // if


    // biphase coding: 28 bits into BiPhStr
     for (d = 4; d <= 31; ++d)
      {
       switch (prev){
	case '1' : if (FrameStr[d] == '1')
		     strcat(BiPhStr,Bp01);
		    else
		     strcat(BiPhStr,Bp00); break;

	case '0' : if (FrameStr[d] == '1')
		     strcat(BiPhStr,Bp10);
		    else
		     strcat(BiPhStr,Bp11); break;
       } // switch
       prev = BiPhStr[strlen(BiPhStr)-1];
      } // for d


  // write binary audio data to RAM (PROM file)
    for (k = 0; k < 8; ++k){
      strmove(BiPhStr,ff,k*8,8);      // one channel = 8x8 = 64 bit biphase coded data
      RAMAudioData[no*16 + ch*8 + k] = bintobyte(ff);

    }

    ++NoOf8Bytes;                    // 8 bytes written to binary file

      if (Fr < 383)                  // 192 subframes * 2
	++Fr;
       else
	Fr = 0;                      // start preamble Z


    if (SubFrame < 2)                // toggles between channel A and B
      ++SubFrame;
     else
      SubFrame = 1;

 } // for n

} // biphase -------------------------------------------------




void calcrc(int ch)
{
int k,n,
    crc[184],
    Q[8],
    X8;

 for (k = 0; k < 5; ++k)                  // calculate crc in 5 blocks
  {
    for (n = 0; n < 8; ++n)              // init the 8 crc registers to 1
     Q[n] = 1;

    for (n = 0; n < 184; ++n)            // get the 184 crc bits in bit C
     crc[n] = ((AudioData[ch][(k*768)+(n*4)+3] & 0x02) >> 1);

    for (n = 0; n < 184; ++n){           // G(x) = x^8 + x^4 + x^3 + x^2 +1   
	 X8 = (crc[n] ^ Q[7]);				 // see annex B in AES3-1992
	 Q[7] = Q[6];
	 Q[6] = Q[5];
	 Q[5] = Q[4];
	 Q[4] = (Q[3] ^ X8);
	 Q[3] = (Q[2] ^ X8);
	 Q[2] = (Q[1] ^ X8);
	 Q[1] = Q[0];
	 Q[0] = X8;
    }
      // set 8 CRC bit in byte 23
      if (Q[0] == 1)
       AudioData[ch][(k*768)+191*4+3] = AudioData[ch][(k*768)+191*4+3] | 0x02;
      if (Q[1] == 1)
       AudioData[ch][(k*768)+190*4+3] = AudioData[ch][(k*768)+190*4+3] | 0x02;
      if (Q[2] == 1)
       AudioData[ch][(k*768)+189*4+3] = AudioData[ch][(k*768)+189*4+3] | 0x02;
      if (Q[3] == 1)
       AudioData[ch][(k*768)+188*4+3] = AudioData[ch][(k*768)+188*4+3] | 0x02;
      if (Q[4] == 1)
       AudioData[ch][(k*768)+187*4+3] = AudioData[ch][(k*768)+187*4+3] | 0x02;
      if (Q[5] == 1)
       AudioData[ch][(k*768)+186*4+3] = AudioData[ch][(k*768)+186*4+3] | 0x02;
      if (Q[6] == 1)
       AudioData[ch][(k*768)+185*4+3] = AudioData[ch][(k*768)+185*4+3] | 0x02;
      if (Q[7] == 1)
       AudioData[ch][(k*768)+184*4+3] = AudioData[ch][(k*768)+184*4+3] | 0x02;

 } // for (k = 0 ..

} // calcrc





char *strmove(char *instr, char *sout, int st, int no)
{
 int k;

 k = 0;
 while((instr[k] != '\0') && (k <= no)){
   sout[k] = instr[k+st];
   k++;
 }
 sout[k-1] = '\0';
 return(sout);
}






int parity(int ch, int no)
{  
 int      d,          // loop counter
	  p,          // counts number of '1'
	  EvenPar;    // 1=even parity   0=odd parity
 unsigned long int SubFrame,
                   xx;
 char     Digit[3];   // 2 binary digits
// char     Frame[33];  // 32 bit binary subframe string - for debug only
 char     aa;
 // char    ef[33];
 // char    *ff = ef;


 // calculate the 32 bit subframe from the 4 bytes
 xx = AudioData[ch][no*4+0];
 SubFrame = 0x1000000L * xx;
 xx = AudioData[ch][no*4+1];
 SubFrame = 0x10000L * xx + SubFrame;
 xx = AudioData[ch][no*4+2];
 SubFrame = 0x100 * xx + SubFrame;
 xx = AudioData[ch][no*4+3];
 SubFrame = xx + SubFrame;


 p = 0;
 strcpy(Digit,"01");
 for(d = 31; d >= 0; --d)
  {
   aa = Digit[SubFrame & 1];
   if (aa == '1')
    ++p;                       // counts number of '1'
   xx = SubFrame >> 1;         // shift right one position
   SubFrame = xx;
  } // for


// Frame[32] = '\x0';            // terminate string with NULL


 if ((p % 2) == 0) {
   EvenPar = 1;
  }
  else{
   EvenPar = 0;
   ++AudioData[ch][no*4+3];  // set the parity bit P (frame bit 0)
  }

 return(EvenPar);
} // parity




int pow2(int y)
// beregner 2^y, return in x
{
 int x,n;
 x = 1;

 for(n = 0; n < y ; ++n)
  x = x * 2;

 return(x);
}




unsigned char invertbyte( unsigned char inb)
// invert the 8 bits in a byte
{
unsigned char bb;
bb = 0;
 if ((inb & 0x01) == 0x01)
  bb = bb + 0x80;
 if ((inb & 0x02) == 0x02)
  bb = bb + 0x40;
 if ((inb & 0x04) == 0x04)
  bb = bb + 0x20;
 if ((inb & 0x08) == 0x08)
  bb = bb + 0x10;
 if ((inb & 0x10) == 0x10)
  bb = bb + 0x08;
 if ((inb & 0x20) == 0x20)
  bb = bb + 0x04;
 if ((inb & 0x40) == 0x40)
  bb = bb + 0x02;
 if ((inb & 0x80) == 0x80)
  bb = bb + 0x01;

return(bb);
}


