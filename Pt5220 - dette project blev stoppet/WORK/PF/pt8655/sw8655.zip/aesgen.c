/********************************************************************
* Project	: PT5220  AES/EBU generator PT86xx
* Filename	: AESGEN.C
* Revision	: 990803
* Purpose	: Main module, Interrupt- and Command-Handling.
* Org.date	: 990803
* Author	: PF
********************************************************************
HISTORY:

*/

#include <xa.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <intrpt.h>
#include <string.h>
#include "equ.h"
#include "seri1.h"
#include "maketone.h"
#include "aesgen.h"
#include "sine.h"
#include "dbfs.h"

// VERSION SETTING:     xxy = version xx.y, first 'x' can not be '0'.
#define version	10

// V24 ADDRESS: (0xf0 if OPTION):
#define defaddr 0xf0


extern void syssetup(void);

NUC myaddress;
near char header1;
NUI Number,		// First number received on v24-bus
    Number1;		// Second number received on v24-bus
bit std,                // flags for requests from master-up
    req,
    quit,
    save,
    WCLK_select_1,      // Select word clock (0=audio   1=word clock)
    Disable_WCLK_XLR_1, // Disable word clock on XLR-connector
    WCLK_select_2,      // Select word clock (0=audio   1=word clock)
    Disable_WCLK_XLR_2; // Disable word clock on XLR-connector
NUC errstatus;		// error status

NUC instring[25];	// receive string from serial
NUC instr_index;	// index into receive string (instring)

UI  Contrreg_1;         // Variables for output-port in PLD
UI  Contrreg_2;



// *****************************************************************

// START-UP BY TURNING OFF THE WATCH-DOG
#asm
	psect	text, global, reloc=2, align=2
		global	powerup, start
powerup:
	clr	0x02fa		;clear watchdog enable flag
	mov.b	0x45d,#0xa5	;watchdog1
	mov.b	0x45e,#0x5a	;watchdog2
	jmp	start
#endasm

// ******************************************************************
near struct kommando
{	 char Aa;
	 char Bb;
	 void (*funktion)(void);
};

//**********************************************************
// copies a string from ROM(code) to RAM
char *Cstrcpy(char * to, code char * from)
{
	char *	cp;

	cp = to;
	while(*cp++ = *from++)
		continue;
	return (to);
}

//**********************************************************
void dummy(void){

}

//**********************************************************
void SetControlReg_1(void){

 if (TimingSystem_1 == PALSystem)
   Contrreg_1 &= 0xFD;  // clear bit 1
  else
   Contrreg_1 |= 0x02;  // set bit 1

 if (ClickPeriode_1 == ClickPeriode1Sec)
   Contrreg_1 &= 0xEF;  // clear bit 4
  else
   Contrreg_1 |= 0x10;  // set bit 4

 Contrreg_1 &= 0x1F;    // clear bit 5,6,7
 switch (ClickMode_1){
   case  1 : Contrreg_1 |= 0x20;   // set bit 5
             break;
   case  2 : Contrreg_1 |= 0x40;   // set bit 6
             break;
   case  3 : Contrreg_1 |= 0x60;   // set bit 5,6
             break;
 }  

 PortContrreg_1 = Contrreg_1;  // write to port in PLD	
}



// *****************************************************************
void setadr(void)	// HA  -set V24 address (at start-up)
{  if (req)
   {  req= 0;
      return_char(myaddress);
   }
   else if (std)
   {  S1ADDR= myaddress= (UC)Number;
      T1B8= 1;		// set 9 bit transmit
      put_char1(myaddress); // send address back for control
   }
}

//********************************************************
void setplayaudio(void){
  Contrreg_1 |= 0x01;  // set bit 0
  PlayAudio_1 = 1;
  PortContrreg_1 = Contrreg_1;  // write to port in PLD	
}

void clearplayaudio(void){
  Contrreg_1 &= 0xFE;  // clear bit 0
  PlayAudio_1 = 0;
  PortContrreg_1 = Contrreg_1;  // write to port in PLD	
}




//***********************************************************
void selectwordclock(void){
  Contrreg_1 |= 0x04;  // set bit 2
  WCLK_select_1 = 1;
  PortContrreg_1 = Contrreg_1;  // write to port in PLD	
}

void selectaudio(void){
  Contrreg_1 &= 0xFB;  // clear bit 2
  WCLK_select_1 = 0;
  PortContrreg_1 = Contrreg_1;  // write to port in PLD	
}


//***********************************************************
// HF  -set frequency on channel
// Number = channel (ChA or ChB)
// Number1 = freq
void setfreq(void)	
{  if (req){
     req= 0;
     if (Number == ChA)
       return_int(AudioFreqA);
      else if (Number == ChB)
       return_int(AudioFreqB);
   }
   else if (std){
     if (Number == ChA)
       AudioFreqA = (UI)Number1;
      else if (Number == ChB)
       AudioFreqB = (UI)Number1;
   }
}


//**********************************************************
// HL  -set level on channel
// Number = channel (ChA or ChB)
// Number1 = level
void setlevel(void)	
{  if (req){
     req= 0;
     if (Number == ChA)
       return_int(LevelA);
      else if (Number == ChB)
       return_int(LevelB);
   }
   else if (std){
     if (Number == ChA)
       LevelA = (UI)Number1;
      else if (Number == ChB)
       LevelB = (UI)Number1;
   }
}

//**********************************************************
// HM  -set audio mode on channel A and B
// Number = audiomode (both ChA and ChB)
void setaudiomode(void)	
{  if (req){
    req= 0;
     return_int(AudioMode);
   }
   else if (std){
    if (Number <=3) 
     AudioMode = (UI)Number;
   }
}

//**********************************************************
// HE - set emphasis = J17,5017 or OFF on channel A and B
// Number = emphasis (0=off  1=5015  2=J17)
void setemphasis(void){
   if (req){
     req= 0;
     return_int(Emphasis);
   }
   else if (std){
    if (Number <= 2)
     Emphasis = (UI)Number;
   }  
}


//**********************************************************
// HU  - set U-string for channel A or B
// Number = channel (ChA or ChB)
// instring = U-string
void setustring(void){
   if (req){
     req= 0;
     if (Number == ChA)
       return_string(UstrA);
      else if (Number == ChB)
       return_string(UstrB);
   }
   else if (std){
     if (Number == ChA)
       strcpy((char *)UstrA,(char *)instring);
      else if (Number == ChB)
       strcpy((char *)UstrB,(char *)instring);
   }
}

//**********************************************************
// HT  - set start position for U-string for channel A or B
// Number = channel (ChA or ChB)
// Number1 = start position
void setstartustring(void){
   if (req){
     req= 0;
     if (Number == ChA)
       return_int(UstartA);
      else if (Number == ChB)
       return_int(UstartB);
   }
   else if (std){
     if (Number == ChA)
       UstartA = Number1;
      else if (Number == ChB)
       UstartB = Number1;
   }
}

//**********************************************************
// HK  - set click mode for generator #1
// Number = click mode
// Number1 = click periode
void setclickmode(void){
   if (req){
     req= 0;
     return_int_int(ClickMode_1,ClickPeriode_1);
   }
   else if (std){
     if (Number < 8)
      ClickMode_1 = Number;
     if (Number1 < 4)
      ClickPeriode_1 = Number1;

     SetControlReg_1(); 
   }
}

//**********************************************************
// HG  - set timing system and timing audio/video for generator #1
// Number =  timing system
// Number1 = timing audio/video
void settiming(void){
   if (req){
     req= 0;
     return_int_int(TimingSystem_1,TimingAudVideo_1);
   }
   else if (std){
     if (Number < 2)
      TimingSystem_1 = Number;
     if (Number1 < 0x228)
      TimingAudVideo_1 = Number1;
   }

   PortTimreg_1 = TimingAudVideo_1;
   SetControlReg_1();
}



// ****************************************************************
// stores an unsigned integer in flash prom address = fla_addr
// Dummy function: erstattes af rigtig routine fra Kim
void Wr_flash_int(UL fla_addr, NUI dd){
}




// *****************************************************************
void wrtext(void)   // HW  -write user text in flash sector #18
// 10 x 10 char text strings starting at 0h, 10h, 20h ... 90h
{  
UC i;
UI f;
  i = 0;
  while (i < 11){
   f = instring[i+1];
   f = f << 8;
   f = f + instring[i];
   Wr_flash_int(SA18 + (Number * 16) + i, f);
   i = i + 2;
  }
}
// *****************************************************************

void rdtext(void)   // HR  -read user text in flash sector #18
// 10 x 10 char text strings at 0h, 10h, 20h ... 90h
{  
 UC i, s[10];
 UI t;
 far UI *p;          // absolute pointer to flash word addresses

   p = (far UI *)(SA18 + (Number * 0x10));  // points to start of text

   if (req){
      req= 0;
      for (i=0;i<10;i++){  
       t = *p;
       s[i*2] = (UC)(t & 0x00ff);           // read first char into string
       s[i*2 + 1]= (UC)((t & 0xff00) >> 8); // read second char into string
       p++;        // points to the next word in flash prom 
      } 
      return_string(s);
   }
}


// *****************************************************************
void verreport(void)   // HI?
{  if (req)
   {  req= 0;
      return_char(version);
   }
}

//*****************************************************************
// Copies audiodata from SRAM to audio RAM
// addr = start address in audio RAM
void CopyAESData(UL addr){
 UI i;
 far UC *p;          // absolute pointer to audio RAM

   p = (far UC *)addr;  // points to start of audio RAM
   for (i=0; i<15360; i++){  
    *p = RAMAudioData[i];
    p++;        // points to the next char in audio RAM 
   } 
}



//******************************************************************
// calculates the aes data and stores them in audio RAM#1
void makeaes_1(void){
int tmp_freq1,
    tmp_freq2;
    
    if (std){
     switch (ClickMode_1){
      case 0 : CalSound();
               clearplayaudio();
               CopyAESData(AudioRAM_1);   // copy to AES-RAM#1
               setplayaudio();
               break;

      case 1 : CalSound();
               clearplayaudio();
               CopyAESData(AudioRAM_1);
               
               tmp_freq1 = AudioFreqA;
               AudioFreqA = 0;         // click in Ch-A
               CalSound();
               AudioFreqA = tmp_freq1;
               CopyAESData(AudioRAM_1+0x4000);
               setplayaudio();
               break;
      case 2 : CalSound();
               clearplayaudio();
               CopyAESData(AudioRAM_1);
               
               tmp_freq1 = AudioFreqA;
               AudioFreqA = 0;         // click in Ch-A
               CalSound();
               AudioFreqA = tmp_freq1;
               CopyAESData(AudioRAM_1+0x4000);
               tmp_freq2 = AudioFreqB;
               AudioFreqB = 0;         // click in Ch-B
               CalSound();
               AudioFreqB = tmp_freq2;
               CopyAESData(AudioRAM_1+0x8000); 
               setplayaudio();
               break;
      case 3 : CalSound();
               clearplayaudio();
               CopyAESData(AudioRAM_1);
               
               tmp_freq1 = AudioFreqA;
               tmp_freq2 = AudioFreqB;
               AudioFreqA = 0;         // click in Ch-A and Ch-B
               AudioFreqB = 0;
               CalSound();
               AudioFreqA = tmp_freq1;
               AudioFreqB = tmp_freq2;
               CopyAESData(AudioRAM_1+0x4000);
               setplayaudio();
               break;
     } // switch

   }// if

}



// *****************************************************************
void opstart(void)
{
  errstatus= 0;		// no errors

// copy default sound values to variables  
  LevelA = defLevelA;
  LevelB = defLevelB;
  AudioFreqA = defAudioFreqA;
  AudioFreqB = defAudioFreqB;
  AudioMode = defAudioMode;
  Emphasis = defEmphasis;
  UstartA = defUstartA;
  Cstrcpy((char *)UstrA,(code char *)defUstrA);
  UstartB = defUstartB;
  Cstrcpy((char *)UstrB,(code char *)defUstrB);

  ClickMode_1 = defClickMode;
  ClickPeriode_1 = defClickPeriode;
  TimingAudVideo_1 = 0;
  TimingSystem_1 = PALSystem;
  ClickMode_2 = defClickMode;
  ClickPeriode_2 = defClickPeriode;
  TimingAudVideo_2 = 0;
  TimingSystem_2 = PALSystem;
  WCLK_select_1 = 0;
  Disable_WCLK_XLR_1 = 0;
  WCLK_select_2 = 0;
  Disable_WCLK_XLR_2 = 0;

  PortContrreg_1 = Contrreg_1 = 0x00;
  PortContrreg_2 = Contrreg_2 = 0x00;
   
}
// *****************************************************************

void readstat(void)	// HS  -Read status for generator #1 and #2
{  
 if (req){
   req= 0;
   return_int(PortStatusreg);
 }
}
// *****************************************************************

code const struct kommando kommandotabel[] = {

'H','A',setadr,
'H','C',makeaes_1,
'H','E',setemphasis,
'H','F',setfreq,
'H','G',settiming,
'H','I',verreport,
'H','K',setclickmode,
'H','M',setaudiomode,
'H','L',setlevel,
'H','S',readstat,
'H','T',setstartustring,
'H','U',setustring,
'S','W',dummy
};
// *****************************************************************
// Command Machine
// *****************************************************************

void CommandExecute(char A,char B) {
UC x;
for (x = 0; x < (sizeof(kommandotabel)/sizeof(struct kommando)); x++)
   if (A==kommandotabel[x].Aa)
      if (B==kommandotabel[x].Bb){
	header1 = A;
	kommandotabel[x].funktion();
	break;
      }
}
// *****************************************************************

void CharHandler(UC c)
{  static UC MesState;
   static char First,Second;
   switch ( MesState)
   {  case 0: 	if(isalpha(c)){
  	      	  First = toupper(c); 
  	      	  MesState = 1;
	      	}  break;
      case 1: 	if(isalpha(c)){
    	      	  Second =toupper(c); 
    	      	  MesState = 2; 
    	      	  Number = 0;
	      	}
		else 
		 MesState= 0;
	      	break;
      case 2:	if(isdigit(c))  
                 Number = (c-'0') + 10 * Number;
		else if (c==',')  
		 MesState= 3;
		else if (c==34){
		 MesState= 4;		// was quote, start string
		 instr_index= 0;
		}
		else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$')
		{  MesState = 5;
		   std= 0; 
		   quit= 0; 
		   save= 0; 
		   req= 0;
	           if (c == '?') 
	            req = 1;
	           else if (c == '!') 
	            quit = 1;
	           else if (c == '$') 
	            save = 1;
		   else  std= 1;
	           // CommandExecute(First,Second);
		}
		else MesState= 0;
		break;
      case 3:	if(isdigit(c))  
                  Number1 = 10 * Number1 + (c-'0');
		 else if (c==34){
		  MesState= 4;		// was quote, start string
		  instr_index= 0;
		}
		else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$')
		{  MesState = 5;
		   std= 0; quit= 0; save= 0; req= 0;
		   if (c == '?') 
		    req = 1;
		   else if (c == '!') 
		    quit = 1;
		   else if (c == '$') 
		    save = 1;
		   else  std= 1;
		   // CommandExecute(First,Second);
		}
		else MesState= 0;
		break;
      case 4:	if (c==34)  
                 instring[instr_index]= 0;  // end the string
		else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$')
		{  MesState = 5;
		   std= 0; 
		   quit= 0; 
		   save= 0; 
		   req= 0;
		   if (c == '?') 
		    req = 1;
		   else if (c == '!') 
		    quit = 1;
		   else if (c == '$') 
		    save = 1;
		   else  std= 1;
		   // CommandExecute(First,Second);
		}
		else 
		 instring[instr_index++]= c; // save the char in string
		break;
      case 5:	MesState = 0;
		if (c==0x80) 
		 CommandExecute(First,Second);
		break;
      default:	MesState = 0; 
                break;
   }
}
// *****************************************************************

void kommun(void)
{  UC gc;
   while ((gc=get_char1()) != 0)	/* handle characters from buffer */
            CharHandler(gc);
}
// *****************************************************************
// *****************************************************************

void main(void)
{
// System set-up        // see XA-user guide 1997 page 280 
   syssetup();

 // set-up counters and interrupts
   IEL= 0;		// reset timers
   IT0= 1;		//INTR0 EDGE TRIG
   IT1= 1;		//INTR1 EDGE TRIG
   EX0= 0;		//DISABLE INTR FROM EXT0
   EX1= 0;		//DISABLE INTR FROM EXT1
 /*
   TMOD= 0x21;	// T1 =8 bit reload, T0 =16 bit (not used)
   ET1= 0;	// intrpt from timer1 disabled
   ET0= 0;
   RTL1= -48;	// reload value for Timer 1, sets Baud rate to 9600
 */
 // alternativ til timer 1: timer2 til V24 (max-rate)
   T2MOD= 0x31;	// use T2 for V24_1, count up
   T2CAPH= -1;	// set reload values for max Baud
   T2CAPL= -6;
   TH2= -1;	// set for max. Baud
   TL2= -6;
   TR2= 1;	// start V24-timer
   SWE |= 1;	// enable SW-interrupt 1 for moving command to cyclic buffer

   S1CON= 0xf0;	// 0xf2,Transmit mode 3, 9 bit UART, Address mode, Rec.enable


/* DEFINITION OF INTERRUPTS (see 1997 manual pg.89)
  Interrupt:	Level:	Reg-bank:
EX0 (line1)	15	2	banked
EX1 (line2)	15	2	banked
serial1		14	1	banked
ser.1-end	 1	0	not banked
// SOFTWARE-INTERRUPTS:
none
*/
ROM_VECTOR(IV_RI1, serial1_int, IV_SYSTEM+IV_PRI14+IV_BANK1)
ROM_VECTOR(IV_SWI1, serial_end, IV_SYSTEM+IV_PRI01+IV_BANK0)

   IPA5= 0x0e;    // serial 1 TX/Rx prior.


   S1ADDR= myaddress= defaddr;	// default receive address
   S1ADEN= 0xFF;  // mask for receive address (zeroes makes don't care)

   serial1_init();

   opstart();

   EA= 1;			// enable all interrupts


// *****************************************************************

// main interrupt waiting loop

   while(1){
     kommun();
   }
}
