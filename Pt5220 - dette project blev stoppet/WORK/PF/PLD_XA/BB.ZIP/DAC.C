/*******************************************************************
* Project	: PT5220  Black Burst
* Filename	: DAC.C
* Version	: 1.0
* Purpose	: u-wire control of 8-bit DAC MB88347L via uP-PORT
* Org.date	: 990816
* Author	: PF
********************************************************************
HISTORY:
*/

#include <xa.h>			// define 8051 registers
#include "equ.h"

#define UC 	unsigned char
#define UI 	unsigned int

void waitus(UI time);	// 1 us wait routine

static bit   DI   @ 0x398;   // P3.0  RxD0
static bit   CLK  @ 0x38e;   // P1.6  T2
static bit   LD   @ 0x39c;   // P3.4  T0

// *****************************************************************


void Wr_dac(UC dacno, UC data)
// dacno: bit 11-8,  data: bit 7-0
// MSB(bit11) is written first.
// max clock is 2.5 MHz
{
UI d;
UC n;
 LD = 0;          // clear LOAD pin on dac
 CLK = 0;         // clear CLOCK pin on dac
 d = dacno;
 d = d << 8;      // shift dacno into bit 11-8
 d = d + data;    // put data into bit 7-0
 for (n = 0; n < 12; n++) {
  if ((d & 0x0800) == 0)
    DI = 0;
   else
    DI = 1;
  waitus(1);  
  CLK = 1;
  waitus(1);
  CLK = 0;
  waitus(1);
  d = d << 1;
 } //for

 LD = 1;       // start d/a converting
 waitus(1);
 LD = 0;

}
// *****************************************************************

void waitus(UI time){	// 1 us wait routine
  UC n;
  while (time-- > 0){ 	// wait 1 us x time
   n= 1;
   while (n>0)
    n--;
  }
}
// ******************************************************************

