#ifndef _FSL_H
#define _FSL_H

#include "xbasic_types.h"
#include "mb_interface.h"       /* Legacy reasons. We just have to include this guy who defines the FSL stuff */

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif
#endif /* _FSL_H */

