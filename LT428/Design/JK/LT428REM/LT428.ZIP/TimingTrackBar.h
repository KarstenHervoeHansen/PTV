//---------------------------------------------------------------------------
#ifndef TimingTrackBarH
#define TimingTrackBarH
//---------------------------------------------------------------------------
#include <vcl\SysUtils.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Forms.hpp>
#include <vcl\ComCtrls.hpp>
//---------------------------------------------------------------------------
class TimingTrackBar : public TTrackBar
{
private:
protected:
public:
	__fastcall TimingTrackBar(TComponent* Owner);
__published:
};
//---------------------------------------------------------------------------
#endif
