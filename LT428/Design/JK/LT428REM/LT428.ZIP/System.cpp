//-------------------- -------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "System.h"
#include "mainform.h"
#include "proper.h"
#include "util.h"
#include "pt52class.h"
#include "names.h"

//---------------------------- TStrings --------------------------
#pragma resource "*.dfm"

AnsiString PTVsyslines[] =
  {
  {"PT5201 will always reset to this system"},
  {"when doing a factory reset. Please note"},
  {"that this does NOT affect any of the four"},
  {"user presets."}
  };

  AnsiString LEADERsyslines[] =
  {
  {"LT428 will always reset to this system"},
  {"when doing a factory reset. Please note"},
  {"that this does NOT affect any of the four"},
  {"user presets."}
  };

  AnsiString LEADERcallines[] =
  {
  {"Calibrating the LT428 will alter the factory"},
  {"settings of the unit."},
  {"Calibration requires that a frequency counter"},
  {"is connected to output BB1."}
  };

  AnsiString PTVcallines[] =
  {
  {"Calibrating the PT5201 will alter the factory"},
  {"settings of the unit."},
  {"Calibration requires that a frequency counter"},
  {"is connected to output BB1."}
  };


TSystemForm *SystemForm;

extern int delay_tick;
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
__fastcall TSystemForm::TSystemForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::FormShow(TObject *Sender)
{
	bool tmpEnable = false;
	const char* *ptr;
	char TxBuffer[25], RxBuffer[25];


#ifdef LEADER
 PresetMemo->Lines->Add(LEADERsyslines[0]);
 PresetMemo->Lines->Add(LEADERsyslines[1]);
 PresetMemo->Lines->Add(LEADERsyslines[2]);
 PresetMemo->Lines->Add(LEADERsyslines[3]);
 Memo1->Lines->Add(LEADERcallines[0]);
 Memo1->Lines->Add(LEADERcallines[1]);
 Memo1->Lines->Add(LEADERcallines[2]);
 Memo1->Lines->Add(LEADERcallines[3]);
#else
 PresetMemo->Lines->Add(PTVsyslines[0]);
 PresetMemo->Lines->Add(PTVsyslines[1]);
 PresetMemo->Lines->Add(PTVsyslines[2]);
 PresetMemo->Lines->Add(PTVsyslines[3]);
 Memo1->Lines->Add(PTVcallines[0]);
 Memo1->Lines->Add(PTVcallines[1]);
 Memo1->Lines->Add(PTVcallines[2]);
 Memo1->Lines->Add(PTVcallines[3]);
#endif
	// Prepare TV system choice
	SystemComboBox->Items->Clear();

 	ptr = ResetSystemTxt;
	while (*ptr)
		SystemComboBox->Items->Add( *ptr++);

	SystemComboBox->ItemIndex = 0;

	if (PT5201CommPort->Connected() || TestModeConnected)
	  {
		if (!TestModeConnected)
      {
			sprintf(TxBuffer, "FACT:MAIN:SYST?\r\n");
			if (TrxRequest( TxBuffer, 20, (Byte *)RxBuffer))
	 		  {
				if (!strcmp( RxBuffer, "PAL"))
					SystemComboBox->ItemIndex = 0;
		   	else
  				if (!strcmp( RxBuffer, "NTSC"))
  					SystemComboBox->ItemIndex = 1;
          else
    				if (!strcmp( RxBuffer, "JNTSC"))
    					SystemComboBox->ItemIndex = 2;
			  }
      }
    else
			SystemComboBox->ItemIndex = 0;

		tmpEnable = true;
	  }

	ResetBitBtn->Enabled    = tmpEnable;
	SystemComboBox->Enabled = tmpEnable;

	UnlockButton->Caption = "Unlock";
	CalibUpDown->Enabled  = false;
	MinCalibButton->Enabled = false;
	MaxCalibButton->Enabled = false;
	SaveBitBtn->Enabled = false;

	UnlockButton->Enabled = tmpEnable && !PropertiesForm->LockCalibCheckBox->Checked;
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::FormClose(TObject *Sender, TCloseAction &Action)
{
	TrxGenlockCalibEnable( false);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::ResetBitBtnClick(TObject *Sender)
  {
	if ( !TestModeConnected)
    {
		RSTCommand();

    delay_tick = 0;
    //while(delay_tick != 2)
    //  ;
    // Delay

		TrxApparatusInfoRequest();
    }
  }
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::SystemComboBoxChange(TObject *Sender)
{
	FactSystemCommand( SystemComboBox->ItemIndex);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::UnlockButtonClick(TObject *Sender)
{
	if ( UnlockButton->Caption == "Lock")
  {
		UnlockButton->Caption = "Unlock";

		CalibUpDown->Enabled = false;
		MinCalibButton->Enabled = false;
		MaxCalibButton->Enabled = false;
		SaveBitBtn->Enabled = false;
  }
  else
  {
		UnlockButton->Caption = "Lock";

		CalibUpDown->Enabled = true;
		MinCalibButton->Enabled = true;
		MaxCalibButton->Enabled = true;
		SaveBitBtn->Enabled = true;
  }

	TrxGenlockCalibEnable( CalibUpDown->Enabled);
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::SaveBitBtnClick(TObject *Sender)
{
	UnlockButton->Caption = "Unlock";

	CalibUpDown->Enabled = false;
	MinCalibButton->Enabled = false;
	MaxCalibButton->Enabled = false;
	SaveBitBtn->Enabled = false;

	TrxGenlockCalibStore();
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void __fastcall TSystemForm::CalibUpDownClick(TObject *Sender, TUDBtnType Button)
{
	if ( Button == btNext)
		TrxGenlockCalibAdjust(UP);
  else
		TrxGenlockCalibAdjust(DOWN);
}
//---------------------------------------------------------------------------
void __fastcall TSystemForm::MaxCalibButtonClick(TObject *Sender)
{
	TrxGenlockCalibAdjust( MAXValue);
}
//---------------------------------------------------------------------------
void __fastcall TSystemForm::MinCalibButtonClick(TObject *Sender)
{
	TrxGenlockCalibAdjust( MINValue);
}
//---------------------------------------------------------------------------
void __fastcall TSystemForm::HelpButtonClick(TObject *Sender)
{
	Application->HelpContext( IDH_EDITSYSTEM);
}
//---------------------------------------------------------------------------
