/*
Terminalprogram for PT5201: 7108 100 74821

000606 Peter Frederiksen, PTV


Rettelser:



*/

#define TESTSWVER  "SW Ver. 000710    7108 100 74821"

#include <utility.h>
#include <rs232.h>
#include <ansi_c.h>
#include <formatio.h>
#include <cvirte.h>		/* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>
#include "com5201.h"
#include "comspgutil.h"

#define spgaddr 0x15		// internal V24-addr for SPG
#define bbaddr 0x34		// internal V24-addr for BB
#define COMNo 1
#define baudrate 9600

const char FKeyDefFilename[10] = {"fkey.dat"};
const char COMstr[3][5] = {"","com1","com2"};


static int mainPNL;
int	Err232, 
		ComOpen,
		fkeyfile;
char	FKeystr[50],
		txtstr[2][80],
		KeyStr[10][80],
		FKeyFilename[50];
double timeout;


int ReadFKeyFile(void){
int bytes_read, n, validread;


 DisableBreakOnLibraryErrors();
 if (strlen(FKeyFilename) == 0)
  Fmt(FKeyFilename,"%s<%s",FKeyDefFilename);
 fkeyfile = OpenFile (FKeyFilename, VAL_READ_ONLY, VAL_OPEN_AS_IS,VAL_ASCII);
 EnableBreakOnLibraryErrors();
 if (fkeyfile == -1){
	ResetTextBox (mainPNL, PANEL_F1_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F2_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F3_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F4_TEXT, "");

	ResetTextBox (mainPNL, PANEL_F5_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F6_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F7_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F8_TEXT, "");
   return (validread = FALSE);
 } 

 StringUpperCase (FKeyFilename);
 Fmt(txtstr[0],"%s<%s",FKeyFilename);
 SetCtrlVal (mainPNL, PANEL_FKEYFILE, txtstr[0]);
 
 n = 0;
 do{
 	bytes_read = ReadLine (fkeyfile, KeyStr[n], -1);
 	n++;
 } while ((bytes_read != -2) && (bytes_read != -1));	

 CloseFile (fkeyfile);

 ResetTextBox (mainPNL, PANEL_F1_TEXT,KeyStr[0]);
 ResetTextBox (mainPNL, PANEL_F2_TEXT,KeyStr[1]);
 ResetTextBox (mainPNL, PANEL_F3_TEXT,KeyStr[2]);
 ResetTextBox (mainPNL, PANEL_F4_TEXT,KeyStr[3]);
 ResetTextBox (mainPNL, PANEL_F5_TEXT,KeyStr[4]);
 ResetTextBox (mainPNL, PANEL_F6_TEXT,KeyStr[5]);
 ResetTextBox (mainPNL, PANEL_F7_TEXT,KeyStr[6]);
 ResetTextBox (mainPNL, PANEL_F8_TEXT,KeyStr[7]);


validread = bytes_read != -1;
return validread;
}



int SaveFKeyFile(void){
int n, validsave, bytes_written;
char wrtbuf[80];

 validsave = TRUE;

 GetCtrlVal (mainPNL, PANEL_F1_TEXT, KeyStr[0]);
 GetCtrlVal (mainPNL, PANEL_F2_TEXT, KeyStr[1]);
 GetCtrlVal (mainPNL, PANEL_F3_TEXT, KeyStr[2]);
 GetCtrlVal (mainPNL, PANEL_F4_TEXT, KeyStr[3]);
 GetCtrlVal (mainPNL, PANEL_F5_TEXT, KeyStr[4]);
 GetCtrlVal (mainPNL, PANEL_F6_TEXT, KeyStr[5]);
 GetCtrlVal (mainPNL, PANEL_F7_TEXT, KeyStr[6]);
 GetCtrlVal (mainPNL, PANEL_F8_TEXT, KeyStr[7]);

 DisableBreakOnLibraryErrors();
 fkeyfile = OpenFile (FKeyFilename, VAL_WRITE_ONLY, VAL_TRUNCATE,VAL_ASCII);
 EnableBreakOnLibraryErrors();
 if (fkeyfile == -1)
  return (validsave = FALSE);

 for (n = 0; n < 8; n++) {
  Fmt(wrtbuf,"%s<%s\n",KeyStr[n]);
  bytes_written = WriteFile (fkeyfile, wrtbuf, strlen(wrtbuf));
  if (bytes_written == -1){
   validsave = FALSE;
   CloseFile (fkeyfile);
   break;
  } 
 } 
  
 CloseFile (fkeyfile);

 if (validsave == TRUE)
   Fmt(txtstr[0],"%s<FKey saved in '%s'",FKeyFilename);
  else 
   Fmt(txtstr[0],"%s<Error saving FKey in '%s'",FKeyFilename);
 MessagePopup("COM5201",txtstr[0]); 
 
 

return validsave;
}




int main (int argc, char *argv[])
{

	if (InitCVIRTE (0, argv, 0) == 0)	/* Needed if linking in external compiler; harmless otherwise */
		return -1;	/* out of memory */
	if ((mainPNL = LoadPanel (0, "com5201.uir", PANEL)) < 0)
		return -1;

	Err232 = OpenComConfig (COMNo, COMstr[COMNo], baudrate, 0, 8, 2, 500, 500);
	if (Err232 == 0)
	 ComOpen = TRUE;
	 else{
	 MessagePopup ("COM Port", "Open Failed");
	 exit(1);
	 }

	GetCtrlVal (mainPNL, PANEL_TIMEOUT, &timeout);
	SetCtrlVal (mainPNL, PANEL_TESTSW, TESTSWVER);

	ResetTextBox (mainPNL, PANEL_COMTEXT, "");
	Fmt(txtstr[1],"%s<COM%i\n",COMNo);
	SetCtrlVal (mainPNL, PANEL_COMTEXT, txtstr[1]);
	Fmt(txtstr[1],"%s<Baud: %i",baudrate);
	SetCtrlVal (mainPNL, PANEL_COMTEXT, txtstr[1]);
	SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_CTRL_VAL, TRUE);
	SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_GREEN);


	DisplayPanel (mainPNL);

	Fmt(FKeyFilename,"%s<%s",argv[1]);
	
	ReadFKeyFile();

/*	
	ResetTextBox (mainPNL, PANEL_F1_TEXT, ":FACT:V24C:COMM 21,'GS?';");
	ResetTextBox (mainPNL, PANEL_F2_TEXT, ":OUTP:AUD:AES:TIM 0;");
	ResetTextBox (mainPNL, PANEL_F3_TEXT, ":OUTP:BB1:SYST PAL;");
	ResetTextBox (mainPNL, PANEL_F4_TEXT, ":OUTP:BB1:SYST NTSC;");
	
	ResetTextBox (mainPNL, PANEL_F5_TEXT, ":INP:GENL:SYST PALB;");
	ResetTextBox (mainPNL, PANEL_F6_TEXT, ":INP:GENL:SYST NTSC;");
	ResetTextBox (mainPNL, PANEL_F7_TEXT, ":INP:GENL:SYST INT;");
	ResetTextBox (mainPNL, PANEL_F8_TEXT, "*IDN?;");
*/

/*
// Ops�tning til GPV:	
	ResetTextBox (mainPNL, PANEL_F1_TEXT, "*IDN?;");
	ResetTextBox (mainPNL, PANEL_F2_TEXT, ":FACT:PASS 'PASS5201';");
	ResetTextBox (mainPNL, PANEL_F3_TEXT, ":FACT:PASS?;");
	ResetTextBox (mainPNL, PANEL_F4_TEXT, ":FACT:V24C:TRAN SPG;");
	
	ResetTextBox (mainPNL, PANEL_F5_TEXT, ":FACT:V24C:TRAN BB;");
	ResetTextBox (mainPNL, PANEL_F6_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F7_TEXT, "");
	ResetTextBox (mainPNL, PANEL_F8_TEXT, "");
*/

	RunUserInterface ();
	return 0;
}




void SendCommand(char *sendstr){

char COM1Buf[50], *instr;
int n,l;
unsigned int result;

if (ComOpen == FALSE){
 MessagePopup ("COM Port", "Port not open");
 return;
} 


SetCtrlVal (mainPNL, PANEL_RCVSTR, "      ");
SetCtrlVal (mainPNL, PANEL_SENDSTR, "     ");



Fmt(COM1Buf,"%s<%s",sendstr);

FlushInQ(COMNo);
WriteCOMPort(COMNo, COM1Buf);

Fmt(txtstr[1],"%s<%s",sendstr);
SetCtrlVal (mainPNL, PANEL_SENDSTR, txtstr[1]);


instr = ReadlnCOMPort(COMNo, timeout);
if (strlen(instr) > 0){
 CopyString (txtstr[0], 0, instr, 0, strlen(instr));
 SetCtrlVal (mainPNL, PANEL_RCVSTR, txtstr[0]);
 }


if (RS232Timeout == 1)
 SetCtrlVal (mainPNL, PANEL_RCVSTR, "timeout" );
else
if (COMbytes_read == 0)
 SetCtrlVal (mainPNL, PANEL_RCVSTR, "      " );


}








int CVICALLBACK ExitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			CloseCom(COMNo);
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK FKeyCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			switch (control){
			 case PANEL_F1_BTN: GetCtrlVal (mainPNL, PANEL_F1_TEXT, FKeystr); break;
			 case PANEL_F2_BTN: GetCtrlVal (mainPNL, PANEL_F2_TEXT, FKeystr); break;
			 case PANEL_F3_BTN: GetCtrlVal (mainPNL, PANEL_F3_TEXT, FKeystr); break;
			 case PANEL_F4_BTN: GetCtrlVal (mainPNL, PANEL_F4_TEXT, FKeystr); break;

			 case PANEL_F5_BTN: GetCtrlVal (mainPNL, PANEL_F5_TEXT, FKeystr); break;
			 case PANEL_F6_BTN: GetCtrlVal (mainPNL, PANEL_F6_TEXT, FKeystr); break;
			 case PANEL_F7_BTN: GetCtrlVal (mainPNL, PANEL_F7_TEXT, FKeystr); break;
			 case PANEL_F8_BTN: GetCtrlVal (mainPNL, PANEL_F8_TEXT, FKeystr); break;
			}
			
			SendCommand(FKeystr);

			break;
	}
	return 0;
}






int CVICALLBACK ComCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if ((control == PANEL_OPENCOM) && (ComOpen == FALSE)){
			 	Err232 = OpenComConfig (COMNo, COMstr[COMNo], baudrate, 0, 8, 2, 500, 500);
			 	ComOpen = TRUE;
				SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_GREEN);
			} 	
			else if ((control == PANEL_CLOSECOM) && (ComOpen == TRUE)){
				CloseCom(COMNo);
			 	ComOpen = FALSE;
				SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_RED);

			
			}


			break;
	}
	return 0;
}

int CVICALLBACK SaveCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			SaveFKeyFile();
			break;
	}
	return 0;
}


int CVICALLBACK TimeoutCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_VAL_CHANGED:
		 GetCtrlVal (mainPNL, PANEL_TIMEOUT, &timeout);
		

			break;
	}
	return 0;
}
