/* 
Utility file for test af PT5201
File: comspgutil.c

nov 1996, Peter Frederiksen


*/

#include <userint.h>
#include <ansi_c.h>
#include <formatio.h>
#include <rs232.h>
#include <utility.h>
#include "def.h"


// header files for uir files



char	ASCIIdata[100];			// ASCII data read from a COM port
unsigned char BINdata[2000];	// Binary data read from a COM port
int	RS232Timeout; 
int COMbytes_read;



//-------------------------------------------------------------------------------
char *ReadlnCOMPort(int PortNo, double Timeout){
 SetComTime (PortNo, Timeout);   // set timeout
 ASCIIdata[0] = 0x0;
 COMbytes_read = ComRdTerm (PortNo, ASCIIdata, 100, LF);   //terminates on LF
 if (COMbytes_read > 0) {
  if(ASCIIdata[COMbytes_read - 1] == CR)
    ASCIIdata[COMbytes_read - 1] = 0x00;
    else
    ASCIIdata[COMbytes_read] = 0x00;
  RS232Timeout = FALSE;
 }  
  else{
   ASCIIdata[0] = 0x30;
   ASCIIdata[1] = 0x00;	   // '0' + NULL
   RS232Timeout = TRUE;
  }
 
 return (&ASCIIdata[0]);
}



//-------------------------------------------------------------------------------
unsigned char *ReadBinCOMPort(int PortNo, double Timeout, int NoOfBytes){
int bytes_read;
int InQL;
// SetComTime (PortNo, Timeout);   // set timeout
 BINdata[0] = 0x0;
 bytes_read = ComRd (PortNo, BINdata, NoOfBytes);   //terminates on NoOfBytes
 BINdata[bytes_read] = 0x0;
 return (&BINdata[0]);
}



//-------------------------------------------------------------------------------
void WriteCOMPort(int PortNo, char TransmitStr[]){
int bytes_send;
int NoOfBytes;

 NoOfBytes = StringLength (TransmitStr);
 FlushOutQ(PortNo);
 bytes_send = ComWrt (PortNo, TransmitStr, NoOfBytes);
 
 while 
  (GetOutQLen(PortNo)> 0);
}


