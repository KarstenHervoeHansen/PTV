
extern int hp34970;
extern int RS232Timeout; 
extern int COMbytes_read;
extern int comerr, DUTCOM, Cont, Stop, Loop, TestOk; 
extern char *strread;



extern int	
		mainPNL, 
		bbpicturePNL,
		cbpicturePNL,
		wclkpicturePNL;


extern char *ReadlnCOMPort(int PortNo, double Timeout);
extern void WriteCOMPort(int PortNo, char TransmitStr[]);
extern void WaitForContinue(void);
extern int WriteProtect(int OnOff, int flag);
extern int GetGenlockStatus(void);
