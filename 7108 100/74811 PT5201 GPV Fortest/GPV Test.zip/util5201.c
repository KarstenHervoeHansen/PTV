/* 
Utility file for test af PT5201
File: util5201.c

nov 1996, Peter Frederiksen


*/

#include <userint.h>
#include <ansi_c.h>
#include <formatio.h>
#include <rs232.h>
#include <utility.h>
#include "def.h"



int	mainPNL, 
		bbpicturePNL,
		cbpicturePNL,
		wclkpicturePNL;



char	ASCIIdata[100];			// ASCII data read from a COM port
unsigned char BINdata[2000];	// Binary data read from a COM port
int	RS232Timeout; 
int COMbytes_read;
int comerr, DUTCOM;
int Cont, Stop, Loop, TestOk;
char *strread;


//-------------------------------------------------------------------------------
char *ReadlnCOMPort(int PortNo, double Timeout){
int bytes_read;
 SetComTime (PortNo, Timeout);   // set timeout
 ASCIIdata[0] = 0x0;
 bytes_read = ComRdTerm (PortNo, ASCIIdata, 100, LF);   //terminates on LF
 if (bytes_read > 0) {
  if(ASCIIdata[bytes_read - 1] == CR)
    ASCIIdata[bytes_read - 1] = 0x00;
  ASCIIdata[bytes_read] = 0x00;
  RS232Timeout = FALSE;
 }  
  else{
   ASCIIdata[0] = 0x30;
   ASCIIdata[1] = 0x00;	   // '0' + NULL
   RS232Timeout = TRUE;
  }
 
 return (&ASCIIdata[0]);
}




//-------------------------------------------------------------------------------
unsigned char *ReadBinCOMPort(int PortNo, double Timeout, int NoOfBytes){
int bytes_read;
int InQL;
// SetComTime (PortNo, Timeout);   // set timeout
 BINdata[0] = 0x0;
 bytes_read = ComRd (PortNo, BINdata, NoOfBytes);   //terminates on NoOfBytes
 BINdata[bytes_read] = 0x0;
 return (&BINdata[0]);
}



//-------------------------------------------------------------------------------
void WriteCOMPort(int PortNo, char TransmitStr[]){
int bytes_send;
int NoOfBytes;

 NoOfBytes = StringLength (TransmitStr);
 FlushOutQ(PortNo);
 bytes_send = ComWrt (PortNo, TransmitStr, NoOfBytes);
 
 while 
  (GetOutQLen(PortNo)> 0);
}


//-------------------------------------------------------------------------------
void WaitForContinue(void){
int handle_returned, controlID_returned;
 Cont = FALSE;
 while (Cont == FALSE)
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
}


//-------------------------------------------------------------------------------
int WriteProtect(int OnOff, int flag){
/* Indstiller password i apparatet til enten ON eller OFF
   OnOff: ON  = password s�ttes til ON
   		  OFF = password s�ttes til OFF
   flag:  TRUE  = Meddelelse gives til bruger om tilstand af password
   flag:  FALSE = Ingen meddelelse gives til bruger om tilstand af password
   
Hvis der ikke er svar p� RS-232 kommunikationen gives der altid meddelelse 
til brugeren

return:  TRUE hvis password er som �nsket og der er kontakt via RS-232, eller FALSE
*/
char *strread;
int OnOffOk;

OnOffOk = TRUE;

//#if AT232
 if (OnOff == ON){
  WriteCOMPort(DUTCOM,":FACT:PASS ON;");
  Delay(0.05);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:PASS?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strcmp (strread, "ON") != 0) {
   MessagePopup(" RS-232 remote"," FEJL:  Check RS-232 kabel, og at apparatet er t�ndt");
   OnOffOk = FALSE;
  } 
  else
  if (flag == TRUE)
   MessagePopup(" Skrivebeskyttelse"," ON");
 } // if (OnOff == ON)
 
 else{
  WriteCOMPort(DUTCOM,":FACT:PASS 'PASS5201';");
  Delay(0.05);
 
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:PASS?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strcmp (strread, "OFF") != 0){	 // master SW med password funktion
   MessagePopup(" RS-232 remote"," FEJL:  Check RS-232 kabel, og at apparatet er t�ndt");
   OnOffOk = FALSE;
  }
  else
  if (flag == TRUE)
   MessagePopup(" Skrivebeskyttelse"," OFF");
 } 

//#endif
 return OnOffOk;
}


int GetGenlockStatus(void){
// status = tilstand af UNLOCKED LED l�ses i SPG'en
int gs;
 
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GS?';");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (strlen(strread) > 0)
  Scan(strread,"%s>%i",&gs);
  else
  gs = 0;
 gs = gs & 0x06;	 // udmask bit 1,2    (bit 0,3-7=0)
 
return gs;
} // GetGenlockStatus
 
