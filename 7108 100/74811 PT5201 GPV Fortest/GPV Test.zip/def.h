#define IEEEBUS 0		//IEEE interface 
#define AT232 0			//RS232 interface (com5,6,7)


#define YES    1
#define NO     0
#define TRUE   1
#define FALSE  0
#define LF    10
#define CR    13
#define WAIT   1
#define NOWAIT 0
#define ON     1
#define OFF    0

#define DUT_LOCKED 0x02	   // genlock status register i SPG
#define DUT_INTERN 0x04

#define SPGNOTRESET 2

#define LOCALLOG    0		  // log cal data on C-drive
#define LANLOG      1		  // log cal data on LAN (M-drive)
						      // see 'LogDestination'
						
#define PAL    0
#define NTSC   1

#define L625 625
#define L525 525

