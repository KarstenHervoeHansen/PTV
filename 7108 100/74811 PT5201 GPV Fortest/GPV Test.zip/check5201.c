#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include "util5201.h"
#include "def.h"

// uir-file
#include "gpv5201.h"

const float shifttime = 0.8;


int GenlockOk, PowerOk, BB1Ok, BB2Ok, BB3Ok, CBOk, AudioOk, n;
int GenlockStatus;
char dutstr[50],txtstr[100];
int handle_returned, controlID_returned;



//--------------------------------------------------------------------------
int InitPT5201(void){
WriteCOMPort(DUTCOM, ":FACT:MAIN:SYST PAL;");	// start-up system = PAL
Delay(0.03);
WriteCOMPort(DUTCOM, ":FACT:RESET;");				// reset brugerindstillinger
Delay(0.5);

WriteCOMPort(DUTCOM, ":FACT:MAIN:IDN:COMP 'PTV';");
WriteCOMPort(DUTCOM, ":FACT:MAIN:IDN:COMP 'PTV';");
WriteCOMPort(DUTCOM, ":FACT:MAIN:IDN:TYPE 'PT5201';");
WriteCOMPort(DUTCOM, ":FACT:MAIN:IDN:KUN 'KUxxxxxx';");
WriteCOMPort(DUTCOM, ":FACT:MAIN:IDN:SWR '1.0';");
WriteCOMPort(DUTCOM, ":FACT:MAIN:NC '944905201001';");

return (1);
}


//--------------------------------------------------------------------------
int PowerTest(void){

SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, TRUE);

SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Power Supply:");
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Kontroller str�mforbrug til stik X9 pin 1,2:\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "     Max 2.3ADC       (typisk 1.9A)\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Kontroller sp�ndinger i stik X13  (GND = pin 2):\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "      5.0 � 0.2VDC  (pin 3)\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "      3.3 � 0.2VDC  (pin 5)\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "     -5.0 � 0.2VDC  (pin 7)\n\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n");

WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }

 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 if (TestOk == TRUE)
   SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n   Power supply OK   -    forts�t med n�ste test\n");
  else
   SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n   Power supply FAILED\n");

SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);

return(TRUE);
}



//------------------------------------------------------------------------
int GenlockTest(void){
int p;
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Genlock:");
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PAL video generator til GENLOCK\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PC-COM port til RS232-stik X9\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "     Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "     Stop:    Tast F12\n\n\n");
SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, TRUE);

WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }

GenlockOk = TRUE;

 if (WriteProtect(OFF,FALSE) == FALSE){
  ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
  SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
  GenlockOk = FALSE;
  SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
  return FALSE;
  }

InitPT5201();

// init genlock system
WriteCOMPort(DUTCOM, ":FACT:V24C:COMM 21,'GZ';");			// Reset SPG
Delay(0.03);
WriteCOMPort(DUTCOM, ":FACT:V24C:COMM 21,'GX1380';");		// ref voltage from dac v74 for tcxo
Delay(0.03);
WriteCOMPort(DUTCOM, ":FACT:GENL:HPHZ 196290,196290;");	// HPH zero saved in NVRAM
Delay(0.03);
WriteCOMPort(DUTCOM, ":FACT:GENL:PHAS 0,0;");		// H-Phase saved in NVRAM
Delay(0.03);
WriteCOMPort(DUTCOM, ":FACT:GENL:UREF:DAC 1380;");			// ref for tcxo saved in NVRAM
Delay(0.03);

WriteCOMPort(DUTCOM, ":INP:GENL:SYST PALB;");				// PAL Burst
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Vent *");
Delay(2.0);
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, " *");

n = 0;
GenlockStatus = GetGenlockStatus();
  while ((GenlockStatus != DUT_LOCKED) & (n < 4)) {
	GenlockStatus = GetGenlockStatus();
 	Delay(1);
 	n++;
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, " *");
  }				



ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");

if (GenlockStatus != DUT_LOCKED){
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n   Genlock test FAILED\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return(FALSE);
}

SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n   Genlock test OK    -    forts�t med n�ste test\n");
SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);

return(TRUE);
 


/* 
// ---- test of ID-string in NVRAM ---------------------
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,"*IDN?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   IDN = ");
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, strread);
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 
 p = FindPattern (strread, 0, -1, "PTV", 1, 0);
 
 if (p != 0){
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   IDN = ");
 	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, strread);
 	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n");
   SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Fejl ved skrivning til NVRAM\n");
   }
  else{
   SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Skrivning til NVRAM er OK\n");
 	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "\n\n\n   Forts�t med n�ste test\n");
  } 
*/

}





//------------------------------------------------------------------------
int BBTest(int BBNo){
unsigned char gain,offset,level;	// data for calibration-dac
unsigned char bb;

SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, TRUE);
Fmt(txtstr,"Vejledning:  Black Burst %i",BBNo);
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,txtstr);
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
Fmt(txtstr,"   Forbind BB%i til oscilloscop og afslut i 75 ohm\n\n",BBNo);
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, txtstr);
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PC-COM port til RS232-stik X9\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Indstil oscilloscop:  200mV/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         10us/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         Input: DC-koblet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n\n");


WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }


if (WriteProtect(OFF,FALSE) == FALSE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 GenlockOk = FALSE;
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return FALSE;
 }


ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Check at der er et videosignal p� oscilloscopet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Signalet skal variere i: sync-amplitude\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                            burst-amplitude\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                            DC-level\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test OK:      Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test FAILED:  Tast F12\n\n");

Fmt(dutstr,":OUTP:BB%i:SYST PAL;",BBNo);	// select PAL
WriteCOMPort(DUTCOM, dutstr);

switch (BBNo){
 case 1: bb = 'H'; break;
 case 2: bb = 'J'; break;
 case 3: bb = 'K'; break;
} 

gain = offset = level = 0xFF;
n = 0;
Loop = TRUE;
while (Loop == TRUE){
 Delay(shifttime);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

 switch (n){
 	case 0 :gain ^= 0xFF; Fmt(dutstr,":FACT:V24C:COMM 52,'%cE%i';",bb,gain); break;
 	case 1 :offset ^= 0xFF; Fmt(dutstr,":FACT:V24C:COMM 52,'%cC%i';",bb,offset); break;
 	case 2 :level ^= 0xFF; Fmt(dutstr,":FACT:V24C:COMM 52,'%cD%i';",bb,level); break;
 }
 WriteCOMPort(DUTCOM, dutstr);

 Delay(shifttime);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

 switch (n){
 	case 0 :gain ^= 0xFF;  Fmt(dutstr,":FACT:V24C:COMM 52,'%cE%i';",bb,gain);break;
 	case 1 :offset ^= 0xFF;  Fmt(dutstr,":FACT:V24C:COMM 52,'%cC%i';",bb,offset);break;
 	case 2 :level ^= 0xFF;  Fmt(dutstr,":FACT:V24C:COMM 52,'%cD%i';",bb,level);
 			  n = -1; break;
 }
 WriteCOMPort(DUTCOM, dutstr);

n++;
}


ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
if (TestOk == TRUE)
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Black Burst OK   -    forts�t med n�ste test\n");
 else
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Black Burst FAILED\n");
 
 Fmt(dutstr,":FACT:BB%i:DAC %i,%i,%i;",BBNo,128,128,128);		// save in NVRAM
 WriteCOMPort(DUTCOM, dutstr);

SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);

return(TestOk);
}





//------------------------------------------------------------------------
int TSGTest(void){
unsigned char chroma,adjust;	// data for calibration-dac


SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, TRUE);
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Test Signal Generator");
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind TSG til oscilloscop og afslut i 75 ohm\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PC-COM port til RS232-stik X9\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Indstil oscilloscop:  200mV/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         10us/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         Input: DC-koblet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n\n");


WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }


if (WriteProtect(OFF,FALSE) == FALSE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 GenlockOk = FALSE;
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return FALSE;
 }


ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Check at der er et color bar videosignal p� oscilloscopet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Signalet skal variere i: amplitude\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                            DC-level\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test OK:      Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test FAILED:  Tast F12\n\n\n");

WriteCOMPort(DUTCOM, ":OUTP:TSG:SYST PAL;PATT CBEBU;");
WriteCOMPort(DUTCOM, ":OUTP:CBG:SYST PAL;PATT CBEBU;");

adjust = 0xFF;
chroma = 0x0F;
Loop = TRUE;
n = 0;
while (Loop == TRUE){
 switch (n){
 	case 0 :adjust ^= 0xFF; break;
 	case 1 :chroma ^= 0x0F; break;
 }
 Fmt(dutstr,":FACT:TSG:CGAIN %i,%i;",chroma, chroma);
 WriteCOMPort(DUTCOM, dutstr);
 Fmt(dutstr,":FACT:CBG:CGAIN %i,%i;",chroma, chroma);
 WriteCOMPort(DUTCOM, dutstr);
 Delay(shifttime);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

 switch (n){
 	case 0 :adjust ^= 0xFF; break;
 	case 1 :chroma ^= 0x0F; 
 			  n = -1; break;
 }
 Fmt(dutstr,":FACT:TSG:AGAIN %i,%i;",adjust, adjust);
 WriteCOMPort(DUTCOM, dutstr);
 Fmt(dutstr,":FACT:CBG:AGAIN %i,%i;",adjust, adjust);
 WriteCOMPort(DUTCOM, dutstr);
 Delay(shifttime);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

n++; 

}

 WriteCOMPort(DUTCOM, ":FACT:TSG:CGAIN 8,8;");		// save in NVRAM
 WriteCOMPort(DUTCOM, ":FACT:TSG:AGAIN 240,240;");
 WriteCOMPort(DUTCOM, ":FACT:CBG:CGAIN 8,8;");		// save in NVRAM
 WriteCOMPort(DUTCOM, ":FACT:CBG:AGAIN 240,240;");

ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
if (TestOk == TRUE)
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test Signal Generator OK   -    forts�t med n�ste test\n");
 else
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test Signal Generator FAILED\n");
 
SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
return(TestOk);

}




//------------------------------------------------------------------------
int AudioTest(void){

// ---- Analog audio --------------------------------------------
SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, TRUE);
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Analog Audio" );
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind Audio-L og Audio-R til oscilloscop\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PC-COM port til RS232-stik X9\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Indstil oscilloscop:  1V/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         200us/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         Input: DC-koblet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n\n");


WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }


if (WriteProtect(OFF,FALSE) == FALSE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 GenlockOk = FALSE;
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return FALSE;
 }


ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Check at der er 500Hz - 1kHz - 8kHz sinussignal p� oscilloscopet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Signalerne skal variere i: amplitude\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                              frekvens\n");

SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test OK:      Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test FAILED:  Tast F12\n\n\n");

WriteCOMPort(DUTCOM, ":OUTP:AUD:OUTP ANAL;");		// select analog audio
WriteCOMPort(DUTCOM, ":FACT:AUD:ALEV 180,180;");	// save in NVRAM

Loop = TRUE;
while (Loop == TRUE){
 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:SIGN S1KHZ;");
 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:LEVEL +6;");
 Delay(shifttime + 0.3);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:SIGN S500HZ;");
 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:LEVEL +4;");
 Delay(shifttime + 0.3);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:SIGN S8KHZ;");
 WriteCOMPort(DUTCOM, ":OUTP:AUD:ANAL:LEVEL -2;");
 Delay(shifttime + 0.3);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

}



// ---- Word clock output --------------------------------------------
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Word clock" );
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind WORD CLOCK til oscilloscop og afslut i 75 ohm\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forbind PC-COM port til RS232-stik X9\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Indstil oscilloscop:  0.5V/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         10us/div\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                         Input: DC-koblet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n\n");


WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
 return (FALSE);
 }

WriteCOMPort(DUTCOM, ":OUTP:AUD:OUTP AES;");		// select aes audio

ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Check at der er 48kHz eller 44.1kHz firkantsignal p� oscilloscopet\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Signalet skal skifte mellem de 2 frekvenser\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Amplituden skal v�re 2.5Vpp\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test OK:      Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Test FAILED:  Tast F12\n\n\n");


Loop = TRUE;
while (Loop == TRUE){
 WriteCOMPort(DUTCOM, ":OUTP:AUD:AES:WORD F48KHZ;");
 Delay(shifttime + 0.5);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 WriteCOMPort(DUTCOM, ":OUTP:AUD:AES:WORD F441KHZ;");
 Delay(shifttime + 0.5);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
}






ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
if (TestOk == TRUE)
 AudioOk = TRUE;
 else
 AudioOk = FALSE;

if (TestOk == TRUE)
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Audio OK\n");
 else
 SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Audio FAILED\n");

SetCtrlAttribute (mainPNL, MAIN_PNL_F1BTN, ATTR_DIMMED, FALSE);
return(AudioOk);
}
















/*
//----------------------------------------------------------------------------
int HP34970Test(void){
ViChar mm[20];
int no, xx;
ViInt16 ch;
float measvolt;


hp34970a_voltageMeasure (hp34970, "101", HP34970A_VM_VTYPE_DC,
								 HP34970A_VM_VRANGE_10V,
								 HP34970A_VM_RES_5_5DIG, mm);

ReadDCVolt("101", &measvolt);
ReadACVolt("101", &measvolt);
ReadACVolt("101", &measvolt);
ReadACVolt("101", &measvolt);
								 






  hp34970a_switch (hp34970, "212", HP34970A_SW_POS_CLOSE,HP34970A_SW_MODE_NORMAL);
  hp34970a_switch (hp34970, "211", HP34970A_SW_POS_CLOSE,HP34970A_SW_MODE_NORMAL);




return(TRUE);
}



int ReadDCVolt(char channel[10], float *result){
ViChar datastr[20];
int st;
// hp34970a_voltageMeasure must be executed once before using this function
hp34970a_voltageSetup (hp34970, channel, HP34970A_VS_VTYPE_DC,
							  HP34970A_VS_VRANGE_AUTO,
							  HP34970A_VS_RES_4_5DIG);
st = hp34970a_cmdString_Q (hp34970, "READ?", 20, datastr);
Scan(datastr,"%s>%f[b4]",result);

return (st);
}



int ReadACVolt(char channel[10], float *result){
ViChar datastr[20];
int st;
// hp34970a_voltageMeasure must be executed once before using this function
hp34970a_voltageSetup (hp34970, channel, HP34970A_VS_VTYPE_AC,
							  HP34970A_VS_VRANGE_10V, HP34970A_VS_RES_4_5DIG);
st = hp34970a_cmdString_Q (hp34970, "READ?", 20, datastr);
Scan(datastr,"%s>%f[b4]",result);

return (st);
}



*/
