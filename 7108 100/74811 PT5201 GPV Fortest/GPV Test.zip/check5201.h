extern int PowerTest(void);
extern int GenlockTest(void);
extern int BBTest(int BBNo);
extern int TSGTest(void);
extern int AudioTest(void);
extern int GenlockOk, PowerOk, BB1Ok, BB2Ok, BB3Ok, CBOk, AudioOk;
