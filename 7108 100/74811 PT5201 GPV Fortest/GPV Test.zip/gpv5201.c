/*
Testprogram til GPV for simpel test af PT5201: 
12NC: 7108 100 74811

Programmet kalder ved et tryk p� F1 et eksternt program til at loade software til f�lgende:
	Master-CPU'en (incl billed+lyd data for CB-generator og setup for PLD V8)
	BlackBurst Generator
	SPG

Derefter testes der f�lgende ved at taste F2 - F8:
 F2:   Power supply (sp�ndinger, str�mforbrug)
 F3:   Genlock
 F4-6: Black Burst 1,2 og 3 generatorer
 F7:   Color Bar generatoren
 F8:   Audio
 
 F9 er en totaltest som ikke er implementeret
 
 Billeder af Black Burst, Color Bar og Word Clock signal kan vises
 
 
Rettelser:
000717	Kommandoer til CBG rettet (AGAIN, CGAIN)

 
*/

#include <formatio.h>
#include <utility.h>
#include <ansi_c.h>
#include <rs232.h>
#include <userint.h>
#include "gpv5201.h"		// header file

#include "check5201.h"
#include "util5201.h"
#include "def.h"

#define TESTSWVER  "Test sw ver: 000801    7108 100 74811"

int main (int argc, char *argv[])
{
int xx;
	if ((mainPNL = LoadPanel (0, "gpv5201.uir", MAIN_PNL)) < 0)
		return -1;
	if ((bbpicturePNL = LoadPanel (0, "gpv5201.uir", BB_PNL)) < 0)
		return -1;
	if ((cbpicturePNL = LoadPanel (0, "gpv5201.uir", CB_PNL)) < 0)
		return -1;
	if ((wclkpicturePNL = LoadPanel (0, "gpv5201.uir", WCLK_PNL)) < 0)
		return -1;
		
	comerr = OpenComConfig (1, "com1", 9600, 0, 8, 2, 512, 512);
	if (comerr == 0)
	 DUTCOM = 1;
	 else{
	 DUTCOM = -1;
	 MessagePopup (" FEJL: Open COM Port ", "COM1 kunne ikke �bnes");
	 }
		
	SetCtrlVal (mainPNL, MAIN_PNL_TESTSW, TESTSWVER);
	
	ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Inden apparatet testes, skal alle MAX3000-serie PLD'erne loades\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   fra Altera softwaren MAX+plusII med ByteBlaster forbundet til\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   stik X4. Dette g�res kun en gang.\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   \n\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Hvis apparatet er nyt: start med F1: Power Check\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "                          og derefter F2: Upload\n\n");
	SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Gennemf�r derefter test fra F3 - F8\n");

	SetCtrlAttribute (mainPNL, MAIN_PNL_F9BTN, ATTR_VISIBLE, FALSE);
	SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTMSG9, ATTR_VISIBLE, FALSE);
	DisplayPanel (mainPNL);
	RunUserInterface ();
	return 0;
}


//****************************************************************************
int Upload (void){
int uploadfile, byteread;
char instr[100];
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Upload af software" );



DisableBreakOnLibraryErrors();
uploadfile = OpenFile ("upload.txt", VAL_READ_ONLY, VAL_OPEN_AS_IS,VAL_ASCII);
EnableBreakOnLibraryErrors();

if (uploadfile == -1){
 MessagePopup ("Fejl", "Filen 'upload.txt' ikke fundet");
 return FALSE;
}

byteread = 0;

while (byteread != -2){
 byteread = ReadLine (uploadfile, instr, -1);
 InsertTextBoxLine (mainPNL, MAIN_PNL_TEXTBOX, -1, instr);
}

CloseFile (uploadfile);


return TRUE;
}








//****************************************************************************
int NotOk_Upload (void){
int syserr;
 
SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:  Upload software til master CPU:");
ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   S�t jumper i PP2 (BOOT)\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Slut / t�nd for apparatet\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Vent til lysdioderne D28 og D31 blinker i takt\n\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Forts�t: Tast F11\n");
SetCtrlVal (mainPNL, MAIN_PNL_TEXTBOX, "   Stop:    Tast F12\n\n\n");

WaitForContinue();
if (Stop == TRUE){
 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");
 SetCtrlAttribute (mainPNL, MAIN_PNL_TEXTBOX, ATTR_LABEL_TEXT,"Vejledning:");
 return (FALSE);
 }

 CloseCom(DUTCOM);
 Delay(0.5);
 syserr = system ("pt5201loader.exe pt5201loader.ini");
 Delay(0.5);
 comerr = OpenComConfig (1, "com1", 9600, 0, 8, 2, 512, 512);

 ResetTextBox (mainPNL, MAIN_PNL_TEXTBOX, "\n");

if (syserr == 0)
  return TRUE;
 else
  return FALSE;
}



//****************************************************************************
void ShowPicture(void){
int pressed;

 GetCtrlVal (mainPNL, MAIN_PNL_BB_BTN, &pressed);
 if (pressed == TRUE)
   DisplayPanel(bbpicturePNL);
  else
   HidePanel(bbpicturePNL);

 GetCtrlVal (mainPNL, MAIN_PNL_CB_BTN, &pressed);
 if (pressed == TRUE)
   DisplayPanel(cbpicturePNL);
  else
   HidePanel(cbpicturePNL);

 GetCtrlVal (mainPNL, MAIN_PNL_WCLK_BTN, &pressed);
 if (pressed == TRUE)
   DisplayPanel(wclkpicturePNL);
  else
   HidePanel(wclkpicturePNL);



}




//*********** Callback ********************************************************
int CVICALLBACK FKeyCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			SetCtrlAttribute (mainPNL, MAIN_PNL_EXITBTN, ATTR_DIMMED, TRUE);

			switch (control){
			 case MAIN_PNL_F1BTN: PowerTest(); break;
			 case MAIN_PNL_F2BTN: Upload(); break;
			 case MAIN_PNL_F3BTN: GenlockTest(); break;
			 case MAIN_PNL_F4BTN: BBTest(1); break;
			 case MAIN_PNL_F5BTN: BBTest(2); break;
			 case MAIN_PNL_F6BTN: BBTest(3); break;
			 case MAIN_PNL_F7BTN: TSGTest(); break;
			 case MAIN_PNL_F8BTN: AudioTest(); break;
			 }
		
		 	SetCtrlAttribute (mainPNL, MAIN_PNL_EXITBTN, ATTR_DIMMED,FALSE);
			break;
	}
	return 0;
}


int CVICALLBACK COMMCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
int comst;		
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal (mainPNL, MAIN_PNL_COMPORT, &comst);
			if (comst == 1){
			 comerr = OpenComConfig (1, "com1", 9600, 0, 8, 2, 512, 512);
			 if (comerr == 0){
	 		  DUTCOM = 1;
	 		  CloseCom(2);
	 		 } 
	 		else{
			 DUTCOM = -1;
	 		 MessagePopup (" FEJL: Open COM Port ", "COM port kunne ikke �bnes");
	 		 }
	 		}
			else if (comst == 2){
			 comerr = OpenComConfig (2, "com2", 9600, 0, 8, 2, 512, 512);
			 if (comerr == 0){
	 		  DUTCOM = 2;
	 		  CloseCom(1);
	 		 } 
	 		else{
			 DUTCOM = -1;
	 		 MessagePopup (" FEJL: Open COM Port ", "COM port kunne ikke �bnes");
	 		 }
	 		}
	 		
		

			break;
	}
	return 0;
}


int CVICALLBACK ExitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			CloseCom(DUTCOM);
			 
			QuitUserInterface (0);
			break;
	}
	return 0;
}



int CVICALLBACK F11KeyCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			TestOk = TRUE;
			Cont = TRUE;
			Stop = FALSE;
			Loop = FALSE;
			break;
	}
	return 0;
}


int CVICALLBACK F12KeyCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			TestOk = FALSE;
			Cont = TRUE;
			Stop = TRUE;
			Loop = FALSE;
			break;
	}
	return 0;
}


int CVICALLBACK ShowPictureCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			ShowPicture();

			break;
	}
	return 0;
}
