/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2000. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  BB_PNL                          1
#define  BB_PNL_BBPICTURE                2

#define  CB_PNL                          2
#define  CB_PNL_CBPICTURE                2

#define  MAIN_PNL                        3
#define  MAIN_PNL_TEXTBOX                2
#define  MAIN_PNL_EXITBTN                3       /* callback function: ExitCallback */
#define  MAIN_PNL_F12BTN                 4       /* callback function: F12KeyCallback */
#define  MAIN_PNL_F11BTN                 5       /* callback function: F11KeyCallback */
#define  MAIN_PNL_F9BTN                  6       /* callback function: FKeyCallback */
#define  MAIN_PNL_F8BTN                  7       /* callback function: FKeyCallback */
#define  MAIN_PNL_F7BTN                  8       /* callback function: FKeyCallback */
#define  MAIN_PNL_F6BTN                  9       /* callback function: FKeyCallback */
#define  MAIN_PNL_F5BTN                  10      /* callback function: FKeyCallback */
#define  MAIN_PNL_F4BTN                  11      /* callback function: FKeyCallback */
#define  MAIN_PNL_F3BTN                  12      /* callback function: FKeyCallback */
#define  MAIN_PNL_F2BTN                  13      /* callback function: FKeyCallback */
#define  MAIN_PNL_F1BTN                  14      /* callback function: FKeyCallback */
#define  MAIN_PNL_COMPORT                15      /* callback function: COMMCallback */
#define  MAIN_PNL_WCLK_BTN               16      /* callback function: ShowPictureCallback */
#define  MAIN_PNL_CB_BTN                 17      /* callback function: ShowPictureCallback */
#define  MAIN_PNL_BB_BTN                 18      /* callback function: ShowPictureCallback */
#define  MAIN_PNL_TEXTMSG3               19
#define  MAIN_PNL_TEXTMSG4               20
#define  MAIN_PNL_TEXTMSG5               21
#define  MAIN_PNL_TEXTMSG6               22
#define  MAIN_PNL_TEXTMSG8               23
#define  MAIN_PNL_TEXTMSG9               24
#define  MAIN_PNL_TESTSW                 25
#define  MAIN_PNL_TEXTMSG2               26
#define  MAIN_PNL_TEXTMSG1               27
#define  MAIN_PNL_TEXTMSG7               28

#define  WCLK_PNL                        4
#define  WCLK_PNL_WCLKPICTURE            2


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK COMMCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ExitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK F11KeyCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK F12KeyCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FKeyCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ShowPictureCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
