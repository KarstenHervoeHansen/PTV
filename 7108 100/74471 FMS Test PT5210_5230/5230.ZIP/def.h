#define IEEEBUS 1		//IEEE interface 
#define AT232 1			//RS232 interface (com5,6,7)


#define YES    1
#define NO     0
#define TRUE   1
#define FALSE  0
#define LF    10
#define CR    13
#define WAIT   1
#define NOWAIT 0
#define ON     1
#define OFF    0

#define SPGNOTRESET 2

#define LOCALLOG    0		  // log cal data on C-drive
#define LANLOG      1		  // log cal data on LAN (M-drive)
						      // see 'LogDestination'
						
#define VITSEXTDATA  0		  // VITS control PM5640
#define VITSPASS     1

#define PM5640GIEEEADDR 16	  // IEEE addr for PM5640
#define PM5640MIEEEADDR 17

#define REARTERM34401    0	  // HP34401 multimeter
#define FRONTTERM34401   1

#define PAL    0
#define NTSC   1

#define L625 625
#define L525 525

#define ALLUNITS	0	   // apparat config
#define MAIN 		1
#define AUDIOGEN 	2
#define SDIGENLOCK 	3
#define BLACKBURST  4
#define SDIBLACK 	5
#define SDITSG 		6
#define MULTIBB	 	7
#define SPG 		8
#define ANLTSG 		9
#define LTC		   10

#define GENL_PAL		0  // genlock mux styring
#define GENL_NTSC		1
#define GENL_443_HIGH	2
#define GENL_443_LOW	3
#define GENL_358_HIGH	4
#define GENL_358_LOW	5
#define GENL_10M_HIGH	6
#define GENL_10M_LOW	7
#define GENL_OFF       10

#define DUT_LOCKED 0x02	   // genlock status register i SPG
#define DUT_INTERN 0x04

#define SYNC_DAC     0	   // level og offset kalibrering
#define OFFSET_DAC   1
#define SYNC_CAL     0
#define OFFSET_CAL   1

#define PT5210 5210
#define PT5230 5230

#define PT8605 8605
#define PT8635 8635

#define ANLTPG2_8601  9	   // options
#define ANLTPG2_8631 11
#define ANLTPG5_8631 12
#define SDIBLACK34   34
#define SDIBLACK56   56
#define SDIBLACK78   78
#define SDITPG1       1
#define SDITPG2	      2
#define SDITPG5	      5
#define SDITSG2	     22
#define SDITSG3	     23
#define SDITSG4	     24

#define XA1_Stik      1	   // stikforbindelser for TPG'er i PT5230
#define XB1_Stik      2
