/*
Main file for PT5210/5230 testprogram
File: pt5230.c

961115 Peter Frederiksen, PTV


971211    PT8601 900 serie tilf�jet
971215    logfil �ndret til LAN S-drev
980707    PT8635 test tilf�jet
980723	  Check ved indtastning af KU-numre (min/max gr�nser for KU-nummer)
980803	  Kontrol af TP01 sp�nding efter 27MHz justering
980917    PT8637 test tilf�jet
981007    Check af TrueTime GPS modtager tilf�jet
990301    SDI-generatorer: check af CRC ved EDH-test indf�rt
990527    KU-nummer i SPG-EEPROM: se spgcal.c
990615    Pattern test af 900 numre af PT8602/8603 indf�rt  -  se sditest.c
991012    Check af at apparat og testprogram passer sammen
*/



#include "hp34401a.h"
#include "hp5313xa.h"
#include <ansi_c.h>
#include <gpib.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include <cvirte.h>		/* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>

// header files for uir files
#include "pt5230.h"
#include "bb_sync.h"
#include "phase.h"
#include "sdi.h"
#include "vlm.h"
#include "cfg.h"
#include "spghph.h"
#include "spggenl.h"
#include "spgphase.h"
#include "aes.h"
#include "vcc.h"
#include "fan.h"
#include "ltc.h"
#include "filter.h"


// general utilities
#include "cviutil.h"
#include "def.h"		// define statements

// calibration utilities
#include "vlmutil.h"
#include "bbcal.h"
#include "spgcal.h"
#include "sditest.h"
#include "aescal.h"
#include "ltctest.h"
#include "config.h"
#include "clktest.h"




#define TESTSWVER  "Ver. 001011        7108 100 74471"



int main (int argc, char *argv[])
{
int ConfirmReply;
ViInt16 InputTermHP34401;
int sm,sg;
char ff[MAX_FILENAME_LEN];
int button_pressed;
int vcaOk;



if (argc > 1){
 if ((strcmp(argv[1],"5230") == 0) || (strcmp(argv[1],"PT5230") == 0))
   AppType = PT5230;
  else
   AppType = PT5210;
} //if 



#if IEEEBUS
    IEEEboard = ibfind ("gpib0");
	devicePM5640G = ibdev (0, PM5640GIEEEADDR, NO_SAD, T3s, 1, 0);
	sg = iberr;
	devicePM5640M = ibdev (0, PM5640MIEEEADDR, NO_SAD, T3s, 1, 0);
	sm = iberr;
#endif
	

	if (InitCVIRTE (0, argv, 0) == 0)	/* Needed if linking in external compiler; harmless otherwise */
		return -1;	/* out of memory */
	if ((mainPNL = LoadPanel (0, "pt5230.uir", MAIN_PNL)) < 0)
	 	 return -1;
	if ((syncPNL = LoadPanel (mainPNL, "bb_sync.uir", SYNC_PNL)) < 0)
		return -1;
	if ((vlmPNL = LoadPanel (mainPNL, "vlm.uir", VLM_PNL)) < 0)
		return -1;
	if ((spghphPNL = LoadPanel (mainPNL, "spghph.uir", SPGHPH_PNL)) < 0)
		return -1;
	if ((spggenlPNL = LoadPanel (mainPNL, "spggenl.uir", SPGGEN_PNL)) < 0)
		return -1;
	if ((selgenlPNL = LoadPanel (0, "spggenl.uir", SELGEN_PNL)) < 0)
		return -1;
	if ((phasePNL = LoadPanel (mainPNL, "phase.uir", SCH_PNL)) < 0)
		return -1;
	if ((parbbPNL = LoadPanel (mainPNL, "phase.uir", PARBB_PNL)) < 0)
		return -1;
	if ((spgphasePNL = LoadPanel (mainPNL, "spgphase.uir", SPGPHA_PNL)) < 0)
		return -1;
	if ((aesPNL = LoadPanel (mainPNL, "aes.uir", AES_PNL)) < 0)
		return -1;
	if ((amspPNL = LoadPanel (mainPNL, "sdi.uir", AMSP_PNL)) < 0)
		return -1;
	if ((jitPNL = LoadPanel (mainPNL, "sdi.uir", JIT_PNL)) < 0)
		return -1;
	if ((rlossPNL = LoadPanel (mainPNL, "sdi.uir", RLOSS_PNL)) < 0)
		return -1;
	if ((sdigenlPNL = LoadPanel (mainPNL, "sdi.uir", SDIGEN_PNL)) < 0)
		return -1;
	if ((sdiPNL = LoadPanel (mainPNL, "sdi.uir", SDI_PNL)) < 0)
		return -1;
	if ((pattPNL = LoadPanel (mainPNL, "sdi.uir", PATT_PNL)) < 0)
		return -1;
	if ((configPNL = LoadPanel (mainPNL, "cfg.uir", CONFIG)) < 0)  // config panel
		return -1;
	if ((instrPNL = LoadPanel (mainPNL, "cfg.uir", INSTR_PNL)) < 0)
		return -1;
	if ((vccPNL = LoadPanel (mainPNL, "vcc.uir", VCC_PNL)) < 0)
		return -1;
	if ((fanPNL = LoadPanel (mainPNL, "fan.uir", FAN_PNL)) < 0)
		return -1;
	if ((ocxoPNL = LoadPanel (mainPNL, "ocxo.uir", FAN_PNL)) < 0)
		return -1;
	if ((ltcPNL = LoadPanel (mainPNL, "ltc.uir", LTC_PNL)) < 0)
		return -1;
	if ((clockPNL = LoadPanel (mainPNL, "ltc.uir", CLK_PNL)) < 0)
		return -1;
	if ((filterPNL = LoadPanel (mainPNL, "filter.uir", FILT_PNL)) < 0)
		return -1;
	if ((showfiltjustPNL = LoadPanel (filterPNL, "filter.uir", FLTJUS_PNL)) < 0)
		return -1;
		
 mainmenuhandle = LoadMenuBar (mainPNL, "pt5230.uir", MAINMENU);
 
 SetCtrlAttribute (phasePNL, SCH_PNL_COMM, ATTR_VISIBLE, TRUE);    // =TRUE ved debug phase kalibrering
																   // BB & Analog TPG

 SetCtrlVal (mainPNL, MAIN_PNL_SWVER, TESTSWVER);				   // Test SW rev
 
 // GPS receiver
 SetCtrlAttribute (mainPNL, MAIN_PNL_GPS_TIMER, ATTR_INTERVAL, 50.0); // Timer interval
 CheckXLDCRef();
 GPSCheckNo = 0;

 SetMenuItems(MAINMENU);	 								// set menu items = dimmed / not dimmed
 
  
 // Init PC DIO24 interface ----------------------
 outp(IOAddr+3,0x80);	   //set mode 
 outp(IOAddr+0,0xFF);	   //port A 
 outp(IOAddr+1,0xFF);	   //port B 
 outp(IOAddr+2,0xFF);	   //port C 
 
 // Init Video Level Meter ----------------------------
 vlm_StartLine = 100;
 vlm_NoOfLines = 100;
 vlm_StartPos = 31.0;
 vlm_Delay = 2.0;
 
 // Remote Control PM5662G/M   (PC DIO24) --------
 PM5662Status = 0xFF;
 

 Err232 = OpenComConfig (DUTCOM, COMname[DUTCOM-1], 9600, 0, 8, 2, 500, 500);

#if AT232
 if (OpenComConfig (VCACOM, COMname[VCACOM-1], 19200, 0, 8, 2, 5000, 500) != 0){
	MessagePopup (" Kan ikke �bne COM5 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }

 if (OpenComConfig (PT5210COM, COMname[PT5210COM-1], 9600, 0, 8, 2, 500, 500) != 0){
	MessagePopup (" Kan ikke �bne COM6 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }
 
 if (OpenComConfig (PM3094COM, COMname[PM3094COM-1], 9600, 0, 8, 2, 500, 500) != 0){
	MessagePopup (" Kan ikke �bne COM7 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }
#endif

 
 DisplayPanel (mainPNL);

 if (ReadVLMGain() == FALSE)		// file = VLMGAIN.DAT
  return FALSE;

 if (ReadTestSetup() == FALSE)		// file = TSTSETUP.DAT
  return FALSE;

 

 if (GPSStatusOk == FALSE)
  MessagePopup(" TrueTime GPS modtager fejler"," HP53132 m� IKKE anvendes til 27 MHz kalibrering !!\n Kontakt evt instrument service");
 
 
 //Check if connected to LAN
  LogDest = LANLOG;
  if (GetFirstFile ("M:\\MEASDATA", 1, 0, 0, 0, 0, 1, ff) != 0){
	button_pressed = GenericMessagePopup (" Ingen forbindelse til LAN  (M-drev)",
										  " Genstart Windows og husk at logge p� LAN med navn = 'PROD_5210'",
										  "Afbryd og genstart Windows","Log til lokal harddisk","", 0, -1, 0,
										  VAL_GENERIC_POPUP_BTN1,
										  VAL_GENERIC_POPUP_BTN1,
										  VAL_GENERIC_POPUP_BTN2);

   if (button_pressed == 1)
    return FALSE;
   if (button_pressed == 2){
    LogDest = LOCALLOG;
    MessagePopup(" Kalibreringsdata"," Kalibreringsdata logges til C-drev\n Husk at overf�re data til logfil i 'M:\\MEASDATA\\.....' n�r LAN igen er ok");
   } 
  } 


 

 // Check IEEE connection to DVM and Counter
 DisableBreakOnLibraryErrors();
 DevClear (0, 22);
 Delay(0.2);
#if IEEEBUS
 ErrIEEE = hp34401a_init ("GPIB::22", VI_OFF, VI_ON, &hp34401);
	if (ErrIEEE) {
	 MessagePopup (" IEEE fejl  (adresse 22)", "Ingen kontakt med multimeter HP34401\n\nCheck: IEEE-kabel\n            at instrumentet er t�ndt");
	 return FALSE;
	}
 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 10, 1);


 DevClear (0, 3);
 Delay(0.2);
 ErrIEEE = hp5313xa_init ("GPIB::3", VI_OFF, VI_ON, 2, &hp53132);
 
	if (ErrIEEE) {
	 MessagePopup (" IEEE fejl  (adresse 3)", "Ingen kontakt med counter HP53132\n\nCheck: IEEE-kabel\n            at instrumentet er t�ndt");
	 return FALSE;
	}

 EnableBreakOnLibraryErrors();


 CheckHP53132ExtRef();
#endif

 
 SetGenlockSignal(GENL_OFF);
	
 if (Set5640Standard("G") != 0)
  return;
 if (Set5640Standard("M") != 0)
  return;
	
 Set5640Vits(VITSPASS);

	
 RunUserInterface ();
 return 0;
}



void CVICALLBACK BBCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
int BBNo;		
	switch (menuItem) {
	 case MAINMENU_BB_BB1_TOTAL: BBNo = 1; break;
	 case MAINMENU_BB_BB3_TOTAL: BBNo = 3; break;
	 case MAINMENU_BB_BB5_TOTAL: BBNo = 5; break;
	 case MAINMENU_BB_BB7_TOTAL: BBNo = 7; break;
	}
	if (menuItem != MAINMENU_BB_PARBB)	
	 if (MakeSyncOffsetCal(BBNo,SYNC_CAL,FALSE) == TRUE)	   // 1,3,5,7 BB
	  if (MakeSyncOffsetCal(BBNo,OFFSET_CAL,FALSE) == TRUE)
	   if (MakePhaseCal(BBNo,PAL) == TRUE)
	    if (MakePhaseCal(BBNo,NTSC) == TRUE)
	 if (MakeSyncOffsetCal(BBNo+1,SYNC_CAL,FALSE) == TRUE)   // 2,4,6,8 BB
	  if (MakeSyncOffsetCal(BBNo+1,OFFSET_CAL,FALSE) == TRUE)
	   if (MakePhaseCal(BBNo+1,PAL) == TRUE)
	    MakePhaseCal(BBNo+1,NTSC);
	    
	if (menuItem == MAINMENU_BB_PARBB)	
	 TestParBB();
		
}




void CVICALLBACK SDITestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
//  1   = TPG1  PT8602/03		
//  2   = TPG2  PT8632/33		
//  5   = TPG5  PT8632/33		
int menuSel;													  
	switch (menuItem) {

		case MAINMENU_SDI_BLK34_CAL : if (SDICal(L625,34,FALSE) == TRUE)
										 SDICal(L525,34,FALSE); break;
		case MAINMENU_SDI_BLK56_CAL : if (SDICal(L625,56,FALSE) == TRUE)
										 SDICal(L525,56,FALSE); break;
		case MAINMENU_SDI_BLK78_CAL : if (SDICal(L625,78,FALSE) == TRUE)
										 SDICal(L525,78,FALSE); break;
		
		case MAINMENU_SDI_TSG2_CAL :   if (SDICal(L625,22,FALSE) == TRUE)		 // TSG2 PT8639
										 SDICal(L525,22,FALSE); break;
		case MAINMENU_SDI_TSG3_CAL :   if (SDICal(L625,23,FALSE) == TRUE)		 // TSG3 PT8639
										 SDICal(L525,23,FALSE); break;
		case MAINMENU_SDI_TSG4_CAL :   if (SDICal(L625,24,FALSE) == TRUE)		 // TSG4 PT8639
										 SDICal(L525,24,FALSE); break;

		case MAINMENU_SDI_TPG102_CAL :if (SDICal(L625,1,FALSE) == TRUE)		 // TPG1 PT8602/03
										  SDICal(L525,1,FALSE); break;
		case MAINMENU_SDI_TPG132_CAL :if (SDICal(L625,1,FALSE) == TRUE)		 // TPG1 PT8632
										  SDICal(L525,1,FALSE); break;
		case MAINMENU_SDI_TPG2_CAL :   if (SDICal(L625,2,TRUE) == TRUE)			 // TPG2 PT8632/33
										 SDICal(L525,2,FALSE); break;
		case MAINMENU_SDI_TPG5_CAL :   if (SDICal(L625,5,TRUE) == TRUE)			 // TPG5 PT8632/33
										 SDICal(L525,5,FALSE); break;
										 
		case MAINMENU_SDI_BLK34_PATT:    CheckSDIPattern(34,FALSE); break;
		case MAINMENU_SDI_BLK56_PATT:    CheckSDIPattern(56,FALSE); break;
		case MAINMENU_SDI_BLK78_PATT:    CheckSDIPattern(78,FALSE); break;
		case MAINMENU_SDI_TPG102_PATT:   CheckSDIPattern(1,FALSE); break;		 // TPG1 PT8602/03
		case MAINMENU_SDI_TPG132_PATT:   CheckSDIPattern(1,FALSE); break;		 // TPG1 PT8632
		case MAINMENU_SDI_TPG2_PATT:     CheckSDIPattern(2,FALSE); break;		 // TPG2 PT8602/03
		case MAINMENU_SDI_TPG5_PATT:     CheckSDIPattern(5,FALSE); break;		 // TPG5 PT8602/03
		case MAINMENU_SDI_TSG2_PATT:     CheckSDIPattern(22,FALSE); break;		 // TSG2 PT8639
		case MAINMENU_SDI_TSG3_PATT:     CheckSDIPattern(23,FALSE); break;		 // TSG3 PT8639
		case MAINMENU_SDI_TSG4_PATT:     CheckSDIPattern(24,FALSE); break;		 // TSG4 PT8639
		
		
		case MAINMENU_SDI_BLK34_JITAMSP: if (SDIJitterTest(34,FALSE) == TRUE)
										  SDIAmplSpecTest(34,FALSE);break;
		case MAINMENU_SDI_BLK56_JITAMSP: if (SDIJitterTest(56,FALSE) == TRUE)
										  SDIAmplSpecTest(56,FALSE);break;
		case MAINMENU_SDI_BLK78_JITAMSP: if (SDIJitterTest(78,FALSE) == TRUE)
										  SDIAmplSpecTest(78,FALSE);break;
		case MAINMENU_SDI_TPG102_JITAMSP:if (SDIJitterTest(1,FALSE) == TRUE)		 // TPG1 PT8602/03
										  SDIAmplSpecTest(1,FALSE);break;
		case MAINMENU_SDI_TPG132_JITAMSP:if (SDIJitterTest(1,FALSE) == TRUE)		 // TPG1 PT8632
										  SDIAmplSpecTest(1,FALSE);break;
		case MAINMENU_SDI_TPG2_JITAMSP: if (SDIJitterTest(2,FALSE) == TRUE)		 // TPG2 PT8632/33
										  SDIAmplSpecTest(2,FALSE);break;
		case MAINMENU_SDI_TPG5_JITAMSP: if (SDIJitterTest(5,FALSE) == TRUE)		 // TPG5 PT8632/33
										  SDIAmplSpecTest(5,FALSE);break;
		case MAINMENU_SDI_TSG2_JITAMSP: if (SDIJitterTest(22,FALSE) == TRUE)		 // TSG2 PT8639
										  SDIAmplSpecTest(22,FALSE);break;
		case MAINMENU_SDI_TSG3_JITAMSP: if (SDIJitterTest(23,FALSE) == TRUE)		 // TSG3 PT8639
										  SDIAmplSpecTest(23,FALSE);break;
		case MAINMENU_SDI_TSG4_JITAMSP: if (SDIJitterTest(24,FALSE) == TRUE)		 // TSG4 PT8639
										  SDIAmplSpecTest(24,FALSE);break;
										  
		case MAINMENU_SDI_BLK34_RLOSS:  SDIReturnLossTest(34,FALSE); break;
		case MAINMENU_SDI_BLK56_RLOSS:  SDIReturnLossTest(56,FALSE); break;
		case MAINMENU_SDI_BLK78_RLOSS:  SDIReturnLossTest(78,FALSE); break;
		case MAINMENU_SDI_TPG102_RLOSS: SDIReturnLossTest(1,FALSE); break;		  // TPG1 PT8602/03
		case MAINMENU_SDI_TPG132_RLOSS: SDIReturnLossTest(1,FALSE); break;		  // TPG1 PT8632
		case MAINMENU_SDI_TPG2_RLOSS:   SDIReturnLossTest(2,FALSE); break;		  // TPG2 PT8632/33
		case MAINMENU_SDI_TPG5_RLOSS:   SDIReturnLossTest(5,FALSE); break;		  // TPG5 PT8632/33
		case MAINMENU_SDI_TSG2_RLOSS:   SDIReturnLossTest(22,FALSE); break;		  // TSG2 PT8639
		case MAINMENU_SDI_TSG3_RLOSS:   SDIReturnLossTest(23,FALSE); break;		  // TSG3 PT8639
		case MAINMENU_SDI_TSG4_RLOSS:   SDIReturnLossTest(24,FALSE); break;		  // TSG4 PT8639

		case MAINMENU_SDI_BLK34_EMBAUDIO  : CheckSDIEmbAudio_EDH(34,FALSE); break;
		case MAINMENU_SDI_BLK56_EMBAUDIO  : CheckSDIEmbAudio_EDH(56,FALSE); break;
		case MAINMENU_SDI_BLK78_EMBAUDIO  : CheckSDIEmbAudio_EDH(78,FALSE); break;
		case MAINMENU_SDI_TPG102_EMBAUDIO : CheckSDIEmbAudio_EDH(1,TRUE); break;   // PT8602/03
		case MAINMENU_SDI_TPG132_EMBAUDIO : CheckSDIEmbAudio_EDH(1,TRUE); break;   // PT8632
		case MAINMENU_SDI_TPG2_EMBAUDIO   : CheckSDIEmbAudio_EDH(2,TRUE); break;   // PT8632/33
		case MAINMENU_SDI_TPG5_EMBAUDIO   : CheckSDIEmbAudio_EDH(5,TRUE); break;   // PT8632/33
		case MAINMENU_SDI_TSG2_EMBAUDIO   : CheckSDIEmbAudio_EDH(22,FALSE); break;  // PT8639
		case MAINMENU_SDI_TSG3_EMBAUDIO   : CheckSDIEmbAudio_EDH(23,FALSE); break;  // PT8639
		case MAINMENU_SDI_TSG4_EMBAUDIO   : CheckSDIEmbAudio_EDH(24,FALSE); break;  // PT8639
		
		case MAINMENU_SDI_GENL:		   		SDIGenlockTest(); break;
		case MAINMENU_SDI_RESETSDI_TPG102:	ResetSDI(SDITPG1); break;		// PT8602/03   se sditest.c
		case MAINMENU_SDI_RESETSDI_TPG132:	ResetSDI(SDITPG1); break;		// PT8632
		case MAINMENU_SDI_RESETSDI_TPG2:	ResetSDI(SDITPG2); break;		// PT8633
		case MAINMENU_SDI_RESETSDI_TPG5:	ResetSDI(SDITPG5); break;		// PT8633


		// SDI 900 serier monteret som SDI-TPG1 = PT8602/03
		case MAINMENU_SDI_TSG900_CAL625 : SDI900Cal(L625,1,FALSE); break;
		case MAINMENU_SDI_TSG900_CAL525 : SDI900Cal(L525,1,FALSE); break;
	}
}




// menu on mainPNL
void CVICALLBACK SPGTestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem) {
		case MAINMENU_SPG_HPHGENL:		if (MakeSPGHPHCal() == TRUE)
										 if (MakeSPGGenlockCal(PAL) == TRUE)
										  MakeSPGGenlockCal(NTSC); break;
		case MAINMENU_SPG_TESTGENLOCK: 	if (MakeSPGGenlockInput() == TRUE)
										 MakeSPGGenlockSystem(); break;
		case MAINMENU_SPG_CHECKOVEN:	CheckOven(); break;			// se spgcal.c
		case MAINMENU_SPG_INT27REF: 	MakeOCXOCal(27); break;	   
		case MAINMENU_SPG_INT10REF: 	MakeOCXOCal(10); break;
		case MAINMENU_SPG_RESETSPG: 	MakeSPGReset(); break;
	}	
}


// menu on mainPNL
void CVICALLBACK AudioTestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem) {
		case MAINMENU_AUDIOGEN_8605:      TestAudioGen(PT8605,1);  break;
		case MAINMENU_AUDIOGEN_8635_AES1: TestAudioGen(PT8635,1);  break;
		case MAINMENU_AUDIOGEN_8635_AES2: TestAudioGen(PT8635,2);  break;
		case MAINMENU_AUDIOGEN_8635_WC1:  TestWordClockOutputs(1);  break;
		case MAINMENU_AUDIOGEN_8635_WC2:  TestWordClockOutputs(2);  break;
		case MAINMENU_AUDIOGEN_8635_MODE5210:  TestAudioGen5210Mode(); break;
		
	}
}


// menu on mainPNL
void CVICALLBACK DiverseCallBack (int menuBar, int menuItem, void *callbackData,
	int panel) {
		
	switch (menuItem){
		case MAINMENU_DIVERSE_VLM : RunVLMMeasurement();break;
		case MAINMENU_DIVERSE_SDIRL : SDIReturnLossMeasurement();break;
		case MAINMENU_DIVERSE_CALDATA : ReadCalData(); break;     	// se config.c
		case MAINMENU_DIVERSE_CALFILES : ShowCalFiles(); break;
		case MAINMENU_DIVERSE_SETUP5211 : SetupPT5211(); break;   	// se sditest.c
		case MAINMENU_DIVERSE_POWERJUST : CalPowerSupply(); break;	// se bbcal.c
		case MAINMENU_DIVERSE_FAN: CheckFan();break;
		case MAINMENU_DIVERSE_WPON: WriteProtect(ON,TRUE); break;
		case MAINMENU_DIVERSE_WPOFF: WriteProtect(OFF,TRUE); break;
		case MAINMENU_DIVERSE_PM5640SCH: ReadPM5640ScHCalData(); break;
		case MAINMENU_DIVERSE_INSTR: ShowInstrumentSetup(); break;	  //se cviutil.c
		case MAINMENU_DIVERSE_SELGENLSIGNAL: DisplayPanel(selgenlPNL); break; // se spgcal.c + spggenl.uir
		case MAINMENU_DIVERSE_EXITPROGRAM:  CloseCom(DUTCOM);
											#if AT232
											CloseCom(VCACOM);
											CloseCom(PM3094COM);
											CloseCom(PT5210COM);
											#endif	
											#if IEEEBUS
											hp34401a_close (hp34401);
											hp5313xa_close (hp53132);
											#endif	
											QuitUserInterface (0);
											break;
	}
}


// menu on mainPNL
void CVICALLBACK LTCCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {

		switch (menuItem){
		 case MAINMENU_LTC: LTC_TotalTest(); break;			 // see ltctest.c

		}
}


// menu on mainPNL
void CVICALLBACK TimeClockCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {

		switch (menuItem){
		 case MAINMENU_CLOCK_VITC:   if (Clock_VITCTest(PAL) == TRUE)  // see clktest.c
									   Clock_VITCTest(NTSC); break;
		 case MAINMENU_CLOCK_LTC:    if (Clock_LTCTest(PAL) == TRUE)
									   Clock_LTCTest(NTSC); break;
		 case MAINMENU_CLOCK_REF1HZ:  Clock_1HzTest(FALSE); break;
		 case MAINMENU_CLOCK_BATTERY: CheckRAMBatteryStatus (1); break;
		}
}




// menu on totPNL
void CVICALLBACK TotCallBack (int menuBar, int menuItem, void *callbackData,
	int panel) {
	Cont = TRUE;
	switch (menuItem){
		 case TOTMENU_BASIC_RESETSPG:
		 case TOTMENU_BASIC_PS:
		 case TOTMENU_BASIC_FAN:
		 case TOTMENU_BASIC_OVEN:
		 case TOTMENU_BASIC_F27:
		 case TOTMENU_BASIC_GENL:
		 case TOTMENU_BASIC_SPG:
		 case TOTMENU_BASIC_BB1:
		 case TOTMENU_BASIC_BB2:
		 						BasicTotalTest(menuItem); break;   // se spgcal.c
		 						
		 
		 case TOTMENU_ANL_TPG2_8601_NCO:     AnalogTPGTotalTest(ANLTPG2_8601,1); break;  // se bbcal.c
		 case TOTMENU_ANL_TPG2_8601_LEVEL:   AnalogTPGTotalTest(ANLTPG2_8601,2); break;
		 case TOTMENU_ANL_TPG2_8601_FILTER:  AnalogTPGTotalTest(ANLTPG2_8601,3); break;
		 case TOTMENU_ANL_TPG2_8601_PHASE:   AnalogTPGTotalTest(ANLTPG2_8601,4); break;
		 case TOTMENU_ANL_TPG2_8601_PATTERN: AnalogTPGTotalTest(ANLTPG2_8601,5); break;

		 case TOTMENU_ANL_TPG2_8631_NCO:     AnalogTPGTotalTest(ANLTPG2_8631,1); break;  // se bbcal.c
		 case TOTMENU_ANL_TPG2_8631_LEVEL:   AnalogTPGTotalTest(ANLTPG2_8631,2); break;
		 case TOTMENU_ANL_TPG2_8631_FILTER:  AnalogTPGTotalTest(ANLTPG2_8631,3); break;
		 case TOTMENU_ANL_TPG2_8631_PHASE:   AnalogTPGTotalTest(ANLTPG2_8631,4); break;
		 case TOTMENU_ANL_TPG2_8631_PATTERN: AnalogTPGTotalTest(ANLTPG2_8631,5); break;
                                
		 case TOTMENU_ANL_TPG5_8631_NCO:     AnalogTPGTotalTest(ANLTPG5_8631,1); break;  // se bbcal.c
		 case TOTMENU_ANL_TPG5_8631_LEVEL:   AnalogTPGTotalTest(ANLTPG5_8631,2); break;
		 case TOTMENU_ANL_TPG5_8631_FILTER:  AnalogTPGTotalTest(ANLTPG5_8631,3); break;
		 case TOTMENU_ANL_TPG5_8631_PHASE:   AnalogTPGTotalTest(ANLTPG5_8631,4); break;
		 case TOTMENU_ANL_TPG5_8631_PATTERN: AnalogTPGTotalTest(ANLTPG5_8631,5); break;
                                
		 						
		 						
		 case TOTMENU_SDI_BLK34_TIMING:    SDITotalTest(SDIBLACK34,1); break;		// SDI Black#34
		 case TOTMENU_SDI_BLK34_JITAMSP:   SDITotalTest(SDIBLACK34,2); break;
		 case TOTMENU_SDI_BLK34_RLOSS:     SDITotalTest(SDIBLACK34,3); break;
		 case TOTMENU_SDI_BLK34_EMBAUDEDH: SDITotalTest(SDIBLACK34,4); break;
		 case TOTMENU_SDI_BLK34_PATT:      SDITotalTest(SDIBLACK34,5); break;

		 case TOTMENU_SDI_BLK56_TIMING:     SDITotalTest(SDIBLACK56,1); break;		// SDI Black#56
		 case TOTMENU_SDI_BLK56_JITAMSP:    SDITotalTest(SDIBLACK56,2); break;
		 case TOTMENU_SDI_BLK56_RLOSS:      SDITotalTest(SDIBLACK56,3); break;
		 case TOTMENU_SDI_BLK56_EMBAUDEDH:  SDITotalTest(SDIBLACK56,4); break;
		 case TOTMENU_SDI_BLK56_PATT:       SDITotalTest(SDIBLACK56,5); break;
		 
		 case TOTMENU_SDI_BLK78_TIMING:     SDITotalTest(SDIBLACK78,1); break;		// SDI Black#78
		 case TOTMENU_SDI_BLK78_JITAMSP:    SDITotalTest(SDIBLACK78,2); break;
		 case TOTMENU_SDI_BLK78_RLOSS:      SDITotalTest(SDIBLACK78,3); break;
		 case TOTMENU_SDI_BLK78_EMBAUDEDH:  SDITotalTest(SDIBLACK78,4); break;
		 case TOTMENU_SDI_BLK78_PATT:       SDITotalTest(SDIBLACK78,5); break;
		 
		 case TOTMENU_SDI_TSG2_TIMING:      SDITotalTest(SDITSG2,1); break;      //  PT8639
		 case TOTMENU_SDI_TSG2_JITAMSP:     SDITotalTest(SDITSG2,2); break;
		 case TOTMENU_SDI_TSG2_RLOSS:       SDITotalTest(SDITSG2,3); break;
		 case TOTMENU_SDI_TSG2_EMBAUDEDH:   SDITotalTest(SDITSG2,4); break;
		 case TOTMENU_SDI_TSG2_PATT:        SDITotalTest(SDITSG2,5); break;

		 case TOTMENU_SDI_TSG3_TIMING:      SDITotalTest(SDITSG3,1); break;      //  PT8639
		 case TOTMENU_SDI_TSG3_JITAMSP:     SDITotalTest(SDITSG3,2); break;
		 case TOTMENU_SDI_TSG3_RLOSS:       SDITotalTest(SDITSG3,3); break;
		 case TOTMENU_SDI_TSG3_EMBAUDEDH:   SDITotalTest(SDITSG3,4); break;
		 case TOTMENU_SDI_TSG3_PATT:        SDITotalTest(SDITSG3,5); break;

		 case TOTMENU_SDI_TSG4_TIMING:      SDITotalTest(SDITSG4,1); break;      //  PT8639
		 case TOTMENU_SDI_TSG4_JITAMSP:     SDITotalTest(SDITSG4,2); break;
		 case TOTMENU_SDI_TSG4_RLOSS:       SDITotalTest(SDITSG4,3); break;
		 case TOTMENU_SDI_TSG4_EMBAUDEDH:   SDITotalTest(SDITSG4,4); break;
		 case TOTMENU_SDI_TSG4_PATT:        SDITotalTest(SDITSG4,5); break;

		 case TOTMENU_SDI_TPG102_TIMING:    SDITotalTest(SDITPG1,1); break;      //  PT8602/03
		 case TOTMENU_SDI_TPG102_JITAMSP:   SDITotalTest(SDITPG1,2); break;
		 case TOTMENU_SDI_TPG102_RLOSS:     SDITotalTest(SDITPG1,3); break;
		 case TOTMENU_SDI_TPG102_EMBAUDEDH: SDITotalTest(SDITPG1,4); break;
		 case TOTMENU_SDI_TPG102_PATT:      SDITotalTest(SDITPG1,5); break;

		 case TOTMENU_SDI_TPG132_TIMING:    SDITotalTest(SDITPG1,1); break;      //  PT8632
		 case TOTMENU_SDI_TPG132_JITAMSP:   SDITotalTest(SDITPG1,2); break;
		 case TOTMENU_SDI_TPG132_RLOSS:     SDITotalTest(SDITPG1,3); break;
		 case TOTMENU_SDI_TPG132_EMBAUDEDH: SDITotalTest(SDITPG1,4); break;
		 case TOTMENU_SDI_TPG132_PATT:      SDITotalTest(SDITPG1,5); break;

		 case TOTMENU_SDI_TPG2_TIMING:      SDITotalTest(SDITPG2,1); break;        //  PT8633
		 case TOTMENU_SDI_TPG2_JITAMSP:     SDITotalTest(SDITPG2,2); break;
		 case TOTMENU_SDI_TPG2_RLOSS:       SDITotalTest(SDITPG2,3); break;
		 case TOTMENU_SDI_TPG2_EMBAUDEDH:   SDITotalTest(SDITPG2,4); break;
		 case TOTMENU_SDI_TPG2_PATT:        SDITotalTest(SDITPG2,5); break;

		 case TOTMENU_SDI_TPG5_TIMING:      SDITotalTest(SDITPG5,1); break;        //  PT8633
		 case TOTMENU_SDI_TPG5_JITAMSP:     SDITotalTest(SDITPG5,2); break;
		 case TOTMENU_SDI_TPG5_RLOSS:       SDITotalTest(SDITPG5,3); break;
		 case TOTMENU_SDI_TPG5_EMBAUDEDH:   SDITotalTest(SDITPG5,4); break;
		 case TOTMENU_SDI_TPG5_PATT:        SDITotalTest(SDITPG5,5); break;

		 case TOTMENU_AES_AES1:             PT8635TotalTest(1); break;		   // se aescal.c
		 case TOTMENU_AES_AES2:             PT8635TotalTest(2); break;
		 case TOTMENU_AES_WC1:              PT8635TotalTest(3); break;
		 case TOTMENU_AES_WC2:              PT8635TotalTest(4); break;
		 case TOTMENU_AES_PT5210MODE:       PT8635TotalTest(5); break;

		 case TOTMENU_CLOCK_VITC:           TimeClockTotalTest(1); break;	   // se clktest.c
		 case TOTMENU_CLOCK_LTC:            TimeClockTotalTest(2); break;
		 case TOTMENU_CLOCK_REF1HZ:         TimeClockTotalTest(3); break;
	
	} 
		
}




void CVICALLBACK AnalogTPGCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem){
	  case MAINMENU_ANL_TPG2_8601_LEVEL:								  // 8601
       		if (MakeSyncOffsetCal(ANLTPG2_8601,SYNC_CAL,FALSE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG2_8601,OFFSET_CAL,FALSE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_LEVEL:								  // 8631
       		if (MakeSyncOffsetCal(ANLTPG2_8631,SYNC_CAL,TRUE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG2_8631,OFFSET_CAL,FALSE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_LEVEL:								  // 8631
       		if (MakeSyncOffsetCal(ANLTPG5_8631,SYNC_CAL,TRUE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG5_8631,OFFSET_CAL,FALSE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG2_8601,PAL,FALSE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG2_8601,NTSC,FALSE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG2_8631,PAL,TRUE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG2_8631,NTSC,FALSE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG5_8631,PAL,TRUE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG5_8631,NTSC,FALSE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_PATTERN:
	  		CheckANLTPGPattern(ANLTPG2_8601,TRUE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_PATTERN:
	  		CheckANLTPGPattern(ANLTPG2_8631,TRUE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_PATTERN:
	  		CheckANLTPGPattern(ANLTPG5_8631,TRUE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_NCO:
	  		JusterNCO(ANLTPG2_8601);
	       break;
	  case MAINMENU_ANL_TPG2_8631_NCO:
	  		JusterNCO(ANLTPG2_8631);
	       break;
	  case MAINMENU_ANL_TPG5_8631_NCO:
	  		JusterNCO(ANLTPG5_8631);
	       break;

	  case MAINMENU_ANL_TPG2_8601_FILTER:
	  		JusterFilter(ANLTPG2_8601);
	       break;
	  case MAINMENU_ANL_TPG2_8631_FILTER:
	  		JusterFilter(ANLTPG2_8631);
	       break;
	  case MAINMENU_ANL_TPG5_8631_FILTER:
	  		JusterFilter(ANLTPG5_8631);
	       break;
	       
	  case MAINMENU_ANL_RESET_TPG2:	ResetANL(ANLTPG2_8601); break;		// PT8601   se sditest.c
	 }   	
}



// ---------- Ctrl-X on mainPNL ----------------------------------------------------
int CVICALLBACK ExitBtn (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2){ 

	switch (event) {
		case EVENT_COMMIT:
			CloseCom(DUTCOM);
#if AT232
			CloseCom(VCACOM);
			CloseCom(PM3094COM);
			CloseCom(PT5210COM);
#endif	
#if IEEEBUS
			hp34401a_close (hp34401);
			hp5313xa_close (hp53132);
			
#endif	
			QuitUserInterface (0);
			break;
	}
	return 0;
}






// --------- F11 og F12 on mainPNL ----------------------------------------------------
int CVICALLBACK MenuSelectCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			 switch (control){
              case MAIN_PNL_MAINSELBTN:  EmptyMenuBar (totalmenuhandle);
 									     mainmenuhandle = LoadMenuBar (mainPNL, "pt5230.uir", MAINMENU);
										 SetMenuItems(MAINMENU);	// set menu items = dimmed / not dimmed
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_MAINSELBTN, ATTR_DIMMED, TRUE);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_TOTALSELBTN, ATTR_DIMMED, FALSE);
 									     
             				break;
              case MAIN_PNL_TOTALSELBTN: EmptyMenuBar (mainmenuhandle);
 									     totalmenuhandle = LoadMenuBar (mainPNL, "pt5230.uir", TOTMENU);
										 SetMenuItems(TOTMENU);	// set menu items = dimmed / not dimmed
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_MAINSELBTN, ATTR_DIMMED, FALSE);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_TOTALSELBTN, ATTR_DIMMED, TRUE);
             				break;
			 }
			break;
	}
	return 0;
}
