/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 1999. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAIN_PNL                        1
#define  MAIN_PNL_EXIT_BTN               2       /* callback function: ExitBtn */
#define  MAIN_PNL_GPSRECEIVER            3
#define  MAIN_PNL_HP53132EXTREF          4
#define  MAIN_PNL_MAINSELBTN             5       /* callback function: MenuSelectCallBack */
#define  MAIN_PNL_TOTALSELBTN            6       /* callback function: MenuSelectCallBack */
#define  MAIN_PNL_SWVER                  7
#define  MAIN_PNL_NAME1                  8
#define  MAIN_PNL_NAME2                  9
#define  MAIN_PNL_DEC1                   10
#define  MAIN_PNL_GPS_TIMER              11      /* callback function: GPSXLDCCallBack */
#define  MAIN_PNL_GPSCHECKNUMBER         12


     /* Menu Bars, Menus, and Menu Items: */

#define  MAINMENU                        1
#define  MAINMENU_BB                     2
#define  MAINMENU_BB_BB1_TOTAL           3       /* callback function: BBCallBack */
#define  MAINMENU_BB_BB3_TOTAL           4       /* callback function: BBCallBack */
#define  MAINMENU_BB_BB5_TOTAL           5       /* callback function: BBCallBack */
#define  MAINMENU_BB_BB7_TOTAL           6       /* callback function: BBCallBack */
#define  MAINMENU_BB_SEPBB               7
#define  MAINMENU_BB_PARBB               8       /* callback function: BBCallBack */
#define  MAINMENU_ANL                    9
#define  MAINMENU_ANL_TPG2_8601          10
#define  MAINMENU_ANL_TPG2_8601_SUBMENU  11
#define  MAINMENU_ANL_TPG2_8601_NCO      12      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8601_LEVEL    13      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8601_FILTER   14      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8601_PHASE    15      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8601_PATTERN  16      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8631          17
#define  MAINMENU_ANL_TPG2_8631_SUBMENU  18
#define  MAINMENU_ANL_TPG2_8631_NCO      19      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8631_LEVEL    20      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8631_FILTER   21      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8631_PHASE    22      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG2_8631_PATTERN  23      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG5_8631          24
#define  MAINMENU_ANL_TPG5_8631_SUBMENU  25
#define  MAINMENU_ANL_TPG5_8631_NCO      26      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG5_8631_LEVEL    27      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG5_8631_FILTER   28      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG5_8631_PHASE    29      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_TPG5_8631_PATTERN  30      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_SEP1               31
#define  MAINMENU_ANL_RESET              32      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_RESET_SUBMENU      33
#define  MAINMENU_ANL_RESET_TPG2         34      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_RESET_TPG231       35      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_ANL_RESET_TPG531       36      /* callback function: AnalogTPGCallBack */
#define  MAINMENU_SDI                    37
#define  MAINMENU_SDI_BLK34              38
#define  MAINMENU_SDI_BLK34_SUBMENU      39
#define  MAINMENU_SDI_BLK34_CAL          40      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK34_JITAMSP      41      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK34_RLOSS        42      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK34_EMBAUDIO     43      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK34_PATT         44      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK56              45
#define  MAINMENU_SDI_BLK56_SUBMENU      46
#define  MAINMENU_SDI_BLK56_CAL          47      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK56_JITAMSP      48      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK56_RLOSS        49      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK56_EMBAUDIO     50      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK56_PATT         51      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK78              52
#define  MAINMENU_SDI_BLK78_SUBMENU      53
#define  MAINMENU_SDI_BLK78_CAL          54      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK78_JITAMSP      55      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK78_RLOSS        56      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK78_EMBAUDIO     57      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_BLK78_PATT         58      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_SEP1               59
#define  MAINMENU_SDI_TSG2               60
#define  MAINMENU_SDI_TSG2_SUBMENU       61
#define  MAINMENU_SDI_TSG2_CAL           62      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG2_JITAMSP       63      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG2_RLOSS         64      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG2_EMBAUDIO      65      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG2_PATT          66      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG3               67
#define  MAINMENU_SDI_TSG3_SUBMENU       68
#define  MAINMENU_SDI_TSG3_CAL           69      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG3_JITAMSP       70      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG3_RLOSS         71      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG3_EMBAUDIO      72      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG3_PATT          73      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG4               74
#define  MAINMENU_SDI_TSG4_SUBMENU       75
#define  MAINMENU_SDI_TSG4_CAL           76      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG4_JITAMSP       77      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG4_RLOSS         78      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG4_EMBAUDIO      79      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG4_PATT          80      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_SEP2               81
#define  MAINMENU_SDI_TPG102             82
#define  MAINMENU_SDI_TPG102_SUBMENU     83
#define  MAINMENU_SDI_TPG102_CAL         84      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG102_JITAMSP     85      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG102_RLOSS       86      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG102_EMBAUDIO    87      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG102_PATT        88      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG132             89
#define  MAINMENU_SDI_TPG132_SUBMENU     90
#define  MAINMENU_SDI_TPG132_CAL         91      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG132_JITAMSP     92      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG132_RLOSS       93      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG132_EMBAUDIO    94      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG132_PATT        95      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG2               96
#define  MAINMENU_SDI_TPG2_SUBMENU       97
#define  MAINMENU_SDI_TPG2_CAL           98      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG2_JITAMSP       99      /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG2_RLOSS         100     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG2_EMBAUDIO      101     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG2_PATT          102     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG5               103
#define  MAINMENU_SDI_TPG5_SUBMENU       104
#define  MAINMENU_SDI_TPG5_CAL           105     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG5_JITAMSP       106     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG5_RLOSS         107     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG5_EMBAUDIO      108     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TPG5_PATT          109     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_SEP3               110
#define  MAINMENU_SDI_TSG900             111
#define  MAINMENU_SDI_TSG900_SUBMENU     112
#define  MAINMENU_SDI_TSG900_CAL625      113     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_TSG900_CAL525      114     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_SEP4               115
#define  MAINMENU_SDI_GENL               116     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_SEO5               117
#define  MAINMENU_SDI_RESETSDI           118     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_RESETSDI_SUBMENU   119
#define  MAINMENU_SDI_RESETSDI_TPG102    120     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_RESETSDI_TPG132    121     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_RESETSDI_TPG2      122     /* callback function: SDITestCallBack */
#define  MAINMENU_SDI_RESETSDI_TPG5      123     /* callback function: SDITestCallBack */
#define  MAINMENU_SPG                    124
#define  MAINMENU_SPG_HPHGENL            125     /* callback function: SPGTestCallBack */
#define  MAINMENU_SPG_TESTGENLOCK        126     /* callback function: SPGTestCallBack */
#define  MAINMENU_SPG_CHECKOVEN          127     /* callback function: SPGTestCallBack */
#define  MAINMENU_SPG_INT27REF           128     /* callback function: SPGTestCallBack */
#define  MAINMENU_SPG_INT10REF           129     /* callback function: SPGTestCallBack */
#define  MAINMENU_SPG_SPGSEP             130
#define  MAINMENU_SPG_RESETSPG           131     /* callback function: SPGTestCallBack */
#define  MAINMENU_AUDIOGEN               132
#define  MAINMENU_AUDIOGEN_8605          133     /* callback function: AudioTestCallBack */
#define  MAINMENU_AUDIOGEN_8635          134
#define  MAINMENU_AUDIOGEN_8635_SUBMENU  135
#define  MAINMENU_AUDIOGEN_8635_AES1     136     /* callback function: AudioTestCallBack */
#define  MAINMENU_AUDIOGEN_8635_AES2     137     /* callback function: AudioTestCallBack */
#define  MAINMENU_AUDIOGEN_8635_WC1      138     /* callback function: AudioTestCallBack */
#define  MAINMENU_AUDIOGEN_8635_WC2      139     /* callback function: AudioTestCallBack */
#define  MAINMENU_AUDIOGEN_8635_MODE5210 140     /* callback function: AudioTestCallBack */
#define  MAINMENU_LTC                    141     /* callback function: LTCCallBack */
#define  MAINMENU_CLOCK                  142     /* callback function: TimeClockCallBack */
#define  MAINMENU_CLOCK_VITC             143     /* callback function: TimeClockCallBack */
#define  MAINMENU_CLOCK_LTC              144     /* callback function: TimeClockCallBack */
#define  MAINMENU_CLOCK_REF1HZ           145     /* callback function: TimeClockCallBack */
#define  MAINMENU_CLOCK_BATTERY          146     /* callback function: TimeClockCallBack */
#define  MAINMENU_DIVERSE                147
#define  MAINMENU_DIVERSE_POWERJUST      148     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_FAN            149     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_CALDATA        150     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_CALFILES       151     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SETUP5211      152     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SEP1           153
#define  MAINMENU_DIVERSE_SELGENLSIGNAL  154     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SEP2           155
#define  MAINMENU_DIVERSE_WPOFF          156     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_WPON           157     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SEP3           158
#define  MAINMENU_DIVERSE_VLM            159     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SDIRL          160     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SEP4           161
#define  MAINMENU_DIVERSE_PM5640SCH      162     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_INSTR          163     /* callback function: DiverseCallBack */
#define  MAINMENU_DIVERSE_SEP5           164
#define  MAINMENU_DIVERSE_EXITPROGRAM    165     /* callback function: DiverseCallBack */

#define  TOTMENU                         2
#define  TOTMENU_BASIC                   2
#define  TOTMENU_BASIC_RESETSPG          3       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_PS                4       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_FAN               5       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_OVEN              6       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_F27               7       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_GENL              8       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_SPG               9       /* callback function: TotCallBack */
#define  TOTMENU_BASIC_BB1               10      /* callback function: TotCallBack */
#define  TOTMENU_BASIC_BB2               11      /* callback function: TotCallBack */
#define  TOTMENU_SDI                     12
#define  TOTMENU_SDI_BLK34               13
#define  TOTMENU_SDI_BLK34_SUBMENU       14
#define  TOTMENU_SDI_BLK34_TIMING        15      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK34_JITAMSP       16      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK34_RLOSS         17      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK34_EMBAUDEDH     18      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK34_PATT          19      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK56               20
#define  TOTMENU_SDI_BLK56_SUBMENU       21
#define  TOTMENU_SDI_BLK56_TIMING        22      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK56_JITAMSP       23      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK56_RLOSS         24      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK56_EMBAUDEDH     25      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK56_PATT          26      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK78               27
#define  TOTMENU_SDI_BLK78_SUBMENU       28
#define  TOTMENU_SDI_BLK78_TIMING        29      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK78_JITAMSP       30      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK78_RLOSS         31      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK78_EMBAUDEDH     32      /* callback function: TotCallBack */
#define  TOTMENU_SDI_BLK78_PATT          33      /* callback function: TotCallBack */
#define  TOTMENU_SDI_SEP1                34
#define  TOTMENU_SDI_TSG2                35
#define  TOTMENU_SDI_TSG2_SUBMENU        36
#define  TOTMENU_SDI_TSG2_TIMING         37      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG2_JITAMSP        38      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG2_RLOSS          39      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG2_EMBAUDEDH      40      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG2_PATT           41      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG3                42
#define  TOTMENU_SDI_TSG3_SUBMENU        43
#define  TOTMENU_SDI_TSG3_TIMING         44      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG3_JITAMSP        45      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG3_RLOSS          46      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG3_EMBAUDEDH      47      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG3_PATT           48      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG4                49
#define  TOTMENU_SDI_TSG4_SUBMENU        50
#define  TOTMENU_SDI_TSG4_TIMING         51      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG4_JITAMSP        52      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG4_RLOSS          53      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG4_EMBAUDEDH      54      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TSG4_PATT           55      /* callback function: TotCallBack */
#define  TOTMENU_SDI_SEP2                56
#define  TOTMENU_SDI_TPG102              57
#define  TOTMENU_SDI_TPG102_SUBMENU      58
#define  TOTMENU_SDI_TPG102_TIMING       59      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG102_JITAMSP      60      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG102_RLOSS        61      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG102_EMBAUDEDH    62      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG102_PATT         63      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG132              64
#define  TOTMENU_SDI_TPG132_SUBMENU      65
#define  TOTMENU_SDI_TPG132_TIMING       66      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG132_JITAMSP      67      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG132_RLOSS        68      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG132_EMBAUDEDH    69      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG132_PATT         70      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG2                71
#define  TOTMENU_SDI_TPG2_SUBMENU        72
#define  TOTMENU_SDI_TPG2_TIMING         73      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG2_JITAMSP        74      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG2_RLOSS          75      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG2_EMBAUDEDH      76      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG2_PATT           77      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG5                78
#define  TOTMENU_SDI_TPG5_SUBMENU        79
#define  TOTMENU_SDI_TPG5_TIMING         80      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG5_JITAMSP        81      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG5_RLOSS          82      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG5_EMBAUDEDH      83      /* callback function: TotCallBack */
#define  TOTMENU_SDI_TPG5_PATT           84      /* callback function: TotCallBack */
#define  TOTMENU_ANL                     85
#define  TOTMENU_ANL_TPG2_8601           86
#define  TOTMENU_ANL_TPG2_8601_SUBMENU   87
#define  TOTMENU_ANL_TPG2_8601_NCO       88      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8601_LEVEL     89      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8601_FILTER    90      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8601_PHASE     91      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8601_PATTERN   92      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8631           93
#define  TOTMENU_ANL_TPG2_8631_SUBMENU   94
#define  TOTMENU_ANL_TPG2_8631_NCO       95      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8631_LEVEL     96      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8631_FILTER    97      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8631_PHASE     98      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG2_8631_PATTERN   99      /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG5_8631           100
#define  TOTMENU_ANL_TPG5_8631_SUBMENU   101
#define  TOTMENU_ANL_TPG5_8631_NCO       102     /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG5_8631_LEVEL     103     /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG5_8631_FILTER    104     /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG5_8631_PHASE     105     /* callback function: TotCallBack */
#define  TOTMENU_ANL_TPG5_8631_PATTERN   106     /* callback function: TotCallBack */
#define  TOTMENU_AES                     107
#define  TOTMENU_AES_AES1                108     /* callback function: TotCallBack */
#define  TOTMENU_AES_AES2                109     /* callback function: TotCallBack */
#define  TOTMENU_AES_WC1                 110     /* callback function: TotCallBack */
#define  TOTMENU_AES_WC2                 111     /* callback function: TotCallBack */
#define  TOTMENU_AES_PT5210MODE          112     /* callback function: TotCallBack */
#define  TOTMENU_CLOCK                   113
#define  TOTMENU_CLOCK_VITC              114     /* callback function: TotCallBack */
#define  TOTMENU_CLOCK_LTC               115     /* callback function: TotCallBack */
#define  TOTMENU_CLOCK_REF1HZ            116     /* callback function: TotCallBack */


     /* Callback Prototypes: */ 

void CVICALLBACK AnalogTPGCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK AudioTestCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK BBCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK DiverseCallBack(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK ExitBtn(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GPSXLDCCallBack(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK LTCCallBack(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK MenuSelectCallBack(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK SDITestCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK SPGTestCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK TimeClockCallBack(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK TotCallBack(int menubar, int menuItem, void *callbackData, int panel);


#ifdef __cplusplus
    }
#endif
