
extern int TestAudioGen(int AESNo, int AudioGenNo);
extern int TestWordClockOutputs(int AudioGenNo);
extern char *ReadAudioPTNo (int aesno);
extern char *ReadAudioKUNumber (int aesno);
extern char *ReadAudioProdDate (int aesno);
extern char *ReadAudioCalDate (int aesno);
extern int TestAudioGen5210Mode(void);
extern int PT8635TotalTest(int TestNo);
