
extern int	jitPNL,
			sdiPNL,
			amspPNL,
			pattPNL,
			rlossPNL,
			sdigenlPNL;
			
extern int XX1_Stik;

extern const float xd;  // remote genlock error

int GetTPGXX1Connection(void);
extern int SDICal(int TVLines, int SDINo, int GetXX1);
extern int SDI900Cal(int TVLines, int SDINo, int GetXX1);
extern int CheckSDIPattern(int SDINo, int GetXX1);
extern int SDIJitterTest(int SDINo, int GetXX1);
extern int SDIAmplSpecTest(int SDINo, int GetXX1);
extern int SDIReturnLossTest(int SDINo, int GetXX1);
extern int SDIGenlockTest(void);
extern int CheckSDIEmbAudio_EDH(int SDINo, int GetXX1);
extern int SDITotalTest(int Item,int Sel);


extern char *ReadSDIKUNumber (int SDINo, int xx_stik);
extern char *ReadSDIProdDate (int SDINo, int xx_stik);
extern char *ReadSDICalDate (int SDINo, int xx_stik);
extern char *ReadRLossInEEPROM (int SDINo, int xx_stik);
extern char *ReadJitterInEEPROM (int SDINo, int xx_stik);
extern char *ReadAmspInEEPROM (int SDINo, int xx_stik);
extern char *ReadSDIGenlKUNumber (void);
extern char *ReadSDIGenlProdDate (void);
extern char *ReadSDIGenlCalDate (void);
extern int SDIReturnLossMeasurement(void);
extern int ResetSDI(int SDINo);
extern int SetupPT5211(void);
