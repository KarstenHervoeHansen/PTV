/* bbcal.c
 PT5210:   Analog Black Burst Calibration  (BB1,2 + PT8608)
           Analog TSG Calibration  (PT8601)
           
 BB har interne RS-232 adresser:  BB1-2 = 0 	 BB3-4 = 17d
                                  BB5-6 = 19d    BB7-8 = 18d
 961122, PF


 Rettelser:
 970224 PF/SNJ	NTSC fasen er flyttet 2 fields, s�ledes at ScH med linie 11 puls er ok ved 
 				m�ling med PM5662
				Se konstanten PhaseOffsetNTSC
				
 970613 PF		PT86xx nummer i BB moduler er fejlagtigt skrevet som PT8606. Dette
 				er en fejl, og det rettes derfor til det korrekte PT8608.

 970901 PF      Kalibrering af +12 og -5 volt indf�rt. 
 				Kal data logges til 'PowerSupplyLogFile'
 				Se 'BasicTotalTest' i filen 'spgcal'

 980420 PF      Test af PT8631 indf�rt
 
 981102 PF/SNJ  Tolerance i TP07 �ndres fra 3.0-3.4V til 3.0-3.6V
 990816 PF      Text i PT8601 testes med pos1 og pos2
 991116 PF		Reset af Analog TPG indf�rt - se 'ResetANL'

 delay ved <<<<<<<<(111) skal fjernes

*/

#include <gpib.h>
#include <rs232.h>
#include <ansi_c.h>
#include "phase.h"
#include <utility.h>
#include <formatio.h>
#include <userint.h>
#include "cviutil.h"
#include "bb_sync.h"
#include <hp34401a.h>
#include "pt5230.h"
#include "cfg.h"
#include "sdi.h"
#include "spgcal.h"
#include "aescal.h"
#include "sditest.h"
#include "ltctest.h"
#include "vcc.h"
#include "fan.h"
#include "filter.h"
#include "def.h"






// logfiles: 0=local logfile on E-drive	   1=logfile on LAN S-drive
char BBLogFile[2][50] = {"c:\\5230log\\bbcal.log","m:\\measdata\\5230\\bbcal.log"};
char PowerSupplyLogFile[2][50] = {"c:\\5230log\\pscal.log","m:\\measdata\\5230\\pscal.log"};


//  BB 
const int  		
		ScHOffsetPAL = -540,
		PhaseOffsetPAL = -5450;
															    
const int  		
		ScHOffsetNTSC = -30,			
		PhaseOffsetNTSC = 230630400-8250;   // 230630400 = (525*2*1716*256)/2 



// Power supply tolerancer
int PSTol = 7;	   // � % tol for power supply failure
int ADC5Max = 134 * 1.08;	// A/D konverter m�linger
int ADC5Min = 134 * 0.92;	// nom ADC v�rdi m�lt 970901 PF, KU010503
int ADC12Max = 147 * 1.08;	
int ADC12Min = 147 * 0.92;	
int ADCM5Max = 128 * 1.08;	
int ADCM5Min = 128 * 0.92;	


// Analog TSG
const int  		
		TSGScHOffsetPAL = -150,
		TSGPhaseOffsetPAL = 1105920000 - 2224600; // 8601/31	 max = 0x41eb0000 = 1105920000


const int  		
		TSGScHOffsetNTSC = -530,
		TSGPhaseOffsetNTSC = 461260800 - 3527150; //max= 0x1b7e4800 = 461260800


// ------ BB ---------------------
const int		
		MaxBBPhase = 5000,		   // typisk = 4705
		MinBBPhase = 4400,
		MaxBBScHPhasePAL = 1500,   //   --   = 1310
		MinBBScHPhasePAL = 1100;
		MaxBBScHPhaseNTSC = 1900,  //	--   = 1715
		MinBBScHPhaseNTSC = 1500;

// ------ Analog TPG ------------
const int		
		MaxTPGPhase = 1200000000,	// typisk = 1104 mio   eller 457 mio
		MinTPGPhase =  200000000,   // 200 mio
		MaxTPGScHPhasePAL = 2047,   //   --   = 1900
		MinTPGScHPhasePAL = 1700;
		MaxTPGScHPhaseNTSC = 1700,  //	 --   = 1520
		MinTPGScHPhaseNTSC = 1300;




const double	Max5 = 5.1, 			// juster omr�de for +5V supply
				Min5 = 5.0,
				Max12 = 12.5,			// check level for +12V supply
				Min12 = 11.5,
				MaxM5 = -4.8,			// check level for -5V supply
				MinM5 = -5.2,

			 	SPGTP7Max = 3.6,		// check level for SPG TP7 (ovn regulering)
			 	SPGTP7Min = 3.0,
			 	AudioTP1Min = -3.0,		// check level for audio VCO
			 	AudioTP1Max =  3.0,
			 	LTC_TP7MaxG = 2.3,		// check level for LTC VCO   (PAL)
			 	LTC_TP7MinG = 1.5,
			 	LTC_TP7MaxM = 3.1,		// check level for LTC VCO   (NTSC)
			 	LTC_TP7MinM = 2.3;

const int		FanRunTemp = 45;	    // check gr�nse for bl�ser on/off

unsigned char	DACValue;				// level + offset kalibrering

int 			PhaseOffset,
    			ScHOffset,
				ScHValue,
				PhaseValue;
				
int				BBNumber;
				ATPGNumber,				// ved filterjustering i PT8601/31
				XX_Stik;				//  -         -        -     -
				
int  CheckingOven,
	 CheckingPS;
	 CheckingAudioVCO,
	 CheckingLTCVCO,
     CalibratingPS;
	 
int  AnalogTPGSelected;	   // v�lger mellem BB og Analog TPG ved phase & ScH kalibrering

int SaveToFile;

int	err,
	n,
    ConfirmReply;

int CalPAL[2],		 // phase,ScHphase, for PAL
	CalNTSC[2],		 // phase,ScHphase for NTSC
	CalDAC[2];		 // level,offset


//--- prototyping -----------------------------------------------------------------------
int InitBB(int BBNo);
int SaveCalData(int Unit);
int ShowCalFiles(void);
int ReadADC(int *Temp, int *Plus5, int *Minus5, int *Plus12);
char *ReadMULBBKUNumber (void);
char *ReadMULBBProdDate (void);
char *ReadMULBBCalDate (void);
int TestParBB(void);
int InitParBB(void);
int InitANLTPG(int tpgno, int xx1_stik);
int WriteParBBCalDate(void);
int CheckBBCaldata(int BBNo,int TV);
int CheckANLTPGPattern(int ANLTPGNo, int GetXX1);
int JusterFilter(int ATPGNo);



//--------------------------------------------------------------------------------
void SetDAC(unsigned char dac, int BB, int DACType){

 if ((DACType == SYNC_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    Fmt(DUTStr,"%s<COMM 'HD',%i;",dac);
   else
    Fmt(DUTStr,"%s<COMM 'JD',%i;",dac);
 }  

 if ((DACType == OFFSET_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    Fmt(DUTStr,"%s<COMM 'HC',%i;",dac);
   else
    Fmt(DUTStr,"%s<COMM 'JC',%i;",dac);
 }  
 
 if ((DACType == SYNC_DAC) && (BB >= ANLTPG2_8601))
  Fmt(DUTStr,"%s<COMM 'AD',%i;",dac);

 if ((DACType == OFFSET_DAC) && (BB >= ANLTPG2_8601))
  Fmt(DUTStr,"%s<COMM 'AC',%i;",dac);

 WriteCOMPort(DUTCOM,DUTStr);
 SetCtrlVal(syncPNL, SYNC_PNL_COMMTXT,DUTStr);
 Delay(0.8);

} // SetDAC


//---------------------------------------------------------------------------------
void StoreDAC(int BB, int DACType){
 if ((DACType == SYNC_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HD$';",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JD$';",0,-1);
 }  
 
 if ((DACType == OFFSET_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HC$';",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JC$';",0,-1);
 }  


 if ((DACType == SYNC_DAC) && (BB >= ANLTPG2_8601))
  CopyString(DUTStr,0,"COMM 'AD$';",0,-1);

 if ((DACType == OFFSET_DAC) && (BB >= ANLTPG2_8601))
  CopyString(DUTStr,0,"COMM 'AC$';",0,-1);
 
 
 WriteCOMPort(DUTCOM,DUTStr);
 SetCtrlVal(syncPNL, SYNC_PNL_COMMTXT,DUTStr);
 Delay(2.2);

} // StoreDAC



//------------------------------------------------------------------------------
int ReadDAC(int BB, int DACType, unsigned int *dacdataread) {
char *strread;

 FlushInQ(DUTCOM);

 if ((DACType == SYNC_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HD?';",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JD?';",0,-1);
 }  

 if ((DACType == OFFSET_DAC) && (BB < ANLTPG2_8601)){
  if ((BB % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HC?';",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JC?';",0,-1);
 }  
 
 if ((DACType == SYNC_DAC) && (BB >= ANLTPG2_8601))
  CopyString(DUTStr,0,"COMM 'AD?';",0,-1);

 if ((DACType == OFFSET_DAC) && (BB >= ANLTPG2_8601))		
  CopyString(DUTStr,0,"COMM 'AC?';",0,-1);

 WriteCOMPort(DUTCOM,DUTStr);
 strread = ReadlnCOMPort(DUTCOM,1.0);
 Scan(strread,"%s>%i",dacdataread);

return StringLength(strread);
} //ReadDAC








int MakeSyncOffsetCal(int BBNo, int CalType, int GetXX1){
// BBNo 1-8 = Black Burst	  
// BBNo for Analog TPG: se #define �verst i denne fil

const double MinmVStepSync = 0.1;   	// mV	   (typisk = 0.25 mV pr step)
const double MaxmVStepSync = 0.5;
const double MinmVStepDCOffset = 0.8;   // mV	   (typisk = 1.14 mV pr step)
const double MaxmVStepDCOffset = 1.5;

const int MaxNoOfMeas = 10;		// max antal m�linger for kalibrering

double MinmVStep;   
double MaxmVStep;

unsigned char DACValueSend;		// v�rdi sent til DAC

int NoOfMeas;
int NoOfOkMeas;
int StartKal;
int LevelInsideTol,
	LevelOk;
double	mVprStep,
		NomLevel,
		LevelTol;
double meas,m1;
char TitleStr[30];
char MsgStr[100];
char LevelStr[20];
char ErrStr[200];
char *dataread, 
     *strread;
unsigned int DACdataRead;

int handle_returned, 
    controlID_returned;


 if (CalType == SYNC_CAL){
  if (BBNo < ANLTPG2_8601)
    BBCalOk = TRUE;
   else
    ANLCalOk = TRUE;
 }   

 // set password = off & check RS-232 forbindelse
 if (CalType == SYNC_CAL)
  if (WriteProtect(OFF,FALSE) == FALSE){
   BBCalOk = FALSE;
   return FALSE;
  } 


 // -----  kun for PT8631  ------------------
 if (GetXX1 == TRUE)
  if (GetTPGXX1Connection() == 3){
   ANLCalOk = FALSE;
   return FALSE;
  }



// init EEPROM -------------------------------
 if (CalType == SYNC_CAL){
  if (BBNo < ANLTPG2_8601)
   if (InitBB(BBNo) == FALSE){
    BBCalOk = FALSE;
    return FALSE;
   }
   
  if (BBNo >= ANLTPG2_8601)
   if (InitANLTPG(BBNo,XX1_Stik) == FALSE){	  // PT86xx og No900 opdateres
    ANLCalOk = FALSE;
    return FALSE;
   } 
 } // if (CalType ==



// init panel
 if (BBNo < ANLTPG2_8601 )
   Fmt(TitleStr,"%s< Black Burst #%i ",BBNo);

 if ((BBNo == ANLTPG2_8601) && (PT86No == 0))
   Fmt(TitleStr,"%s< Analog TPG  PT8601 ");
 else 
 if ((BBNo == ANLTPG2_8601) && (PT86No > 0))
   Fmt(TitleStr,"%s< Analog TPG  PT8601/%i ",PT86No);


 if ((BBNo == ANLTPG2_8631) && (PT86No <= 31))
   Fmt(TitleStr,"%s< Analog TPG2  (PT8631) ");
 else 
 if ((BBNo == ANLTPG2_8631) && (PT86No > 900))
   Fmt(TitleStr,"%s< Analog TPG2  PT8631/%i ",PT86No);


 if ((BBNo == ANLTPG5_8631) && (PT86No <= 31))
   Fmt(TitleStr,"%s< Analog TPG5  (PT8631) ");
 else 
 if ((BBNo == ANLTPG5_8631) && (PT86No > 900))
   Fmt(TitleStr,"%s< Analog TPG5  PT8631/%i ",PT86No);

 // BB kalibrering
 if (BBNo < ANLTPG2_8601){
  if (CalType == SYNC_CAL){
   SetVLM(50,200,20,30);			// measurements in sync bottom
   VLMdata(0,4);					// AC coupled meter
   MinmVStep = MinmVStepSync;   
   MaxmVStep = MaxmVStepSync;
   NomLevel = NomSyncLevel;
   LevelTol = SyncLevelTol;
   SetCtrlAttribute (syncPNL, SYNC_PNL_LEVELBOX, ATTR_LABEL_TEXT,"Sync Level:");
  }
 
  if (CalType == OFFSET_CAL){
   SetVLM(50,200,400,500);		// measurements in active video line
   VLMdata(1,4);					// DC coupled meter
   MinmVStep = MinmVStepDCOffset;   
   MaxmVStep = MaxmVStepDCOffset;
   NomLevel = NomDCOffset;
   LevelTol = DCOffsetTol;
   SetCtrlAttribute (syncPNL, SYNC_PNL_LEVELBOX, ATTR_LABEL_TEXT,"DC Offset:");
  }
  SetCtrlAttribute (syncPNL, SYNC_PNL_VIDEOMETER, ATTR_MAX_VALUE, 200.0);
  SetCtrlAttribute (syncPNL, SYNC_PNL_VIDEOMETER, ATTR_MIN_VALUE, -400.0);
 } 


 // Analog TPG kalibrering
 if (BBNo >= ANLTPG2_8601){				
  if (CalType == SYNC_CAL){			//measurements in 100% window bottom
   SetVLM(130,200,320,400);			// StartLine,StopLine,StartPos,StopPos
   VLMdata(0,4);					// AC coupled meter
   MinmVStep = MinmVStepSync;   
   MaxmVStep = MaxmVStepSync;
   NomLevel = NomWindowLevel;
   LevelTol = SyncLevelTol;
   SetCtrlAttribute (syncPNL, SYNC_PNL_LEVELBOX, ATTR_LABEL_TEXT,"Sync Level:");
  }
 
  if (CalType == OFFSET_CAL){   // measurements in active video line
   SetVLM(130,200,500,570);		
   VLMdata(1,4);					// DC coupled meter
   MinmVStep = MinmVStepDCOffset;   
   MaxmVStep = MaxmVStepDCOffset;
   NomLevel = NomDCOffset;
   LevelTol = DCOffsetTol;
   SetCtrlAttribute (syncPNL, SYNC_PNL_LEVELBOX, ATTR_LABEL_TEXT,"DC Offset:");
  }
  SetCtrlAttribute (syncPNL, SYNC_PNL_VIDEOMETER, ATTR_MAX_VALUE, 800.0);
  SetCtrlAttribute (syncPNL, SYNC_PNL_VIDEOMETER, ATTR_MIN_VALUE, -400.0);
 } 

 
 
 Fmt(LevelStr,"%s<%f[p0w5] � %f[p0] mV",NomLevel,LevelTol);
 InsertTextBoxLine(syncPNL, SYNC_PNL_LEVELBOX,0,LevelStr);
 
 SetPanelAttribute (syncPNL, ATTR_TITLE, TitleStr);

 DisplayPanel (syncPNL);

 SetCtrlAttribute (syncPNL, SYNC_PNL_STATUSLED, ATTR_ON_COLOR,VAL_GREEN);
 
 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);


 if (CheckFrontRearTerminal(REARTERM34401) == FALSE) {
  HidePanel(syncPNL);
  if (BBNo < ANLTPG2_8601)
    BBCalOk = FALSE;
   else
    ANLCalOk = FALSE;
  return FALSE;
 }
 
 
 StartKal = YES;
 if (CalType == SYNC_CAL)
  StartKal = ConfirmPopup (""," Start kalibrering?");
 
 if (StartKal == NO) {
  HidePanel (syncPNL);
  if (BBNo < ANLTPG2_8601)
    BBCalOk = FALSE;
   else
    ANLCalOk = FALSE;
  return FALSE;
 }

 if (CalType == SYNC_CAL)
  switch (BBNo) {
   case 1 : WriteCOMPort(DUTCOM,":OUTP:BB1:SYST PAL;"); break;
   case 2 : WriteCOMPort(DUTCOM,":OUTP:BB2:SYST PAL;"); break;
   case 3 : WriteCOMPort(DUTCOM,":OUTP:BB3:SYST PAL;"); break;
   case 4 : WriteCOMPort(DUTCOM,":OUTP:BB4:SYST PAL;"); break;
   case 5 : WriteCOMPort(DUTCOM,":OUTP:BB5:SYST PAL;"); break;
   case 6 : WriteCOMPort(DUTCOM,":OUTP:BB6:SYST PAL;"); break;
   case 7 : WriteCOMPort(DUTCOM,":OUTP:BB7:SYST PAL;"); break;
   case 8 : WriteCOMPort(DUTCOM,":OUTP:BB8:SYST PAL;"); break;
   case ANLTPG2_8601 : WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST PAL;"); 
                       Delay(0.1);
   			           WriteCOMPort(DUTCOM,":OUTP:ASIG:PATT WIN100;");break;
   case ANLTPG2_8631 : WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL;"); 
                       Delay(0.1);
   			           WriteCOMPort(DUTCOM,":OUTP:ATPG2:PATT WIN100;");break;
   case ANLTPG5_8631 : WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL;"); 
                       Delay(0.1);
   			           WriteCOMPort(DUTCOM,":OUTP:ATPG5:PATT WIN100;");break;
  }

 Delay(0.1);
 

 done = FALSE;
 LevelInsideTol = FALSE;
 DACValue = 130;	// startv�rdi for DAC
 NoOfOkMeas = 0;	// antal m�linger indenfor tol
 NoOfMeas = 0;		// antal m�linger

 // Send addr for unit
 switch (BBNo) {
  case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;"); break;  // BB 1,2
  case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;"); break;
  case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;"); break;  // BB 3,4
  case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;"); break;
  case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;"); break;  // BB 5,6
  case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;"); break;
  case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;"); break;  // BB 7,8
  case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;"); break;
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;"); break;   // Analog TPG 8601
  case ANLTPG2_8631: 
  case ANLTPG5_8631: if (XX1_Stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");
                      else 
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");break;   // Analog TPG 8631
 }

 Delay(0.1);
 

 // BB kalibrering: reset SyncDAC, OffsetDAC, Phase og Sch (b�de PAL og NTSC)
 if ((CalType == SYNC_CAL) && (BBNo < ANLTPG2_8601)){
  if ((BBNo % 2) == 1)
    WriteCOMPort(DUTCOM,"COMM 'HZ';");   // 1. BB
   else
    WriteCOMPort(DUTCOM,"COMM 'JZ';");   // 2. BB
 }



 // 1. m�ling
 SetDAC(DACValue,BBNo,CalType);
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34401a_singleMeas (hp34401, &m1);
 EnableBreakOnLibraryErrors();
 m1 = m1 * 1000 / VLMGain;
 SetCtrlVal (syncPNL, SYNC_PNL_VIDEOMETER, m1);
 
 
 // 2. m�ling
 DACValue = DACValue - 30;
 SetDAC(DACValue,BBNo,CalType);
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
 EnableBreakOnLibraryErrors();
 meas = meas * 1000 / VLMGain;
 SetCtrlVal (syncPNL, SYNC_PNL_VIDEOMETER, meas);
 
 // beregn DAC v�rdi 
 mVprStep = (meas-m1) / 30;
 DACValue = DACValue - ((NomLevel - meas) / mVprStep);

 
 // check mV pr step
 if ( (fabs(mVprStep) < MinmVStep) || (fabs(mVprStep) > MaxmVStep)){
  SyncLevelOk = FALSE;
  Fmt(ErrStr,"%s< mV pr DAC-Sync step udenfor tol (%f[p2w5] - %f[p2w5]):  %f[p2w5]",fabs(MinmVStep),fabs(MaxmVStep),fabs(mVprStep));

  if (CalType == SYNC_CAL)
    Fmt(ErrStr,"%s[a]<\n Typisk v�rdi: 0.25mV/step\n Check modstande og lodninger");
   else
    Fmt(ErrStr,"%s[a]<\n Typisk v�rdi: 1.25mV/step\n Check modstande og lodninger");
  

  if (CalType == SYNC_CAL)
   MessagePopup (" Sync Level Kalibreringsfejl ",ErrStr);
   else
   MessagePopup (" Offset Kalibreringsfejl ",ErrStr);
  HidePanel (syncPNL);
  if (BBNo < ANLTPG2_8601)
    BBCalOk = FALSE;
   else
    ANLCalOk = FALSE;

  return FALSE;
 }

 
	do {

		 if (CalType == SYNC_CAL)
  		   SetDAC(DACValue,BBNo,SYNC_DAC);
  		  else
   		   SetDAC(DACValue,BBNo,OFFSET_DAC);
		 
		 DACValueSend = DACValue;
 	     GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);

		 DisableBreakOnLibraryErrors();
		 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
		 EnableBreakOnLibraryErrors();

		 meas = meas * 1000 / VLMGain;
		 SetCtrlVal (syncPNL, SYNC_PNL_VIDEOMETER, meas);
		 
		 if ((CalType == OFFSET_CAL) && (BBNo >= ANLTPG2_8601)){
		  if (meas > NomLevel)		  // Offset DAC: Analog TPG k�rer omvendt af BB
  		   DACValue++;
		   else
		  if (meas < NomLevel)
		   DACValue--;
		  }
		 else{
		  if (meas > NomLevel)
  		   DACValue--;
		   else
		  if (meas < NomLevel)
		   DACValue++;
		  }
		 
		LevelInsideTol = ((meas > (NomLevel - LevelTol)) & (meas < (NomLevel + LevelTol)));
			
		if (LevelInsideTol){
		 NoOfOkMeas++;
		 SetCtrlAttribute (syncPNL, SYNC_PNL_STATUSLED, ATTR_ON_COLOR,VAL_GREEN);
		 }
		else {
		 NoOfOkMeas = 0;
		 SetCtrlAttribute (syncPNL, SYNC_PNL_STATUSLED, ATTR_ON_COLOR,VAL_RED);
		 }

		
		 if ((NoOfOkMeas > 3) && (done == FALSE))	  // mindst 3 OK-m�linger i tr�k f�r godkendelse
		  LevelOk = TRUE;
		 else 
		  LevelOk = FALSE;
		  
		 NoOfMeas++; 
		
	} while ((LevelOk == FALSE) && (done == FALSE) && (NoOfMeas <= MaxNoOfMeas));
	

  
  if (NoOfMeas > MaxNoOfMeas){
   Fmt(ErrStr,"%s< Fejlet efter mere end %i m�linger\n DAC = %i",MaxNoOfMeas,DACValueSend);
   if (CalType == SYNC_CAL){
     MessagePopup (" Level Kalibrering",ErrStr);
     SyncLevelOk = FALSE;
    } 
    else{
     MessagePopup (" Offset Kalibrering",ErrStr);
     DCOffsetOk = FALSE;
    }
    
   HidePanel (syncPNL);
   return FALSE;
  }
	


 if (CalType == SYNC_CAL)
   SyncLevelOk = LevelOk;
  else
   DCOffsetOk = LevelOk;


 if ((SyncLevelOk == YES) && (CalType == SYNC_CAL))
  StoreDAC(BBNo,SYNC_DAC);

 if ((DCOffsetOk == YES)  && (CalType == OFFSET_CAL))
  StoreDAC(BBNo,OFFSET_DAC);
	
 if ((SyncLevelOk == NO) && (CalType == SYNC_CAL)){
  if (BBNo < ANLTPG2_8601)
    BBCalOk = FALSE;
   else
    ANLCalOk = FALSE;
  SetCtrlAttribute (syncPNL, SYNC_PNL_STATUSLED, ATTR_ON_COLOR,VAL_RED);
  MessagePopup ("Sync Level Kalibrering", "Kalibrering   AFVIST ");
 }
	 
 if ((DCOffsetOk == NO)  && (CalType == OFFSET_CAL)){
  if (BBNo < ANLTPG2_8601)
    BBCalOk = FALSE;
   else
    ANLCalOk = FALSE;
  SetCtrlAttribute (syncPNL, SYNC_PNL_STATUSLED, ATTR_ON_COLOR,VAL_RED);
  MessagePopup ("DC Offset Kalibrering", "Kalibrering   AFVIST ");
 }
		 

 
 if( ((SyncLevelOk == YES) & (CalType == SYNC_CAL)) || ((DCOffsetOk == YES)  & (CalType == OFFSET_CAL)) ) {
  if (CalType == SYNC_CAL) 
    if (ReadDAC(BBNo, SYNC_DAC, &DACdataRead) < 2){
     MessagePopup ("Sync Level Kalibrering", " Intet svar ved l�sning af kalibreringsdata i EEPROM ");
    if (BBNo < ANLTPG2_8601)
      BBCalOk = FALSE;
     else
      ANLCalOk = FALSE;
     SyncLevelOk = FALSE;
    } 

  if (CalType == OFFSET_CAL) 
    if (ReadDAC(BBNo, OFFSET_DAC, &DACdataRead) < 2){
     MessagePopup ("DC Offset Kalibrering", " Intet svar ved l�sning af kalibreringsdata i EEPROM ");
    if (BBNo < ANLTPG2_8601)
      BBCalOk = FALSE;
     else
      ANLCalOk = FALSE;
     
     DCOffsetOk = FALSE;
    }
 
 
  if ((DACValue > DACdataRead + 1) || (DACValue < DACdataRead - 1)){
   if (CalType == SYNC_CAL){
    MessagePopup ("Sync Level Kalibrering", " Kalibreringsdata ikke gemt korrekt i EEPROM ");
    if (BBNo < ANLTPG2_8601)
      BBCalOk = FALSE;
     else
      ANLCalOk = FALSE;
    SyncLevelOk = FALSE;
   }  
   else {
    MessagePopup ("DC Offset Kalibrering", " Kalibreringsdata ikke gemt korrekt i EEPROM ");
    if (BBNo < ANLTPG2_8601)
      BBCalOk = FALSE;
     else
      ANLCalOk = FALSE;
    DCOffsetOk = FALSE;
   } 
  }
 }

HidePanel (syncPNL);

 if (CalType == SYNC_CAL)
   return SyncLevelOk;
  else	
   return DCOffsetOk;
   
} // MakeSyncOffsetCal





//----------------------------------------------------------------------------
int TestParBB(void){

 // set password = off & check RS-232 forbindelse
 ParBBOk = TRUE;
 DisplayPanel(parbbPNL);
 ResetTextBox (parbbPNL, PARBB_PNL_TXTBOX, "");

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (parbbPNL);
  ParBBOk = FALSE;
  return FALSE;
  }

 InitParBB();
 
 ParBBOk = TRUE;
 SetPM5662(PAL);
 SetPanelAttribute (parbbPNL, ATTR_TITLE, " Multi BB Buffer Test  (PAL) ");
 WriteCOMPort(DUTCOM,":OUTP:BBPAR:SYST PAL_ID; SCHP 0;");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Forbind output BB2 til 5662 CH-A\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Forbind outputs BB3,4,5,6,9,10 til 5662 CH-B\n\n");
 //SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Indstil 5662G: VECT A      INT REF \n");
 //SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Indstil 5662M: WFM  A  2H  INT REF \n\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Check at PAL signalet er ok: Burst vektorer     = 135� og 225�\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                              Burst amplituder   = 300 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                              ScH fase           = 0 � 3�\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                              sync level         = 300 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                              DC offset          = 0 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                              Delay (BB2/BB Par) = < 10ns \n\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Juster p� potmeter R9 s�ledes at synclevel er ens p� 5662M\n\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Ved fejl: Tryk F9\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Ved OK:   Tryk F4");
 
 WaitForContinue();

 if (ParBBOk == FALSE){
  MessagePopup (" Multi BB Buffer Test  (PAL)", " FEJLET");
  HidePanel(parbbPNL);
  return FALSE;
 }

 ResetTextBox (parbbPNL, PARBB_PNL_TXTBOX, "");
 SetPM5662(NTSC);
 SetPanelAttribute (parbbPNL, ATTR_TITLE, " Multi BB Buffer Test  (NTSC) ");
 WriteCOMPort(DUTCOM,":OUTP:BBPAR:SYST NTSC; SCHP 0;");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Forbind output BB2 til 5662 CH-A\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Forbind outputs BB3,4,5,6,9,10 til 5662 CH-B\n\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Check at NTSC signalet er ok: Burst vektor       = 180�\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                               Burst amplitude    = 286 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                               ScH fase           = 0 � 3�\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                               sync level         = 286 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                               DC offset          = 0 � 3 mV\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX,"                               Delay (BB2/BB Par) = < 10ns \n\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Ved fejl: Tryk F9\n");
 SetCtrlVal(parbbPNL, PARBB_PNL_TXTBOX," Ved OK:   Tryk F4");
 
 WaitForContinue();

 if (ParBBOk == FALSE)
  MessagePopup (" Multi BB Buffer Test  (NTSC)", " FEJLET");

 if (ParBBOk == TRUE){
  MessagePopup (" Multi BB Buffer Test", " OK");
  WriteParBBCalDate();
 }
 
 HidePanel(parbbPNL);

return ParBBOk;
}




//-------------------------------------------------------------------------------
char *ReadBBKUNumber (int BB, int xx1_stik) {
  // read BB or ANLTSG KU nummer  (user text 2)
char *strread;
  FlushInQ(DUTCOM);
  switch (BB){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',2;"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',2;"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',2;"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',2;"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',2;"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',2;"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',2;"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',2;"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AR?',2;"); break;
   case ANLTPG2_8631: 
   case ANLTPG5_8631: if (xx1_stik == XA1_Stik)
                        WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AR?',2;");
                       else
                        WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AR?',2;");break;
  }
  Delay(0.05);
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,3,6);	 // "KUxxxxxx"   return xxxxxx

 return strread;
}						  



char *ReadBBProdDate (int BB, int xx1_stik) {
  // read BB or ANLTSG produktions dato  (user text 3)
char *strread;
  FlushInQ(DUTCOM);
  switch (BB){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',3;"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',3;"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',3;"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',3;"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',3;"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',3;"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',3;"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',3;"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AR?',3;"); break;
   case ANLTPG2_8631: 
   case ANLTPG5_8631: if (xx1_stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AR?',3;");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AR?',3;");break;
  }
  Delay(0.05);
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}


char *ReadBBCalDate (int BB, int xx1_stik) {
  // read BB or ANLTSG kalibrerings dato  (user text 4)
char *strread;
  FlushInQ(DUTCOM);
  switch (BB){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',4;"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HR?',5;"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',4;"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HR?',5;"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',4;"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HR?',5;"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',4;"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HR?',5;"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AR?',4;"); break;
   case ANLTPG2_8631: 
   case ANLTPG5_8631: if (xx1_stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AR?',4;");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AR?',4;");break;
  }
  Delay(0.05);
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}

char *ReadBBSWVer (int BB) {
  // read BB or ANLTPG SW version from �P
char *strread;

  FlushInQ(DUTCOM);
  switch (BB){
   case 1: WriteCOMPort(DUTCOM,":OUTP:BB1:VERS?;"); break;
   case 2: WriteCOMPort(DUTCOM,":OUTP:BB2:VERS?;"); break;
   case 3: WriteCOMPort(DUTCOM,":OUTP:BB3:VERS?;"); break;
   case 4: WriteCOMPort(DUTCOM,":OUTP:BB4:VERS?;"); break;
   case 5: WriteCOMPort(DUTCOM,":OUTP:BB5:VERS?;"); break;
   case 6: WriteCOMPort(DUTCOM,":OUTP:BB6:VERS?;"); break;
   case 7: WriteCOMPort(DUTCOM,":OUTP:BB7:VERS?;"); break;
   case 8: WriteCOMPort(DUTCOM,":OUTP:BB8:VERS?;"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":OUTP:ASIG:VERS?;"); break;
   case ANLTPG2_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG2:VERS?;"); break;
   case ANLTPG5_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG5:VERS?;"); break;
  }
  Delay(0.05);
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 1)
   CopyString(strread,0,strread,strlen(strread)-3,3);	 // PTV,PTxxxx,KUxxxxxx,v.v
   

 return strread;
 
}


char *ReadMasterSWVer (void) {
  // read Master & SPG uP SW ver
char *strread;

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"*IDN?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,strlen(strread)-9,9);	 // PTV,PTxxxx,KUxxxxxx,mm.m-ss.s  //CopyString(strread,0,strread,strlen(strread)-3,3);

return strread;
}



char *ReadMasterKUStr (void) {
  // read Master KU str
char *strread;
int p;

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"*IDN?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);	 // PROTELE,PTxxxx,KUxxxxxx,mm.m-ss.s 
  p = FindPattern (strread, 0, -1, "KU", 1, 0);
  if (p > 0)
   CopyString(strread,0,strread,p+2,6);
  else
   Fmt(strread,"%s<??????");

return strread;
}





//------------------------------------------------------------------------------------
char *ReadSDISWVer (int SDI) {
  // read SDI  SW version from �P
char *strread;
  FlushInQ(DUTCOM);
  switch (SDI){
   case SDIBLACK34: WriteCOMPort(DUTCOM,":OUTP:SB34:VERS?;"); break;
   case SDIBLACK56: WriteCOMPort(DUTCOM,":OUTP:SB56:VERS?;"); break;
   case SDIBLACK78: WriteCOMPort(DUTCOM,":OUTP:SB78:VERS?;"); break;

   case SDITSG2: WriteCOMPort(DUTCOM,":OUTP:STSG2:VERS?;"); break;
   case SDITSG3: WriteCOMPort(DUTCOM,":OUTP:STSG3:VERS?;"); break;
   case SDITSG4: WriteCOMPort(DUTCOM,":OUTP:STSG4:VERS?;"); break;
   
   case SDITPG1: if (AppType == PT5210)
                  WriteCOMPort(DUTCOM,":OUTP:SDIS:VERS?;"); break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,strlen(strread)-3,3);	 // PTV,PTxxxx,KUxxxxxx,v.v

 return strread;
}

 







//-------------------------------------------------------------------------------
int WriteBBCalDate(int BBNo){
char *dd;					// MM-DD-YYYY

 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 // Send addr for BB#
 if (BBNo < 9){
  CopyString(DUTStr,0,":FACT:V24C:ADDR",0,-1);
  CopyString(DUTStr,StringLength(DUTStr),V24Addr[BBNo],0,-1);
 } 
 if (BBNo == 9)
  CopyString(DUTStr,0,":FACT:V24C:ADDR ANLS;",0,-1);
  
 WriteCOMPort(DUTCOM, DUTStr);

 if (BBNo < 9){
  if ((BBNo % 2) == 1)
    CopyString(DUTStr,StringLength(DUTStr),"COMM 'HW',4,'",0,-1);
   else 
    CopyString(DUTStr,StringLength(DUTStr),"COMM 'HW',5,'",0,-1);
 }   
 
 if (BBNo == 9)  
  CopyString(DUTStr,StringLength(DUTStr),"COMM 'AW',5,'",0,-1);

 CopyString(DUTStr,StringLength(DUTStr),dato,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),"';",0,-1);
 WriteCOMPort(DUTCOM, DUTStr);
 
 Delay(0.2);

return TRUE;
}




//--------------------------------------------------------------------------------
int WriteParBBCalDate(void){
char *dd;					// MM-DD-YYYY

 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 Fmt(DUTStr,"%s<:FACT:MULT:TEXT 4,'%s';",dato);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.2);

return TRUE;
}







//-------------------------------------------------------------------------------
int InitBB(int BBNo){

int n,button_pressed;
int ValidKU;
char *usertxt,*MasterSPGSW,BBSW[20];
char *dd;					// MM-DD-YYYY
char response[10]; 			// svar fra PromptPopup
char *KUread,*strread;
char PromptStr[50];
 
 
 
 if ((BBNo == 3) || (BBNo == 4)){
  KUread = ReadBBKUNumber(BBNo,XX1_Stik);
  if (CompareStrings (KUread, 0, "999333", 0, 0) == 0) {
   MessagePopup(" BB kalibrering"," Denne BB er et referencemodul, og m� IKKE kalibreres!!\n Kalibrering stoppet");
   return FALSE;
  }
 }


 // Send addr for BB#
 CopyString(DUTStr,0,":FACT:V24C:ADDR",0,-1);
 CopyString(DUTStr,StringLength(DUTStr),V24Addr[BBNo],0,-1);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.1);


 // 0  producent
 if ((BBNo % 2) == 1){		// kun i BB 1,3,5,7
  WriteCOMPort(DUTCOM,"COMM 'HW',0,'PTV';");
  Delay(0.2);
 }
 
 // 1  12nc
 if ((BBNo % 2) == 1){		// kun i BB 1,3,5,7
   CopyString(DUTStr,0,"COMM 'HW',1,'",0,-1);
 
  if (BBNo == 1)
   CopyString(DUTStr,StringLength(DUTStr),NC12[0],0,-1);
  if ((BBNo == 3) | (BBNo == 5) | (BBNo == 7))
   CopyString(DUTStr,StringLength(DUTStr),NC12[3],0,-1);
  CopyString(DUTStr,StringLength(DUTStr),"';",0,-1);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.7);
 }
 
 
 if ((BBNo % 2) == 1){		// kun i BB 1,3,5,7
  // 2  KU nummer
  KUread = ReadBBKUNumber(BBNo,XX1_Stik);
  if (isdigit(KUread[2]) == FALSE)	
    CopyString(KUread,0,"",0,-1);

  Fmt(PromptStr,"%s< BB # %i",BBNo);
  
  EnterKUNo(PromptStr, KUread, response);
  
  Fmt(DUTStr,"%s<COMM 'HW',2,'KU%s';",response);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 } // if (BBNo ...
 

 // get system date 
 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 // 3  produktionsdato
 usertxt = ReadBBProdDate(BBNo,XX1_Stik);
 if (isdigit(usertxt[0]) == FALSE){			  
   if ((BBNo % 2) == 1) {
    Fmt(DUTStr,"%s<COMM 'HW',3,'%s';",dato);
    WriteCOMPort(DUTCOM, DUTStr);
    Delay(0.2);
   }
 }

 // 4 & 5 kalibreringsdato 
 usertxt = ReadBBCalDate(BBNo,XX1_Stik);
 if (isdigit(usertxt[0]) == FALSE){			  
  if ((BBNo % 2) == 1)
    Fmt(DUTStr,"%s<COMM 'HW',4,'%s';",dato);
   else
    Fmt(DUTStr,"%s<COMM 'HW',5,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 }


 // 6   PT-nummer 
 if (BBNo < 3)   
   WriteCOMPort(DUTCOM, "COMM 'HW',6,'NA';");
  else 
   WriteCOMPort(DUTCOM, "COMM 'HW',6,'PT8608';");
 Delay(0.2);

 // 7   reserveret - ikke defineret.


 // write IDN string to main board EEPROM	 (text 2)
 if (BBNo == 1){
  WriteCOMPort(DUTCOM,":FACT:MAIN:TEXT 0,'PTV';");
  Delay(0.1);
  
  if (AppType == PT5210)
    WriteCOMPort(DUTCOM,":FACT:MAIN:TEXT 6,'PT5210';");
   else 
    WriteCOMPort(DUTCOM,":FACT:MAIN:TEXT 6,'PT5230';");
  Delay(0.1);

  Fmt(DUTStr,"%s<:FACT:MAIN:TEXT 2,'KU%s';",response);  // 'response' = svar fra PromptPopup
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.1);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:MAIN:TEXT? 2;");
  strread = ReadlnCOMPort(DUTCOM,0.5);  // "KUxxxxxx"
  CopyString(strread,0,strread,3,6);	   //  xxxxxx
  if (strcmp(response,strread) != 0){
   MessagePopup(" KU nummer i MAIN EEPROM"," FEJL ved KU-nummer i main board EEPROM\n L�st KU nummer ikke det samme som skrevet !");
   return FALSE;
  } 
 } 

return TRUE;
} // InitBB




char *ReadANLTPGHwVer (int tpgno, int xx1_stik) {
  // read Analog TPG hardware version
char *strread;
 // Send addr for ANLS
 if (tpgno == ANLTPG2_8601)
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
 if ((tpgno == ANLTPG2_8631) || (tpgno == ANLTPG5_8631))
  if (xx1_stik == XA1_Stik)
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
  else
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'AV?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
 return strread;
}



char *ReadANLTPGSwVer (int tpgno, int xx1_stik) {
  // read Analog TPG SW version from �P
char *strread;
 // Send addr for ANLS
 if (tpgno == ANLTPG2_8601)
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
 if ((tpgno == ANLTPG2_8631) || (tpgno == ANLTPG5_8631))
  if (xx1_stik == XA1_Stik)
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
  else
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'AI?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
 return strread;
}






//----------------------------------------------------------------------------------
int InitANLTPG(int ANLTPGNo, int xx1_stik){
// L�ser fra PT8601/8631
// Returnerer No900:  9xx   for PT8601/900 serie
//			  PT86No: 1     for PT8601
//			  PT86No: 31    for PT8631
int n,button_pressed;
int ValidKU;
char *usertxt;
char *dd;					// MM-DD-YYYY
char response[10]; 			// svar fra PromptPopup
char *KUread,*strread;
char PromptStr[50];


 
 
 No900 = 0;
 usertxt = ReadANLTPGHwVer(ANLTPGNo, xx1_stik);
 Scan(usertxt,"%s>%i",&PT86No);
 if (PT86No > 1){					// 900 serie
  No900 = 900 + (PT86No / 256);
  PT86No = PT86No & 0x000000ff;		// test kun p� bit 0-7, clear 8-31
 }
 else 
 if ((PT86No != 1) && (PT86No != 31)){
  WriteCOMPort(DUTCOM,"COMM 'AZ';");  
  MessagePopup("Analog TPG"," Generator ikke monteret !");
  return FALSE;
 }

 usertxt = ReadANLTPGSwVer(ANLTPGNo, xx1_stik);
  if (RS232Timeout == TRUE) {
   Delay(0.05);
   WriteCOMPort(DUTCOM,"COMM 'AZ';");  
   Delay(2.0);
  }

 // Send addr for ANLTPG
 if (ANLTPGNo == ANLTPG2_8601)
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
 if ((ANLTPGNo == ANLTPG2_8631) || (ANLTPGNo == ANLTPG5_8631))
  if (XX1_Stik == XA1_Stik)
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
   else
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1
 

 // 0  producent
  WriteCOMPort(DUTCOM,"COMM 'AW',0,'PTV';");
  Delay(0.2);
 
 
 // 1  12nc
  if (ANLTPGNo == ANLTPG2_8601)
   WriteCOMPort(DUTCOM, "COMM 'AW',1,'109 82980';");
  if ((ANLTPGNo == ANLTPG2_8631) || (ANLTPGNo == ANLTPG5_8631))
   WriteCOMPort(DUTCOM, "COMM 'AW',1,'109 84880';");
  Delay(0.2);

 
 // 2  KU nummer
  KUread = ReadBBKUNumber(ANLTPGNo,XX1_Stik);
  if (isdigit(KUread[2]) == FALSE)	
    CopyString(KUread,0,"",0,-1);

 Fmt(PromptStr,"%s< Analog TPG");

 EnterKUNo(PromptStr, KUread, response);

 Fmt(DUTStr,"%s<COMM 'AW',2,'KU%s';",response);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.2);
 

 // get system date 
 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 
 // 3  produktionsdato
 usertxt = ReadBBProdDate(ANLTPGNo,XX1_Stik);
 if (isdigit(usertxt[0]) == FALSE){			  
   Fmt(DUTStr,"%s<COMM 'AW',3,'%s';",dato);
   WriteCOMPort(DUTCOM, DUTStr);
   Delay(0.2);
 }

 
 // 4  kalibreringsdato 
 usertxt = ReadBBCalDate(ANLTPGNo,XX1_Stik);
 if (isdigit(usertxt[0]) == FALSE){			  
  Fmt(DUTStr,"%s<COMM 'AW',4,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 }


 // 6   PT-nummer 
 if (ANLTPGNo = ANLTPG2_8601)
  WriteCOMPort(DUTCOM, "COMM 'AW',6,'PT8601';");
  
 if ((ANLTPGNo = ANLTPG2_8631) || (ANLTPGNo = ANLTPG5_8631))
  WriteCOMPort(DUTCOM, "COMM 'AW',6,'PT8631';");
 Delay(0.2);

 // 7   reserveret - ikke defineret.
 return TRUE;
} // InitANLTPG















char *ReadMULBBKUNumber (void) {
  // read Par BB KU nummer  (user text 2)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:MULT:TEXT? 2;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 1)
   CopyString(strread,0,strread,3,6);
 return strread;
}						  



//----------------------------------------------------------------------------------
char *ReadMULBBProdDate (void) {
  // read Par BB produktions dato  (user text 3)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:MULT:TEXT? 3;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}


//----------------------------------------------------------------------------------
char *ReadMULBBCalDate (void) {
  // read Par BB kalibrerings dato  (user text 4)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:MULT:TEXT? 4;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}





//---------------------------------------------------------------------------------
int InitParBB(void){

int n;
int ValidKU;
char *usertxt;
char *dd;					// MM-DD-YYYY
char response[10]; 			// svar fra PromptPopup
char *KUread;
char PromptStr[50];
 
 
 // 0  producent
  WriteCOMPort(DUTCOM,":FACT:MULT:TEXT 0,'PTV';");
  Delay(0.3);
 
 // 1  12nc
  WriteCOMPort(DUTCOM,":FACT:MULT:TEXT 1,'109 82960';");
  Delay(0.9);
 
 
  // 2  KU nummer
  KUread = ReadMULBBKUNumber();
  if (isdigit(KUread[2]) == FALSE)	
    CopyString(KUread,0,"",0,-1);

  EnterKUNo(" Multi BB", KUread, response);
  
  Fmt(DUTStr,"%s<:FACT:MULT:TEXT 2,'KU%s';",response);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.3);
 

 // get system date 
 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 // 3  produktionsdato
 usertxt = ReadMULBBProdDate();
 if (isdigit(usertxt[0]) == FALSE){			  
  Fmt(DUTStr,"%s<:FACT:MULT:TEXT 3,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.3);
 }

 // 4 kalibreringsdato 
 usertxt = ReadMULBBCalDate();
 if (isdigit(usertxt[0]) == FALSE){			  
  Fmt(DUTStr,"%s<:FACT:MULT:TEXT 4,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 }


 // 6   PT-nummer 
 WriteCOMPort(DUTCOM,":FACT:MULT:TEXT 6,'PT8604';");
 Delay(0.2);

 // 7   reserveret - ikke defineret.

return TRUE;
} // InitParBB












//-------- BB -----------------------------------------------------------------------
void SetPhase(int ph){
char PhaseStr[30];

 Fmt(PhaseStr,"%s<%i",ph);
 
 if (TV == PAL){
  if ((BBNumber % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HG',",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JG',",0,-1);
 }  

 if (TV == NTSC){
  if ((BBNumber % 2) == 1)
    CopyString(DUTStr,0,"COMM 'HM',",0,-1);
   else
    CopyString(DUTStr,0,"COMM 'JM',",0,-1);
 }  

 CopyString(DUTStr,StringLength(DUTStr),PhaseStr,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),";",0,-1);
 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.1);
 SetCtrlVal (phasePNL, SCH_PNL_COMM, DUTStr);  // kun ved debug  
 // se SetCtrlAttribute (phasePNL, SCH_PNL_COMM, ATTR_VISIBLE, FALSE); i pt5210.c
}



//------- BB ------------------------------------------------------------------------
void SetScH(int sch){
char ScHStr[30];

 Fmt(ScHStr,"%s<%i",sch);
 
 if ((BBNumber % 2) == 1)
   CopyString(DUTStr,0,"COMM 'HH',",0,-1);
  else
   CopyString(DUTStr,0,"COMM 'JH',",0,-1);

 CopyString(DUTStr,StringLength(DUTStr),ScHStr,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),";",0,-1);
 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.1);

}


//------------ Analog TPG ------------------------------------------------------------
void SetTPGPhase(int ph){
char PhaseStr[30];

 Fmt(PhaseStr,"%s<%i",ph);
 
 if (TV == PAL)
  CopyString(DUTStr,0,"COMM 'AK',",0,-1);  // 980401 AG �ndret til AK
  
 if (TV == NTSC)
  CopyString(DUTStr,0,"COMM 'AM',",0,-1);

 CopyString(DUTStr,StringLength(DUTStr),PhaseStr,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),";",0,-1);
 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.1);
 SetCtrlVal (phasePNL, SCH_PNL_COMM, DUTStr); // kun ved debug
 // se SetCtrlAttribute (phasePNL, SCH_PNL_COMM, ATTR_VISIBLE, FALSE); i pt5230.c
}



//--- Analog TSG ---------------------------------------------------------------------
void SetTPGScH(int sch){
char ScHStr[30];

 Fmt(ScHStr,"%s<%i[u]",sch);

 CopyString(DUTStr,0,"COMM 'AH',",0,-1);

 CopyString(DUTStr,StringLength(DUTStr),ScHStr,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),";",0,-1);
 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.1);

}







// -------  read PAL/NTSC cal data and check values  -------------------------------
int CheckBBCaldata(int BBNo,int TV){
char *strread, 
	 BBKUStr[20],
	 MasterSPGSW[20],
	 BBSW[20],
	 MsgStr[200],
	 wrtbuf[150],
     *dd,					// MM-DD-YYYY
	 *tt;					// HH:MM:SS
int MaxScH,
	MinScH,
	MaxPhase,
	MinPhase,
	pp[2],
    fhandle,
	bytes_written;

 FlushInQ(DUTCOM);
 if (TV == PAL){ 
  if (BBNo < 9){
   MaxScH = MaxBBScHPhasePAL;
   MinScH = MinBBScHPhasePAL;
   MaxPhase = MaxBBPhase;
   MinPhase = MinBBPhase;
  }
  if (BBNo >= 9){
   MaxScH = MaxTPGScHPhasePAL;
   MinScH = MinTPGScHPhasePAL;
   MaxPhase = MaxTPGPhase;
   MinPhase = MinTPGPhase;
  }
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HX?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JX?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HX?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JX?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HX?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JX?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HX?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JX?';"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANSL;COMM 'AX?';"); break;
   case ANLTPG2_8631: 
   case ANLTPG5_8631: if (XX1_Stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AX?';");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AX?';");break;
  }
 } // (if (TV == PAL)


 if (TV == NTSC){
  if (BBNo < 9){
   MaxScH = MaxBBScHPhaseNTSC;
   MinScH = MinBBScHPhaseNTSC;
   MaxPhase = MaxBBPhase;
   MinPhase = MinBBPhase;
   }
  if (BBNo >= 9){
   MaxScH = MaxTPGScHPhaseNTSC;
   MinScH = MinTPGScHPhaseNTSC;
   MaxPhase = MaxTPGPhase;
   MinPhase = MinTPGPhase;
   }
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HY?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JY?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HY?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JY?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HY?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JY?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HY?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JY?';"); break;
   case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANSL;COMM 'AY?';"); break;
   case ANLTPG2_8631: 
   case ANLTPG5_8631: if (XX1_Stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AY?';");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AY?';");break;
  }
 } // if (TV == NTSC)
 
 
 strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 1){
    Scan(strread,"%s>%2i[x]",pp);
  
    if (TV == PAL){
     CalPAL[0] = pp[0]; CalPAL[1] = pp[1];
    }
    else {
     CalNTSC[0] = pp[0]; CalNTSC[1] = pp[1];
    }

  /*
  Fmt(MsgStr," Kalibreringsv�rdi:\n Phase = %i   (%i - %i)  \n ScH = %i     (%i - %i)",
  		pp[0],MinPhase,MaxPhase,pp[1],MinScH,MaxScH);
  MessagePopup(" Kalibreringsv�rdier for Phase og ScH ",MsgStr);
  */   
     
     
    if ((pp[0] < MinPhase) || (pp[0] > MaxPhase) || (pp[1] < MinScH) || (pp[1] > MaxScH)){
     Fmt(MsgStr," Kalibreringsv�rdi:\n Phase = %i   (%i - %i)  \n ScH = %i     (%i - %i)\n Fejlen kan opst�, hvis der tastes OK n�r kalibreringen IKKE er ok\n Gennemf�r en ny kalibrering",
   	    pp[0],MinPhase,MaxPhase,pp[1],MinScH,MaxScH);
     MessagePopup(" Kalibrering af Phase og ScH afvist",MsgStr);
     return FALSE;
     }
     else { 
     
      // get system date 
      dd = DateStr();
      CopyString(dato,0,dd,8,2);
      CopyString(dato,strlen(dato),dd,0,2);
      CopyString(dato,strlen(dato),dd,3,2);
 
      // get system time
      tt = TimeStr();
  
	  strread = ReadBBKUNumber(BBNo,XX1_Stik);
      CopyString(BBKUStr,0,strread,0,-1);
	  
  	  if (TV == NTSC){
       // check om logfil findes, ellers opret en ny logfil
       fhandle = OpenFile (BBLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   
      strread = ReadBBSWVer (BBNo);
      CopyString(BBSW,0,strread,0,-1);
      
      strread = ReadMasterSWVer();
      CopyString(MasterSPGSW,0,strread,0,-1);



  // read sync level DAC
  FlushInQ(DUTCOM);
  switch (BBNo){
  case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HD?';"); break;
  case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JD?';"); break;
  case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HD?';"); break;
  case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JD?';"); break;
  case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HD?';"); break;
  case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JD?';"); break;
  case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HD?';"); break;
  case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JD?';"); break;
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ANLS;COMM 'AD?';"); break;
  case ANLTPG2_8631: 
  case ANLTPG5_8631: if (XX1_Stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AD?';");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AD?';");break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[w3]",&CalDAC[0]);


  // read offset DAC
  FlushInQ(DUTCOM);
  switch (BBNo){
  case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HC?';"); break;
  case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JC?';"); break;
  case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HC?';"); break;
  case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JC?';"); break;
  case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HC?';"); break;
  case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JC?';"); break;
  case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HC?';"); break;
  case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JC?';"); break;
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AC?';"); break;
  case ANLTPG2_8631: 
  case ANLTPG5_8631: if (XX1_Stik == XA1_Stik)
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AC?';");
                      else
                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AC?';");break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[w3]",&CalDAC[1]);
      
      

   // BB cal data + master SW + SPG SW gemmes i logfil
      Fmt(wrtbuf,"%s<%s,%s,KU%s,%i,%i,%i,%i,%i,%i,%i,Unit SW=%s,Master-SPG SW=%s,%i\n",
          dato,tt,BBKUStr,BBNo,CalDAC[0],CalDAC[1],CalPAL[0],CalPAL[1],CalNTSC[0],CalNTSC[1],BBSW,MasterSPGSW,AppType);	
      bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
      CloseFile(fhandle);
     } 
		     
      return TRUE;
     }
  }
  else{
    pp[0] = 0;
    pp[1] = 0;
    MessagePopup(" Kalibrering af Phase og ScH afvist"," Ingen kalibreringsv�rdier l�st fra EEPROM");
    return FALSE;
  }//if strlen
   
} //CheckBBCaldata





//-------------------------------------------------------------------------------
int MakePhaseCal(int BBNo, int TVSys) {
/* 
 Ved start af kalibrering, resettes registre i BB generator for b�de PAL og NTSC.
 Det betyder, at b�de PAL og NTSC skal kalibreres; ogs� selv om kun det ene af 
 systemerne skal kalibreres.
 Reset foreg�r ved start af sync level kalibrering. Se funktionen MakeSyncOffsetCal.
 */

char TitleStr[50];
int handle_returned, controlID_returned;


 AnalogTPGSelected = FALSE;
 
 Set5640Standard("G");
 Set5640Pattern("G", 290);
 Set5640Standard("M");
 Set5640Pattern("M", 290);
 
 TV = TVSys;
 BBNumber = BBNo;
 if (TVSys == PAL)
  Fmt(TitleStr,"%s< PAL Fase, ScH og burst amplitude for BB #%i ",BBNo);
   else
  Fmt(TitleStr,"%s< NTSC Fase, ScH og burst amplitude for BB #%i ",BBNo);

 done = FALSE;
 PhaseScHOk == FALSE;
 
 DisplayPanel (phasePNL);
 SetPanelAttribute (phasePNL, ATTR_TITLE, TitleStr);

 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILOP_BTN, ATTR_DIMMED,TRUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILNED_BTN, ATTR_DIMMED,TRUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILOP_BTN, ATTR_DIMMED,FALSE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILNED_BTN, ATTR_DIMMED,FALSE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCH_DEC, ATTR_FRAME_COLOR,VAL_BLUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_DEC, ATTR_FRAME_COLOR,VAL_LT_GRAY);

 
 if (TVSys == PAL) {
  PhaseValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MAX_VALUE, PhaseValue + 2000);
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MIN_VALUE, PhaseValue - 2000);
  SetCtrlVal (phasePNL, SCH_PNL_PHASE_SLIDE, PhaseValue);
  ScHValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MAX_VALUE, ScHValue + 300);
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MIN_VALUE, ScHValue - 300);
  SetCtrlVal (phasePNL, SCH_PNL_SCH_SLIDE, ScHValue);
  ScHOffset = ScHOffsetPAL;
  PhaseOffset = PhaseOffsetPAL;
 } 
 else {
  PhaseValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MAX_VALUE, PhaseValue + 400);
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MIN_VALUE, PhaseValue - 400);
  SetCtrlVal (phasePNL, SCH_PNL_PHASE_SLIDE, PhaseValue);
  ScHValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MAX_VALUE, ScHValue + 300);
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MIN_VALUE, ScHValue - 300);
  SetCtrlVal (phasePNL, SCH_PNL_SCH_SLIDE, ScHValue);
  ScHOffset = ScHOffsetNTSC;
  PhaseOffset = PhaseOffsetNTSC;
 }
 
 

 ResetTextBox(phasePNL, SCH_PNL_PHASESCHTXTBOX,"");
 if (TV == PAL) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST PAL_ID;SCHP 0;");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT BB          til 5662 CH-B\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662G: VECT B        INT REF \n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662M: WFM  A-B  2H  INT REF  X-MAG\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," ScH afl�ses p� 5662G      Fase afl�ses p� 5662M\n");
  if ((BBNo % 2) == 1)
   SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," HUSK: Burst amplitude justeres til samme amplitude som sync med C203\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX,"\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved fejl: Tryk F9           ");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved OK:   Tryk F4");
  SetPM5662(PAL);
 }

 if (TV == NTSC) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST NTSC;SCHP 0;");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT BB          til 5662 CH-B\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662G: WFM  A-B  2H  INT REF  X-MAG\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662M: VECT B        INT REF \n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," ScH afl�ses p� 5662M      Fase afl�ses p� 5662G\n");
  if ((BBNo % 2) == 0)
    SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," HUSK: Burst amplitude justeres til samme amplitude som sync med C303\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX,"\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved fejl: Tryk F9           ");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved OK:   Tryk F4");
  SetPM5662(NTSC);
 }

 if (TV == PAL){
  if ((BBNo % 2) == 1)
    SetCtrlAttribute (phasePNL, SCH_PNL_BURST, ATTR_VISIBLE, TRUE);
   else
    SetCtrlAttribute (phasePNL, SCH_PNL_BURST, ATTR_VISIBLE, FALSE);
 }
 
 
 
 
 
 if (TV == PAL){
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;");  //<<<<<<<<<<<<< fejl i remote genlock
   Delay(0.2);
   WriteCOMPort(DUTCOM,"SYST PALB;");
   Delay(0.5);
    switch (BBNo) {
     case 1 : WriteCOMPort(DUTCOM,":OUTP:BB1:SYST PAL_ID;"); break;
     case 2 : WriteCOMPort(DUTCOM,":OUTP:BB2:SYST PAL_ID;"); break;
     case 3 : WriteCOMPort(DUTCOM,":OUTP:BB3:SYST PAL_ID;"); break;
     case 4 : WriteCOMPort(DUTCOM,":OUTP:BB4:SYST PAL_ID;"); break;
     case 5 : WriteCOMPort(DUTCOM,":OUTP:BB5:SYST PAL_ID;"); break;
     case 6 : WriteCOMPort(DUTCOM,":OUTP:BB6:SYST PAL_ID;"); break;
     case 7 : WriteCOMPort(DUTCOM,":OUTP:BB7:SYST PAL_ID;"); break;
     case 8 : WriteCOMPort(DUTCOM,":OUTP:BB8:SYST PAL_ID;"); break;
    }
  }  
  
  if (TV == NTSC){
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;");
   Delay(0.2);
   WriteCOMPort(DUTCOM,"SYST NTSC;");
   Delay(0.5);
    switch (BBNo) {
     case 1 : WriteCOMPort(DUTCOM,":OUTP:BB1:SYST NTSC;"); break;
     case 2 : WriteCOMPort(DUTCOM,":OUTP:BB2:SYST NTSC;"); break;
     case 3 : WriteCOMPort(DUTCOM,":OUTP:BB3:SYST NTSC;"); break;
     case 4 : WriteCOMPort(DUTCOM,":OUTP:BB4:SYST NTSC;"); break;
     case 5 : WriteCOMPort(DUTCOM,":OUTP:BB5:SYST NTSC;"); break;
     case 6 : WriteCOMPort(DUTCOM,":OUTP:BB6:SYST NTSC;"); break;
     case 7 : WriteCOMPort(DUTCOM,":OUTP:BB7:SYST NTSC;"); break;
     case 8 : WriteCOMPort(DUTCOM,":OUTP:BB8:SYST NTSC;"); break;
    }
  }
   

 // Send addr for BB#
 CopyString(DUTStr,0,":FACT:V24C:ADDR",0,-1);
 CopyString(DUTStr,StringLength(DUTStr),V24Addr[BBNo],0,-1);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.1);

 
 // Reset af PAL & NTSC faser til default v�rdier g�res i MakeSyncOffsetCal 
   


 SetPhase(PhaseValue + PhaseOffset);
 SetScH(ScHValue + ScHOffset);
 

 // her ventes indtil brugeren har tastet OK=F4 eller FEJL=F9
 while (done == FALSE) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 }



 if (PhaseScHOk == FALSE)
   switch (TV){
    case PAL  : MessagePopup (" Phase, ScH og burst amplitude kalibrering", " FEJLET"); 
    			BBCalOk = FALSE;
    			break;
    case NTSC : MessagePopup (" Phase & ScH kalibrering", " FEJLET");
    			BBCalOk = FALSE;
    			break;
   }
  
 
 
 
 if (PhaseScHOk == TRUE) {
  if (TV == PAL){
   if ((BBNo % 2) == 1)
     WriteCOMPort(DUTCOM,"COMM 'HX$';");		// store in EEPROM
    else
     WriteCOMPort(DUTCOM,"COMM 'JX$';");
  }


   if (TV == NTSC){
    if ((BBNo % 2) == 1)
      WriteCOMPort(DUTCOM,"COMM 'HY$';");		// store in EEPROM
     else
      WriteCOMPort(DUTCOM,"COMM 'JY$';");
   }

  Delay(0.5);
  PhaseScHOk = CheckBBCaldata(BBNo,TV);		   // check and save caldata & SW ver

  if (PhaseScHOk == TRUE)
   WriteBBCalDate(BBNo);

 } //if


 if ((BBNo == 2) && (TV == NTSC))
  if (PhaseScHOk == TRUE) {
   SetPM5662(NTSC);
   MessagePopup (" Stik CX302", "Check Black Burst signal p� 5662M         ");
  } 


  HidePanel (phasePNL);
 

  if (PhaseScHOk == TRUE)
    return TRUE;
   else
    return FALSE;
} // MakePhaseCal





//-------------------------------------------------------------------------------
int MakeANLTPGPhaseCal(int ANLTPGNo, int TVSys, int GetXX1) {
// ANLTPGNo  =  9   TPG2 PT8601
// ANLTPGNo  = 10   TPG2 PT8631
// ANLTPGNo  = 11   TPG5 PT8631

// GetXX1  Angiver om stikforbindelse til PT8631 skal angives af brugeren eller ej.
//         Ved PT8601 er stikforbindelsen altid kendt

char TitleStr[60], *strread;
int handle_returned, controlID_returned;

 AnalogTPGSelected = TRUE;
 
 TV = TVSys;

 if (TVSys == PAL)
  switch (ANLTPGNo){
   case ANLTPG2_8601 : Fmt(TitleStr,"%s< PAL Fase, ScH for Analog TPG 2  (PT8601) "); break;
   case ANLTPG2_8631 : Fmt(TitleStr,"%s< PAL Fase, ScH for Analog TPG 2  (PT8631) "); break;
   case ANLTPG5_8631 : Fmt(TitleStr,"%s< PAL Fase, ScH for Analog TPG 5  (PT8631) "); break;
  }
 else 
 if (TVSys == NTSC)
  switch (ANLTPGNo){
   case ANLTPG2_8601 : Fmt(TitleStr,"%s< NTSC Fase, ScH for Analog TPG 2  (PT8601) "); break;
   case ANLTPG2_8631 : Fmt(TitleStr,"%s< NTSC Fase, ScH for Analog TPG 2  (PT8631) "); break;
   case ANLTPG5_8631 : Fmt(TitleStr,"%s< NTSC Fase, ScH for Analog TPG 5  (PT8631) "); break;
  }

 SetPanelAttribute (phasePNL, ATTR_TITLE, TitleStr);
 SetCtrlAttribute (phasePNL, SCH_PNL_BURST, ATTR_VISIBLE, FALSE);

 done = FALSE;
 PhaseScHOk == FALSE;
 
 DisplayPanel (phasePNL);

 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILOP_BTN, ATTR_DIMMED,TRUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILNED_BTN, ATTR_DIMMED,TRUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILOP_BTN, ATTR_DIMMED,FALSE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILNED_BTN, ATTR_DIMMED,FALSE);
 SetCtrlAttribute (phasePNL, SCH_PNL_SCH_DEC, ATTR_FRAME_COLOR,VAL_BLUE);
 SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_DEC, ATTR_FRAME_COLOR,VAL_LT_GRAY);

 
 if (TVSys == PAL) {
  PhaseValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MAX_VALUE, PhaseValue + 1000);
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MIN_VALUE, PhaseValue - 1000);
  SetCtrlVal (phasePNL, SCH_PNL_PHASE_SLIDE, PhaseValue);
  ScHValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MAX_VALUE, ScHValue + 200);
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MIN_VALUE, ScHValue - 200);
  SetCtrlVal (phasePNL, SCH_PNL_SCH_SLIDE, ScHValue);
  ScHOffset = TSGScHOffsetPAL;
  PhaseOffset = TSGPhaseOffsetPAL;
 } 
 else {
  PhaseValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MAX_VALUE, PhaseValue + 1000);
  SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_SLIDE, ATTR_MIN_VALUE, PhaseValue - 1000);
  SetCtrlVal (phasePNL, SCH_PNL_PHASE_SLIDE, PhaseValue);
  ScHValue = 0;
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MAX_VALUE, ScHValue + 200);
  SetCtrlAttribute (phasePNL, SCH_PNL_SCH_SLIDE, ATTR_MIN_VALUE, ScHValue - 200);
  SetCtrlVal (phasePNL, SCH_PNL_SCH_SLIDE, ScHValue);
  ScHOffset = TSGScHOffsetNTSC;
  PhaseOffset = TSGPhaseOffsetNTSC;
 }
 

  
 // -----  kun for PT8631  ------------------
 if (GetXX1 == TRUE)
  if (GetTPGXX1Connection() == 3){
   PhaseScHOk = FALSE;
   return FALSE;
  }


 

 ResetTextBox(phasePNL, SCH_PNL_PHASESCHTXTBOX,"");
 if (TV == PAL) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST PAL_ID;SCHP 0;");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT ANL SIG     til 5662 CH-B\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662G: VECT B        INT REF \n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662M: WFM  A-B  2H  INT REF  X-MAG\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," ScH afl�ses p� 5662G      Fase afl�ses p� 5662M\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," ScH afl�ses p� 5662G      Fase afl�ses p� 5662M\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX,"\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved fejl: Tryk F9           ");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved OK:   Tryk F4");
  SetPM5662(PAL);
 }

 if (TV == NTSC) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST NTSC;SCHP 0;");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Forbind DUT ANL SIG     til 5662 CH-B\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662G: WFM  A-B  2H  INT REF  X-MAG\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Indstil 5662M: VECT B        INT REF \n\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," ScH afl�ses p� 5662M      Fase afl�ses p� 5662G\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX,"\n");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved fejl: Tryk F9           ");
  SetCtrlVal(phasePNL, SCH_PNL_PHASESCHTXTBOX," Ved OK:   Tryk F4");
  SetPM5662(NTSC);
 }

 
 
 if (TV == PAL){
   Delay(0.2);
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); //<<<<<<<<<<<<<<<<<<<<<<<<<<<
   Delay(xd);
   WriteCOMPort(DUTCOM,"SYST PALB;");
   Delay(0.2);
   if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601))
    WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST PAL_ID; PATT BLAC; TEXT OFF;");
   else 
   if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631))
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL_ID; PATT BLAC;");
   else 
   if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631))
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL_ID; PATT BLAC;");
    
   Delay(0.2);

 // Send addr for ANLTPG
  if (ANLTPGNo == ANLTPG2_8601)
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
  if ((ANLTPGNo == ANLTPG2_8631) || (ANLTPGNo == ANLTPG5_8631))
   if (XX1_Stik == XA1_Stik)
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
   else
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1

   Delay(0.2);

   
   // reset TPG   PAL
   WriteCOMPort(DUTCOM, "COMM 'AK',0;"); // 980401 AG �ndret til AK (=PAL_ID)
   Delay(0.1);
   WriteCOMPort(DUTCOM, "COMM 'AH',0;");
   Delay(0.1);
   WriteCOMPort(DUTCOM, "COMM 'AX$';");
   Delay(0.5);
   WriteCOMPort(DUTCOM, "COMM 'AO',0;");
   Delay(0.1);
  }  
  
  if (TV == NTSC){
   Delay(0.2);
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); //<<<<<<<<<<<<<<<<<<<<<<<<<<<<
   Delay(xd);
   WriteCOMPort(DUTCOM,"SYST NTSC;");
   Delay(0.5);
   if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601))
    WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST NTSC; PATT BLAC; TEXT OFF;");
   else 
   if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631))
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST NTSC; PATT BLAC; TEXT OFF;");
   else 
   if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631))
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST NTSC; PATT BLAC; TEXT OFF;");

   Delay(0.2);
    
  // Send addr for ANLTPG
  if (ANLTPGNo == ANLTPG2_8601)
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
  if ((ANLTPGNo == ANLTPG2_8631) || (ANLTPGNo == ANLTPG5_8631))
   if (XX1_Stik == XA1_Stik)
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
   else
    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1

   Delay(0.2);
   // reset TPG   NTSC
   WriteCOMPort(DUTCOM, "COMM 'AM',0;");
   Delay(0.1);
   WriteCOMPort(DUTCOM, "COMM 'AH',0;");
   Delay(0.1);
   WriteCOMPort(DUTCOM, "COMM 'AY$';");
   Delay(0.5);
   WriteCOMPort(DUTCOM, "COMM 'AO',0;");
   Delay(0.1);
  }
   

 // Send addr for Analog TPG  
 if (ANLTPGNo == ANLTPG2_8601)
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
 if ((ANLTPGNo == ANLTPG2_8631) || (ANLTPGNo == ANLTPG5_8631))
  if (XX1_Stik == XA1_Stik)
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");  // stik XA1
  else
   WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");  // stik XB1
 
 Delay(0.05);
 
 SetTPGPhase(PhaseValue + PhaseOffset);
 SetTPGScH(ScHValue + ScHOffset);
 

 // her ventes indtil brugeren har tastet OK=F4 eller FEJL=F9
 while (done == FALSE) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 }



 if (PhaseScHOk == FALSE)
   switch (TV){
    case PAL  : MessagePopup (" Phase, ScH og burst amplitude kalibrering", " FEJLET"); 
    			BBCalOk = FALSE;
    			break;
    case NTSC : MessagePopup (" Phase & ScH kalibrering", " FEJLET");
    			BBCalOk = FALSE;
    			break;
   }
  

 
 
 if (PhaseScHOk == TRUE) {
  if (TV == PAL)
    WriteCOMPort(DUTCOM,"COMM 'AX$';");		// store in EEPROM


  if (TV == NTSC)
   WriteCOMPort(DUTCOM,"COMM 'AY$';");		// store in EEPROM

  Delay(0.5);
  PhaseScHOk = CheckBBCaldata(ANLTPGNo,TV); 

  Delay(0.1);
  if (PhaseScHOk == TRUE)
   WriteBBCalDate(ANLTPGNo);

 } //if



  HidePanel (phasePNL);
 

  if (PhaseScHOk == TRUE)
    return TRUE;
   else
    return FALSE;
} // MakeANLTPGPhaseCal







// ------------ Analog TPG Pattern ----------------------------------------------------
int CheckANLTPGPattern(int ANLTPGNo, int GetXX1){
double PatternShiftDelay;
int handle_returned, controlID_returned;
char *usertxt;

// GetXX1 bruges ikke
// SDINo:     SDITPG = 1,2 eller 5       SDI Black = 34,56 eller 78
//            SDITSG = 22,23 eller 24
// TVLines:   L625 eller L525

 ANLTPGPattOk = TRUE;
 PatternShiftDelay = 3.0;

 ResetTextBox(pattPNL, PATT_PNL_TXTBOX,"");

 ANLTPGPattOk = WriteProtect(OFF,FALSE);
 if (ANLTPGPattOk == FALSE){
  HidePanel (pattPNL);
  return ANLTPGPattOk;
 }
 Delay(0.1);
 

 if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601)){
  WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST PAL; PATT CBEBU;"); 
  PT86No = 1;
 } 
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631)){
  WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL; PATT CBEBU;"); 
  PT86No = 31;
 } 
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631)){
  WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL; PATT CBEBU;"); 
  PT86No = 31;
 } 

 SetPM5662(PAL);
 SetCtrlVal(pattPNL, PATT_PNL_SCOPMSG," ");
 
 if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601))
  SetPanelAttribute (pattPNL, ATTR_TITLE, " Analog TPG Pattern  (PT8601) ");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631))
  SetPanelAttribute (pattPNL, ATTR_TITLE, " Analog TPG2 Pattern  (PT8631) ");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631))
  SetPanelAttribute (pattPNL, ATTR_TITLE, " Analog TPG5 Pattern  (PT8631) ");
 
 if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601))
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Forbind ANL SIG til PM5662 CH-B\n");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631))
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Forbind ANL-TPG2 til PM5662 CH-B\n");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631))
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Forbind ANL-TPG5 til PM5662 CH-B\n");

 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Indstil PM5662G INPUT = CH-B\n");
 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Barco monitor indstilles til composite: Tast 'INP1'\n\n");
 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Tast F4: OK\n      F9: STOP\n\n");
 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," P� monitor vises derefter f�lgende pattern i r�kkef�lge:\n");
 
 if (PT86No == 1){
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," PAL:   EBU Colorbar     Colorbar+Red    Window 100%\n");
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," NTSC:  SMPTE Colorbar   Multi Burst     Cross Hatch\n");
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Teksten 'TOMMY' eller 'DENNIS' vises nogle steder:\n\n");
 }
 if (PT86No == 31){
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," PAL:   EBU Colorbar     Philips 4:3     Window 100%\n");
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," NTSC:  SMPTE Colorbar   Pluge           Cross Hatch\n");
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Teksten 'TOMMY OG DENNIS' eller 'PTV PROTELE VISION' vises nogle steder:\n");
  SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Teksten i Philips 4:3 skifter position\n\n");
 }

 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Kontroller at alle pattern vises korrekt p� monitoren\n");
 SetCtrlVal(pattPNL, PATT_PNL_TXTBOX," Tast F4: OK\n      F9: FEJL");

 DisplayPanel (pattPNL);
 WaitForContinue();

 if (ANLTPGPattOk == FALSE){
  MessagePopup (" Analog TPG Pattern Test", " AFBRUDT");
  HidePanel(pattPNL);
  return FALSE;
 }
 
 done = FALSE;

 // ----- Analog TSG pattern test   8601 -------------------
 if (PT86No == 1)
 while (done == FALSE){
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  WriteCOMPort(DUTCOM,"SYST PAL; PATT CBEBU;");
  WriteCOMPort(DUTCOM,"TEXT ON; TEXT POS1;");
  WriteCOMPort(DUTCOM,"TEXT ' TOMMY ';");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"SYST PAL; PATT CBRED75;");
  WriteCOMPort(DUTCOM,"TEXT ON; TEXT POS2;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"SYST PAL; PATT WIN100;");
  WriteCOMPort(DUTCOM,"TEXT OFF;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"SYST NTSC; PATT CBSMPTE;");
  WriteCOMPort(DUTCOM,"TEXT ON; TEXT POS1;");
  WriteCOMPort(DUTCOM,"TEXT ' DENNIS ';");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"SYST NTSC; PATT MULT;");
  WriteCOMPort(DUTCOM,"TEXT ON; TEXT POS2;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"SYST NTSC; PATT CROS;");
  WriteCOMPort(DUTCOM,"TEXT OFF;");
  Delay(PatternShiftDelay);
 } // while

 // ----- Analog TSG pattern test   8631 -------------------
 if (PT86No == 31)
 while (done == FALSE){
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL; PATT CBEBU;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL; PATT CBEBU;");
  WriteCOMPort(DUTCOM,"TEXT:STR1 ON; STR1 ' DENNIS ';");
  WriteCOMPort(DUTCOM,"STR2 ON; STR2 ' & ';");
  WriteCOMPort(DUTCOM,"STR3 ON; STR3 ' TOMMY ';");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL; PATT PHIL43;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL; PATT PHIL43;");
  Delay(xd);  // <<<<<<<<<<<<< (111) skal fjernes
  WriteCOMPort(DUTCOM,"TEXT:STR1 ON; STR1 ' TOMMY ';"); 
  WriteCOMPort(DUTCOM,"STR2 ON; STR2 ' DENNIS ';");
  WriteCOMPort(DUTCOM,"STYL COMP;");
  Delay(1.0);
  WriteCOMPort(DUTCOM,"STYL STAN;");
  Delay(2.0);
  if (done == TRUE) break;
  WriteCOMPort(DUTCOM,"STYL COMP;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL; PATT WIN100;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL; PATT WIN100;");
  WriteCOMPort(DUTCOM,"TEXT:STR1 OFF;");
  WriteCOMPort(DUTCOM,"STR2 OFF;");
  WriteCOMPort(DUTCOM,"STR3 OFF;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST NTSC; PATT CBSMPTE;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST NTSC; PATT CBSMPTE;");
  WriteCOMPort(DUTCOM,"TEXT:STR1 ON; STR1 ' PTV ';");
  WriteCOMPort(DUTCOM,"STR2 ON; STR2 ' PROTELE ';");
  WriteCOMPort(DUTCOM,"STR3 ON; STR3 ' VISION ';");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST NTSC; PATT PLUG;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST NTSC; PATT PLUG;");
  Delay(PatternShiftDelay);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (done == TRUE) break;
  if (ANLTPGNo == ANLTPG2_8631)
    WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST NTSC; PATT CROS;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST NTSC; PATT CROS;");
  WriteCOMPort(DUTCOM,"TEXT:STR1 OFF;");
  WriteCOMPort(DUTCOM,"STR2 OFF;");
  WriteCOMPort(DUTCOM,"STR3 OFF;");
  Delay(PatternShiftDelay);
 } // while

 if (ANLTPGPattOk == FALSE){
  MessagePopup (" Analog TPG Pattern Test", " FEJLET");
  HidePanel(pattPNL);
  return FALSE;
 }

 if ((AppType == PT5210) && (ANLTPGNo == ANLTPG2_8601))
  WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST PAL; PATT CBEBU;TEXT OFF;");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG2_8631))
  WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL; PATT CBEBU;TEXT:STR1 OFF;STR2 OFF;STR3 OFF;");
 if ((AppType == PT5230) && (ANLTPGNo == ANLTPG5_8631))
  WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL; PATT CBEBU;TEXT:STR1 OFF;STR2 OFF;STR3 OFF;");
  
 MessagePopup (" Analog TPG Pattern Test", " OK");
 HidePanel(pattPNL);
 
return TRUE;
} //CheckANLTPGPattern






//----------------------------------------------------------------------------
int CalPowerSupply(void) {
/* 
Justering af +5V supply med potmeter p� power supply.
Kontrolm�ling af +12V og -5V med AD-konverter PCF8591 p� main board.
�vre og nedre gr�nse for overv�gning af +12V og -5V beregnes og gemmes i EEPROM. Korrekt gemning af 
data i EEPROM kontrolleres.
Overv�gning af +12V og -5V g�res aktiv med kommandoen  ":FACT:MAIN:PSC ON;"
*/ 
double voltmeas, VMax,VMin;
int handle_returned, controlID_returned;
int Temp, 
	Plus5, 
	Minus5, Minus5Min, Minus5Max,
	Plus12, Plus12Min, Plus12Max,
	Plus12read[2],Minus5read[2],
	p, bytes_written, fhandle, CalSavedOk,
    ADCOk;
char *strread, *tt, *dd, dato[20], wrtbuf[100], MsgTxt[50], TitleStr[30], MasterSPGSW[20], MasterKUStr[20];
 
 CalibratingPS = TRUE;
 CheckingPS = FALSE;
 CheckingLTCVCO = FALSE;
 CheckingOven = FALSE;
 CheckingAudioVCO = FALSE;

 // Make A/D converter results visible
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (vccPNL, VCC_PNL_TEXTMSG, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (vccPNL, VCC_PNL_DECORATION, ATTR_VISIBLE, TRUE);


 DisplayPanel(vccPNL);
 SetPanelAttribute (vccPNL, ATTR_TITLE, " +5VDC Kalibrering ");


 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (vccPNL);
  VoltOk = FALSE;
  return FALSE;
  }

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);

 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(vccPNL);
  return FALSE;
 }
 
 
 ResetTextBox (vccPNL, VCC_PNL_TXTBOX, "");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Juster 5 volt forsyning med potmeter p� powersupply\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Der m�les med HP34401 i testpunkt +5V ved stikket XK1\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " HUSK: N�r der trykkes p� F4, SKAL proben holdes p� testpunktet +5V\n\n\n");
// PSC s�ttes = ON uanset om der trykkes F4 eller F9. 
// Hvis PSC kun s�ttes = ON n�r der trykkes F4 skal f�lgende advarsel vises. 970901 PF
// SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " ADVARSEL: Hvis der trykkes F9 vil +12 og -5 VDC ikke bliver overv�get n�r apparatet er i drift.\n");
// SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, "           Apparatet p� IKKE afleveres i denne tilstand.\n\n\n");
 VMax = Max5;
 VMin = Min5;
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MAX_VALUE, VMax + 0.3);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MIN_VALUE, VMin - 0.3);


 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved OK:   Tryk F4\n");
 Fmt(MsgTxt,"%s<%f[p2] - %f[p2] VDC",VMin,VMax);
 
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_LABEL_TEXT,MsgTxt);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_TEXT_JUSTIFY,VAL_CENTER_JUSTIFIED);

 done = FALSE;
 VoltOk = TRUE;
 ADCOk = TRUE;
 CalSavedOk = FALSE;

 while (done == FALSE) {
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  
  DisableBreakOnLibraryErrors();
  ErrIEEE = hp34401a_singleMeas (hp34401, &voltmeas);
  EnableBreakOnLibraryErrors();
  
  ReadADC(&Temp, &Plus5, &Minus5, &Plus12);
  Fmt(MsgTxt," %i[w3]   (%i[w3]-%i[w3])",Plus5,ADC5Min,ADC5Max);
  SetCtrlVal (vccPNL, VCC_PNL_PLUS5, MsgTxt);
  Fmt(MsgTxt," %i[w3]   (%i[w3]-%i[w3])",Plus12,ADC12Min,ADC12Max);
  SetCtrlVal (vccPNL, VCC_PNL_PLUS12, MsgTxt);
  Fmt(MsgTxt," %i[w3]   (%i[w3]-%i[w3])",Minus5,ADCM5Min,ADCM5Max);
  SetCtrlVal (vccPNL, VCC_PNL_MINUS5, MsgTxt);
  SetCtrlVal (vccPNL, VCC_PNL_VCCSLIDE, voltmeas);

  if ((Plus12 > ADC12Max) || (Plus12 < ADC12Min))
	SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_TEXT_COLOR, VAL_RED);
   else
	SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_TEXT_COLOR, VAL_GREEN);

  if ((Plus5 > ADC5Max) || (Plus5 < ADC5Min))
	SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_TEXT_COLOR, VAL_RED);
   else
	SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_TEXT_COLOR, VAL_GREEN);

  if ((Minus5 > ADCM5Max) || (Minus5 < ADCM5Min))
	SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_TEXT_COLOR, VAL_RED);
   else
	SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_TEXT_COLOR, VAL_GREEN);

  if ((voltmeas > VMax) || (voltmeas < VMin)) {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_RED);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_RED);
    }
   else {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_GREEN);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_GREEN);
   } 

 } // while
 

 if ((voltmeas > VMax) || (voltmeas < VMin))
  VoltOk = FALSE;

 if ((Minus5 > ADCM5Max) || (Minus5 < ADCM5Min) ||
     (Plus12 > ADC12Max) || (Plus12 < ADC12Min) ||
     (Plus5 > ADC5Max)   || (Plus5 < ADC5Min))
  ADCOk = FALSE;

 
 if ((VoltOk == TRUE) && (ADCOk == TRUE)){
  
   //Plus12 = Plus12 + 30;   // test af power supply failure
   //Minus5 = Minus5 + 30;
   Plus12Max =  Plus12 + (Plus12 * PSTol / 100);  // �tol ved power supply failure
   Plus12Min =  Plus12 - (Plus12 * PSTol / 100);
   Minus5Max =  Minus5 + (Minus5 * PSTol / 100);
   Minus5Min =  Minus5 - (Minus5 * PSTol / 100);

   Fmt(wrtbuf,"%s<:FACT:MAIN:PS12 %i,%i;",Plus12Min,Plus12Max);
   WriteCOMPort(DUTCOM, wrtbuf);
   Delay(0.05);
   Fmt(wrtbuf,"%s<:FACT:MAIN:PSN5 %i,%i;",Minus5Min,Minus5Max);
   WriteCOMPort(DUTCOM, wrtbuf);
   Delay(0.05);
   FlushInQ(DUTCOM);
   WriteCOMPort(DUTCOM,":FACT:MAIN:PS12?;");
   strread = ReadlnCOMPort(DUTCOM,0.5);
   Scan(strread,"%s>%2i[x]",Plus12read);
   Delay(0.05);
   FlushInQ(DUTCOM);
   WriteCOMPort(DUTCOM,":FACT:MAIN:PSN5?;");
   strread = ReadlnCOMPort(DUTCOM,0.5);
   Scan(strread,"%s>%2i[x]",Minus5read);
   Delay(0.05);
   CalSavedOk = ((Plus12Min == Plus12read[0]) &&
   			     (Plus12Max == Plus12read[1]) &&
   			     (Minus5Min == Minus5read[0]) &&
   			     (Minus5Max == Minus5read[1]));
 }
 

  if ((VoltOk == TRUE) && ((CalSavedOk == TRUE))){
   WriteCOMPort(DUTCOM, ":FACT:MAIN:PSC ON;");
   
   // get system date 
   dd = DateStr();
   CopyString(dato,0,dd,8,2);
   CopyString(dato,strlen(dato),dd,0,2);
   CopyString(dato,strlen(dato),dd,3,2);
 
   // get system time
   tt = TimeStr();
   
   fhandle = OpenFile (PowerSupplyLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   
   strread = ReadMasterSWVer();
   CopyString(MasterSPGSW,0,strread,0,-1);
   
   strread = ReadMasterKUStr();
   CopyString(MasterKUStr,0,strread,0,-1);
      
   // Power supply cal data + master SW + SPG SW gemmes i power supply logfil
   Fmt(wrtbuf,"%s<%s,%s,KU%s,ADC_12=,%i[w3],%i[w3],%i[w3],ADC_M5=,%i[w3],%i[w3],%i[w3],Master-SPG SW=%s,%i\n",dato,tt,MasterKUStr,Plus12,Plus12read[0],Plus12read[1],Minus5,Minus5read[0],Minus5read[1],MasterSPGSW,AppType);	
   bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
   CloseFile(fhandle);
   
   MessagePopup (" Power Supply Kalibrering"," OK\n Kalibreringsdata gemt i EEPROM");
  }
  else{
   WriteCOMPort(DUTCOM, ":FACT:MAIN:PSC ON;");
   if ((CalSavedOk == FALSE) && (VoltOk == TRUE))
    MessagePopup (" Power Supply Kalibrering"," FEJLET\n Data IKKE gemt korrekt i EEPROM\n");
   if (VoltOk == FALSE)
    MessagePopup (" Power Supply Kalibrering"," FEJLET\n");
  } 
 
 CalibratingPS = FALSE;
 HidePanel(vccPNL);
return VoltOk;
} // CalPowerSupply()









//-------------------------------------------------------------------------------
int ReadADC(int *Temp, int *Plus5, int *Minus5, int *Plus12){
char *strread;
int aa[4];

 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM, ":FACT:ADC:READ?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 Scan(strread,"%s>%4i[x]",aa);
 *Temp = aa[0];
 *Plus5 = aa[1];
 *Minus5 = aa[2];
 *Plus12 = aa[3];

return strlen(strread);
} // ReadADC(int *Temp, int *Plus5, int *Minus5, int *Plus12)








//-----------------------------------------------------------------------------------
int CheckFan(void) {
int handle_returned, controlID_returned;
int ADC1,ADC2,ADC3,ADC4,Temp;
char MsgTxt[80];

  
 DisplayPanel(fanPNL);
 SetPanelAttribute (fanPNL, ATTR_TITLE, " Bl�ser Kontrol ");
 ResetTextBox (fanPNL, FAN_PNL_TXTBOX, "");

 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (fanPNL);
  FanOk = FALSE;
  return FALSE;
  }

 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX," Check at m�lt temperatur er korrekt ved stuetemperatur\n\n");
 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX," NTC modstanden R410 varmes derefter op med varmebl�ser\n");
 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX," NB: Bl�seren k�rer altid svagt n�r apparatet er t�ndt\n\n");
 Fmt(MsgTxt,"%s< Kontroller at bl�seren starter, n�r temperaturen er ca %i�C\n\n",FanRunTemp);
 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX, MsgTxt);
 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(fanPNL,FAN_PNL_TXTBOX, " Ved OK:   Tryk F4\n");
 SetCtrlAttribute (fanPNL, FAN_PNL_ADCSTR, ATTR_TEXT_COLOR, VAL_BLUE);
 
 FanOk = TRUE; 
 done = FALSE;

 while (done == FALSE) {
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  
  // read ADC
  ReadADC(&ADC1,&ADC2,&ADC3,&ADC4);
  Delay(0.3);
  
  if (ADC1 > 104)
    Temp = (int)(215-ADC1)/2.467;
   else 
    Temp = (int)(192-ADC1)/1.95;
  
  Fmt(MsgTxt,"%s< %i�C",Temp);
  SetCtrlVal(fanPNL,FAN_PNL_ADCSTR,MsgTxt);
  SetCtrlVal(fanPNL,FAN_PNL_TERMOMETER,Temp);

 
  ProcessDrawEvents();

 } // while

 if (FanOk == TRUE)
   MessagePopup(" Bl�ser test"," OK");
  else 
   MessagePopup(" Bl�ser test"," FEJLET");

 HidePanel(fanPNL);
return FanOk;
} // CheckFan()





//----------------------------------------------------------------------------
int CheckOven(void) {
// Sp�ndingen m�les i TP7
double SPGTP7meas;
int handle_returned, controlID_returned;
char MsgTxt[30];

 CheckingLTCVCO = FALSE;
 CheckingOven = TRUE;
 CalibratingPS = FALSE;
 CheckingPS = FALSE;
 CheckingAudioVCO = FALSE;
 
 // Make A/D converter results invisible
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_TEXTMSG, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_DECORATION, ATTR_VISIBLE, FALSE);
 
 DisplayPanel(vccPNL);
 SetPanelAttribute (vccPNL, ATTR_TITLE, " Kontrol af Ovn ");
 ResetTextBox (vccPNL, VCC_PNL_TXTBOX, "");

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);

 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(vccPNL);
  OvenOk = FALSE;
  return FALSE;
 }

 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (vccPNL);
  OvenOk = FALSE;
  return FALSE;
  }

 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MAX_VALUE, SPGTP7Max + 0.5);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MIN_VALUE, SPGTP7Min - 0.5);
 
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Sp�ndingen i TP7 kontrolleres, n�r apparatet har v�ret t�ndt > 15 min.\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Der m�les med HP34401 i TP7\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl:  Check sp�ndingen i TP109 = 10.4V\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, "            Check sp�ndingen i TP110 = -3.8V\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved OK:   Tryk F4\n");
 Fmt(MsgTxt,"%s<%f[p2] - %f[p2] VDC",SPGTP7Min,SPGTP7Max);
 
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_LABEL_TEXT,MsgTxt);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_TEXT_JUSTIFY,VAL_CENTER_JUSTIFIED);

 done = FALSE;

 while (done == FALSE) {
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  
  DisableBreakOnLibraryErrors();
  ErrIEEE = hp34401a_singleMeas (hp34401, &SPGTP7meas);
  EnableBreakOnLibraryErrors();
  SetCtrlVal (vccPNL, VCC_PNL_VCCSLIDE, SPGTP7meas);
  if ((SPGTP7meas > SPGTP7Max) || (SPGTP7meas < SPGTP7Min)) {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_RED);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_RED);
   }
   else {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_GREEN);
    SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_GREEN);
   } 
    

 } // while

  if (OvenOk == TRUE)
    MessagePopup (" Ovn Temperatur "," M�ling i TP7\n OK");
   else 
    MessagePopup (" Ovn Temperatur "," M�ling i TP7\n FEJLET");
 
 HidePanel(vccPNL);
 CheckingOven = FALSE;
 
return OvenOk;
} //CheckOven




//----------------------------------------------------------------------------
int CheckAudioGenVCO(int AESNo) {
// Sp�ndingen m�les i TP1
double AudioTP1meas;
int handle_returned, controlID_returned;
char MsgTxt[30];

 CheckingLTCVCO = FALSE;
 CheckingAudioVCO = TRUE;
 CalibratingPS = FALSE;
 CheckingOven = FALSE;
 CheckingPS = FALSE;
 
 // Make A/D converter results invisible
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_TEXTMSG, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_DECORATION, ATTR_VISIBLE, FALSE);

 DisplayPanel(vccPNL);
 ResetTextBox (vccPNL, VCC_PNL_TXTBOX, "");
 SetPanelAttribute (vccPNL, ATTR_TITLE, " Audio Generator: Kontrol af VCO sp�nding ");
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP INT;");

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);

 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(vccPNL);
  return FALSE;
 }

 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MAX_VALUE, AudioTP1Max + 1.0);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MIN_VALUE, AudioTP1Min - 1.0);
 
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Sp�ndingen i TP1 kontrolleres, n�r apparatet har v�ret t�ndt i > 15 min.\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " HUSK: Intern 27 MHz ref skal v�re justeret\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Der m�les med HP34401 i TP1\n\n");
 if (AESNo == PT8605)
  SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Hvis sp�ndingen er for h�j: fjern C14 og/eller C15\n");
 if (AESNo == PT8635)
  SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Hvis sp�ndingen er for h�j: fjern C27 og/eller C28\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, "   -      -      er for lav: sammenlod SP2\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " BEM�RK: Proben skal holdes p� TP1 for at m�le korrekt\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved OK:   Tryk F4\n");
 Fmt(MsgTxt,"%s<%f[p2] - %f[p2] VDC",AudioTP1Min,AudioTP1Max);
 
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_LABEL_TEXT,MsgTxt);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_TEXT_JUSTIFY,VAL_CENTER_JUSTIFIED);

 done = FALSE;

 while (done == FALSE) {
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  
  DisableBreakOnLibraryErrors();
  ErrIEEE = hp34401a_singleMeas (hp34401, &AudioTP1meas);
  EnableBreakOnLibraryErrors();
  SetCtrlVal (vccPNL, VCC_PNL_VCCSLIDE, AudioTP1meas);
  if ((AudioTP1meas > AudioTP1Max) || (AudioTP1meas < AudioTP1Min)) {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_RED);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_RED);
    }
   else {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_GREEN);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_GREEN);
    }

 } // while


 HidePanel(vccPNL);
 CheckingAudioVCO = FALSE;
 
return AudioTP1Ok;
} //CheckAudioGenVCO





//----------------------------------------------------------------------------
int CheckLTCVCO(int TVSystem) {
// Sp�ndingen m�les i TP7
double LTCTP7meas,TP7Max,TP7Min;
int handle_returned, controlID_returned;
char MsgTxt[30];
short AddrList[2] = {3,-1};

 EnableLocal (0, AddrList);  // set HP counter (IEEE addr 3) = local

 CheckingLTCVCO = TRUE;
 CheckingAudioVCO = FALSE;
 CalibratingPS = FALSE;
 CheckingOven = FALSE;
 CheckingPS = FALSE;
 
 // Make A/D converter results invisible
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_PLUS12, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_MINUS5, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_TEXTMSG, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (vccPNL, VCC_PNL_DECORATION, ATTR_VISIBLE, FALSE);
 
 DisplayPanel(vccPNL);
 ResetTextBox (vccPNL, VCC_PNL_TXTBOX, "");

 if (TVSystem == PAL){
   TP7Max = LTC_TP7MaxG;
   TP7Min = LTC_TP7MinG;
   SetPanelAttribute (vccPNL, ATTR_TITLE, " LTC: Kontrol af VCO sp�nding (PAL) ");
   }
  else {
   TP7Max = LTC_TP7MaxM;
   TP7Min = LTC_TP7MinM;
   SetPanelAttribute (vccPNL, ATTR_TITLE, " LTC: Kontrol af VCO sp�nding (NTSC) ");
   }

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);
 
 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(vccPNL);
  LTCTP7Ok = FALSE;
  return FALSE;
 }

 
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel(vccPNL);
  LTCTP7Ok = FALSE;
  return FALSE;
 }
 
 
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MAX_VALUE, TP7Max + 1.0);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_MIN_VALUE, TP7Min - 1.0);
 
 if (TVSystem == PAL){
   Set5640Standard("G");
   WriteCOMPort(DUTCOM,":INP:GENL:INP A; SYST PALB;");
  }
  else{
   Set5640Standard("M");
   WriteCOMPort(DUTCOM,":INP:GENL:INP A; SYST NTSC;");
  }
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Sp�ndingen i TP7 kontrolleres, n�r apparatet har v�ret t�ndt i > 15 min.\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Der m�les med HP34401 i TP7\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl: Check sp�nding i TP6 = 5 Volt\n");
 if (TVSystem == PAL)
   SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, "           Check frekvens i TP8 = 4.000 kHz\n\n");
  else
   SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, "           Check frekvens i TP8 = 4.795 kHz\n\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(vccPNL,VCC_PNL_TXTBOX, " Ved OK:   Tryk F4");
 Fmt(MsgTxt,"%s<%f[p2] - %f[p2] VDC",TP7Min,TP7Max);
 
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_LABEL_TEXT,MsgTxt);
 SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_TEXT_JUSTIFY,VAL_CENTER_JUSTIFIED);

 done = FALSE;

 while (done == FALSE) {
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  
  DisableBreakOnLibraryErrors();
  ErrIEEE = hp34401a_singleMeas (hp34401, &LTCTP7meas);
  EnableBreakOnLibraryErrors();
  SetCtrlVal (vccPNL, VCC_PNL_VCCSLIDE, LTCTP7meas);
  if ((LTCTP7meas > TP7Max) || (LTCTP7meas < TP7Min)) {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_RED);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_RED);
    }
   else {
    SetCtrlAttribute (vccPNL, VCC_PNL_VCCSLIDE, ATTR_FILL_COLOR, VAL_GREEN);
	SetCtrlAttribute (vccPNL, VCC_PNL_LED, ATTR_ON_COLOR, VAL_GREEN);
    }

 } // while


 HidePanel(vccPNL);
 CheckingLTCVCO = FALSE;
 
return LTCTP7Ok;
} //CheckLTCVCO




//-------------------------------------------------------------------------------
int JusterNCO(int ATPGNo){

 JusterNCOOk = TRUE;
 ResetTextBox (filterPNL, FILT_PNL_TXTBOX, "");
 if (ATPGNo = ANLTPG2_8601)
  SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG (PT8601)  Justering af 13.5 MHz amplitude ");
 if (ATPGNo = ANLTPG2_8631)
  SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG2 (PT8631)  Justering af 13.5 MHz amplitude ");
 if (ATPGNo = ANLTPG5_8631)
  SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG5 (PT8631)  Justering af 13.5 MHz amplitude ");

 SetCtrlAttribute (filterPNL, FILT_PNL_CCIR17_BTN, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_MULTIPULSE_BTN, ATTR_VISIBLE,FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_SINXX_BTN, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_LINESWEEP_BTN, ATTR_VISIBLE,FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_MULTIBURST_BTN, ATTR_VISIBLE,FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_SHOWHIDEFILTJUST_BTN, ATTR_VISIBLE,FALSE);

 SetCtrlAttribute (filterPNL, FILT_PNL_PATTERNMSG, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_DECORATION, ATTR_VISIBLE, FALSE);
 SetCtrlAttribute (filterPNL, FILT_PNL_TXTBOX, ATTR_HEIGHT, 300);

 DisplayPanel(filterPNL);

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel(filterPNL);
  JusterNCOOk = FALSE;
  return FALSE;
 }

 SelectPM3094Setup(4);
 
 SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F4");
 
 DisplayPanel(filterPNL);
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," M�l med CH2 oscilloscope probe i TP94 \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Juster amplitude til max  (ca 1.2 Vpp)\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Check DC-level = 2.5 � 0.3 VDC\n\n\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Ved fejl: Tryk F9\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Ved OK:   Tryk F4\n");

 WaitForContinue();

 if (JusterNCOOk == TRUE)
   MessagePopup (" Justering af amplitude i TP94"," OK");
  else 
   MessagePopup (" Justering af amplitude i TP94"," FEJLET");

 HidePanel(filterPNL);

return JusterNCOOk;
} // JusterNCO()





//---------------------------------------------------------------------------
int JusterFilter(int ATPGNo){
char *strread;

 ATPGNumber = ATPGNo;	  // ATPGNumber bruges i CallBack funktioner
 JusterFilterOk = TRUE;
 ResetTextBox (filterPNL, FILT_PNL_TXTBOX, "");
 switch (ATPGNo){
  case ANLTPG2_8601: SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG  PT8601:  Justering af filter "); break;
  case ANLTPG2_8631: SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG2  PT8631:  Justering af filter "); break;
  case ANLTPG5_8631: SetPanelAttribute (filterPNL, ATTR_TITLE, " Analog TPG5  PT8631:  Justering af filter "); break;
 }

 SetCtrlAttribute (filterPNL, FILT_PNL_CCIR17_BTN, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_MULTIPULSE_BTN, ATTR_VISIBLE,TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_SINXX_BTN, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_LINESWEEP_BTN, ATTR_VISIBLE,TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_MULTIBURST_BTN, ATTR_VISIBLE,TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_SHOWHIDEFILTJUST_BTN, ATTR_VISIBLE,TRUE);
 SetCtrlVal (filterPNL, FILT_PNL_SHOWHIDEFILTJUST_BTN,0);   // set button = off
 
 SetCtrlAttribute (filterPNL, FILT_PNL_PATTERNMSG, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_DECORATION, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (filterPNL, FILT_PNL_TXTBOX, ATTR_HEIGHT, 450);

 SelectPM3094Setup(5);
 SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F5");
 
 DisplayPanel(filterPNL);
 
 
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel(filterPNL);
  JusterNCOOk = FALSE;
  return FALSE;
 }

 if ((ATPGNo == ANLTPG2_8631) || (ATPGNo == ANLTPG5_8631)){
   strread = ReadBBProdDate(ATPGNo,XB1_Stik);   // check til hvilket stik ATPG er forbundet
   if (RS232Timeout == FALSE)
    XX_Stik = XB1_Stik;							// XX_Stik bruges i CallBack funktioner
 
   if (RS232Timeout == TRUE){
    strread = ReadBBProdDate(ATPGNo,XA1_Stik);
    if (RS232Timeout == FALSE)
     XX_Stik = XA1_Stik;
     else{
      MessagePopup (" Fejl"," Ingen kontakt med Analog TPG");
      HidePanel(filterPNL);
      JusterNCOOk = FALSE;
      return FALSE;
      }
   } // if (RS232Timeout
 } // if ((ATPGNo
 

 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Indstil network analyzer HP3577A\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"     INPUT = A\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"     DISPLY FCTN = LOG MAGFREQ:  FREQ start - stop = 0.1 - 20 MHz \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"     DISPLY FCTN = DELAY:        FREQ start - stop = 0.1 -  6 MHz \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Forbind ANL SIG til network analyzer input\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Forbind PP1 til network analyzer output\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Juster 3 nulpunkter med L20:  8.05 MHz\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"                         L21: 10.00 MHz\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"                         L19: 16.80 MHz\n\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Juster delay med L15/17: max 5 ns variation til 5 MHz\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"                  L16/18:  -  - -      -      -  -  - \n\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Med PP1 monteret:  M�l med scop CH1  (Pattern = SinX/X)\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Juster sinx/x korrektion med L22/C83:  4.0 - 5.8 MHz\n\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Med PP1 monteret:  M�l med scop CH1  (Pattern = Multiburst/Linesweep)\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Check at frekvens response er flad indenfor 1% til 5.0 MHz\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX,"   -   -      -        -    -    -      -    2% til 5.8 MHz\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Mindre just. med L15/17 og L16/18 kan foretages (check delay).\n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," \n");
 SetCtrlVal(filterPNL, FILT_PNL_TXTBOX," Ved fejl: Tryk F9          Ved OK:   Tryk F4\n");

 WaitForContinue();

 if (JusterFilterOk == TRUE)
   MessagePopup (" Justering af filter"," OK");
  else 
   MessagePopup (" Justering af filter"," FEJLET");


 HidePanel(filterPNL);
 HidePanel(showfiltjustPNL);

return JusterFilterOk;
}




//-----------------------------------------------------------------------
int AnalogTPGTotalTest(int ANLTPGNo, int TestNo){

	JusterFilterOk = FALSE;
	JusterNCOOk = FALSE;
	ANLTPGPattOk = FALSE;
	DCOffsetOk = FALSE;
	PhaseScHOk = FALSE;
	
	// opdaterer variablen XX1_Stik
    if (GetTPGXX1Connection() == 3){
     return FALSE;
    }
	
	
	if (TestNo == 1)
	 JusterNCO(ANLTPGNo);

	if ((TestNo == 2) || (JusterNCOOk == TRUE)){
      if (MakeSyncOffsetCal(ANLTPGNo,SYNC_CAL,XX1_Stik) == TRUE)
	   MakeSyncOffsetCal(ANLTPGNo,OFFSET_CAL,XX1_Stik);
    }
 		 
	if ((TestNo == 3) || (DCOffsetOk == TRUE))
	 JusterFilter(ANLTPGNo);

	if ((TestNo == 4) || (JusterFilterOk == TRUE)){
	  if (MakeANLTPGPhaseCal(ANLTPGNo,PAL,FALSE) == TRUE)
	   MakeANLTPGPhaseCal(ANLTPGNo,NTSC,FALSE);
	}      	 

	if ((TestNo == 5) || (PhaseScHOk == TRUE))
	 CheckANLTPGPattern(ANLTPGNo,FALSE);

	
return TRUE;
}



//-------------------------------------------------------------------------------
int ResetANL(int ANLTPGNo){
int button_pressed;
char *usertxt;

  if (AppType == PT5210)
    button_pressed = ConfirmPopup ("Reset Analog Generator PT8601", " ADVARSEL: Reset bruges normalt kun p� nyproducerede generatorer\n Kalibreringsdata nulstilles\n Forts�t?");
   else
    button_pressed = ConfirmPopup ("Reset Analog Generator PT8631", " ADVARSEL: Reset bruges normalt kun p� nyproducerede generatorer\n Kalibreringsdata nulstilles\n Forts�t?");
 
  if (button_pressed == NO)
   return FALSE;
 
  
  
  if (ANLTPGNo != ANLTPG2_8601)
   if (GetTPGXX1Connection() == 3)
    return FALSE;
  

  switch (ANLTPGNo){
    case ANLTPG2_8601: if (AppType == PT5210)
                    	WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");	// 8601 i PT5210
                    	break;
    case ANLTPG2_8631:
    case ANLTPG5_8631: if (AppType == PT5230){
    					if (XX1_Stik == XA1_Stik)
                    	 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;"); // 8631 i PT5230
                   		else
                    	 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");
                    	} 
                    	break;
  }
  
  Delay(0.05);
  WriteCOMPort(DUTCOM,"COMM 'AZ';");  // reset generator
  Delay(2.0);
  

  usertxt = ReadANLTPGSwVer(ANLTPGNo, XX1_Stik);
  if (RS232Timeout == FALSE){
     MessagePopup ("Reset af Analog generator", "Generator er nu reset\nSluk / t�nd for apparatet");
     return TRUE;
     }
    else{
     MessagePopup ("Reset af Analog generator", "Generator er IKKE reset");
     return FALSE;

  }

} // ResetANL()












//----------------------------------------------------------------------------
int CVICALLBACK ScHPilopCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int psch;		
	switch (event) {
		case EVENT_COMMIT:
			 GetCtrlVal(phasePNL,SCH_PNL_SCH_SLIDE,&ScHValue);
			 ScHValue = ScHValue + 3;
			 SetCtrlVal(phasePNL,SCH_PNL_SCH_SLIDE,ScHValue);
			 psch = ScHValue + ScHOffset;
			 if (psch < 0)
			  psch = 2048 + psch;
		
			if (AnalogTPGSelected == TRUE)
			  SetTPGScH(psch);
			 else
			  SetScH(psch);
			break;
	}
	return 0;
}

int CVICALLBACK ScHPilnedCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int psch;
	switch (event) {
		case EVENT_COMMIT:
			 GetCtrlVal(phasePNL,SCH_PNL_SCH_SLIDE,&ScHValue);
			 ScHValue = ScHValue - 3;
			 SetCtrlVal(phasePNL,SCH_PNL_SCH_SLIDE,ScHValue);
			 psch = ScHValue + ScHOffset;
			 if (psch < 0)
			  psch = 2048 + psch;
		
			if (AnalogTPGSelected == TRUE)
			  SetTPGScH(psch);
			 else
			  SetScH(psch);
			break;
	}
	return 0;
}

int CVICALLBACK SchSlideCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int psch;
	switch (event) {
		case EVENT_VAL_CHANGED:
			 GetCtrlVal(phasePNL,SCH_PNL_SCH_SLIDE,&ScHValue);
			 psch = ScHValue + ScHOffset;
			 if (psch < 0)
			  psch = 2048 + psch;
		
			if (AnalogTPGSelected == TRUE)
			  SetTPGScH(psch);
			 else
			  SetScH(psch);
			break;
	}
	return 0;
}



int CVICALLBACK PhasePilopCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int pv;		
	switch (event) {
		case EVENT_COMMIT:
			 GetCtrlVal(phasePNL,SCH_PNL_PHASE_SLIDE,&PhaseValue);
			 PhaseValue = PhaseValue + 5;
			 SetCtrlVal(phasePNL,SCH_PNL_PHASE_SLIDE,PhaseValue);
			 pv = PhaseValue + PhaseOffset;
			 if (TV == PAL) {
			  if (pv < 0)
			   pv = 1105920000 + pv;
			 }  
			 if (TV == NTSC) {
			  if (PhaseValue < 0)
			   pv = 461260800 + pv;
			 }
		
			if (AnalogTPGSelected == TRUE)
			  SetTPGPhase(pv);
			 else
			  SetPhase(pv);
			break;
	}
	return 0;
}


int CVICALLBACK PhasePilnedCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int pv;		
	switch (event) {
		case EVENT_COMMIT:
			 GetCtrlVal(phasePNL,SCH_PNL_PHASE_SLIDE,&PhaseValue);
			 PhaseValue = PhaseValue - 5;
			 SetCtrlVal(phasePNL,SCH_PNL_PHASE_SLIDE,PhaseValue);
			 pv = PhaseValue + PhaseOffset;
			 if (TV == PAL) {
			  if (pv < 0)
			   pv = 1105920000 + pv;
			 }  
			 if (TV == NTSC) {
			  if (pv < 0)
			   pv = 461260800 + pv;
			 } 
		
			if (AnalogTPGSelected == TRUE)
			  SetTPGPhase(pv);
			 else
			  SetPhase(pv);
			break;
	}
	return 0;
}


int CVICALLBACK PhaseSlideCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int pv;
	switch (event) {
		case EVENT_VAL_CHANGED:
			 GetCtrlVal(phasePNL,SCH_PNL_PHASE_SLIDE,&PhaseValue);
			 pv = PhaseValue + PhaseOffset;
			 if (TV == PAL) {
			  if (pv < 0)
			   pv = 1105920000 + pv;
			 }  
			 if (TV == NTSC) {
			  if (pv < 0)
			   pv = 461260800 + pv;
			 }
			if (AnalogTPGSelected == TRUE)
			  SetTPGPhase(pv);
			 else
			  SetPhase(pv);
			break;
	}
	return 0;
}



int CVICALLBACK ExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			done = TRUE;
			if (panel == phasePNL)
			 PhaseScHOk = FALSE;

			break;
	}
	return 0;
}

int CVICALLBACK Phase_LeftCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILOP_BTN, ATTR_DIMMED,TRUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILNED_BTN, ATTR_DIMMED,TRUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILOP_BTN, ATTR_DIMMED,FALSE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILNED_BTN, ATTR_DIMMED,FALSE);

		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_DEC, ATTR_FRAME_COLOR,VAL_BLUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCH_DEC, ATTR_FRAME_COLOR,VAL_LT_GRAY);
			break;
	}
	return 0;
}

int CVICALLBACK Phase_RightCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILOP_BTN, ATTR_DIMMED,TRUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASEPILNED_BTN, ATTR_DIMMED,TRUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILOP_BTN, ATTR_DIMMED,FALSE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCHPILNED_BTN, ATTR_DIMMED,FALSE);
		
		 SetCtrlAttribute (phasePNL, SCH_PNL_SCH_DEC, ATTR_FRAME_COLOR,VAL_BLUE);
		 SetCtrlAttribute (phasePNL, SCH_PNL_PHASE_DEC, ATTR_FRAME_COLOR,VAL_LT_GRAY);
			break;
	}
	return 0;
}

int CVICALLBACK PhaseScHOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			done = TRUE;
			PhaseScHOk = TRUE;
			break;
	}
	return 0;
}



int CVICALLBACK VCCOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: 	done = TRUE;
	 						if (CheckingPS == TRUE)
	 						 VoltOk = TRUE;
	 						if (CheckingOven == TRUE)
	 						 OvenOk = TRUE;
	 						if (CheckingAudioVCO == TRUE)
	 						 AudioTP1Ok = TRUE;
	 						if (CheckingLTCVCO == TRUE)
	 						 LTCTP7Ok = TRUE;
							break;
	}
	return 0;
}


int CVICALLBACK VCCExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	done = TRUE;
	 						if (CalibratingPS == TRUE)
	 						 VoltOk = FALSE;
	 						if (CheckingPS == TRUE)
	 						 VoltOk = FALSE;
	 						if (CheckingOven == TRUE)
	 						 OvenOk = FALSE;
	 						if (CheckingAudioVCO == TRUE)
	 						 AudioTP1Ok = FALSE;
	 						if (CheckingLTCVCO == TRUE)
	 						 LTCTP7Ok = FALSE;
							break;
	}
	return 0;
}

int CVICALLBACK FanOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: done = TRUE; FanOk = TRUE;
						   break;
	}
	return 0;
}

int CVICALLBACK FanExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: done = TRUE;  FanOk = FALSE;
						   break;
	}
	return 0;
}

int CVICALLBACK DataOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: Cont = TRUE;
						   break;
	}
	return 0;
}

int CVICALLBACK ParBBOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: Cont = TRUE;

			break;
	}
	return 0;
}

int CVICALLBACK ParBBExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: Cont = TRUE;
						   ParBBOk = FALSE;

			break;
	}
	return 0;
}

int CVICALLBACK FilterExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
				Cont = TRUE;
				JusterNCOOk = FALSE;
				JusterFilterOk = FALSE;

			break;
	}
	return 0;
}

int CVICALLBACK FilterOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
				Cont = TRUE;

			break;
	}
	return 0;
}



int CVICALLBACK SpecialPatternCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
		 
		 switch (ATPGNumber){
		  case ANLTPG2_8601: if (AppType == PT5210){
		                      WriteCOMPort(DUTCOM,":OUTP:ASIG:SYST PAL;");
		                      WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;");
		                     }
		                     break;
		                    
		  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG2:SYST PAL;");
		  					 if (XX_Stik == XA1_Stik)
		                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");
		                      else 
		                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");
		                     break;
		                    
		  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG5:SYST PAL;");
		 					 if (XX_Stik == XA1_Stik)
		                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;");
		                      else 
		                       WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;");
		                     break;
		 } // switch

		 switch (control){
		  case FILT_PNL_CCIR17_BTN : 
				WriteCOMPort(DUTCOM, "COMM 'AP',17;");
				SelectPM3094Setup(6);
				SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F6");
		  		break;
		  case FILT_PNL_SINXX_BTN : 
				WriteCOMPort(DUTCOM, "COMM 'AP',19;");
				SelectPM3094Setup(8);
				SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F8");
		  		break;
		  case FILT_PNL_MULTIPULSE_BTN : 
				WriteCOMPort(DUTCOM, "COMM 'AP',18;");
				SelectPM3094Setup(6);
				SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F6");
		  		break;
		  case FILT_PNL_LINESWEEP_BTN : 
				WriteCOMPort(DUTCOM, "COMM 'AP',20;");
				SelectPM3094Setup(5);
				SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F5");
		  		break;
		  case FILT_PNL_MULTIBURST_BTN : 
				WriteCOMPort(DUTCOM, "COMM 'AP',12;");
				SelectPM3094Setup(5);
				SetCtrlVal (filterPNL, FILT_PNL_SCOPSETUP," PM3094: FRONTS = F5");
		  		break;
		 } // switch
		break;
	}
	return 0;
}



int CVICALLBACK ShowHideFilterJustCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
int pressed;		
	switch (event) {
		case EVENT_VAL_CHANGED:
			GetCtrlVal (filterPNL, FILT_PNL_SHOWHIDEFILTJUST_BTN, &pressed);
			if (pressed == TRUE)
			  DisplayPanel(showfiltjustPNL);
			 else
			  HidePanel(showfiltjustPNL);
			break;
	}
	return 0;
}
