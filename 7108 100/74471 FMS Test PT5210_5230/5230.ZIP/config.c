#include <ansi_c.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>

#include "cfg.h"
#include <userint.h>
#include "def.h"
#include "bbcal.h"
#include "spgcal.h"
#include "sditest.h"
#include "aescal.h"
#include "ltctest.h"
#include "clktest.h"
#include "cviutil.h"
#include "pt5230.h"


const char CalDataFilePath[2][50] = {"e:\\caldata\\","m:\\measdata\\5230\\"};	// where to save caldata on disk

const char FileExt5210[5] = {"._10"};
const char FileExt5230[5] = {"._30"};

char	FileExt[5];	// file extention filer med kalibreringsdata (SaveCalData)

int ATPGFound,
    SDIFound;

char *strread;
char *usertxt;

char datastr[100];

char BBStr[9][100],			  // PT8608
	 SPGStr[100],
	 SDIStr[6][100],		  // PT8602/03/09/32/33/39
	 ATPGStr[4][100],		  // PT8601/31
	 MULBBStr[100],			  // PT8604
	 AESStr[100],			  // PT8605/35
	 LTCStr[100],			  // PT8607
	 ClockStr[100],			  // PT8637
	 SDIGenlStr[100],		  // PT8606
     PowerSupplyCalStr[50],
     MainIDNStr[40],
     MainKUStr[10];


//overskrifter
const char header_BB[100]      = {"        BB#  Sync Offset GFase    GScH     MFase    MScH        KU      PROD    KAL     SW\n"};
const char header_SPG[100]     = {"         PAL HPH,ScH      NTSC HPH,ScH                       KU      PROD    KAL     SW\n"};
const char header_AES[100]     = {"                                                                KU      PROD    KAL\n"};
const char header_SDI[100]     = {"         SDI#  GFase      MFase     RLoss   Jit    Amsp         KU      PROD    KAL     SW\n"};
const char header_MULBB[100]   = {"                                                                KU      PROD    KAL\n"};
const char header_ATPG[100]    = {"       ATPG# Sync Offset GFase    GScH     MFase   MScH         KU      PROD    KAL     SW\n"};
const char header_LTC[100]     = {"                                                                KU      PROD    KAL\n"};
const char header_SDIGENL[100] = {"                                                                KU      PROD    KAL\n"};


// prototypes
int SaveCalData(void);



//----------------------------------------------------------------------------------------------------------
int ReadBB(int BBNo){
char levelstr[10],
	 offsetstr[10],
	 phasegstr[30],
	 phasemstr[30],
	 proddstr[10],
	 caldstr[10],
	 kustr[10],
	 unitswstr[10];
	 

 // read KU number
if (BBNo <=2)
  Fmt(BBStr[BBNo],"%s<Basic  ,");
 else
  Fmt(BBStr[BBNo],"%s<PT8608 ,");

 strread = ReadBBKUNumber(BBNo,0);
 if (strlen(strread) < 6){
  return FALSE;
 } 
 
 Fmt(kustr,"%s<%s",strread);
 
  
  // read sync level DAC
  FlushInQ(DUTCOM);
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HD?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JD?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HD?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JD?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HD?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JD?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HD?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JD?';"); break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Fmt(levelstr,"%s<%s",strread);
 
  // read offset DAC
  FlushInQ(DUTCOM);
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HC?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JC?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HC?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JC?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HC?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JC?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HC?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JC?';"); break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Fmt(offsetstr,"%s<%s",strread);

  // read PAL phase and ScH
  FlushInQ(DUTCOM);
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HX?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JX?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HX?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JX?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HX?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JX?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HX?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JX?';"); break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Fmt(phasegstr,"%s<%s",strread);

  // read NTSC phase and ScH
  FlushInQ(DUTCOM);
  switch (BBNo){
   case 1: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'HY?';"); break;
   case 2: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_0;COMM 'JY?';"); break;
   case 3: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HY?';"); break;
   case 4: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'JY?';"); break;
   case 5: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HY?';"); break;
   case 6: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'JY?';"); break;
   case 7: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HY?';"); break;
   case 8: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'JY?';"); break;
  }
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Fmt(phasemstr,"%s<%s",strread);


  strread = ReadBBProdDate(BBNo,0);
  Fmt(proddstr,"%s<%s",strread);
 
  strread = ReadBBCalDate(BBNo,0);
  Fmt(caldstr,"%s<%s",strread);
  
  strread = ReadBBSWVer(BBNo);
  if (strlen(strread) > 1)
    Fmt(unitswstr,"%s<%s",strread);
   else
    return FALSE;



  Fmt(BBStr[BBNo],"%s[a]<  %i, %s, %s, %s, %s,      %s, %s, %s, %s\n",BBNo,levelstr,offsetstr,phasegstr,phasemstr,kustr,proddstr,caldstr,unitswstr);


return TRUE;
} // ReadBB(int BBNo)




//----------------------------------------------------------------------------------------------------------
int ReadSPG(void){
char spgcalstr[60],
	 proddstr[10],
	 caldstr[10],
	 kustr[10],
	 unitswstr[10];

 // read KU number
 Fmt(SPGStr,"%s<SPG    ,");

 strread = ReadSPGKUNumber();
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);
 
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:SPGG:READ?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 Fmt(spgcalstr,"%s<%s",strread);
 
 
 strread = ReadSPGProdDate();
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadSPGCalDate();
 Fmt(caldstr,"%s<%s",strread);
 
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,"*IDN?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 CopyString(unitswstr,0,strread,strlen(strread)-9,9);	 // PROTELE,PTxxxx,KUxxxxxx,mm.m-ss.s


 Fmt(SPGStr,"%s[a]< %s,                  %s, %s, %s, %s\n",spgcalstr,kustr,proddstr,caldstr,unitswstr);

 
return TRUE; 
} // ReadSPG(void)








//----------------------------------------------------------------------------------------------------------
int ReadAES(int AESNo){
char proddstr[10],
	 caldstr[10],
	 kustr[10],
	 *strread;
	 
 strread = ReadAudioPTNo(AESNo);
 if (FindPattern (strread, 0, -1, "PT8605", 1, 0) == 0)
  Fmt(AESStr,"%s<PT8605 ,");
 else {
  strread = ReadAudioPTNo(AESNo);
   if (FindPattern (strread, 0, -1, "PT8635", 1, 0) == 0)
    Fmt(AESStr,"%s<PT8635 ,");
   else
    return FALSE;
 } 

 
 // read KU number
 strread = ReadAudioKUNumber(AESNo);
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);

 strread = ReadAudioProdDate(AESNo);
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadAudioCalDate(AESNo);
 Fmt(caldstr,"%s<%s",strread);


 Fmt(AESStr,"%s[aw54]< ");
 Fmt(AESStr,"%s[a]<  %s, %s, %s\n",kustr,proddstr,caldstr);

return TRUE;
} // ReadAES(int AESNo)





//----------------------------------------------------------------------------------------------------------
int ReadSDI(int SDINo){
char phase625str[30],
	 phase525str[30],
	 rlossstr[10],
	 jitstr[10],
	 amspstr[10],
	 proddstr[10],
	 caldstr[10],
	 kustr[10],
	 ptstr[10],
	 unitswstr[10];
int	 lineno,
     xx_stik,
     n,
     sl,
     f,
     p,
     to;

 switch (SDINo){
  case SDIBLACK34: lineno = 1; Fmt(SDIStr[lineno],"%s<PT8609 ,"); break;
  case SDIBLACK56: lineno = 2; Fmt(SDIStr[lineno],"%s<PT8609 ,"); break;
  case SDIBLACK78: lineno = 3; Fmt(SDIStr[lineno],"%s<PT8609 ,"); break;
  case SDITSG2:    lineno = 3; Fmt(SDIStr[lineno],"%s<PT8639 ,"); break;
  case SDITSG3:    lineno = 1; Fmt(SDIStr[lineno],"%s<PT8639 ,"); break;
  case SDITSG4:    lineno = 2; Fmt(SDIStr[lineno],"%s<PT8639 ,"); break;
  case SDITPG1:    lineno = 4; Fmt(SDIStr[lineno],"%s<PT8602 ,"); break;
  case SDITPG2:    lineno = 1; Fmt(SDIStr[lineno],"%s<PT8633 ,"); break;
  case SDITPG5:    lineno = 2; Fmt(SDIStr[lineno],"%s<PT8633 ,"); break;
 }


 // read  PTV,PT86xx,KUxxxxxx,v.v
 FlushInQ(DUTCOM);
 switch (SDINo){
  case SDIBLACK34: WriteCOMPort(DUTCOM,":OUTP:SB34:VERS?;"); break;
  case SDIBLACK56: WriteCOMPort(DUTCOM,":OUTP:SB56:VERS?;"); break;
  case SDIBLACK78: WriteCOMPort(DUTCOM,":OUTP:SB78:VERS?;"); break;
  case SDITSG2:    WriteCOMPort(DUTCOM,":OUTP:STSG2:VERS?;"); break;
  case SDITSG3:    WriteCOMPort(DUTCOM,":OUTP:STSG3:VERS?;"); break;
  case SDITSG4:    WriteCOMPort(DUTCOM,":OUTP:STSG4:VERS?;"); break;
  case SDITPG1:    if (AppType == PT5230) 
  					  WriteCOMPort(DUTCOM,":OUTP:STPG1:VERS?;");       //8632
  					 else 
  					  WriteCOMPort(DUTCOM,":OUTP:SDIS:VERS?;"); break; //8602/03
  case SDITPG2:    WriteCOMPort(DUTCOM,":OUTP:STPG2:VERS?;"); break;   //8633
  case SDITPG5:    WriteCOMPort(DUTCOM,":OUTP:STPG5:VERS?;"); break;   //8633
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);

 
 if (strlen(strread) < 4){
  return FALSE;
 } 
 
 // KU number
 p = FindPattern (strread, 0, -1, "KU", 1, 0);
 if (p < 0){
  if ((SDINo >= SDITSG2) && (SDINo <= SDITSG4))
   SDINo = SDINo - 20;
  Fmt(SDIStr[lineno],"%s[a]<   %i    (ikke kalibreret)\n",SDINo); 
  return TRUE;
 } 

 CopyString(kustr,0,strread,p+2,6);

 // Unit SW ver
 CopyString(unitswstr,0,strread,p+9,strlen(strread)-p-8);

 // PT86xx number
 p = FindPattern (strread, 0, -1, ",PT", 1, 0);
 if (p > 0)
   CopyString(ptstr,0,strread,p+1,6);
  else
   Fmt(ptstr,"%s<PT????");
 
 if (SDINo == SDITPG1)
  Fmt(SDIStr[lineno],"%s<%s ,",ptstr);   // 'ptstr' kan v�re PT8602/03/32
 

  // read SDI GPhase from EEPROM
 FlushInQ(DUTCOM);
 switch (SDINo){
  case SDITSG3:
  case SDIBLACK34: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HX?';"); break;
  case SDITSG4:
  case SDIBLACK56: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HX?';"); break;
  case SDITSG2:
  case SDIBLACK78: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HX?';"); break;

  case SDITPG1:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR SDIT;COMM 'SX?';"); break;   //8632 i PT5230
  case SDITPG2:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'SX?';"); break;  //8633 �verst & nederst
  case SDITPG5:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'SX?';"); break;  //8633 �verst & nederst
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);
 xx_stik = XB1_Stik;
 
 if ((SDINo == SDITPG1) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR SDIS;COMM 'SX?';");	// 8602/03 i PT5210
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 if ((SDINo == SDITPG2) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'SX?';");	// 1 stk. 8633 til stik XA1
  strread = ReadlnCOMPort(DUTCOM,0.5);
  xx_stik = XA1_Stik;
 }

 Fmt(phase625str,"%s<");
 sl = strlen(strread);
 f = 9 - sl;
 for (n=0;n<f;n++)
  Fmt(phase625str,"%s[a]< ");
 Fmt(phase625str,"%s[a]<%s",strread);


  
  // read SDI MPhase from EEPROM
 FlushInQ(DUTCOM);
 switch (SDINo){
  case SDITSG3:
  case SDIBLACK34: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'HY?';"); break;
  case SDITSG4:
  case SDIBLACK56: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_3;COMM 'HY?';"); break;
  case SDITSG2:
  case SDIBLACK78: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'HY?';"); break;

  case SDITPG1:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR SDIT;COMM 'SY?';"); break;   //8632 i PT5230
  case SDITPG2:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'SY?';"); break;  //8633 �verst & nederst
  case SDITPG5:    WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'SY?';"); break;  //8633 �verst & nederst
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);
 
 if ((SDINo == SDITPG1) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR SDIS;COMM 'SY?';");	// 8602/03 i PT5210
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 if ((SDINo == SDITPG2) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'SY?';");	// 1 stk. 8633 til stik XB1
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 Fmt(phase525str,"%s<");
 sl = strlen(strread);
 f = 9 - sl;
 for (n=0;n<f;n++)
  Fmt(phase525str,"%s[a]< ");
 Fmt(phase525str,"%s[a]<%s",strread);

 
 // Return Loss
 strread = ReadRLossInEEPROM(SDINo,xx_stik);
 if (strlen(strread) > 2)
   Fmt(rlossstr,"%s<%s",strread);
  else 
   Fmt(rlossstr,"%s<  -- ");
 
 // Jitter
 strread = ReadJitterInEEPROM(SDINo,xx_stik);
 if (strlen(strread) > 2)
   Fmt(jitstr,"%s<%s",strread);
  else
   Fmt(jitstr,"%s<  -- ");
 
 // Amplitude spectrum
 strread = ReadAmspInEEPROM(SDINo,xx_stik);
 if (strlen(strread) > 2)
   Fmt(amspstr,"%s<%s",strread);
  else 
   Fmt(amspstr,"%s< -- ");

 strread = ReadSDIProdDate(SDINo,xx_stik);
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadSDICalDate(SDINo,xx_stik);
 Fmt(caldstr,"%s<%s",strread);

 switch (SDINo){
  case SDITSG2: SDINo = 2; break;
  case SDITSG3: SDINo = 3; break;
  case SDITSG4: SDINo = 4; break;
 }
 
 Fmt(SDIStr[lineno],"%s[a]<  %i[w2], %s, %s, %s, %s, %s,        %s, %s, %s, %s\n",SDINo,phase625str,phase525str,rlossstr,jitstr,amspstr,kustr,proddstr,caldstr,unitswstr);

 SDIFound = TRUE;

return TRUE;
} // ReadSDI(int SDINo)






//----------------------------------------------------------------------------------------------------------
int ReadATPG(int ATPGNo){
char levelstr[10],
	 offsetstr[10],
	 phasegstr[30],
	 phasemstr[30],
	 proddstr[10],
	 caldstr[10],
	 kustr[10],
	 ptstr[10],
	 unitswstr[10];
int	 lineno,
     xx_stik,
     p;

 switch (ATPGNo){
  case ANLTPG2_8601: lineno = 1; Fmt(ATPGStr[lineno],"%s<PT8601 ,"); break;
  case ANLTPG2_8631: lineno = 2; Fmt(ATPGStr[lineno],"%s<PT8631 ,"); break;
  case ANLTPG5_8631: lineno = 3; Fmt(ATPGStr[lineno],"%s<PT8631 ,"); break;
 }


 // read  PTV,PT86xx,KUxxxxxx,v.v
 FlushInQ(DUTCOM);
 switch (ATPGNo){
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":OUTP:ASIG:VERS?;"); break; 
  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG2:VERS?;"); break;
  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":OUTP:ATPG5:VERS?;"); break;
 } 

 strread = ReadlnCOMPort(DUTCOM,0.5);

 if (strlen(strread) < 6){
  return FALSE;
 } 

 // KU number
 p = FindPattern (strread, 0, -1, "KU", 1, 0);
 CopyString(kustr,0,strread,p+2,6);

 // Unit SW ver
 CopyString(unitswstr,0,strread,p+9,strlen(strread)-p-8);

 // PT86xx number
 p = FindPattern (strread, 0, -1, ",PT", 1, 0);
 CopyString(ptstr,0,strread,p+1,6);
 


 // read level DAC
 FlushInQ(DUTCOM);
 switch (ATPGNo){
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AD?';"); break;
  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AD?';"); break; // �verst til stik XB1
  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AD?';"); break; // nederst til stik XB1
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);
 xx_stik = XB1_Stik;

 if ((ATPGNo == ANLTPG2_8631) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AD?';");	// 2 stk. 8631 (TPG2 til XA1 og TPG5 til XB1)
  strread = ReadlnCOMPort(DUTCOM,0.5);
  xx_stik = XA1_Stik;
 }

 if (strlen(strread) == 2)
   Fmt(levelstr,"%s<0%s",strread);
  else
   Fmt(levelstr,"%s<%s",strread);
 

 // read offset DAC
 FlushInQ(DUTCOM);
 switch (ATPGNo){
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AC?';"); break;
  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AC?';"); break; 
  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AC?';"); break; 
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);

 if ((ATPGNo == ANLTPG2_8631) && (RS232Timeout == TRUE)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AC?';");	// 2 stk. 8631
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 if (strlen(strread) == 2)
   Fmt(offsetstr,"%s<0%s",strread);
  else
   Fmt(offsetstr,"%s<%s",strread);

 
 // read PAL Phase
 FlushInQ(DUTCOM);
 switch (ATPGNo){
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AX?';"); break;
  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AX?';"); break; 
  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AX?';"); break; 
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);

 if ((ATPGNo == ANLTPG2_8631) && (strlen(strread) < 2)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AX?';");	// 2 stk. 8631
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 if (strlen(strread) > 10)
   Fmt(phasegstr,"%s<%s",strread);
  else 
   Fmt(phasegstr,"%s<          %s",strread);

 // read NTSC Phase
 FlushInQ(DUTCOM);
 switch (ATPGNo){
  case ANLTPG2_8601: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR ANLS;COMM 'AY?';"); break;
  case ANLTPG2_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AY?';"); break; 
  case ANLTPG5_8631: WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_2;COMM 'AY?';"); break; 
 }
 strread = ReadlnCOMPort(DUTCOM,0.5);

 if ((ATPGNo == ANLTPG2_8631) && (strlen(strread) < 2)){
  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR BBU_1;COMM 'AY?';");	// 2 stk. 8631 
  strread = ReadlnCOMPort(DUTCOM,0.5);
 }

 if (strlen(strread) > 10)
   Fmt(phasemstr,"%s<%s",strread);
  else 
   Fmt(phasemstr,"%s<          %s",strread);


 // Prod date
 strread = ReadBBProdDate(ATPGNo,xx_stik);
 Fmt(proddstr,"%s<%s",strread);

 // Cal date
 strread = ReadBBCalDate(ATPGNo,xx_stik);
 Fmt(caldstr,"%s<%s",strread);
 
 switch (ATPGNo){
  case ANLTPG2_8601: ATPGNo = 2; break;
  case ANLTPG2_8631: ATPGNo = 2; break;
  case ANLTPG5_8631: ATPGNo = 5; break;
 }

 Fmt(ATPGStr[lineno],"%s[a]< %i[w2], %s, %s, %s,  %s,        %s, %s, %s, %s\n",ATPGNo,levelstr,offsetstr,phasegstr,phasemstr,kustr,proddstr,caldstr,unitswstr);

 ATPGFound = TRUE;


return TRUE;
} // ReadATPG(int ATPGNo)





//----------------------------------------------------------------------------------------------------------
int ReadSDIGenl(void){
char proddstr[10],
	 caldstr[10],
	 kustr[10];
	 
 // read KU number
 Fmt(SDIGenlStr,"%s<PT8606 ,");

 strread = ReadSDIGenlKUNumber();
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);

 strread = ReadSDIGenlProdDate();
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadSDIGenlCalDate();
 Fmt(caldstr,"%s<%s",strread);


 Fmt(SDIGenlStr,"%s[aw55]< ");
 Fmt(SDIGenlStr,"%s[a]< %s, %s, %s\n",kustr,proddstr,caldstr);

return TRUE;
} // ReadSDIGenl(void)





//----------------------------------------------------------------------------------------------------------
int ReadLTC(void){
char proddstr[10],
	 caldstr[10],
	 kustr[10];
int p;	 

 strread = ReadClockPTNo();
 p = FindPattern (strread, 0, -1, "PT8607", 1, 0);

 if (p == 0)
   Fmt(LTCStr,"%s<PT8607 ,");
  else 
   return FALSE;
	 
 // read KU number
 strread = ReadLTCKUNumber();
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);

 strread = ReadLTCProdDate();
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadLTCCalDate();
 Fmt(caldstr,"%s<%s",strread);


 Fmt(LTCStr,"%s[aw54]< ");
 Fmt(LTCStr,"%s[a]<  %s, %s, %s\n",kustr,proddstr,caldstr);

return TRUE;
} // ReadLTC(void)



//----------------------------------------------------------------------------------------------------------
int ReadClock(void){
char proddstr[10],
	 caldstr[10],
	 kustr[10],
	 swstr[50],
	 battstr[20];
int p;	 
	 
 strread = ReadClockPTNo();
 p = FindPattern (strread, 0, -1, "PT8637", 1, 0);

 if (p == 0)
   Fmt(ClockStr,"%s<PT8637 ,");
  else 
   return FALSE;

 // read KU number
 strread = ReadClockKUNumber();
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);

 strread = ReadClockProdDate();
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadClockCalDate();
 Fmt(caldstr,"%s<%s",strread);

 strread = ReadClockSWVer();
 Fmt(swstr,"%s<%s",strread);
 p = strlen(swstr);
 if (p > 10)
  CopyString(swstr,0,swstr,p-3,3);


 if (CheckRAMBatteryStatus(0) == TRUE)
   Fmt(battstr,"%s<RAM Batteri = OK  ");
  else
   Fmt(battstr,"%s<RAM Batteri = FEJL");


 Fmt(ClockStr,"%s[aw32]< ");
 Fmt(ClockStr,"%s[a]<  %s,   %s, %s, %s, %s\n",battstr,kustr,proddstr,caldstr,swstr);

return TRUE;
} // ReadClock(void)




//----------------------------------------------------------------------------------------------------------
int ReadMULBB(void){
char proddstr[10],
	 caldstr[10],
	 kustr[10];
	 
 // read KU number
 Fmt(MULBBStr,"%s<PT8604 ,");

 strread = ReadMULBBKUNumber();
 if (strlen(strread) < 6){
  return FALSE;
 } 

 Fmt(kustr,"%s<%s",strread);

 strread = ReadMULBBProdDate();
 Fmt(proddstr,"%s<%s",strread);

 strread = ReadMULBBCalDate();
 Fmt(caldstr,"%s<%s",strread);


 Fmt(MULBBStr,"%s[aw50]< ");
 Fmt(MULBBStr,"%s[a]<  %s, %s, %s\n",kustr,proddstr,caldstr);

return TRUE;
} // ReadMULBB(void)








//----------------------------------------------------------------------------------------------------------
int ReadCalData(void){

int n,p;
int handle_returned, controlID_returned;


// SaveToFile = FALSE;
 DisplayPanel(configPNL);
 SetCtrlAttribute (configPNL, CONFIG_RETURN_BTN,ATTR_CTRL_TAB_POSITION, 0);
 SetCtrlAttribute (configPNL, CONFIG_SAVE_BTN, ATTR_DIMMED, FALSE);
 
 ResetTextBox (configPNL, CONFIG_TXT, "");
 
 // tekstfarve = r�d
 SetCtrlAttribute (configPNL, CONFIG_TXT, ATTR_TEXT_COLOR, VAL_RED);

 ProcessDrawEvents();
 
 
 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (configPNL);
  return FALSE;
  }

 SetMenuBarAttribute (mainmenuhandle, MAINMENU_DIVERSE_CALDATA, ATTR_DIMMED,TRUE);

// read main SW + KUnumber
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,"*IDN?;");
 strread = ReadlnCOMPort(DUTCOM,0.5); 
 Fmt(MainIDNStr,"%s<%s\n",strread);	  
 SetCtrlVal (configPNL, CONFIG_TXT, MainIDNStr);
 
 // Main KU number (bruges til filnavn ved gemning)
 p = FindPattern (strread, 0, -1, "KU", 1, 0);
 if (p > 0)
   CopyString(MainKUStr,0,strread,p+2,6);
  else
   Fmt(MainKUStr,"%s<xxxxxx");	  

 Delay(0.05);


// read power supply cal status
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:MAIN:PSC?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);  // "ON | OFF"
 if (strlen(strread) > 1)
   Fmt(datastr,"%s<%s",strread);
  else
   Fmt(datastr,"%s<,???");
 
 Delay(0.05);
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:MAIN:PS12?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);  // "xxx,xxx"
 if (strlen(strread) > 1)
   Fmt(datastr,"%s[a]<,%s",strread);
  else
   Fmt(datastr,"%s[a]<,???,???");

 Delay(0.05);
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:MAIN:PSN5?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);  // "xxx,xxx"
 if (strlen(strread) > 1)
   Fmt(datastr,"%s[a]<,%s",strread);
  else
   Fmt(datastr,"%s[a]<,???,???");
 
 
 Fmt(PowerSupplyCalStr,"%s<Power Supply: %s\n",datastr);
 SetCtrlVal (configPNL, CONFIG_TXT, PowerSupplyCalStr);
 ProcessDrawEvents();
 


 
 // ---- SPG ----------
 SetCtrlVal (configPNL, CONFIG_TXT, header_SPG);
 ReadSPG();
 SetCtrlVal (configPNL, CONFIG_TXT, SPGStr);
 ProcessDrawEvents();
 
 
 // --- Black Burst ------
 SetCtrlVal (configPNL, CONFIG_TXT, header_BB);

 for (n = 1;n < 9; n++){	 // BB# 1 - 8
  if (ReadBB(n) == TRUE)
   SetCtrlVal (configPNL, CONFIG_TXT, BBStr[n]);
  ProcessDrawEvents();
 }
 


 // --- SDI generatorer ------
 SDIFound = FALSE;
 SetCtrlVal (configPNL, CONFIG_TXT, header_SDI);

 if (ReadSDI(SDIBLACK34) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[1]);
 ProcessDrawEvents();
 if (ReadSDI(SDIBLACK56) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[2]);
 ProcessDrawEvents();
 if (ReadSDI(SDIBLACK78) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[3]);
 ProcessDrawEvents();
 if (ReadSDI(SDITSG2) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[3]);
 ProcessDrawEvents();
 if (ReadSDI(SDITSG3) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[1]);
 ProcessDrawEvents();
 if (ReadSDI(SDITSG4) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[2]);
 ProcessDrawEvents();
 if (ReadSDI(SDITPG1) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[4]);
 ProcessDrawEvents();
 if (ReadSDI(SDITPG2) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[1]);
 ProcessDrawEvents();
 if (ReadSDI(SDITPG5) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIStr[2]);
 ProcessDrawEvents();


 
 
 // --- Analog TPG  ------
 ATPGFound = FALSE;
 SetCtrlVal (configPNL, CONFIG_TXT, header_ATPG);
 
 if (ReadATPG(ANLTPG2_8601) == TRUE)
 SetCtrlVal (configPNL, CONFIG_TXT, ATPGStr[1]);
 ProcessDrawEvents();
 if (ReadATPG(ANLTPG2_8631) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, ATPGStr[2]);
 ProcessDrawEvents();
 if (ReadATPG(ANLTPG5_8631) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, ATPGStr[3]);
 ProcessDrawEvents();
 

 
 // --- AES/EBU ------
 SetCtrlVal (configPNL, CONFIG_TXT, header_AES);
 
 if (ReadAES(PT8605) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, AESStr);
 else 
 if (ReadAES(PT8635) == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, AESStr);
 ProcessDrawEvents();



 // --- SDI genlock   PT8606 ----------
// SetCtrlVal (configPNL, CONFIG_TXT, header_SDIGENL);
 
 if (ReadSDIGenl() == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, SDIGenlStr);
 ProcessDrawEvents();
 

 // --- LTC   PT8607 ------------------
// SetCtrlVal (configPNL, CONFIG_TXT, header_LTC);
 
 if (ReadLTC() == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, LTCStr);
 ProcessDrawEvents();


 // --- Time Clock   PT8637 ------------------
// SetCtrlVal (configPNL, CONFIG_TXT, header_CLOCK);
 
 if (ReadClock() == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, ClockStr);
 ProcessDrawEvents();
 
 
 

 // --- MUL BB   PT8604 ---------------
// SetCtrlVal (configPNL, CONFIG_TXT, header_MULBB);
 
 if (ReadMULBB() == TRUE)
  SetCtrlVal (configPNL, CONFIG_TXT, MULBBStr);
 ProcessDrawEvents();
 
	
 

// --- press F10 or F12 -----------
 do {
  GetUserEvent (WAIT, &handle_returned, &controlID_returned);
  switch (controlID_returned){
   case CONFIG_SAVE_BTN:    SaveCalData(); break;	// F10
   case CONFIG_RETURN_BTN: 	break;					// F12
  }
   
 } while (controlID_returned != CONFIG_RETURN_BTN);

 SetMenuBarAttribute (mainmenuhandle, MAINMENU_DIVERSE_CALDATA, ATTR_DIMMED,FALSE);
 
 HidePanel(configPNL);

return 0;

} // ReadCalData







int SaveCalData(void){
/*
Gemmer kalibreringsdata fra basisapparatet og alle units. 
Data gemmes i en fil med navnet xxxxxxY._zz hvor
 xxxxxx = KU nummer for apparatet (main board)
 Y		= A for f�rste gang der gemmes, derefter B,C,D.. osv.
 zz     = 10 for PT5210		30 for PT5230
*/
char filename[50], 
     wrtbuf[100], 
     MsgStr[200];
int  bytes_written, 
     fhandle, 
     n, 
     FilePresent, 
     IOErr,
     FmtIOErr,
     fno;
long fsize;	

  if (AppType == PT5210)
    CopyString(FileExt ,0,FileExt5210,0,-1);
   else 
    CopyString(FileExt ,0,FileExt5230,0,-1);
   

  fno = 64;  // = ASCII 65 = A
  FilePresent = TRUE;
  while (FilePresent == TRUE) {
   fno++;							 // start with 'A'
   Fmt(filename,"%s<%s%s%c%s",CalDataFilePath[LogDest],MainKUStr,(char)fno,FileExt);
   if (fno > 90 ){					 // 90 = 'Z'
    Fmt(filename,"%s<%s%s%c%s",CalDataFilePath[LogDest],MainKUStr,(char)(fno-1),FileExt);
    Fmt(MsgStr,"%s< Der er ingen ledig fil til at gemme data i\n Sidst brugte fil var '%s'\n Slet nogle af filerne i '%s'",filename,CalDataFilePath[LogDest]);
    MessagePopup(" Fejl ved gemning af kalibreringsdata",MsgStr);
    HidePanel(configPNL);
    return FALSE;
   } 
   FilePresent = GetFileInfo (filename, &fsize);
  } //while


  fhandle = OpenFile (filename, VAL_WRITE_ONLY, VAL_TRUNCATE, VAL_ASCII);

  bytes_written = WriteFile (fhandle, MainIDNStr, strlen(MainIDNStr));
  bytes_written = WriteFile (fhandle, PowerSupplyCalStr, strlen(PowerSupplyCalStr));
  
  // SPG
  bytes_written = WriteFile (fhandle, header_SPG, strlen(header_SPG));
  bytes_written = WriteFile (fhandle, SPGStr, strlen(SPGStr));

  // BB
  bytes_written = WriteFile (fhandle, header_BB, strlen(header_BB));
  for (n = 1; n < 9; n++){
   if (strlen(BBStr[n]) > 10)
    bytes_written = WriteFile (fhandle, BBStr[n], strlen(BBStr[n]));
  } 

 // SDI
  if  (SDIFound == TRUE)
   bytes_written = WriteFile (fhandle, header_SDI, strlen(header_SDI));
  for (n = 1; n < 6; n++){
   if (strlen(SDIStr[n]) > 10)
    bytes_written = WriteFile (fhandle, SDIStr[n], strlen(SDIStr[n]));
  } 

 // ATPG
  if  (ATPGFound == TRUE)
   bytes_written = WriteFile (fhandle, header_ATPG, strlen(header_ATPG));
  for (n = 1; n < 4; n++){
   if (strlen(ATPGStr[n]) > 10)
    bytes_written = WriteFile (fhandle, ATPGStr[n], strlen(ATPGStr[n]));
  } 

 // AES
  if (strlen(AESStr) > 10){
   bytes_written = WriteFile (fhandle, header_AES, strlen(header_AES));
   bytes_written = WriteFile (fhandle, AESStr, strlen(AESStr));
  } 
  
 // SDIGENL
  if (strlen(SDIGenlStr) > 10){
   bytes_written = WriteFile (fhandle, header_SDIGENL, strlen(header_SDIGENL));
   bytes_written = WriteFile (fhandle, SDIGenlStr, strlen(SDIGenlStr));
  } 
  
 // LTC
  if (strlen(LTCStr) > 10){
   bytes_written = WriteFile (fhandle, header_LTC, strlen(header_LTC));
   bytes_written = WriteFile (fhandle, LTCStr, strlen(LTCStr));
  } 

 // CLOCK
  if (strlen(ClockStr) > 10){
   bytes_written = WriteFile (fhandle, header_LTC, strlen(header_LTC));
   bytes_written = WriteFile (fhandle, ClockStr, strlen(ClockStr));
  } 
  
 // MULBB
  if (strlen(MULBBStr) > 10){
   bytes_written = WriteFile (fhandle, header_MULBB, strlen(header_MULBB));
   bytes_written = WriteFile (fhandle, MULBBStr, strlen(MULBBStr));
  } 
  


  IOErr = CloseFile (fhandle);

  if (IOErr != -1){
    Fmt(MsgStr,"%s< Kalibreringsdata gemt i fil '%s'",filename);
    MessagePopup(" Kalibreringsdata",MsgStr);
   }
  else{
	FmtIOErr = GetFmtIOError ();
    Fmt(MsgStr,"%s< Fejl ved gemning i fil '%s'\n Fejlkode=%i",filename,FmtIOErr);
    MessagePopup(" Kalibreringsdata",MsgStr);
  } 

 SetCtrlAttribute (configPNL, CONFIG_SAVE_BTN, ATTR_DIMMED, TRUE);  // kun gemning i fil en gang pr. l�sning

return TRUE;
} // SaveCalData(void) 








//----------------------------------------------------------------------------------
int ShowCalFiles(void){
int  select_status, 
     dfile, 
     bytes_read,
     IOErr,
     lineno;
char selected_path[MAX_PATHNAME_LEN], 
     line[150];


 SetPanelAttribute (configPNL, ATTR_TITLE, "");
 ProcessDrawEvents();

 DisplayPanel(configPNL);   //configPNL findes i cfg.uir file

 select_status = VAL_EXISTING_FILE_SELECTED;
 SetCtrlAttribute (configPNL, CONFIG_SAVE_BTN, ATTR_VISIBLE, FALSE);  // F10 = save button bruges ikke her
 
 while (select_status == VAL_EXISTING_FILE_SELECTED) {
  
  select_status = FileSelectPopup (CalDataFilePath[LogDest], "*.?__", "*.?__;*.*",
								   " Kalibreringsfiler",
								   VAL_SELECT_BUTTON, 1, 0, 1, 0,
								   selected_path);

  if (select_status != VAL_EXISTING_FILE_SELECTED) {
   HidePanel(configPNL);
   return TRUE;
  }


  SetPanelAttribute (configPNL, ATTR_TITLE, selected_path);
  SetCtrlAttribute (configPNL, CONFIG_TXT, ATTR_TEXT_COLOR, VAL_RED);
  
  dfile = OpenFile (selected_path, VAL_READ_ONLY, VAL_OPEN_AS_IS,VAL_ASCII);

  ResetTextBox (configPNL, CONFIG_TXT, "");
  bytes_read = ReadLine (dfile, line, 100);
  IOErr = GetFmtIOError ();
  if ((IOErr == 0) && (bytes_read >= 0)) {
   Fmt(line,"%s[a]<\n");
   SetCtrlVal(configPNL, CONFIG_TXT,line);
  }
 
  while ((IOErr == 0) && (bytes_read >= 0)){
   bytes_read = ReadLine (dfile, line, 100);
   IOErr = GetFmtIOError ();
   Fmt(line,"%s[a]<\n");
   SetCtrlVal(configPNL, CONFIG_TXT,line);
  } // while

  IOErr = CloseFile (dfile);
  WaitForContinue();


 } //while
 
 HidePanel(configPNL);


return TRUE;
} // ShowCalFiles(void)
 



















int CVICALLBACK CFGReturnCallBack (int panel, int control, int event, // F12
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:

			break;
	}
	return 0;
}


int CVICALLBACK CFGSaveCallBack (int panel, int control, int event,  // F10
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:

			break;
	}
	return 0;
}
