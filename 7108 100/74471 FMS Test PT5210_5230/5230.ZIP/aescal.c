/* 
Test af audio generatorer PT8605 og PT8635 i PT5210/PT5230
File: aescal.c

marts 1997, Peter Frederiksen



Rettelser:
980707  PT8635 test tilf�jet PT5230 test
990517  Fall/Rise time nedre gr�nse �ndret fra 30 til 25 ns
991012  PT8635 test i PT5210
		Test af leveldetektorer ved video-audio lock test
*/

#include <gpib.h>
#include "hp5313xa.h"
#include <ansi_c.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include <userint.h>
#include "aes.h"
#include "cviutil.h"
#include "bbcal.h"
#include "def.h"

char AESLogFile[2][50] = {"c:\\5230log\\aescal.log","m:\\measdata\\5230\\aescal.log"};

char AESKUStr[20],
     MasterSPGSW[15];


const double AESFreqTol = 0.1;   // Hz	   Audio tones tolerances
const double Freq48kHzTol = 1;   // Hz     48 kHz ref tolerances


// AES BNC parameters
const double AESBNCRiseTimeMax = 44;      // ns
const double AESBNCRiseTimeMin = 25;
const double AESBNCFallTimeMax = 44;
const double AESBNCFallTimeMin = 25;

const double AESBNCVoltppMax = 1.1;       // V
const double AESBNCVoltppMin = 0.9; 

const double AESBNCVoltOffsetMax = 0.05;  // V


// wordclock parameters
const double WClkRiseTimeMin = 30;	      // ns
const double WClkRiseTimeMax = 50;
const double WClkFallTimeMin = 30;
const double WClkFallTimeMax = 50;

const double WClkVoltppMax = 2.7;         // V
const double WClkVoltppMin = 2.3;         // V
const double WClkVoltOffsetMax = 1.50;	  // V
const double WClkVoltOffsetMin = 1.00;	  // V



int AESFreqOk,
    AudioGenOk,
    RiseTimeOk,
    FallTimeOk,
    VoltppOk,
    VoltOffsetOk,
    WClkRiseFallOk,
    WClkOk,
    WClkVoltppOk,
    WClkOffsetOk;
    
int InitAudioGen(int AESNo);
int ReadCounter_AES(double CHAFreq,double CHBFreq);
int InitHP53132_AES(void);
int MeasWordClockRiseFallTime(int WCNo);
int MeasWordClockOffset(int WCNo);
char *ReadAudioKUNumber (int aesno);
int TestAudioGen5210Mode(void);
int PT8635TotalTest(int TestNo);


ViReal64 RiseTime,FallTime,Voltpp,VoltOffset;








//-----------------------------------------------------------------------------------
int TestAudioGen(int AESNo, int AudioGenNo){
/*
AESNo = 8605 eller 8635
AudioGenNo = 1 eller 2 (kun for PT8635)

Der testes f�lgende:
 init af EEPROM
 m�ling af VCO sp�nding i TP1
 m�ling af signal p� BNC-stik: Vpp, offset, rise/fall time (m�ling p� wordclock signal)
 m�ling af 800Hz, 1kHz og 1kHz/400Hz (Dual) frekvenser.
 kontrol af level p� TEK764
 konrol af video/audio lock for PAL og NTSC-phase 1-5.
 
*/
int handle_returned, 
    controlID_returned,
    bytes_written,
    fhandle;
char *strread,
     TxtStr[80],
	 wrtbuf[100],
     *d,			// MM-DD-YYYY
	 *tt;			// HH:MM:SS
int IICport[2], LevelDet;
int AudioVideoLockedOk,
	AudioLevelDetectorOk,
	n;
ViReal64  VoltMax,VoltMin;



 if (AESNo == PT8605)
   SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8605 Audio Generator ");
  else{
   if (AudioGenNo == 1)
     SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8635 Audio Generator #1 ");
    else
     SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8635 Audio Generator #2 ");
  }  
 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 DisplayPanel (aesPNL);
 

 AudioGenOk = WriteProtect(OFF,FALSE);
 if (AudioGenOk == FALSE){
  HidePanel (aesPNL);
  return AudioGenOk;
 }
 
 RiseTimeOk = TRUE;
 FallTimeOk = TRUE;
 VoltppOk = TRUE;
 VoltOffsetOk = TRUE;


 if (AppType == PT5210){
   if (AESNo == PT8605)
    WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN S800HZ; LEV DBM9FS; TIM PAL;");
    
    if (AESNo == PT8635){
     if (AudioGenNo == 1)
       WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN S800HZ; LEV DBM9FS; TIM PAL;");
      else 
      if (AudioGenNo == 2)
       WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN S800HZ; LEV DBM9FS; TIM PAL;");
    }
 }  
  

 if (AppType == PT5230){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN S800HZ; LEV DBM9FS; TIM PAL;");
  else 
   if (AudioGenNo == 2)
    WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN S800HZ; LEV DBM9FS; TIM PAL;");
 }
 
#if IEEE 
 DevClear (0, 3);
#endif 
 Delay(0.5);
 InitHP53132_AES();
 
 if ((AESNo == PT8605) || ((AESNo == PT8635) && (AudioGenNo == 1)))
  InitAudioGen(AESNo);
 
 
 
 
// VCO sp�nding -------------------------------------------------------------
 if ((AESNo == PT8605) || ((AESNo == PT8635) && (AudioGenNo == 1))){
  AudioGenOk = CheckAudioGenVCO(AESNo);   // function findes i bbcal.c
  if (AudioGenOk == FALSE){
   MessagePopup (" Audio generator test ", " VCO sp�ndingstest FEJLET ");
   HidePanel (aesPNL);
   return AudioGenOk;
  }
 } // if ((AESNo == PT8605...



 // 48kHz ref test -----------------------------------------------------------
 DisplayPanel(aesPNL);
 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 if (AudioGenNo == 1)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES BNC #1 forbindes til HP53132 CH-1\n\n");
  else
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES BNC #2 forbindes til HP53132 CH-1\n\n");
   
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OK:    Tast F4\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Fejl:  Tast F9\n\n");

 WaitForContinue();

 if (AudioGenOk == FALSE){
  MessagePopup (" Audio generator test ", " AFBRUDT ");
  HidePanel (aesPNL);
  return FALSE;
 }

 
 // set generator = 48 kHz  (wordclock) ---------------------------------------
 switch (AppType){
 	case PT5210: if (AESNo == PT8605)
    				WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN F48KHZ;");
   				  else{  // PT8635
   					if (AudioGenNo == 1)
    					WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN F48KHZ;");
   					 else
    					WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN F48KHZ;");
    				}	
    			 break;	
	case PT5230: if (AudioGenNo == 1)
					WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN WORD;");
				  else
					WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN WORD;");
				 break;	
 }
 
 Delay(2);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," 48 kHz");
 
 AESFreqOk = ReadCounter_AES(48000,0);


 if (AESFreqOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   OK\n\n");
  else {
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   FAIL\n");
   AudioGenOk = FALSE;
  }
  
 

 // Rise/Fall time   -----------------------------------------------------------
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Risetime     ");
 ErrIEEE = hp5313xa_inputCond (hp53132, 1, VI_OFF, VI_ON, VI_OFF,VI_OFF);
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:RISE:TIME?");
 Delay(3);
 ErrIEEE = hp5313xa_mathRes (hp53132, &RiseTime);
 RiseTime = RiseTime * 1e9;  // til ns
 if (AESNo == PT8635)
  RiseTime = RiseTime - 9;
 if ((RiseTime > AESBNCRiseTimeMax) || (RiseTime < AESBNCRiseTimeMin))
  RiseTimeOk = FALSE;
 
 if (RiseTimeOk == TRUE)
   Fmt(TxtStr,"%s<%f[p1] ns    OK\n",RiseTime);
  else {
   Fmt(TxtStr,"%s<%f[p1] ns    FAIL   (%f[p1] - %f[p1])\n",RiseTime,AESBNCRiseTimeMin,AESBNCRiseTimeMax);
   AudioGenOk = FALSE;
  }
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Falltime     ");
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:FALL:TIME?");
 Delay(3);
 ErrIEEE = hp5313xa_mathRes (hp53132, &FallTime);
 FallTime = FallTime * 1e9;
 if (AESNo == PT8635)
  FallTime = FallTime - 6;
 if ((FallTime > AESBNCFallTimeMax) || (FallTime < AESBNCFallTimeMin))
  FallTimeOk = FALSE;
 
 if (FallTimeOk == TRUE)
   Fmt(TxtStr,"%s<%f[p1] ns    OK\n",FallTime);
  else {
   Fmt(TxtStr,"%s<%f[p1] ns    FAIL   (%f[p1] - %f[p1])\n",FallTime,AESBNCFallTimeMin,AESBNCFallTimeMax);
   AudioGenOk = FALSE;
  } 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);



// BNC Vpp offset  ---------------------------------------------------------------
 ErrIEEE = hp5313xa_inputCond (hp53132, 1, VI_ON, VI_ON, VI_OFF,VI_OFF);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Volt pp    ");
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:MAX?");
 Delay(2);
 ErrIEEE = hp5313xa_dataRes (hp53132, &VoltMax);
 VoltMax = VoltMax / 2;   // der m�les uden afslutning

 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:MIN?");
 Delay(2);
 ErrIEEE = hp5313xa_dataRes (hp53132, &VoltMin);
 VoltMin = VoltMin / 2;  // der m�les uden afslutning
 
 Voltpp = VoltMax - VoltMin - 0.02;
 VoltOffset = fabs(VoltMax) - fabs(VoltMin);
 
 if ((Voltpp > AESBNCVoltppMax) || (Voltpp < AESBNCVoltppMin))
  VoltppOk = FALSE;

 if (VoltppOk == TRUE)
   Fmt(TxtStr,"%s<%f[p2w5] Vpp    OK\n",Voltpp);
  else {
   Fmt(TxtStr,"%s<%f[p2w5] Vpp    FAIL   (%f[p1] - %f[p1])\n",Voltpp,AESBNCVoltppMin,AESBNCVoltppMax);
   AudioGenOk = FALSE;
  } 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," DC Offset  ");
 if (VoltOffset > AESBNCVoltOffsetMax)
  VoltOffsetOk = FALSE;
  
 if (VoltOffsetOk == TRUE)
   Fmt(TxtStr,"%s<%f[p2w5] VDC    OK\n",VoltOffset);
  else {
   Fmt(TxtStr,"%s<%f[p2w5] VDC    FAIL   (max %f[p1])\n",VoltOffset,AESBNCVoltOffsetMax);
   AudioGenOk = FALSE;
  } 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 
 ErrIEEE = hp5313xa_inputCond (hp53132, 1, VI_OFF, VI_ON, VI_OFF,VI_OFF);
 
 ProcessDrawEvents();
 Delay(1);
 
 if (AudioGenOk == FALSE){
  MessagePopup (" Audio generator test ", " FEJLET ");
  HidePanel (aesPNL);
  return FALSE;
 }



 // Audio freq test ------------------------------------
 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 if (AudioGenNo == 1){
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES BNC #1 forbindes til TEK 764 AES 75 input\n");
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES XLR #1 forbindes til TEK 764 AES 110 input\n");
   }
  else{
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES BNC #2 (MCX-stik = CX2) forbindes til TEK 764 AES 75 input\n");
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," AES XLR #2 (stik = XC2)     forbindes til TEK 764 AES 110 input\n");
 }

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 Menu: Input CH 1-2: BNC-unbalanced \n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"              Input CH 3-4: XLR-balanced \n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 Menu: Headphones Audio Source = MANUAL\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"                         Manual Left CH-1    Manual Right CH-2\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 HEADPHONE kabel forbindes til HP53132 counter CH-1 og CH-2\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 VIEW: AUDIO\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 VOLUME drejes i max  (helt h�jre om)\n\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OK:    Tast F4\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Fejl:  Tast F9\n\n");


 WaitForContinue();
 if (AudioGenOk == FALSE){
  MessagePopup (" Audio generator test ", " FEJLET ");
  HidePanel (aesPNL);
  return FALSE;
 }

 
// Dual 1000/400 Hz 
#if IEEE
 DevClear (0, 3);
#endif 
 Delay(0.5);
 InitHP53132_AES();
 
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN DUAL; LEV DB0FS; TIM PAL;");
  
 if (AESNo == PT8635){
  if (AudioGenNo == 1){
    WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN DUAL;");
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB0FS;");
    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM PAL;"); 
    }
   else{
    WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN DUAL;");
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB0FS;");
    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM PAL;"); 
  } 
 }

 Delay(2.0);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Dual 1 kHz / 400 Hz");
 
 AESFreqOk = ReadCounter_AES(1000,400);

 if (AESFreqOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   OK\n");
  else{
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   FAIL\n");
   AudioGenOk = FALSE;
  }
  


// Stereo 800 Hz 
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN S800HZ;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN S800HZ;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN S800HZ;");
 }
 
 Delay(2.0);

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Stereo 800 Hz");
 
 AESFreqOk = ReadCounter_AES(800,800);
 if (AESFreqOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"         OK\n");
  else {
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"         FAIL\n");
   AudioGenOk = FALSE;
  }
  
 //  Stereo 1 kHz 
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN S1KHZ;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
   WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN S1KHZ;");
  else
   WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN S1KHZ;");
 }  
 
 Delay(2);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Stereo 1 kHz");
 
 AESFreqOk = ReadCounter_AES(1000,1000);
 if (AESFreqOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"          OK");
  else {
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"          FAIL");
   AudioGenOk = FALSE;
  }
  
 
 Delay(1);

 if (AudioGenOk == FALSE){
  MessagePopup (" Audio generator test ", " FEJLET ");
  HidePanel (aesPNL);
  return FALSE;
 }

 


// ------- Audio level test ------------------------------------------------------
 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"\n\n Afl�s level p� TEK 764\n");
 if (AESNo == PT8605)
  SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Level skal skifte mellem 0, -9, -12, -14, -16, -18, -20 og MUTE\n\n");
 else
 if (AESNo == PT8635)
  SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Level skal skifte mellem 0, -9, -12, -15, -16, -18, -20 og MUTE\n\n");

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Check at der er signal i b�de CH-1, CH-2, CH-3 og CH-4\n\n");
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OBS: Mellem levelskiftene vises der muligvis CODE ERROR. Dette er ingen fejl!\n\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OK:    Tast F4\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Fejl:  Tast F9\n\n");
 
 Cont = FALSE;
 while (Cont == FALSE) {
 
 
 // 0 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB0FS;");

 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB0FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB0FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 
 
 // 9 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB9FS;");

 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB9FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB9FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 
 
 // 12 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB12FS;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB12FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB12FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 
 
 // 14/15 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB14FS;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB15FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB15FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 
 
 // 16 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB16FS;");
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB16FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB16FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 
 
 // 18 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB18FS;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB18FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB18FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 

 // 20 dBFS
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV DB20FS;");
 
 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB20FS;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB20FS;");
 }  
 Delay(2);
 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 if (Cont == TRUE) break;
 

 // silence/MUTE
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:LEV SIL;");

 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV SIL;");
   else
    WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV SIL;");
 }  
 Delay(3);
 
 } // while


 
// leave level test with level = 9 dBFS 
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:SIGN DUAL:LEV DB9FS;");

 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN DUAL:LEV DB9FS;");
   else 
    WriteCOMPort(DUTCOM,":OUTP:AUD2:SIGN DUAL:LEV DB9FS;");
 }  
 
 
 if (AudioGenOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Audio level test  OK\n");
  else {
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Audio level test  FEJLET\n");
   HidePanel(aesPNL);
   return AudioGenOk;
   }
 Delay(1);

  

// ------- Audio/Video Lock test --------------------------------------- 
 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Test af audio-video lock og level detektorer:\n\n");
 if (AESNo == PT8605){
  SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Lysdioden D1 skal lyse konstant\n");
  SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Lysdioden D4 m� gerne slukke et kort �jeblik mellem hver lock\n\n");
 } 
 
 if (AESNo == PT8635){
  SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Lysdioden D3 skal lyse konstant\n");
  
  if (AudioGenNo == 1)
    SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Lysdioden D5 m� gerne blinke et kort �jeblik mellem hver lock\n\n");
   else
    SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Lysdioden D4 m� gerne blinke et kort �jeblik mellem hver lock\n\n");
 } 
 

 AudioVideoLockedOk = TRUE;
 AudioLevelDetectorOk = TRUE;

 for (n = 0; n < 6; n++){
  switch (n){
    case 0 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," PAL lock          ");
             if (AESNo == PT8605)
    		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM PAL;"); 
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
    		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM PAL;"); 
     		   else
    		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM PAL;"); 
     		 }  
    		 break;
    case 1 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," NTSC Phase 1  lock"); 
             if (AESNo == PT8605)
    		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM NTSC1;"); 
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
    		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM NTSC1;"); 
     		   else
    		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM NTSC1;"); 
     		 }  
    		 break;
    case 2 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," NTSC Phase 2  lock"); 
             if (AESNo == PT8605)
    		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM NTSC2;"); 
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
    		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM NTSC2;"); 
     		   else
    		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM NTSC2;"); 
     		 }  
    		 break;
    case 3 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," NTSC Phase 3  lock");
             if (AESNo == PT8605)
    		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM NTSC3;"); 
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
    		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM NTSC3;"); 
     		   else
    		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM NTSC3;"); 
     		 }  
			 break;
    case 4 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," NTSC Phase 4  lock"); 
             if (AESNo == PT8605)
    		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM NTSC4;"); 
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
    		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM NTSC4;"); 
     		   else
    		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM NTSC4;"); 
     		 }  
    		 break;
    case 5 : SetCtrlVal(aesPNL, AES_PNL_TXTBOX," NTSC Phase 5  lock"); 
             if (AESNo == PT8605)
     		  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM NTSC5;");
             
             if (AESNo == PT8635){
              if (AudioGenNo == 1)
       		    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM NTSC5;");
     		   else
     		    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM NTSC5;");
     		 }
    		 break;
   } // switch

  Delay(1.5);				 // delay fra lock kommando til test om der er video/audio lock
  FlushInQ(DUTCOM);
  if (AESNo == PT8605)
   WriteCOMPort(DUTCOM,":FACT:AUD:READ?;");
  if (AESNo == PT8635){
   if (AudioGenNo == 1)
     WriteCOMPort(DUTCOM,":FACT:AUD1:READ?;");
    else
     WriteCOMPort(DUTCOM,":FACT:AUD2:READ?;");
  }  

  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%2i[x]",IICport);	// PORT0=V5   PORT1=V9   (PT8605: se 4008 109 82910)
  										// PORT0: bit0-2:L0-2     bit 3-6:S0-3    bit7:27MHz lock
  										// PORT1: bit0-2:VS0-2    bit 3:VIDLOCK   bit4-7:not used

										// Gen #1: PORT0=V10   PORT1=V11   (PT8635: se 4008 109 84900)
										// Gen #2: PORT0=V12   PORT1=V13
  										// PORT0: bit0-2:L0-2     bit 3-6:S0-3    bit7:27MHz lock
  										// PORT1: bit0-2:VS0-2    bit 3:VIDLOCK   bit4-6:Level OK signals

  
//  Fmt(TxtStr,"%s<  %s\n",strread);			// debug only
//  SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);

  if (AudioGenNo == 1){
   if (((IICport[1] & 0x08) != 0x08) || ((IICport[0] & 0x80) != 0x80))  // videolock1 + 27MHzlock
    AudioVideoLockedOk = FALSE;
   if ((IICport[1] & 0x70) != 0x70){   // level detector ok
    LevelDet = IICport[1];
 	AudioLevelDetectorOk = FALSE;
   }
  }  


  if (AudioGenNo == 2){
   if ((IICport[1] & 0x08) != 0x08)   // videolock2
    AudioVideoLockedOk = FALSE;
   if ((IICport[1] & 0x70) != 0x70){   // level detector ok
    LevelDet = IICport[1];
 	AudioLevelDetectorOk = FALSE;
   }
  }  
    
  if (AudioVideoLockedOk == TRUE)
    SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"    OK\n");
   else
    SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"    FAIL\n");

 } //for

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"\n");

 if (AudioLevelDetectorOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Level detector  OK\n");

 if (AudioLevelDetectorOk == FALSE){
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Level detector:\n");
   switch (AudioGenNo){
    case 1:	if ((LevelDet & 0x10) == 0x10)
			  Fmt(TxtStr,"%s<   AES BNC#1: OK\n");
		 	else
		  	  Fmt(TxtStr,"%s<   AES BNC#1: FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
		  
			if ((LevelDet & 0x20) == 0x20)
			  Fmt(TxtStr,"%s<   AES BNC#2: OK\n");
			 else
			  Fmt(TxtStr,"%s<   AES BNC#2: FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);

			if ((LevelDet & 0x40) == 0x40)
			  Fmt(TxtStr,"%s<   AES XLR#1: OK\n");
			 else
			  Fmt(TxtStr,"%s<   AES XLR#1: FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
       		break;
    case 2:	if ((LevelDet & 0x10) == 0x10)
			  Fmt(TxtStr,"%s<   AES XLR#2: OK\n");
			 else
			  Fmt(TxtStr,"%s<   AES XLR#2: FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
		  
			if ((LevelDet & 0x20) == 0x20)
			  Fmt(TxtStr,"%s<   WCLK#1:    OK\n");
			 else
			  Fmt(TxtStr,"%s<   WCLK#1:    FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);

			if ((LevelDet & 0x40) == 0x40)
			  Fmt(TxtStr,"%s<   WCLK#2:    OK\n");
			 else
			  Fmt(TxtStr,"%s<   WCLK#2:    FAIL\n");
			SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
    		break;
   }
 
 } // if  
 
 
 
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM,":OUTP:AUD:TIM PAL;"); 

 if (AESNo == PT8635){
  if (AudioGenNo == 1)
    WriteCOMPort(DUTCOM,":OUTP:AUD1:TIM PAL;"); 
   else 
    WriteCOMPort(DUTCOM,":OUTP:AUD2:TIM PAL;");
 }  

 if ((AudioVideoLockedOk == FALSE) || (AudioLevelDetectorOk == FALSE))
  AudioGenOk = FALSE;



 // AES test resultat gemmes i logfil
 if (AudioGenOk == TRUE){
   // get system date 
   d = DateStr();
   CopyString(dato,0,d,8,2);
   CopyString(dato,strlen(dato),d,0,2);
   CopyString(dato,strlen(dato),d,3,2);
 
   // get system time
   tt = TimeStr();
  
   strread = ReadAudioKUNumber(PT8635);
   CopyString(AESKUStr,0,strread,0,-1);

   strread = ReadMasterSWVer();
   CopyString(MasterSPGSW,0,strread,0,-1);

   // check om logfil findes, ellers opret en ny logfil
   fhandle = OpenFile (AESLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   Fmt(wrtbuf,"%s<%s,%s,KU%s,%i,AES/EBU signal = ok,MasterSW=%s,%i\n",dato,tt,AESKUStr,AudioGenNo,MasterSPGSW,AppType);	
   bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
   CloseFile(fhandle);
 } // if
 



 if (AudioGenOk == TRUE)
   MessagePopup(" AES/EBU test ","OK");
  else
   MessagePopup(" AES/EBU test ","FEJLET");

 HidePanel(aesPNL);

return AudioGenOk;
} // TestAudioGen







//--------------------------------------------------------------------------------------------------
int TestWordClockOutputs(int WClkNo){
/*
Der testes f�lgende:
 m�ling af wordclock signal p� 2 MCX-stik: Vpp, offset, rise/fall time
*/
int handle_returned, 
    controlID_returned;
int	bytes_written,
	fhandle;
char *strread,
     TxtStr[80],
	 wrtbuf[100],
     *d,			// MM-DD-YYYY
	 *tt;			// HH:MM:SS


 if (WClkNo == 1)
   SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8635 Wordclock #1 ");
  else
   SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8635 Wordclock #2 ");

 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 ProcessDrawEvents();
 DisplayPanel(aesPNL);
 

 AudioGenOk = WriteProtect(OFF,FALSE);
 if (AudioGenOk == FALSE){
  HidePanel (aesPNL);
  return AudioGenOk;
 }
 

 // 48kHz ref test -----------------------------------------------------------
 if (WClkNo == 1)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Wordclock #1 (MCX-stik = CX3) forbindes til HP53132 CH-1\n");
  else
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Wordclock #2 (MCX-stik = CX4) forbindes til HP53132 CH-1\n");

 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"\n\n");
   
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OK:    Tast F4\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Fejl:  Tast F9\n\n");
 ProcessDrawEvents();

 WaitForContinue();

 if (AudioGenOk == FALSE){
  MessagePopup (" Audio generator test ", " AFBRUDT ");
  HidePanel (aesPNL);
  return FALSE;
 }

 
 // set generator = 48 kHz  (wordclock) ---------------------------------------
 
 Delay(2.0);
 
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," 48 kHz");
 
 AESFreqOk = ReadCounter_AES(48000,0);

 if (AESFreqOk == TRUE)
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   OK\n\n");
  else {
   SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   FAIL\n");
   AudioGenOk = FALSE;
  }
  


 if (MeasWordClockOffset(1) == FALSE)
   AudioGenOk = FALSE;


 ErrIEEE = hp5313xa_inputCond (hp53132, 1, VI_OFF, VI_ON, VI_OFF,VI_OFF);  // counter = 1Mohm, CH = 1
 
 Delay(1);

 
 // Wordclock status gemmes i logfil
 if (AudioGenOk == TRUE){
   // get system date 
   d = DateStr();
   CopyString(dato,0,d,8,2);
   CopyString(dato,strlen(dato),d,0,2);
   CopyString(dato,strlen(dato),d,3,2);
 
   // get system time
   tt = TimeStr();
  
   strread = ReadAudioKUNumber(PT8635);
   CopyString(AESKUStr,0,strread,0,-1);
 	  
   strread = ReadMasterSWVer();
   CopyString(MasterSPGSW,0,strread,0,-1);

   // check om logfil findes, ellers opret en ny logfil
   fhandle = OpenFile (AESLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   
   Fmt(wrtbuf,"%s<%s,%s,KU%s,%i,Vpp=%f[p2], Voffset=%f[p2],MasterSW=%s,%i\n",dato,tt,AESKUStr,WClkNo,Voltpp,VoltOffset,MasterSPGSW,AppType);	
   bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
   CloseFile(fhandle);
 } // if
 
 
 
 
 if (AudioGenOk == TRUE)
   MessagePopup (" Wordclock output ", " OK ");
  else
   MessagePopup (" Wordclock output "," FEJLET ");

 HidePanel (aesPNL);

return AudioGenOk;
} // TestWordClock




//-----------------------------------------------------------------------------------
int TestAudioGen5210Mode(void){
/*
Der testes f�lgende:
 m�ling af AES#2 = silence
 PP5 og PP6 valg af channel mode
*/
int handle_returned, 
    controlID_returned;
int	bytes_written,
	fhandle;
char *strread,
     TxtStr[80],
	 wrtbuf[100],
     *d,			// MM-DD-YYYY
	 *tt;			// HH:MM:SS


 SetPanelAttribute (aesPNL, ATTR_TITLE, " PT8635  AES#2 i PT5210 mode ");

 ResetTextBox(aesPNL, AES_PNL_TXTBOX,"");
 ProcessDrawEvents();
 DisplayPanel(aesPNL);

 AudioGenOk = WriteProtect(OFF,FALSE);
 if (AudioGenOk == FALSE){
  HidePanel (aesPNL);
  return AudioGenOk;
 }

 WriteCOMPort(DUTCOM,":OUTP:AUD1:LEV DB9FS;");
 WriteCOMPort(DUTCOM,":OUTP:AUD2:LEV DB9FS;");  // I PT5210 mode bliver AES#2 level = silence

 WriteCOMPort(DUTCOM,":FACT:AUD2:MODE PT5210;");  // bit 7 i port V13 s�ttes = 1
 
 

 // AES#2 silence test -----------------------------------------------------------
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," BNC AES#2 forbindes til TEK764 AES 75 input\n\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 VIEW: CH STATUS    CHAN = 1 2    FORMAT = TEXT\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   Check at 'Channel mode' skifter mellem 'stereo', '2-channel' og 'monaural'\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   NB: Det er ingen fejl, hvis der vises 'CRC error' ved Channel mode skift'\n\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Check med jumpere isat:\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," PP5 = ON     PP6 = OFF    'Channel mode' = 'monaural'\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," PP5 = OFF    PP6 = ON     'Channel mode' = '2-channel'\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," HUSK: Monter jumpere i PP5 og PP6 efter test\n\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," TEK764 VIEW: AUDIO\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,"   Check at ch-1 og ch-2 level = MUTE\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," \n\n\n");
   
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," OK:    Tast F4\n");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX," Fejl:  Tast F9\n\n");
 ProcessDrawEvents();

 Cont = FALSE;
 while (Cont == FALSE) {
 
  WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN DUAL;");
  Delay(1.5);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (Cont == TRUE) break;
 
  WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN S1KHZ;");
  Delay(1.5);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (Cont == TRUE) break;
 
  WriteCOMPort(DUTCOM,":OUTP:AUD1:SIGN M1KHZ;");
  Delay(1.5);
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
  if (Cont == TRUE) break;
 
 } // while


 // PT5210 mode test status gemmes i logfil
 if (AudioGenOk == TRUE){
   // get system date 
   d = DateStr();
   CopyString(dato,0,d,8,2);
   CopyString(dato,strlen(dato),d,0,2);
   CopyString(dato,strlen(dato),d,3,2);
 
   // get system time
   tt = TimeStr();
  
   strread = ReadAudioKUNumber(PT8635);
   CopyString(AESKUStr,0,strread,0,-1);
 	  
   strread = ReadMasterSWVer();
   CopyString(MasterSPGSW,0,strread,0,-1);

   // check om logfil findes, ellers opret en ny logfil
   fhandle = OpenFile (AESLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   
   Fmt(wrtbuf,"%s<%s,%s,KU%s,AES#2 i PT5210 mode = ok,MasterSW=%s,%i\n",dato,tt,AESKUStr,MasterSPGSW,AppType);	
   bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
   CloseFile(fhandle);
  }




 if (AudioGenOk == TRUE)
   MessagePopup (" Audio generator i PT5210 mode ", " OK ");
  else
   MessagePopup (" Audio generator i PT5210 mode ", " FEJLET ");



 WriteCOMPort(DUTCOM,":FACT:AUD2:MODE PT5230;");  // bit 7 i port V13 s�ttes = 0

 HidePanel (aesPNL);

return AudioGenOk;
} // TestAudioGen5210Mode








 // Rise/Fall time  MCX-stik  ------------------------------------------------------------------
int MeasWordClockRiseFallTime(int WClkNo){
int WCRiseFallOk;
char TxtStr[80];
ViReal64 RiseTime,FallTime;

 WClkRiseFallOk = TRUE;
 Fmt(TxtStr,"%s< Risetime #%i    ",WClkNo);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 ErrIEEE = hp5313xa_inputCond (hp53132, WClkNo, VI_OFF, VI_ON, VI_OFF,VI_OFF);  // counter = CH-1
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:RISE:TIME?");
 Delay(3);
 ErrIEEE = hp5313xa_mathRes (hp53132, &RiseTime);
 RiseTime = RiseTime * 1e9;
 if ((RiseTime > WClkRiseTimeMax) || (RiseTime < WClkRiseTimeMin))
  WCRiseFallOk = FALSE;
 
 if (WCRiseFallOk == TRUE)
   Fmt(TxtStr,"%s<%f[p1] ns    OK\n",RiseTime);
  else 
   Fmt(TxtStr,"%s<%f[p1] ns    FAIL   (%f[p1] - %f[p1])\n",RiseTime,WClkRiseTimeMin,WClkRiseTimeMax);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 

 Fmt(TxtStr,"%s< Falltime #%i    ",WClkNo);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:FALL:TIME?");
 Delay(3);
 ErrIEEE = hp5313xa_mathRes (hp53132, &FallTime);
 FallTime = FallTime * 1e9;
 if ((FallTime > WClkFallTimeMax) || (FallTime < WClkFallTimeMin))
  WCRiseFallOk = FALSE;
 
 if (WCRiseFallOk == TRUE)
   Fmt(TxtStr,"%s<%f[p1] ns    OK\n",FallTime);
  else 
   Fmt(TxtStr,"%s<%f[p1] ns    FAIL   (%f[p1] - %f[p1])\n",FallTime,WClkFallTimeMin,WClkFallTimeMax);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 ProcessDrawEvents();

return WClkRiseFallOk;
} // MeasWordClockRiseFallTime




// Wordclock BNC Vpp + offset  MCX-stik -----------------------------------------------------------------------
int MeasWordClockOffset(int WClkNo){
char TxtStr[80];
ViReal64  VoltMax,VoltMin;

 WClkOffsetOk = TRUE;
 WClkVoltppOk = TRUE;
 WClkOk = TRUE;

 ErrIEEE = hp5313xa_inputCond (hp53132, WClkNo, VI_ON, VI_OFF, VI_OFF, VI_OFF); // Counter Zin = 50 ohm
 
 Fmt(TxtStr,"%s< Volt pp   (75 ohm)    ");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:MAX?");
 Delay(2);
 ErrIEEE = hp5313xa_dataRes (hp53132, &VoltMax);
 VoltMax = (VoltMax * 1.25) - 0.1;   // der m�les med 50 ohm afslutning  i stedet for 75 ohm

 Delay(0.5);
 hp5313xa_writeInstrData (hp53132, ":MEAS:SCAL:VOLT:MIN?");
 Delay(2);
 ErrIEEE = hp5313xa_dataRes (hp53132, &VoltMin);
 VoltMin = (VoltMin * 1.25) + 0.1 ;  // der m�les med 50 ohm afslutning i stedet for 75 ohm
 
 Voltpp = VoltMax - VoltMin;
 VoltOffset = (fabs(VoltMax) - fabs(VoltMin)) / 2;
 
 // Voltpp
 if ((Voltpp > WClkVoltppMax) || (Voltpp < WClkVoltppMin)){
  WClkOk = FALSE;
  WClkVoltppOk = FALSE;
 }
 if (WClkVoltppOk == TRUE)
   Fmt(TxtStr,"%s<%f[p2w5] Vpp    OK\n",Voltpp);
  else 
   Fmt(TxtStr,"%s<%f[p2w5] Vpp    FAIL   (%f[p1] - %f[p1])\n",Voltpp,WClkVoltppMin,WClkVoltppMax);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 

 //VoltOffset
 Fmt(TxtStr,"%s< DC offset   (75 ohm)  ");
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 if ((VoltOffset > WClkVoltOffsetMax) || (VoltOffset < WClkVoltOffsetMin)){
  WClkOk = FALSE;
  WClkOffsetOk = FALSE;
 } 
  
 if (WClkOffsetOk == TRUE)
   Fmt(TxtStr,"%s<%f[p2w5] VDC    OK\n",VoltOffset);
  else 
   Fmt(TxtStr,"%s<%f[p2w5] VDC    FAIL   (%f[p1]-%f[p1])\n",VoltOffset,WClkVoltOffsetMin,WClkVoltOffsetMax);
 SetCtrlVal(aesPNL, AES_PNL_TXTBOX,TxtStr);
 
 ProcessDrawEvents();

return WClkOk;
} // MeasWordClockOffset



//----------------------------------------------------------------------------------
char *ReadAudioPTNo (int aesno) {
  // read audio generator PT86xx number  (user text 6)
char *strread;
  FlushInQ(DUTCOM);
  if (aesno == PT8605)
   WriteCOMPort(DUTCOM,":FACT:AUD:TEXT? 6;");
  if (aesno == PT8635)
   WriteCOMPort(DUTCOM,":FACT:AUD1:TEXT? 6;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}






//----------------------------------------------------------------------------------
char *ReadAudioKUNumber (int aesno) {
  // read audio generator KU nummer  (user text 2)
char *strread;
  FlushInQ(DUTCOM);
  if (aesno == PT8605)
   WriteCOMPort(DUTCOM,":FACT:AUD:TEXT? 2;");
  if (aesno == PT8635)
   WriteCOMPort(DUTCOM,":FACT:AUD1:TEXT? 2;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,3,6);
 return strread;
} // *ReadAudioKUNumber						  



//----------------------------------------------------------------------------------
char *ReadAudioProdDate (int aesno) {
  // read audio generator produktions dato  (user text 3)
char *strread;
  FlushInQ(DUTCOM);
  if (aesno == PT8605)
   WriteCOMPort(DUTCOM,":FACT:AUD:TEXT? 3;");
  if (aesno == PT8635)
   WriteCOMPort(DUTCOM,":FACT:AUD1:TEXT? 3;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}


//----------------------------------------------------------------------------------
char *ReadAudioCalDate (int aesno) {
  // read audio generator kalibrerings dato  (user text 4)
char *strread;
  FlushInQ(DUTCOM);
  if (aesno == PT8605)
   WriteCOMPort(DUTCOM,":FACT:AUD:TEXT? 4;");
  if (aesno == PT8635)
   WriteCOMPort(DUTCOM,":FACT:AUD1:TEXT? 4;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
} // *ReadAudioCalDate



//-------------------------------------------------------------------------------
int ReadCounter_AES(double CHAFreq,double CHBFreq){
char TxtStr[50];
ViReal64 freqmeasA,freqmeasB;

#if IEEEBUS
 
 DisableBreakOnLibraryErrors();

 if (CHAFreq > 0){
 ErrIEEE = hp5313xa_freqPeriodRatio (hp53132, 1, 1, 6, VI_ON, 3);
 Delay(0.2);
 hp5313xa_writeInstrData (hp53132, ":READ?");
 Delay(1.2);
 ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeasA);
 Delay(1.0);
 }

 if (CHBFreq > 0){		
  ErrIEEE = hp5313xa_freqPeriodRatio (hp53132, 2, 1, 6, VI_ON, 3);
  Delay(0.2);
  hp5313xa_writeInstrData (hp53132, ":READ?");
  Delay(1.2);
  ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeasB);
  Delay(0.2);
 } 
 EnableBreakOnLibraryErrors();
 
 if (CHBFreq > 0){				   // Audio tones meas
  if ((fabs(CHAFreq - freqmeasA) > AESFreqTol) || 
      (fabs(CHBFreq - freqmeasB) > AESFreqTol))
   return FALSE;
  else
   return TRUE;
 }
 else{							   // 48 kHz meas
  if (fabs(CHAFreq - freqmeasA) > Freq48kHzTol)
   return FALSE;
  else
   return TRUE;
 }
#else
   return TRUE;
#endif 
 
 
} // ReadCounter_AES








//-------------------------------------------------------------------------------
int InitHP53132_AES(void) {
#if IEEEBUS
 // set input trigger level/slope/attenuation/sensitivity
 ErrIEEE = hp5313xa_trigSens (hp53132, 1, VI_ON, 0.0, VI_OFF, VI_ON, 1);
 ErrIEEE = hp5313xa_trigSens (hp53132, 2, VI_ON, 0.0, VI_OFF, VI_ON, 1);
#endif 
return 0;
}



//----------------------------------------------------------------------------------
int InitAudioGen(int AESNo){

int n,KUNo,ScanErr;
int ValidKU;
char *usertxt;
char *dd;					// MM-DD-YYYY
unsigned char response[10]; // svar fra PromptPopup
char KUStr[10];  			// KUxxxxxx
char *KUread;		 		// L�st KU nummer
char PromptStr[50];
 

 // 0  producent
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM, ":FACT:AUD:TEXT 0,'PTV';");
 else  
 if (AESNo == PT8635)
  WriteCOMPort(DUTCOM, ":FACT:AUD1:TEXT 0,'PTV';");
 Delay(0.2);

 // 1  12nc
 if (AESNo == PT8605)
   Fmt(DUTStr,"%s<:FACT:AUD:TEXT 1,'%s';",NC12[1]);
 else  
 if (AESNo == PT8635)
   Fmt(DUTStr,"%s<:FACT:AUD1:TEXT 1,'%s';",NC12[14]);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.5);
 
 
 
 // 2  KU nummer
 KUread = ReadAudioKUNumber(AESNo);
 if (isdigit(KUread[2]) == FALSE)	
   CopyString(KUread,0,"",0,-1);
    
  
 EnterKUNo(" Audio generator", KUread, response);
   

 if (AESNo == PT8605)
   Fmt(DUTStr,"%s<:FACT:AUD:TEXT 2,'KU%s';",response);
 else 
  if (AESNo == PT8635)
   Fmt(DUTStr,"%s<:FACT:AUD1:TEXT 2,'KU%s';",response);

 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.2);
 
 // get system date 
 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 // 3  produktionsdato
 usertxt = ReadAudioProdDate(AESNo);
 if (isdigit(usertxt[2]) == FALSE){			  
  if (AESNo == PT8605)
   Fmt(DUTStr,"%s<:FACT:AUD:TEXT 3,'%s';",dato);
  else 
  if (AESNo == PT8635)
   Fmt(DUTStr,"%s<:FACT:AUD1:TEXT 3,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 }

 // 4  kalibreringsdato 
 usertxt = ReadAudioCalDate(AESNo);
 if (isdigit(usertxt[2]) == FALSE){			  
  if (AESNo == PT8635)
   Fmt(DUTStr,"%s<:FACT:AUD:TEXT 4,'%s';",dato);
  else 
  if (AESNo == PT8605)
   Fmt(DUTStr,"%s<:FACT:AUD1:TEXT 4,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(0.2);
 } 

 // 6  PT-nummer
 if (AESNo == PT8605)
  WriteCOMPort(DUTCOM, ":FACT:AUD:TEXT 6,'PT8605';");
 else 
 if (AESNo == PT8635)
  WriteCOMPort(DUTCOM, ":FACT:AUD1:TEXT 6,'PT8635';");
 Delay(0.2);

 // 7  reserveret - ikke defineret.

return TRUE;
} // InitAudioGen




//-------------------------------------------------------------------------
int PT8635TotalTest(int TestNo){

	AudioGenOk = FALSE;
	
	if (TestNo == 1)
	 TestAudioGen(PT8635,1);
    
 	if ((TestNo == 2) || (AudioGenOk == TRUE))
 	 TestAudioGen(PT8635,2);

 	if ((TestNo == 3) || (AudioGenOk == TRUE))
 	 TestWordClockOutputs(1);

 	if ((TestNo == 4) || (AudioGenOk == TRUE))
 	 TestWordClockOutputs(2);

	if (AppType == PT5230)
 	 if ((TestNo == 5) || (AudioGenOk == TRUE))
      TestAudioGen5210Mode();
return TRUE;
}









int CVICALLBACK AESOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: Cont = TRUE; AudioGenOk = TRUE;
						break;
	}
	return 0;
}

int CVICALLBACK AESExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: Cont = TRUE; AudioGenOk = FALSE; 
						break;
		
	}
	return 0;
}

