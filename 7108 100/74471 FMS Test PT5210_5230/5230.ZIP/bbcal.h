
extern int DACData[8][2];

extern int syncPNL;
extern int phasePNL;

extern int MakeSyncOffsetCal(int BBNo, int CalType, int xx1_stik);
extern int ReadCalData1(void);
extern int InitBB(int BBNo);
extern int MakeOffsetCal(int BBNo);
extern int MakePhaseCal(int BBNo, int TVSys);  //BB
extern int MakeANLTPGPhaseCal(int ANLTPGNo, int TVSys, int GetXX1); // Analog TPG2/5  8601/8631
extern int CheckANLTPGPattern(int ANLTPGNo, int GetXX1);
extern int CalPowerSupply(void);
extern int CheckPowerSupply(int NomVolt);
extern int CheckFan(void);
extern int CheckOven(void);
extern int CheckAudioGenVCO(int AESNo);
extern char *ReadBBKUNumber (int BB, int xx1_stik);
extern char *ReadBBProdDate (int BB, int xx1_stik);
extern char *ReadBBCalDate (int BB, int xx1_stik);
extern char *ReadBBSWVer (int BB);
extern char *ReadSDISWVer (int SDI);
extern char *ReadMasterSWVer (void);
extern char *ReadMULBBKUNumber (void);
extern char *ReadMULBBProdDate (void);
extern char *ReadMULBBCalDate (void);
extern int CheckLTCVCO(int TVSystem);
extern int TestParBB(void);
extern int JusterNCO(int ATPGNo);
extern int JusterFilter(int ATPGNo);
extern int AnalogTPGTotalTest(int TPGNo, int TestNo);
extern int ResetANL(int ANLTPGNo);
