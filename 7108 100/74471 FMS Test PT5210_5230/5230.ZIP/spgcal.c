/*
Rettelser:
970306 	Kommando GI? indf�rt: l�s SW version i SPG: 
    	GI? returnerer SW ver fra version 020, tidligere udgaver
 		returnerer intet. Her bruges GI til field 1/5 skift i PAL.
 		Med SW ver 020 er GI erstattet af GJ og GJ erstattet af GK.

970603  Test af synclevel rettes fra 150 mV til 180 mV (PAL), og
		fra 20 IRE til 24 IRE (NTSC) efter aftale med BL� og SNJ.
		Dett g�res for at undg� fejl, som kan optr�de pga af hysteresis
		(120-165 mV) i detekteringen af sync.
		
970922  AutoHPH data l�ses og vises p� sk�rm ved fieldskift 1/5 i PAL og
        1/3 i NTSC. Dette har ingen indflydelse p� kalibreringen.
 

981124  MakeSPGReset rettet s�ledes, at l�ste data fra SPG'en vises, 
        hvis reset af SPG fejler. Dette har ingen indflydelse p� kalibreringen.

990527  KU-nummer i SPG-EEPROM: (InitSPG)
        Hvis SPG-EEPROM ikke indeholder gyldigt KU-nummer, l�ses KU-nummer i 
        Main-EEPROM. Hvis Main-EEPROM KU-nummer er gyldigt, skrives dette nummer 
        til SPG-EEPROM. Hvis Main-EEPROM KU-nummer heller ikke er gyldigt, skal 
        brugeren indtaste KU-nummer.

990903  TP01Intmax og TP01max �ndret fra 2.8V til 3.0V (aftalt SNJ)

991125  Check af om BB-ref modul og SDI-genlock modul er monteret udf�res
        efter udf�rsel af Init-function. Dette muligg�r rettelse af KU-nummer
        uden at disse moduler beh�ver at v�re monteret.
 
 */




#include <gpib.h>
#include "hp34401a.h"
#include "hp5313xa.h"
#include "ocxo.h"
#include "spgphase.h"
#include <ansi_c.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include <userint.h>
#include "spghph.h"
#include "spggenl.h"
#include "cviutil.h"
#include "vlmutil.h"
#include "bbcal.h"
#include "sditest.h"
#include "pt5230.h"
#include "def.h"


// SPG har intern RS-232 adresse = 15h = 21d
 
char SPGLogFile[2][50] = {"c:\\5230log\\spgcal.log","m:\\measdata\\5230\\spgcal.log"};
 
const int GenlWaitInterval = 1;  			// sec
const double AutoHPHWaitInterval = 0.9;		// sec

const double F27FreqNom = 27e6;				// Hz
const double F27FreqTol = 0.5;				// Hz

const double F10FreqNom = 10e6;				// Hz
const double F10FreqTol = 0.5;				// Hz

const double TP01MeasDelay = 1.0;			// Tid fra genlock=TRUE indtil m�ling i TP01
const double TP01max = 3.0;					// max sp�nding i TP01 ved extern genlock test
const double TP01min = 0.8;				    // min sp�nding i TP01 ved extern genlock test

const double TP01Intmax = 3.0;				// max sp�nding i TP01 ved intern (27MHz just)
const double TP01Intmin = 0.8;				// min sp�nding i TP01 ved intern (27MHz just) 

const unsigned int hphminmaxdiff = 200;		// max forskel ved HPH m�ling


int SPGSWRev;

int	SPGdone,
	TV;
 
double TP01Voltage;   // VCO sp�nding m�le i TP01

int	GenlockStatus,	  // TRUE hvis apparatet er l�st til extern ref
    VCOVoltageOk;	  // TRUE hvis sp�nding i TP01 er indenfor �vre/nedre gr�nse
int SPGGenlValue,
	SPGGenlOffsetValue;

int InitSPG(void);
int WriteSPGCalDate(void);
int MakeSPGGenlockCal(int TVSys);
int BasicTotalTest(int TestNo);
char *ReadSPGKUNumber (void);

char KUStr[10];  		// KUxxxxxx



//-------------------------------------------------------------------------------
int GetGenlockStatus(void){
// status = tilstand af UNLOCKED LED l�ses i SPG'en
char *strread;
int gs;
 
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GS?';");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (strlen(strread) > 0)
  Scan(strread,"%s>%i",&gs);
  else
  gs = 0;
 gs = gs & 0x06;	 // udmask bit 1,2    (bit 0,3-7=0)
 
return gs;
} // GetGenlockStatus
 

//--------------------------------------------------------------------------------
int CheckGenlockVCOVoltage(float upperlim, float lowerlim, double wait, double *VCOmeas){
/* M�ling af VCO sp�ndingen til SPG 27MHz oscillatoren.
   Der m�les i TP01 2 gange efter hinanden med 0.2 sek interval. Sidste m�ling anvendes.
   Hvis sp�ndingen er udenfor gr�nserne, er oscillatoren ikke l�st sikkert til extern ref.
   wait = tid inden 1. m�ling udf�res
   Return: TRUE hvis m�lingen er indenfor upperlim/lowerlim, ellers returneres FALSE.
           VCOmeas returnerer den m�lte sp�nding.
*/   
double meas;
int VCOstatus;
 Delay(wait);
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
 Delay(0.2);
 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
 EnableBreakOnLibraryErrors();
 VCOstatus = ((meas <= upperlim) && (meas >= lowerlim));
 *VCOmeas = meas;
return VCOstatus;
} // CheckGenlockVCOVoltage



 
//--------------------------------------------------------------------------------
int MakeSPGGenlockInput(void){
// TEST1,2 er en test af inputsystemet: B input    A-B input
// Der testes med genlock til PAL.

// Test #3-8 foreg�r i MakeSPGGenlockSystem

char *SDIKU;
int button_pressed;


 DisplayPanel (spggenlPNL);
 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 ProcessDrawEvents();


 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(spggenlPNL);
  return FALSE;
 }

 
 Set5640Standard("G");
 Set5640Standard("M");
 
 GenlBOk = TRUE;
 GenlA_BOk = TRUE;

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spggenlPNL);
  GenlInputOk = FALSE;
  return FALSE;
  }

 Delay(xd);

 // Check at SDI genlock er monteret
 SDIKU = ReadSDIGenlKUNumber();
 if (strlen(SDIKU) < 6){
  MessagePopup(" SDI Genlock"," SDI Genlock option er ikke monteret !\n Monter option og start igen");
  HidePanel(spggenlPNL);
  return FALSE;
 }
 


 // 1.TEST     Genlock for input B   (PAL) --------------------------------
 SetPanelAttribute (spggenlPNL, ATTR_TITLE, " Genlock input B ");

 WriteCOMPort(DUTCOM,":INP:GENL:INP B;"); // <<<<<<<<<<<<<<<<<<< remote genlock fejl
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST PALB;");
 Delay(xd);
 SetGenlockSignal(GENL_PAL);

 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," GENL SIGNAL forbindes til DUT GENLOCK B\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Kontroller at lysdioden UNLOCKED er slukket\n\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Afbryd:   Tast F9\n");

 WaitForContinue();
 if (GenlBOk == FALSE){
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 Delay(2);
 
 // Check at DUT er genlocked til B
 Repeat = TRUE;
 GenlockStatus = GetGenlockStatus();
   while ((GenlockStatus != DUT_LOCKED) & (GenlBOk == TRUE)) {

	button_pressed = GenericMessagePopup ("DUT genlock",
										  "Genlock PAL burst til B input ikke l�st",
										  "OK", "Afvist", "", 0, -1, 0,
										  VAL_GENERIC_POPUP_BTN1,
										  VAL_GENERIC_POPUP_BTN2,
										  VAL_GENERIC_POPUP_BTN3);
     switch (button_pressed) {
      case 1: GenlBOk = TRUE; Repeat = FALSE; break;
      case 2: GenlBOk = FALSE; Repeat = FALSE; break;
     }

    GenlockStatus = GetGenlockStatus();
   } //while
 



  if (GenlBOk == FALSE) {
   MessagePopup (" Genlock test", " Genlock input B\n FEJLET");
   HidePanel(spggenlPNL);
   SetGenlockSignal(GENL_OFF);
   return FALSE;
  }



// 2. TEST      Genlock for input A-B   (PAL) --------------------------------
 SetPanelAttribute (spggenlPNL, ATTR_TITLE, " Genlock input A-B ");

 WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); // <<<<<<<<<<<<<<<<<<< remote genlock fejl
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST PALB;");
 Delay(1.0); 
 
 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," GENL SIGNAL forbindes til DUT GENLOCK A\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," DUT GENLOCK B forbindes til 5662 CH-A\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," DUT GENLOCK MONITOR forbindes til 5662 CH-B\n\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Check burstamplitude p� GENLOCK MONITOR:\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Amplituden skal v�re ens indenfor �1.5% p� 5662 CH-A og CH-B\n\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Kontroller at lysdioden UNLOCKED er slukket\n\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Afbryd:   Tast F9\n");

 WaitForContinue();
 if (GenlA_BOk == FALSE){
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 // Check at DUT er genlocked til A-B 
 Repeat = TRUE;
 GenlockStatus = GetGenlockStatus();
   while ((GenlockStatus != DUT_LOCKED) & (GenlA_BOk == TRUE)) {

    button_pressed = GenericMessagePopup ("DUT genlock",
									      "Genlock PAL burst til A-B input ikke l�st", "OK", "Afvist", "",
									      0, -1, 0,
									      VAL_GENERIC_POPUP_BTN1,
									      VAL_GENERIC_POPUP_BTN2,
									      VAL_GENERIC_POPUP_BTN3);
     switch (button_pressed) {
      case 1: GenlA_BOk = TRUE; Repeat = FALSE; break;
      case 2: GenlA_BOk = FALSE; Repeat = FALSE; break;
     }

    GenlockStatus = GetGenlockStatus();
   } //while

  if (GenlA_BOk == FALSE) {
   MessagePopup (" Genlock test", " Genlock input A-B\n FEJLET");
   HidePanel(spggenlPNL);
   SetGenlockSignal(GENL_OFF);
   return FALSE;
  }


 SetGenlockSignal(GENL_OFF);

 GenlInputOk = GenlBOk & GenlA_BOk;

 HidePanel(spggenlPNL);
 

return TRUE;
} // MakeSPGGenlockInput






int MakeSPGGenlockSystem(void){
/* 
 TEST 3 .. 8 er en test af genlocksystemet med f�lgende signaler: PAL, NTSC, 4.43MHz, 
 3.58MHz, 10MHz og SDI. Som input v�lges A, dog f�res SDI til SDI Genlock option.
 For PAL, NTSC, 10MHz, 4.43MHz og 3.58MHz genlock testes om der genlockes ved � 6dB.
 Frekvenssignalerne 10MHz, 4.43MHz og 3.58MHz d�mpes med et d�mpeled monteret i 
 genlock mux'en (i BNC-stik panalet).
 Genlock med PAL og NTSC programmeres med PM5640. PAL og NTSC testes desuden 
 med Hum og Noise.
 Test #1 og 2 foreg�r i MakeSPGGenlockInput
*/


// 3. TEST   Genlock PAL --------------------------------

int button_pressed;
int handle_returned, controlID_returned;
int fhandle,
    bytes_written,
    n;
char wrtbuf[100],
     MsgStr[100],   // diverse udskrifter
	 *strread,
     *dd,			// MM-DD-YYYY
	 *tt;			// HH:MM:SS

 DisplayPanel (spggenlPNL);
 
 GenlPALOk = TRUE;
 GenlNTSCOk = TRUE;
 Genl443MHzOk = TRUE;
 Genl358MHzOk = TRUE;
 Genl10MHzOk = TRUE;
 GenlSDIOk = TRUE;
 
 SetPanelAttribute (spggenlPNL, ATTR_TITLE, " Genlock Test  (input A) ");
// ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 ProcessDrawEvents();

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);
 
 button_pressed = ConfirmPopup (" Genlock Test ", " Probe til multimeter HP34401 forbindes til TP01\n ");
 if (button_pressed == NO){
  HidePanel(spggenlPNL);
  return FALSE;
 }

 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 Fmt(MsgStr,"%s< Genlock signal input test:          Sp�nding i TP01: %f[p2] - %f[p2]\n\n",TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spggenlPNL);
  GenlSystemOk = FALSE;
  return FALSE;
  }

 WriteCOMPort(DUTCOM,":INP:GENL:INP A;"); // <<<<<<<<<<<<<<<<<<< remote genlock fejl
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST PALB;");
 Delay(xd);
 Set5640Standard("G");
 Set5640Pattern("G", 290);




// PAL -------- Hum, Noise, Burst=150mV, Sync=180mV --------------------------------------------
 Set5640BurstLevel("G", 300 * 0.5);
 Set5640SyncLevel("G", 300 * 0.6);
 Set5640Hum("G", 1000);
 Set5640Noise("G", -40);
 SetGenlockSignal(GENL_PAL);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   Burst=150mV  Sync=180mV  Hum=1000mV   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while
 
 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);
 
 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Set5640Standard("G");
  GenlPALOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock PAL til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }




// PAL -------- Hum, Noise, Burst, Sync + 6dB --------------------------------------------------
 Set5640BurstLevel("G", 300 * 2);
 Set5640SyncLevel("G", 300 * 2);
 Set5640Hum("G", 1000);
 Set5640Noise("G", -40);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   Burst+Sync=600mV   Hum=1000mV   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 

 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
  
 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Set5640Standard("G");
  GenlPALOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock PAL til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (GenlPALOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  Set5640Standard("G");
  HidePanel(spggenlPNL);
  return FALSE;
 }
 


// 4. TEST    PAL SUBC -------- +4 dB ---------------------------------------------------
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   SUBC = +4dB ");
 SetGenlockSignal(GENL_443_HIGH);
 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST F443MHZ;");
 Delay(xd);

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl443MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock SUBC PAL til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }


 
 
// PAL SUBC -------- - 6dB ---------------------------------------------------------------
 
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   SUBC = -6dB ");
 SetGenlockSignal(GENL_443_LOW);
 
 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl443MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock SUBC PAL til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (Genl443MHzOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  HidePanel(spggenlPNL);
  return FALSE;
 }








 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST NTSC;");
 Delay(xd);
 Set5640Standard("M");
 Set5640Pattern("M", 290);

// 5. TEST    NTSC -------- Hum, Noise, Burst, Sync - 6dB --------------------------------
 Set5640BurstLevel("M", 40 * 0.5);
 Set5640SyncLevel("M", 40 * 0.6);
 Set5640Hum("M", 100);
 Set5640Noise("M", -40);
 SetGenlockSignal(GENL_NTSC);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  Burst=20IRE  Sync=24IRE  Hum=100IRE   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);

 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Set5640Standard("M");
  GenlNTSCOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock NTSC til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

// NTSC -------- Hum, Noise, Burst, Sync + 6dB ------------------------------------------
 Set5640BurstLevel("M", 40 * 2);
 Set5640SyncLevel("M", 40 * 2);
 Set5640Hum("M", 100);
 Set5640Noise("M", -40);
 Delay(1.0);

 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  Burst+Sync=80IRE   Hum=100IRE   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Set5640Standard("M");
  GenlNTSCOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock NTSC til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }
 
 Set5640Standard("G");
 Set5640Standard("M");


 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (Genl443MHzOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  HidePanel(spggenlPNL);
  return FALSE;
 }



 
// 6. TEST   NTSC SUBC -------- +4dB --------------------------------------------
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  SUBC = +4dB ");
 SetGenlockSignal(GENL_358_HIGH);
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST F358MHZ;");
 Delay(xd);

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl358MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock SUBC NTSC til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }



 
 
// NTSC SUBC -------- - 6dB --------------------------------------------
 
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  SUBC = -6dB ");
 SetGenlockSignal(GENL_358_LOW);
 
 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl358MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock SUBC NTSC til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }


 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (Genl358MHzOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  HidePanel(spggenlPNL);
  return FALSE;
 }





// 7. TEST   Genlock 10 MHz --- + 6dB --------------------------------------------------------
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," 10 MHz = +6dB ");
 SetGenlockSignal(GENL_10M_HIGH);
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");  // <<<<<<<<<<<<<<<<<<<<<<<<<<<<
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST F10MHZ;");

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
 
 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl10MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock 10 MHz til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

  // TP01 sp�nding ved 10MHz lock gemmes i logfil

  // get system date 
  dd = DateStr();
  CopyString(dato,0,dd,8,2);
  CopyString(dato,strlen(dato),dd,0,2);
  CopyString(dato,strlen(dato),dd,3,2);
 
  // get system time
  tt = TimeStr();
  
  strread = ReadSPGKUNumber();
  CopyString(KUStr,0,strread,0,-1);
  
  if (strlen(KUStr) != 6){		 // Hvis KU nummer ikke er skrevet til EEPROM
   InitSPG();
   strread = ReadSPGKUNumber();
   CopyString(KUStr,0,strread,0,-1);
  } 

  // check om logfil findes, ellers opret en ny logfil. LogDest angiver drev+sti til logfil.
  fhandle = OpenFile (SPGLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
  Fmt(wrtbuf,"%s<%s,%s,KU%s,10MHz lock: TP01 = %f[p2w5]V,%i\n",dato,tt,KUStr,TP01Voltage,AppType);
  bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
  CloseFile(fhandle);

 
// 10 MHz -------- - 6dB --------------------------------------------
 
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," 10 MHz = -6dB ");
 SetGenlockSignal(GENL_10M_LOW);
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST F10MHZ;");

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
 
 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  Genl10MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock 10 MHz til A input ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }


 SetGenlockSignal(GENL_OFF);



// 8. TEST  SDI Genlock -----------------------------------------------------------------
 button_pressed = ConfirmPopup ("SDI Genlock Test ", "PT5210 D1 BLACK #56 forbindes til DUT SDI GENLOCK\n ");

 if (button_pressed == NO){
  HidePanel(spggenlPNL);
  return FALSE;
 }
 
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," SDI genlock  ");
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP SDI;"); //<<<<<<<<<<<<<<<<<<<<<<<<<<<<
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST SDI625;");
 Delay(xd);
 WriteCOMPort(PT5210COM,":OUTP:SB34:SYST SDI625; PATT CBEBU;");
 WriteCOMPort(PT5210COM,":OUTP:SB56:SYST SDI625; PATT CBEBU;");

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 VCOVoltageOk = CheckGenlockVCOVoltage(TP01max,TP01min,TP01MeasDelay,&TP01Voltage);
 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
 
 if (VCOVoltageOk == TRUE)
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  OK\n",TP01Voltage);
  else
   Fmt(MsgStr,"%s<    TP01=%f[p2]V  AFVIST  (%f[p2] - %f[p2])\n",TP01Voltage,TP01min,TP01max);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,MsgStr);

 if ((GenlockStatus != DUT_LOCKED) || (VCOVoltageOk != TRUE)){
  GenlSDIOk = FALSE;
  MessagePopup (" Genlock fejl"," SDI genlock (625) ikke l�st\n eller\n TP01 sp�nding udenfor tol ");
  HidePanel(spggenlPNL);
  return FALSE;
 }




 // check samlet genlock test
 GenlSystemOk = GenlPALOk & GenlNTSCOk & Genl443MHzOk & 
                Genl358MHzOk & Genl10MHzOk & GenlSDIOk;
 
 if (GenlSystemOk == TRUE)
  MessagePopup (" Genlock Test"," OK");
 
 Set5640Standard("G");
 Set5640Standard("M");
 HidePanel(spggenlPNL);

   
return TRUE;
} //MakeSPGGenlockSystem






//--------------------------------------------------------------------------------
int MakeSPGHPHCal(void){
int handle_returned, controlID_returned;
int svar, button_pressed,n;
unsigned int hph[20],
			 hh,
			 hphmean,
			 hphmax,
			 hphmin,
			 hphdiff,
			 hphreadg,
			 hphreadm;
char *strread,*KUread;
char MsgStr[100];



 DisplayPanel (spghphPNL);
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"");
 

 

 SelectPM3094Setup(1);
 SetCtrlVal (spghphPNL, SPGHPH_PNL_SCOPSETUP, " PM3094: FRONTS = F1");

 ProcessDrawEvents();
 
 
 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spghphPNL);
  AutoHPH_PALOk = FALSE;
  AutoHPH_PALOk = FALSE;
  return FALSE;
  }



 // check SW version i SPG
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR SPG;");
 WriteCOMPort(DUTCOM,"COMM 'GI?';"); 
 strread = ReadlnCOMPort(DUTCOM,0.5);
 Scan(strread,"%s>%i",&SPGSWRev);
 

 
 AutoHPH_PALOk = TRUE;
 AutoHPH_NTSCOk = TRUE;

 Set5640Standard("G");
 Set5640Standard("M");

 strread = ReadSPGKUNumber();
 CopyString(KUStr,0,strread,0,-1);
  
 if (strlen(KUStr) != 6){		 // Hvis KU nummer ikke er skrevet til EEPROM
  InitSPG();
  strread = ReadSPGKUNumber();
  CopyString(KUStr,0,strread,0,-1);
 } 
 
 InitSPG();
 

// check at BB-ref modul er monteret
 KUread = ReadBBKUNumber(3,0);	   // XX1_stik er sat til 0 (bruges kun ved TPG'er)
 if ((strcmp(KUread,"999333") != 0) && 
     (strcmp(KUread,"999444") != 0) &&
     (strcmp(KUread,"020721") != 0)){
  MessagePopup(" SPG kalibrering"," BB referencemodul (KU999333, KU999444 eller KU020721) skal v�re monteret som BB #3\n Monter referencemodul og start igen");
  HidePanel (spghphPNL);
  return FALSE;
 }

 
 // Auto HPH for PAL --------------------------------
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");
 SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, "");

 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind DUT GENLOCK B med scop CH-1\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind DUT BB3 med scop CH-2\n\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Afbryd:   Tast F9\n");


 
 WaitForContinue();
 if (AutoHPH_PALOk == FALSE){
  HidePanel(spghphPNL);
  return FALSE;
 }


 // Set genlock input = PAL_ID
 WriteCOMPort(PT5210COM,":OUTP:BB1:SYST PAL_ID; SCHP 0;");

 // Set DUT genlock to input-AB PAL burst
 WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;");  //<<<<<<<<<<<<<<<<<<<<<<<<<<<<
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST PALB;");
 Delay(xd);
 WriteCOMPort(DUTCOM,":OUTP:BB3:SYST PAL_ID; SCHP 0;");
 
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Genlock=PAL burst         BB3=PAL_ID\n");
 Delay(1);
 
 // Check at DUT er genlocked
 n = 0;
 GenlockStatus = GetGenlockStatus();
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," *");
  n++;
  Delay(GenlWaitInterval);
  ProcessDrawEvents();
 }//while
 
 if (GenlockStatus != DUT_LOCKED){
  Fmt(MsgStr,"%s<Genlock PAL til A input ikke l�st    Status=");
  Fmt(MsgStr,"%s[a]<%x",GenlockStatus);
  Fmt(MsgStr,"%s[a]< (hex)");
  MessagePopup ("Genlock fejl",MsgStr);
  HidePanel(spghphPNL);
  return FALSE;
 }

 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21;");

 Delay(1);
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 FlushInQ(DUTCOM);
 
 // disse m�linger gemmes ikke
 for (n = 0; n < 5; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }

  Delay(0.1);
  WriteCOMPort(DUTCOM,"COMM 'GA';"); 
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]",hh);
  Fmt(MsgStr,"%s[a]<\n");
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
 }
 

 // disse m�linger gemmes og middelv�rdi beregnes
 for (n = 0; n < 10; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  
  Delay(0.1);
  WriteCOMPort(DUTCOM,"COMM 'GA';");
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]",hh);
  Fmt(MsgStr,"%s[a]<\n");
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
  hh = hh & 0x00ffffff;
  hph[n] = hh;
 }
 
 // find hph min
 hphmin = 0xffffffff;
 for (n = 0; n < 10; n++) {
  if (hph[n] < hphmin)
   hphmin = hph[n];
 }
 hphmin = hphmin | 0xff000000;   // set 8 MSB bits

 // find hph max
 hphmax = 0x0;
 for (n = 0; n < 10; n++) {
  if (hph[n] > hphmax)
   hphmax = hph[n];
 }
 hphmax = hphmax | 0xff000000;   // set 8 MSB bits
 
 hphdiff = hphmax - hphmin;
 
 
 // calculate mean
 hphmean = 0;
 for (n = 0; n < 10; n++) 
   hphmean = hphmean + hph[n];
 hphmean = hphmean / 10;
 hphmean = hphmean | 0xff000000;   // set 8 MSB bits

 Fmt(MsgStr,"%s<%i[u]",hphmin);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmax);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmean);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,MsgStr);

 if (hphdiff > hphminmaxdiff) {
  Fmt(MsgStr,"%s< Forskel mellem Max og Min er for stor (max forskel: ");
  Fmt(MsgStr,"%s[a]<%i",hphminmaxdiff);
  Fmt(MsgStr,"%s[a]<)\n Kalibrering stoppet");
  MessagePopup (" SPG Kalibreringsfejl: Auto HPH for PAL", MsgStr);
  AutoHPH_PALOk = FALSE;
  HidePanel(spghphPNL);
  return FALSE;
 }
 
 AutoHPH_PALOk = TRUE;

 if (AutoHPH_PALOk == TRUE) {
  Fmt(DUTStr,"%s<COMM 'GV',");
  Fmt(DUTStr,"%s[a]<%i[u]",hphmean);
  Fmt(DUTStr,"%s[a]<;");
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.3);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  if (hphmean != hh)
   AutoHPH_PALOk = FALSE;
 } 
 

  if (AutoHPH_PALOk == FALSE) {
   MessagePopup (" SPG: Auto HPH kalibrering for PAL fejlet", " Middelv�rdi ikke gemt korrekt i SPG\n Kalibrering stoppes");
   HidePanel(spghphPNL);
   return FALSE;
  }

 
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Linie 7 puls i CH-1 skal v�re i samme field som linie 7 puls i CH-2\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Field 1/5 kan skiftes med tasten 'Skift field 1/5'\n");
 
 Repeat = TRUE;
 while (Repeat == TRUE){

  button_pressed = GenericMessagePopup ("SPG kalibrering:  Field 1/5 for PAL",
									    "OK?", "OK", "Afvist", "Skift field 1/5",
									    0, -1, 0,
									    VAL_GENERIC_POPUP_BTN1,
									    VAL_GENERIC_POPUP_BTN2,
									    VAL_GENERIC_POPUP_BTN3);
   switch (button_pressed) {
    case 1: AutoHPH_PALOk = TRUE; Repeat = FALSE; break;
    case 2: AutoHPH_PALOk = FALSE; Repeat = FALSE; break;
    case 3: if (SPGSWRev < 1) 
    		  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GI';");  // old SPG SW
    		 else
    		  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GJ';");  // fra SWver 020
            Delay(0.05);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 'GA?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadg);
            Delay(0.05);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 'GU?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadm);
            Fmt(MsgStr,"%s<GA?=%i[u]  GU?=%i[u]",hphreadg,hphreadm);
			SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, MsgStr);
    		break;
   }

 } //while
 
 
 // if OK   store in EEPROM after HPH NTSC and genlock(PAL & NTSC) calibration
 

  if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL);
   return FALSE;
  }

 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");
 SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, "");


 Set5640Standard("G");
 Set5640Standard("M");
 

 // Auto HPH for NTSC --------------------------------

 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
   
 // Set genlock input = NTSC incl ID-puls i linie 11
 WriteCOMPort(PT5210COM,":OUTP:BB1:SYST NTSC; SCHP 0;");

 // Set DUT genlock to input-AB NTSC burst
 WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST NTSC;");
 Delay(xd);
 WriteCOMPort(DUTCOM,":OUTP:BB3:SYST NTSC; SCHP 0;");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Genlock: NTSC\n");
 Delay(1);

 // Check at DUT er genlocked 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," *");
  n++;
  Delay(GenlWaitInterval);
  ProcessDrawEvents();
 }//while
 
 if (GenlockStatus != DUT_LOCKED){
  Fmt(MsgStr,"%s<Genlock NTSC til A input ikke l�st    Status=");
  Fmt(MsgStr,"%s[a]<%x",GenlockStatus);
  Fmt(MsgStr,"%s[a]< (hex)");
  MessagePopup ("Genlock fejl",MsgStr);
  HidePanel(spghphPNL);
  return FALSE;
 }


 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21;");

 Delay(1);
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 FlushInQ(DUTCOM);
 
 // disse m�linger gemmes ikke
 for (n = 0; n < 5; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_NTSCOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  Delay(0.1);
  WriteCOMPort(DUTCOM,"COMM 'GU';"); 
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GU?';"); 
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]",hh);
  Fmt(MsgStr,"%s[a]<\n");
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
 }
 

 // disse m�linger gemmes og middelv�rdi beregnes
 for (n = 0; n < 10; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_NTSCOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  Delay(0.1);
  WriteCOMPort(DUTCOM,"COMM 'GU';");
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GU?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]",hh);
  Fmt(MsgStr,"%s[a]<\n");
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
  hh = hh & 0x00ffffff;
  hph[n] = hh;
 }
 
 // find hph min
 hphmin = 0xffffffff;
 for (n = 0; n < 10; n++) {
  if (hph[n] < hphmin)
   hphmin = hph[n];
 }
 hphmin = hphmin | 0xff000000;   // set 8 MSB bits

 // find hph max
 hphmax = 0x0;
 for (n = 0; n < 10; n++) {
  if (hph[n] > hphmax)
   hphmax = hph[n];
 }
 hphmax = hphmax | 0xff000000;   // set 8 MSB bits
 
 hphdiff = hphmax - hphmin;

 
 // calculate mean
 hphmean = 0;
 for (n = 0; n < 10; n++) 
   hphmean = hphmean + hph[n];
 hphmean = hphmean / 10;
 hphmean = hphmean | 0xff000000;   // set 8 MSB bits

 Fmt(MsgStr,"%s<%i[u]",hphmin);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmax);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmean);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,MsgStr);
 
 if (hphdiff > hphminmaxdiff) {
  Fmt(MsgStr,"%s< Forskel mellem Max og Min er for stor (max forskel: ");
  Fmt(MsgStr,"%s[a]<%i",hphminmaxdiff);
  Fmt(MsgStr,"%s[a]<)\n Kalibrering stoppet");
  MessagePopup (" SPG Kalibreringsfejl: Auto HPH for NTSC", MsgStr);
  AutoHPH_NTSCOk = FALSE;
  HidePanel(spghphPNL);
  return FALSE;
 }

 AutoHPH_NTSCOk = TRUE;

 if (AutoHPH_NTSCOk == TRUE) {
  Fmt(DUTStr,"%s<COMM 'GY',");
  Fmt(DUTStr,"%s[a]<%i[u]",hphmean);
  Fmt(DUTStr,"%s[a]<;");
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.3);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 'GU?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  if (hphmean != hh)
   AutoHPH_NTSCOk = FALSE;
 } 
 

  if (AutoHPH_NTSCOk == FALSE) {
   MessagePopup (" SPG: Auto HPH kalibrering for NTSC fejlet","Middelv�rdi ikke gemt korrekt i SPG\n Kalibrering stoppes");
   HidePanel(spghphPNL);
   return FALSE;
  }



 SelectPM3094Setup(2);
 SetCtrlVal (spghphPNL, SPGHPH_PNL_SCOPSETUP, " PM3094: FRONTS = F2");

 
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Linie 11 puls i CH-1 skal v�re i samme field som linie 11 puls i CH-2\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Field 1/3 kan skiftes med tasten 'Skift field 1/3'\n");
 
 Repeat = TRUE;
 while (Repeat == TRUE){

  button_pressed = GenericMessagePopup ("SPG kalibrering:  Field 1/3 for NTSC",
									    "OK?", "OK", "Afvist", "Skift field 1/3",
									    0, -1, 0,
									    VAL_GENERIC_POPUP_BTN1,
									    VAL_GENERIC_POPUP_BTN2,
									    VAL_GENERIC_POPUP_BTN3);
   switch (button_pressed) {
    case 1: AutoHPH_NTSCOk = TRUE; Repeat = FALSE; break;
    case 2: AutoHPH_NTSCOk = FALSE; Repeat = FALSE; break;
    case 3: if (SPGSWRev < 1) 
    		  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GJ';");  // old SPG SW
    		 else
    		  WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GK';");  // fra SWver 020
            Delay(0.05);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 'GA?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadg);
            Delay(0.05);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 'GU?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadm);
            Fmt(MsgStr,"%s<GA?=%i[u]  GU?=%i[u]",hphreadg,hphreadm);
			SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, MsgStr);
    		break;
   }

 } //while
 

 // if OK  store in EEPROM after genlock(PAL & NTSC) calibration. See MakeSPGGenlockCal

 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");


 HidePanel (spghphPNL);
 
return AutoHPH_NTSCOk;
} //MakeSPGHPHCal







//-------------------------------------------------------------------------------
void SetSPGGenlockValue(int genlval){
char SPGGenlStr[11];

 if (TV == PAL)
   Fmt(DUTStr,"%s<COMM 'GF',");
  else
   Fmt(DUTStr,"%s<COMM 'GG',");
 Fmt(DUTStr,"%s[a]<%i",genlval);
 Fmt(DUTStr,"%s[a]<;");

 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.05);
} //SetSPGGenlockValue







//-------------------------------------------------------------------------------
int MakeSPGGenlockCal(int TVSys) {
/* 
 Der kalibreres altid med BB3, som her skal v�re et BB-reference modul
 Kalibreringsdata gemmes i SPGLogFile ved godkendt kalibrering
*/
char TitleStr[50],
	 MsgStr[50],
	 *strread,
	 *strread1,
	 *KUread,
	 wrtbuf[80],
	 SPGCalData[40],
	 MasterSPGSW[20];
char *dd,					// MM-DD-YYYY
	 *tt;					// HH:MM:SS

int handle_returned, controlID_returned;
int fhandle,
	bytes_written;



 Set5640Standard("G");
 Set5640Pattern("G", 290);
 Set5640Standard("M");
 Set5640Pattern("M", 290);
 
 TV = TVSys;
 

 SPGdone = FALSE;
 
 if (TVSys == PAL)
   SPGGenlPhasePALOk = FALSE;
  else
   SPGGenlPhaseNTSCOk = FALSE;
 
 DisplayPanel (spgphasePNL);


 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spgphasePNL);
  SPGCalOk = FALSE;
  return FALSE;
  }


 if (TVSys == PAL)
   SetPanelAttribute (spgphasePNL, ATTR_TITLE, " SPG genlock PAL        (BB3 = ref) ");
  else
   SetPanelAttribute (spgphasePNL, ATTR_TITLE, " SPG genlock NTSC       (BB3 = ref) ");


 
 if (TVSys == PAL) {
  SPGGenlValue = 0;
  SPGGenlOffsetValue = 26240;
  SetCtrlAttribute (spgphasePNL, SPGPHA_PNL_SLIDE, ATTR_MAX_VALUE, SPGGenlValue + 2000);
  SetCtrlAttribute (spgphasePNL, SPGPHA_PNL_SLIDE, ATTR_MIN_VALUE, SPGGenlValue - 2000);
  SetCtrlVal (spgphasePNL, SPGPHA_PNL_SLIDE, SPGGenlValue);
  SetPM5662(PAL);
 } 
 
 if (TVSys == NTSC) {
  SPGGenlValue = 0;
  SPGGenlOffsetValue = 23260;
  SetCtrlAttribute (spgphasePNL, SPGPHA_PNL_SLIDE, ATTR_MAX_VALUE, SPGGenlValue + 2000);
  SetCtrlAttribute (spgphasePNL, SPGPHA_PNL_SLIDE, ATTR_MIN_VALUE, SPGGenlValue - 2000);
  SetCtrlVal (spgphasePNL, SPGPHA_PNL_SLIDE, SPGGenlValue);
  SetPM5662(NTSC);
 }
 
 

 ResetTextBox(spgphasePNL, SPGPHA_PNL_TXTBOX,"");
 if (TVSys == PAL) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST PAL_ID; SCHP 0;");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind DUT BB3         til 5662 CH-B\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Indstil 5662M: WFM  A-B  INT REF  2H  X-MAG\n\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Fase afl�ses p� 5662M\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Afl�s 5662M: Juster s� faseforskel mellem 5662M CH-A og CH-B = 0\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Ved fejl: tryk F9\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Ved OK: tryk F4");
 }

 if (TVSys == NTSC) {
  WriteCOMPort(PT5210COM,":OUTP:BB1:SYST NTSC; SCHP 0;");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind PT5210 BB til DUT GENLOCK A\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind DUT GENLOCK B   til 5662 CH-A\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Forbind DUT BB3         til 5662 CH-B\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," NB: Kabler fra DUT til 5662 SKAL v�re lige lange!!\n\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Indstil 5662G: WFM  A-B  INT REF  2H  X-MAG\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Fase afl�ses p� 5662G\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Afl�s 5662G: Juster s� faseforskel mellem 5662G CH-A og CH-B = 0\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Ved fejl: tryk F9\n");
  SetCtrlVal(spgphasePNL, SPGPHA_PNL_TXTBOX," Ved OK: tryk F4");
 }

 
 if (TVSys == PAL){
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); //<<<<<<<<<<<<<<<<<<<<<<<<<
   Delay(xd);
   WriteCOMPort(DUTCOM,"SYST PALB;");
   Delay(xd);
   WriteCOMPort(DUTCOM,":OUTP:BB3:SYST PAL_ID; SCHP 0;");
  }  
  
  if (TVSys == NTSC){
   WriteCOMPort(DUTCOM,":INP:GENL:INP A_B;"); // <<<<<<<<<<<<<<<<<<<<<<<<<<
   Delay(xd);
   WriteCOMPort(DUTCOM,"SYST NTSC;");
   Delay(xd);
   WriteCOMPort(DUTCOM,":OUTP:BB3:SYST NTSC; SCHP 0;");
  }
   

 

 // Send addr for SPG#
 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21;");
 Delay(0.1);


 SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
 

 // her ventes indtil brugeren har tastst OK=F4 eller FEJL=F9
 while (SPGdone == FALSE) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 }



 // Da NTSC kalibreres efter PAL, gemmes v�rdierne i EEPROM efter NTSC kalibreringen
 // Dette foruds�tter at AutoHPH kalibreringen er udf�rt inden genlock kalibreringen
 
 SPGPhaseCalOk = FALSE;
 if ((TV == NTSC) && (AutoHPH_PALOk == TRUE) && (AutoHPH_NTSCOk == TRUE) && 
  	 (SPGGenlPhasePALOk == TRUE) && (SPGGenlPhaseNTSCOk == TRUE))
  SPGPhaseCalOk = TRUE;  
  	
 if ((TV == NTSC) && (SPGPhaseCalOk == TRUE)){
  WriteSPGCalDate();
  WriteCOMPort(DUTCOM,":FACT:SPGG:STOR;");
  Delay(0.5);
  
  // check af at de 4 v�rdier er gemt korrekt i EEPROM
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:SPGG:STOR?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(SPGCalData,0,strread,0,-1);
  Delay(0.5);
  
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:SPGG:READ?;");
  strread1 = ReadlnCOMPort(DUTCOM,0.5);
  
  
  
  if (CompareStrings (strread, 0, strread1, 0, 0) != 0) {
   MessagePopup (" SPG kalibrering", " FEJL: Kalibreringsdata ikke gemt korrekt i EEPROM");
   if (TV == PAL)
    SPGGenlPhasePALOk = FALSE;
   else
    SPGGenlPhaseNTSCOk = FALSE;
   SPGPhaseCalOk = FALSE;
  }
  else{  // dvs SPG cal = ok
  
   // get system date 
   dd = DateStr();
   CopyString(dato,0,dd,8,2);
   CopyString(dato,strlen(dato),dd,0,2);
   CopyString(dato,strlen(dato),dd,3,2);
 
   // get system time
   tt = TimeStr();
  
   // check om logfil findes, ellers opret en ny logfil
   fhandle = OpenFile (SPGLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
   
   // SPG cal data + SW gemmes i logfil
   strread = ReadMasterSWVer();
   CopyString(MasterSPGSW,0,strread,0,-1);
   
   Fmt(wrtbuf,"%s<%s,%s,%s,%s,SW=%s,%i\n",dato,tt,KUStr,SPGCalData,MasterSPGSW,AppType);	// KUStr: se InitSPG
   bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
   CloseFile(fhandle);
   
   
   MessagePopup (" SPG kalibrering", " Kalibreringsdata gemt i EEPROM og i SPG-logfil");
   }
  
 } //if ((TV == NTSC) && (SPGPhaseCalOk == TRUE))
 
 
 HidePanel (spgphasePNL);
 
 if (TV == NTSC){
  SPGCalOk = SPGPhaseCalOk & AutoHPH_PALOk & AutoHPH_NTSCOk;
 
 }
 
 

 if (TV == PAL)
   return SPGGenlPhasePALOk;
  else
   return SPGGenlPhaseNTSCOk;
 
} // MakeSPGGenlockCal









//--------------------------------------------------------------------------------
int MakeOCXOCal(int Freq){	  // Freq = 27 or 10
char MsgTxt[100],
     TP01Txt[30];
int handle_returned, controlID_returned;
ViReal64 freqmeas,diff,tp01meas; // = double
double FreqNom, FreqTol;


 DisplayPanel(ocxoPNL);

 if (CheckHP53132ExtRef() == FALSE){
   HidePanel(ocxoPNL);
   F27Ok = FALSE;
   return F27Ok;
   } 
   
   
 if (GPSStatusOk == FALSE){      // see  CheckXLDCRef(void) in cviutil.c
   Fmt(MsgTxt,"%s< TrueTime GPS modtager virker ikke korrekt:\n %s",GPSStatusStr);
   MessagePopup (" Fejl ved reference til counter HP53132 ",MsgTxt);
   HidePanel(ocxoPNL);
   F27Ok = FALSE;
   return F27Ok;
 }
   

 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (ocxoPNL);
  F27Ok = FALSE;
  F10Ok = FALSE;
  return FALSE;
  }
 
 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(ocxoPNL);
  return FALSE;
 }

 
 ResetTextBox(ocxoPNL, OCXO_PNL_TXTBOX,"");

 if (Freq == 27){
   SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_VISIBLE, TRUE);
   SetCtrlAttribute (ocxoPNL, OCXO_PNL_DEC1, ATTR_VISIBLE, TRUE);
   SetPanelAttribute (ocxoPNL, ATTR_TITLE, " 27 MHz OCXO ref justering ");
   WriteCOMPort(DUTCOM,":INP:GENL:INP INT;");
   Fmt(MsgTxt,"%s< � %f[p1] Hz",F27FreqTol);
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind probe fra HP53132 CH-A til TP8\n");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Juster frekvens med R151\n\n");
   FreqNom = F27FreqNom;
   FreqTol = F27FreqTol;
   F27Ok = TRUE;
  } 

 if (Freq == 10){
   SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_VISIBLE, FALSE);
   SetCtrlAttribute (ocxoPNL, OCXO_PNL_DEC1, ATTR_VISIBLE, FALSE);
   SetPanelAttribute (ocxoPNL, ATTR_TITLE, " 10 MHz OCXO ref justering ");
   WriteCOMPort(DUTCOM,":INP:GENL:INP INTERNAL2;");
   Fmt(MsgTxt,"%s< � %f[p1] Hz",F10FreqTol);
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind probe fra HP53132 CH-A til TP8\n");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Juster frekvens med R49\n\n");
   FreqNom = F27FreqNom;
   FreqTol = F27FreqTol;
   F10Ok = TRUE;
  } 



 // TP01 sp�nding ved justering af 27MHz ref
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_MAX_VALUE, TP01Intmax + 0.4);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_MIN_VALUE, TP01Intmin - 0.4);
 Fmt(TP01Txt,"%s<TP01:  %f[p1] - %f[p1] Volt",TP01Intmin,TP01Intmax);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_LABEL_TEXT, TP01Txt);


 DisplayPanel(ocxoPNL);

 if (CheckFrontRearTerminal(FRONTTERM34401) == FALSE) {
  HidePanel(ocxoPNL);
  return FALSE;
 }

 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," HUSK: Apparatet skal have v�ret t�ndt i MINDST 2 timer\n");
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX,"       HP53132 skal have v�ret t�ndt i MINDST 1 time\n\n");
 if (Freq == 27)
  SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Kontroller med HP34401 sp�ndingen i TP01 efter justering af R151\n\n\n");
 
 SetCtrlVal(ocxoPNL,OCXO_PNL_TXTBOX, " Ved fejl: Tryk F9\n");
 SetCtrlVal(ocxoPNL,OCXO_PNL_TXTBOX, " Ved OK:   Tryk F4\n");
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_LABEL_TEXT, MsgTxt);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_RED);

#if IEEEBUS
 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 0);

 DevClear (0, 3);
 ErrIEEE = hp5313xa_init ("GPIB::3", VI_OFF, VI_ON, 2, &hp53132);
 Delay(0.1);
 ErrIEEE = hp5313xa_freqPeriodRatio (hp53132, 1, 1, 9, VI_ON, 1);
#endif 
 

 done = FALSE;
 while (done == FALSE) {
  
  // M�ling i TP01
#if IEEEBUS
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34401a_singleMeas (hp34401, &tp01meas);
 EnableBreakOnLibraryErrors();
#else
 tp01meas = 1.4;
 Delay(0.1);
#endif 

  // M�ling af frekvens
#if IEEEBUS
 DisableBreakOnLibraryErrors();
 hp5313xa_writeInstrData (hp53132, ":READ?");
 Delay(1.5);
 ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeas);
 if (ErrIEEE == 0xBFFF0015)  //Timeout
  freqmeas = 0.0;
 Delay(0.1);
 EnableBreakOnLibraryErrors();
#else
 if (Freq == 27)
  freqmeas = 27.0e6;
 else
  freqmeas = 10.0e6;
 Delay(0.1);
#endif 
 
  // min max slide values
  
  diff = fabs(freqmeas - FreqNom);
  if (diff <= 10) {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 10.0);
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -10.0);
   } 
   else 
  if (diff <= 30) {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 50.0);
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -50.0);
   } 
   else
  if (diff <= 80) {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 100.0);
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -100.0);
   } 
   else
  if (diff <= 400) {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 500.0);
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -500.0);
   } 
   else {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 2000.0);
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -2000.0);
   } 

  SetCtrlVal (ocxoPNL, OCXO_PNL_SLIDE, freqmeas - FreqNom);
  Fmt(MsgTxt,"%s<%f[p1]",freqmeas);
  SetCtrlVal (ocxoPNL, OCXO_PNL_FREQ, MsgTxt);

  SetCtrlVal (ocxoPNL, OCXO_PNL_TP01VOLT, tp01meas);	

  ProcessDrawEvents();
  
  if (fabs(freqmeas - FreqNom) > FreqTol) {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_FILL_COLOR, VAL_RED);
	SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_RED);
   } 
   else {
    SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_FILL_COLOR, VAL_GREEN);
	SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_GREEN);
   } 
   
  if ((tp01meas > TP01Intmax) || (tp01meas < TP01Intmin)){
	SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_FILL_COLOR,VAL_RED);
   } 
   else {
	SetCtrlAttribute (ocxoPNL, OCXO_PNL_TP01VOLT, ATTR_FILL_COLOR, VAL_GREEN);
   } 

  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
 } // while

 
 HidePanel(ocxoPNL);


 if (Freq == 27)
   return F27Ok;
  else
   return F10Ok;
}




					   

//--------------------------------------------------------------------------------
int MakeSPGReset(void){ 
int button_pressed;
int dd[4];
char *strread, msgstr[100];

 if (WriteProtect(OFF,FALSE) == FALSE){
  SPGResetOk = FALSE;
  return FALSE;
  }

 button_pressed = ConfirmPopup ("Reset SPG", "ADVARSEL: Reset bruges normalt kun p� nyproducerede SPG'er\nKalibreringsdata nulstilles");

 if (button_pressed == NO){
  SPGResetOk = SPGNOTRESET;
  return SPGResetOk;
 }

 WriteCOMPort(DUTCOM,":FACT:V24C:ADDR 21; COMM 'GZ';");
 Delay(0.1);
 WriteCOMPort(DUTCOM,":FACT:SPGG:STOR;"); 
 Delay(0.3);
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:SPGG:READ?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (StringLength(strread) > 0)
   Scan(strread,"%s>%4i[x]",dd);
  else {
   dd[0] = 0; dd[1] = 0; dd[2] = 0; dd[3] = 0;
  }
  
 if (RS232Timeout == TRUE)
   Fmt(msgstr,"%s< Timeout ved l�sning fra SPG");
  else
   Fmt(msgstr,"%s< Data l�st: %s\n Forventet: 196290,28810,196290,28810",strread);

 SPGResetOk = FALSE;
 if ((dd[0] == 196290) && (dd[1] == 28810) && (dd[2] == 196290) && (dd[3] == 28810))
  SPGResetOk = TRUE;
  
 if (SPGResetOk == TRUE)
   MessagePopup ("Reset SPG", "Kalibreringsdata er nu nulstillet\nSluk / t�nd for apparatet");
  else
   MessagePopup ("Reset af kalibreringsdata FEJLET",msgstr);


return SPGResetOk;
}


//----------------------------------------------------------------------------------
int WriteSPGCalDate(void){
char *dd;					// MM-DD-YYYY

 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);

 
 // 4  kalibreringsdato 
 CopyString(DUTStr,0,":FACT:SPGG:TEXT 4,'",0,-1);
 CopyString(DUTStr,StringLength(DUTStr),dato,0,-1);
 CopyString(DUTStr,StringLength(DUTStr),"';",0,-1);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.3);

return TRUE;
}






//----------------------------------------------------------------------------------
char *ReadSPGKUNumber (void) {
  // read SPG KU nummer  (user text 2)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:SPGG:TEXT? 2;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,3,6);	// "KUxxxxxx"	 return xxxxxx
 return strread;
}						  



//----------------------------------------------------------------------------------
char *ReadSPGProdDate (void) {
  // read SPG produktions dato  (user text 3)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:SPGG:TEXT? 3;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}


//----------------------------------------------------------------------------------
char *ReadSPGCalDate (void) {
  // read SPG kalibrerings dato  (user text 4)
char *strread;
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:SPGG:TEXT? 4;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  CopyString(strread,0,strread,1,6);

 return strread;
}






//----------------------------------------------------------------------------------
int InitSPG(void){

int n, 
    ValidSPGKU, 
    ValidMainKU;
char *usertxt, 
     *strread,
     *dd,					// MM-DD-YYYY
     *KUread;				// L�st KU nummer
unsigned char response[10]; // svar fra PromptPopup
 

 // 0  producent
 WriteCOMPort(DUTCOM, ":FACT:SPGG:TEXT 0,'PTV';");
 Delay(xd);

 // 1  12nc
 Fmt(DUTStr,"%s<:FACT:SPGG:TEXT 1,'%s';",NC12[7]);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(xd);
 
 // 2  KU nummer
 ValidSPGKU = TRUE;
 KUread = ReadSPGKUNumber();				     // get KU-number from SPG-EEPROM
 if (isdigit(KUread[0]) == FALSE){
   CopyString(KUread,0,"",0,-1);
   ValidSPGKU = FALSE;
 }

 if (ValidSPGKU == FALSE){
   FlushInQ(DUTCOM);	                         //get KU-number from main-board EEPROM
   WriteCOMPort(DUTCOM,":FACT:MAIN:TEXT? 2;");
   strread = ReadlnCOMPort(DUTCOM,0.5);          // "KUxxxxxx"
   CopyString(strread,0,strread,3,6);			 // xxxxxx
   ValidMainKU = ((isdigit(strread[0])) != FALSE) &&
                 ((isdigit(strread[1])) != FALSE) &&
                 (strlen(strread) == 6);
   if (ValidMainKU == TRUE)
     CopyString(KUread,0,strread,0,6);
    else
     CopyString(KUread,0,"",0,-1);
   
 }
  
 EnterKUNo(" SPG", KUread, response);

 Fmt(DUTStr,"%s<:FACT:SPGG:TEXT 2,'KU%s';",response);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(xd);
 

 // get system date 
 dd = DateStr();
 CopyString(dato,0,dd,8,2);
 CopyString(dato,StringLength(dato),dd,0,2);
 CopyString(dato,StringLength(dato),dd,3,2);
 
 // 3  produktionsdato
 usertxt = ReadSPGProdDate();
 if (isdigit(usertxt[0]) == FALSE){			  
  Fmt(DUTStr,"%s<:FACT:SPGG:TEXT 3,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(xd);
 }

 // 4  kalibreringsdato 
 usertxt = ReadSPGCalDate();
 if (isdigit(usertxt[0]) == FALSE){			  
  Fmt(DUTStr,"%s<:FACT:SPGG:TEXT 4,'%s';",dato);
  WriteCOMPort(DUTCOM, DUTStr);
  Delay(xd);
 }


 // 6  PT-nummer
 if (AppType == PT5210)
   WriteCOMPort(DUTCOM, ":FACT:SPGG:TEXT 6,'PT5210';");
  else
   WriteCOMPort(DUTCOM, ":FACT:SPGG:TEXT 6,'PT5230';");
  
 Delay(xd);

 // 7  reserveret - ikke defineret.


return TRUE;
} // InitSPG




//----------------------------------------------------------------------------------
int BasicTotalTest(int TestNo){

	VoltOk = FALSE;
	FanOk = FALSE;
	OvenOk = FALSE;
	F27Ok = FALSE;
	GenlInputOk = FALSE;
	GenlSystemOk = FALSE;
	SPGCalOk = FALSE;
	BBCalOk = FALSE;
	SPGResetOk = FALSE;
	
	
	if (TestNo == TOTMENU_BASIC_RESETSPG)
	 MakeSPGReset();

	if ((TestNo == TOTMENU_BASIC_PS) || (SPGResetOk == TRUE) || (SPGResetOk == SPGNOTRESET))
	 CalPowerSupply();

	if ((TestNo == TOTMENU_BASIC_FAN) || (VoltOk == TRUE))
	 CheckFan();

	if ((TestNo == TOTMENU_BASIC_OVEN) || (FanOk == TRUE))
	 CheckOven();

	if ((TestNo == TOTMENU_BASIC_F27) || (OvenOk == TRUE))
	 MakeOCXOCal(27);

	if ((TestNo == TOTMENU_BASIC_GENL) || (F27Ok == TRUE)){
	 if (MakeSPGGenlockInput() == TRUE)
	  MakeSPGGenlockSystem();
	} 

	if ((TestNo == TOTMENU_BASIC_SPG) || ( (GenlInputOk == TRUE) && (GenlSystemOk == TRUE) )){
	 if (MakeSPGHPHCal() == TRUE)
	  if (MakeSPGGenlockCal(PAL) == TRUE)
	   MakeSPGGenlockCal(NTSC);
	}   

	if ((TestNo == TOTMENU_BASIC_BB1) || (SPGCalOk == TRUE)){
	 if (MakeSyncOffsetCal(1,SYNC_CAL,0) == TRUE)
	  if (MakeSyncOffsetCal(1,OFFSET_CAL,0) == TRUE)
	   if (MakePhaseCal(1,PAL) == TRUE)
	    MakePhaseCal(1,NTSC);
	}    

	if ((TestNo == TOTMENU_BASIC_BB2) || (BBCalOk == TRUE)){
	 if (MakeSyncOffsetCal(2,SYNC_CAL,0) == TRUE)
	  if (MakeSyncOffsetCal(2,OFFSET_CAL,0) == TRUE)
	   if (MakePhaseCal(2,PAL) == TRUE)
	    MakePhaseCal(2,NTSC);
	}
	
return TRUE;
}




//----------------------------------------------------------------------------------
int CVICALLBACK OkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	Cont = TRUE; break;
	}	
		
return 0;
}



int CVICALLBACK SPGOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	SPGdone = TRUE;
							if (TV == PAL)
							  SPGGenlPhasePALOk = TRUE;
							 else
 							  SPGGenlPhaseNTSCOk = TRUE;
 							break;
	}
	return 0;
}



int CVICALLBACK ExitSPGCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	Cont = TRUE; 
							AutoHPH_PALOk = FALSE; 
							AutoHPH_NTSCOk = FALSE; 
 							GenlBOk = FALSE;
 							GenlA_BOk = FALSE;
 							GenlPALOk = FALSE;
 							GenlNTSCOk = FALSE;
 							Genl443MHzOk = FALSE;
 							Genl358MHzOk = FALSE;
 							Genl10MHzOk = FALSE;
 							GenlSDIOk = FALSE;
							SPGdone = TRUE;
							if (TV == PAL)
							  SPGGenlPhasePALOk = FALSE;
							 else
							  SPGGenlPhaseNTSCOk = FALSE;
							break;
		
		
	}
	return 0;
}



int CVICALLBACK SPGPilopCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SPGGenlValue = SPGGenlValue + 2;
			SetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}

int CVICALLBACK SPGPilnedCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SPGGenlValue = SPGGenlValue - 2;
			SetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}

int CVICALLBACK SPGSlideCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_VAL_CHANGED:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}

int CVICALLBACK OCXOOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: done = TRUE;
			break;
	}
	return 0;
}

int CVICALLBACK OCXOExitCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT: done = TRUE; F27Ok = FALSE; F10Ok = FALSE;
			break;
	}
	return 0;
}




//-----------  Call back ved afslutning af valg af genlock signaler -----------
int CVICALLBACK ReturnSelGenlCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			 HidePanel(selgenlPNL);
			break;
	}
	return 0;
}

//-----------  Call back ved valg af genlock signaler ----(se spggenl.uir)-----------
int CVICALLBACK GenlSignalCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
int stsel,stattn;
	switch (event) {
		case EVENT_VAL_CHANGED:
			GetCtrlVal (selgenlPNL, SELGEN_PNL_GENLRING, &stsel);
			GetCtrlVal (selgenlPNL, SELGEN_PNL_GENLATTN, &stattn);
			if ((stsel >= 0) && (stsel <=2))
			  SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);
			 else
			  SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE);
			 switch (stsel){
			  case 0: SetGenlockSignal(GENL_OFF);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 1: SetGenlockSignal(GENL_PAL); 
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 2: SetGenlockSignal(GENL_NTSC);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 3: if (stattn == TRUE)
			            SetGenlockSignal(GENL_443_LOW);
			           else
			            SetGenlockSignal(GENL_443_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			  case 4: if (stattn == TRUE)
			            SetGenlockSignal(GENL_358_LOW);
			           else
			            SetGenlockSignal(GENL_358_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			  case 5: if (stattn == TRUE)
			            SetGenlockSignal(GENL_10M_LOW);
			           else
			            SetGenlockSignal(GENL_10M_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			 } // switch
			break;  // switch
	}
	return 0;
}

