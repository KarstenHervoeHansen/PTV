#include <userint.h>
#include <ansi_c.h>
#include <formatio.h>
#include <rs232.h>
#include <utility.h>
#include "cviutil.h"


const int 	XLDCCOM = 8;		// TrueTime GPS receiver XL-DC i test rack   COM Port#
const char 	*COMname[9] = {"","com1","com2","","","com5","com6","com7","com8"};





int		RS232Timeout,
		done, 
		Cont;

char 	ASCIIdata[100];			// ASCII data read from a COM port
 









//-------------------------------------------------------------------------------
char *ReadlnCOMPort(int PortNo, double Timeout){
int bytes_read;
 SetComTime (PortNo, Timeout);   // set timeout
 ASCIIdata[0] = 0x0;
 bytes_read = ComRdTerm (PortNo, ASCIIdata, 100, LF);   //terminates on LF
 if (bytes_read > 0) {
  if(ASCIIdata[bytes_read - 1] == CR)
    ASCIIdata[bytes_read - 1] = 0x00;
 RS232Timeout = FALSE;
 }  
  else{
   ASCIIdata[0] = 0x30;
   ASCIIdata[1] = 0x00;	   // '0' + NULL
   RS232Timeout = TRUE;
  }
 
 return (&ASCIIdata[0]);
}



//-------------------------------------------------------------------------------
void WriteCOMPort(int PortNo, char TransmitStr[]){
int bytes_send;
int NoOfBytes;

 NoOfBytes = StringLength (TransmitStr);
 FlushOutQ(PortNo);
 bytes_send = ComWrt (PortNo, TransmitStr, NoOfBytes);
 
 while 
  (GetOutQLen(PortNo)> 0);
}


void WriteCOMPortTerm(int PortNo, char TStr[],int Term){
// send TransmitStr terminated with Term (CR or LF)
int bytes_send;
int NoOfBytes;
char TransmitStr[50];

 Fmt(TransmitStr,"%s<%s%c",TStr,Term); 

 NoOfBytes = StringLength (TransmitStr);
 FlushOutQ(PortNo);
 bytes_send = ComWrt (PortNo, TransmitStr, NoOfBytes);
 
 while 
  (GetOutQLen(PortNo)> 0);
}




//-------------------------------------------------------------------------------
void WaitForContinue(void){
int handle_returned, controlID_returned;
 Cont = FALSE;
 while (Cont == FALSE)
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
}





