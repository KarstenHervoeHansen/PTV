/*
Program til overv�gning af TrueTime GPS-modtager XL-DC i FMS.

Programmet kommunikerer med XL-DC via PC COM-port #8 (9600 baud,8 bit,2 stop ,none par)
Der l�ses XL-DC status for: antenne, PLL-status og GPS-status.
Status l�ses med Serial Function F72 (manual see section 3-272, page 3-67)

Status skrives til fil p� LAN (se GPSStatusFile) hver 2. minut (hele minuttal)


PF, 980812
*/

#include <utility.h>
#include <formatio.h>
#include <ansi_c.h>
#include <rs232.h>
#include <userint.h>
#include "cviutil.h"




char GPSStatusFile[50] = {"m:\\measdata\\5230\\gpsstat.dat"};
//char GPSStatusFile[50] = {"gpsstat.dat"};	   // kun ved test+debug




int WriteXLDCStatusToFile(int ant, int pll, int gps){
int bytes_written,
    fhandle,
    fileerr;
char *tt,
	 *dd,
     timestr[10],
     datestr[10],
     wrtbuf[100];

 tt = TimeStr();				// get system time
 CopyString(timestr,0,tt,0,5);	// get hour+minutes string
 dd = DateStr();				// get system date
 CopyString(datestr,0,dd,0,-1);	// get date string

 fhandle = OpenFile (GPSStatusFile, VAL_WRITE_ONLY, VAL_TRUNCATE, VAL_ASCII);
 
 Fmt(wrtbuf,"%s<%s\n%s\n",datestr,timestr);	
 bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
 
 Fmt(wrtbuf,"%s<XLDC: ANT %i PLL %i GPS %i\n",ant,pll,gps);	
 bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
 
 fileerr = CloseFile (fhandle);
return (fileerr != -1);   
}









void ReadXLDCFaultStatus(int *ant, int *pll, int *gps){
char *strread;
char StatusStr[50];

 WriteCOMPortTerm(XLDCCOM, "F72",CR);		 // see 3-272

 strread = ReadlnCOMPort(XLDCCOM, 2.0);
 CopyString(StatusStr,0,strread,0,strlen(strread)); 
 
 *ant = (FindPattern (StatusStr, 0, -1, "Antenna: OK", 1, 1) > 0);
 *pll = (FindPattern (StatusStr, 0, -1, "PLL: OK", 1, 1) > 0);
 *gps = (FindPattern (StatusStr, 0, -1, "GPS: Locked", 1, 1) > 0);

}






int main (int argc, char *argv[])
{

int antst,	   // antenna status
    pllst,	   // pll status
    gpsst,	   // gps status
    filest,
    minute,
    n;
char *tt,
     minutestr[5];    


#if AT232	
 if (OpenComConfig (XLDCCOM, COMname[XLDCCOM], 9600, 0, 8, 2, 500, 500) != 0){
   MessagePopup (" Kan ikke �bne COM8 port", " Afslut program - sluk/t�nd PC - start igen");
   return FALSE;
  }

 WriteCOMPortTerm(XLDCCOM, "",CTRL_C);   // stop sending time information (see nmanual 3-199)
 
 WriteCOMPortTerm(XLDCCOM, "F72",CR);	 // dummy write/read to avoid ERROR 05 message
 ReadlnCOMPort(XLDCCOM, 2.0);

#endif


//  antst = 1; pllst = 1; gpsst = 1;	   // test+debug
 
 while (TRUE){						 // loop forever until PC is switched off
  ReadXLDCFaultStatus(&antst,&pllst,&gpsst);	
  
  tt = TimeStr();					 // get system time
  CopyString(minutestr,0,tt,3,2);	 // get minutes string
  Scan(minutestr,"%s>%i",&minute);	 // scan minutes string into integer

  if ((minute % 2) == 0)				 // check for even minutes
   filest = WriteXLDCStatusToFile (antst,pllst,gpsst);  // write to gps status file
 
  for (n=0;n<25;n++){
  Delay(2.0);
  ProcessSystemEvents();
  }
 } // while


 CloseCom(XLDCCOM);
	
 return 0;
}
