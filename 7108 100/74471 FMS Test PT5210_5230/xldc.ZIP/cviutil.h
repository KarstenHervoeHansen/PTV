#define AT232 1


#define YES     1
#define NO      0
#define TRUE    1
#define FALSE   0
#define LF     10
#define CR     13
#define CTRL_C  3
#define WAIT    1
#define NOWAIT  0
#define ON      1
#define OFF     0


extern const int XLDCCOM;			// TrueTime GPS receiver XL-DC i test rack   COM Port#
extern const char *COMname[];





extern char *ReadlnCOMPort(int PortNo, double Timeout);
extern void WriteCOMPort(int PortNo, char TransmitStr[]);
extern void WriteCOMPortTerm(int PortNo, char TransmitStr[],int Term);
