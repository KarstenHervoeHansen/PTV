
extern int TestAESAudioGen(void);
extern int TestAnalogAudioGen(void);
extern int TestWordClockOutput(void);
extern int CalAnalogAudioLevel(int ChNo);
extern int AnalogAudioFreqCheck(void);
extern int AnalogAudioLevelCheck(void);

extern char *ReadAudioCalDate (void);
extern void MeasAnalogAudioLevel(void);

extern int AudioGenTotalTest(int TestNo);
