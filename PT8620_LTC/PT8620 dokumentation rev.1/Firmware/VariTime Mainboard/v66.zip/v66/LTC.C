enum LTCregs
  {
  set_hh = 0, set_mm, set_ss, ctrl1_reg,  H1_reg, ctrl2_reg=24
  };