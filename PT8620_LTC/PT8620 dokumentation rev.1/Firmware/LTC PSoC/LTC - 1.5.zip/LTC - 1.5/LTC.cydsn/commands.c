//*******************************************************************
// handles commands received by the 5V UART - used for debugging only
//*******************************************************************


#include <device.h>
#include <stdlib.h> //string handling routines etc
#include <stdio.h> //sprintf etc.
#include "global.h"
#include "commands.h"
#include "uart.h"
#include "I2C_2.h"
#include "rtc.h"
#include "procs.h"
#include "vitc.h"
#include "ltc.h"

void HandleSerialCommand(void){
		char xdata *p, *p1;
		byte MyByte;
		if (GetCommand(MyS)) {
					GetNextParam((unsigned int *)&p);
					if ((strcmp(p, "h")==0) || (strcmp(p, "?")==0)) {
						sprintf(MyS, "\n\rPT8620 version %u.%1u command list:\n\n\r", (uint16) VersionTens, (uint16) VersionUnits);
						UART_1_PutString(MyS);
						UART_1_PutString("st <hh> <mm> <ss> : Set RTC time.\n\r");
						UART_1_PutString("gt : Get current time.\n\r");
						UART_1_PutString("rt : Refresh time from selected source.\n\r");
						UART_1_PutString("i : LTC inactive.\n\r");
						UART_1_PutString("a : LTC active.\n\r");
						UART_1_PutString("gps : Set source = GPS.\n\r");
						UART_1_PutString("rtc : Set source = RTC.\n\r");
						UART_1_PutString("vitc : Set source = VITC.\n\r");
						UART_1_PutString("ntsc : Set system to NTSC.\n\r");
						UART_1_PutString("pal : Set system to PAL.\n\r");
						//UART_1_PutString("df : Use drop frames.\n\r");
						//UART_1_PutString("ndf : Use non-drop frames.\n\r");
						
					}
					else if (strcmp(p, "st")==0) { //set time
						GetNextParam((unsigned int *)&p);
						MyByte=(byte) strtol(p, &p1, 10);
						Time.hh=MyByte;
						GetNextParam((unsigned int *)&p);
						MyByte=(byte) strtol(p, &p1, 10);						
						Time.mm=MyByte;
						GetNextParam((unsigned int *)&p);
						MyByte=(byte) strtol(p, &p1, 10);						
						Time.ss=MyByte;
						BCDTime=TimeToBCDTime(&Time);
						RTC_SetTime(&Time);
						sprintf(MyS, "Time set to %02u:%02u:%02u\n\r", (uint16) Time.hh, (uint16) Time.mm, (uint16) Time.ss);				
						UART_1_PutString(MyS);
					}
					else if (strcmp(p, "gt")==0) {
						sprintf(MyS, "Time     %02u:%02u:%02u:%02u\n\r", (uint16) Time.hh, (uint16) Time.mm, (uint16) Time.ss, (int16) Frame);
						UART_1_PutString(MyS);
					}
					else if (strcmp(p, "rt")==0) {
						UART_1_PutString("Refreshing time..\n\r");
						MainI2CBuffer.rw_control1 |= MainI2CRefresh;
					}

					else if (strcmp(p, "i")==0) {
						UART_1_PutString("LTC inactive\n\r");
						Control_Reg_1_Write(Control_Reg_1_Read() & 0xFE);
					}
					else if (strcmp(p, "a")==0) {
						UART_1_PutString("LTC active\n\r");
						Control_Reg_1_Write(Control_Reg_1_Read() | 0x01);
					}
					else if (strcmp(p, "gps")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 = (MainI2CBuffer.rw_control1 & 0x8F)|0x10;
					}
					else if (strcmp(p, "rtc")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 = MainI2CBuffer.rw_control1 & 0x8F;
					}
					else if (strcmp(p, "vitc")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 = (MainI2CBuffer.rw_control1 & 0x8F)|0x20;
					}
					else if (strcmp(p, "ntsc")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 |= 0x80;
					}
					else if (strcmp(p, "pal")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 &= 0x7F;
					}
					
					//extra commands for debugging and development, not listed
					else if (strcmp(p, "df")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 &= 0x8D;
					}
					else if (strcmp(p, "ndf")==0) {
						OverrideI2C=TRUE;
						MainI2CBuffer.rw_control1 |= 0x02;
					}

					else if (strcmp(p, "vb")==0) {
						writeVITC=TRUE;
					}
					else if (strcmp(p, "vs")==0) {
						writeVITC=FALSE;
					}
					else if (strcmp(p, "gs")==0) {
						Decoder_GetStatus();
					}
					else if (strcmp(p, "c")==0) {
						UART_1_PutString("crap\n\r"); //used for testing LTC decoder by sending non valid LTC id pattern
						crapbit=TRUE;
					}
					else if (strcmp(p, "u")==0) {
						UART_1_PutString("uncrap\n\r");
						crapbit=FALSE;
					}
					else if (strcmp(p, "pt")==0) { //phase time difference in µs reported
						sprintf(MyS, "Phase timing=%u\n\r", (uint16) PhaseTiming);				
						UART_1_PutString(MyS);
					}
				
					else UART_1_PutString("? Unknown command. Please try again.\n\r"); //strcat(p,"\n\r"));
		}
}

/* [] END OF FILE */
