/*******************************************************************************
* File Name: J9.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_J9_H) /* Pins J9_H */
#define CY_PINS_J9_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "J9_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    J9_Write(uint8 value) ;
void    J9_SetDriveMode(uint8 mode) ;
uint8   J9_ReadDataReg(void) ;
uint8   J9_Read(void) ;
uint8   J9_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define J9_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define J9_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define J9_DM_RES_UP          PIN_DM_RES_UP
#define J9_DM_RES_DWN         PIN_DM_RES_DWN
#define J9_DM_OD_LO           PIN_DM_OD_LO
#define J9_DM_OD_HI           PIN_DM_OD_HI
#define J9_DM_STRONG          PIN_DM_STRONG
#define J9_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define J9_MASK               J9__MASK
#define J9_SHIFT              J9__SHIFT
#define J9_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define J9_PS                     (* (reg8 *) J9__PS)
/* Data Register */
#define J9_DR                     (* (reg8 *) J9__DR)
/* Port Number */
#define J9_PRT_NUM                (* (reg8 *) J9__PRT) 
/* Connect to Analog Globals */                                                  
#define J9_AG                     (* (reg8 *) J9__AG)                       
/* Analog MUX bux enable */
#define J9_AMUX                   (* (reg8 *) J9__AMUX) 
/* Bidirectional Enable */                                                        
#define J9_BIE                    (* (reg8 *) J9__BIE)
/* Bit-mask for Aliased Register Access */
#define J9_BIT_MASK               (* (reg8 *) J9__BIT_MASK)
/* Bypass Enable */
#define J9_BYP                    (* (reg8 *) J9__BYP)
/* Port wide control signals */                                                   
#define J9_CTL                    (* (reg8 *) J9__CTL)
/* Drive Modes */
#define J9_DM0                    (* (reg8 *) J9__DM0) 
#define J9_DM1                    (* (reg8 *) J9__DM1)
#define J9_DM2                    (* (reg8 *) J9__DM2) 
/* Input Buffer Disable Override */
#define J9_INP_DIS                (* (reg8 *) J9__INP_DIS)
/* LCD Common or Segment Drive */
#define J9_LCD_COM_SEG            (* (reg8 *) J9__LCD_COM_SEG)
/* Enable Segment LCD */
#define J9_LCD_EN                 (* (reg8 *) J9__LCD_EN)
/* Slew Rate Control */
#define J9_SLW                    (* (reg8 *) J9__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define J9_PRTDSI__CAPS_SEL       (* (reg8 *) J9__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define J9_PRTDSI__DBL_SYNC_IN    (* (reg8 *) J9__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define J9_PRTDSI__OE_SEL0        (* (reg8 *) J9__PRTDSI__OE_SEL0) 
#define J9_PRTDSI__OE_SEL1        (* (reg8 *) J9__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define J9_PRTDSI__OUT_SEL0       (* (reg8 *) J9__PRTDSI__OUT_SEL0) 
#define J9_PRTDSI__OUT_SEL1       (* (reg8 *) J9__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define J9_PRTDSI__SYNC_OUT       (* (reg8 *) J9__PRTDSI__SYNC_OUT) 


#if defined(J9__INTSTAT)  /* Interrupt Registers */

    #define J9_INTSTAT                (* (reg8 *) J9__INTSTAT)
    #define J9_SNAP                   (* (reg8 *) J9__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins J9_H */


/* [] END OF FILE */
