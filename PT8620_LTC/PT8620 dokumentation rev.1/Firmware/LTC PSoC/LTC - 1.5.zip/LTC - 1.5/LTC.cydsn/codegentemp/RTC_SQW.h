/*******************************************************************************
* File Name: RTC_SQW.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_RTC_SQW_H) /* Pins RTC_SQW_H */
#define CY_PINS_RTC_SQW_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "RTC_SQW_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    RTC_SQW_Write(uint8 value) ;
void    RTC_SQW_SetDriveMode(uint8 mode) ;
uint8   RTC_SQW_ReadDataReg(void) ;
uint8   RTC_SQW_Read(void) ;
uint8   RTC_SQW_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define RTC_SQW_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define RTC_SQW_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define RTC_SQW_DM_RES_UP          PIN_DM_RES_UP
#define RTC_SQW_DM_RES_DWN         PIN_DM_RES_DWN
#define RTC_SQW_DM_OD_LO           PIN_DM_OD_LO
#define RTC_SQW_DM_OD_HI           PIN_DM_OD_HI
#define RTC_SQW_DM_STRONG          PIN_DM_STRONG
#define RTC_SQW_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define RTC_SQW_MASK               RTC_SQW__MASK
#define RTC_SQW_SHIFT              RTC_SQW__SHIFT
#define RTC_SQW_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define RTC_SQW_PS                     (* (reg8 *) RTC_SQW__PS)
/* Data Register */
#define RTC_SQW_DR                     (* (reg8 *) RTC_SQW__DR)
/* Port Number */
#define RTC_SQW_PRT_NUM                (* (reg8 *) RTC_SQW__PRT) 
/* Connect to Analog Globals */                                                  
#define RTC_SQW_AG                     (* (reg8 *) RTC_SQW__AG)                       
/* Analog MUX bux enable */
#define RTC_SQW_AMUX                   (* (reg8 *) RTC_SQW__AMUX) 
/* Bidirectional Enable */                                                        
#define RTC_SQW_BIE                    (* (reg8 *) RTC_SQW__BIE)
/* Bit-mask for Aliased Register Access */
#define RTC_SQW_BIT_MASK               (* (reg8 *) RTC_SQW__BIT_MASK)
/* Bypass Enable */
#define RTC_SQW_BYP                    (* (reg8 *) RTC_SQW__BYP)
/* Port wide control signals */                                                   
#define RTC_SQW_CTL                    (* (reg8 *) RTC_SQW__CTL)
/* Drive Modes */
#define RTC_SQW_DM0                    (* (reg8 *) RTC_SQW__DM0) 
#define RTC_SQW_DM1                    (* (reg8 *) RTC_SQW__DM1)
#define RTC_SQW_DM2                    (* (reg8 *) RTC_SQW__DM2) 
/* Input Buffer Disable Override */
#define RTC_SQW_INP_DIS                (* (reg8 *) RTC_SQW__INP_DIS)
/* LCD Common or Segment Drive */
#define RTC_SQW_LCD_COM_SEG            (* (reg8 *) RTC_SQW__LCD_COM_SEG)
/* Enable Segment LCD */
#define RTC_SQW_LCD_EN                 (* (reg8 *) RTC_SQW__LCD_EN)
/* Slew Rate Control */
#define RTC_SQW_SLW                    (* (reg8 *) RTC_SQW__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define RTC_SQW_PRTDSI__CAPS_SEL       (* (reg8 *) RTC_SQW__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define RTC_SQW_PRTDSI__DBL_SYNC_IN    (* (reg8 *) RTC_SQW__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define RTC_SQW_PRTDSI__OE_SEL0        (* (reg8 *) RTC_SQW__PRTDSI__OE_SEL0) 
#define RTC_SQW_PRTDSI__OE_SEL1        (* (reg8 *) RTC_SQW__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define RTC_SQW_PRTDSI__OUT_SEL0       (* (reg8 *) RTC_SQW__PRTDSI__OUT_SEL0) 
#define RTC_SQW_PRTDSI__OUT_SEL1       (* (reg8 *) RTC_SQW__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define RTC_SQW_PRTDSI__SYNC_OUT       (* (reg8 *) RTC_SQW__PRTDSI__SYNC_OUT) 


#if defined(RTC_SQW__INTSTAT)  /* Interrupt Registers */

    #define RTC_SQW_INTSTAT                (* (reg8 *) RTC_SQW__INTSTAT)
    #define RTC_SQW_SNAP                   (* (reg8 *) RTC_SQW__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins RTC_SQW_H */


/* [] END OF FILE */
