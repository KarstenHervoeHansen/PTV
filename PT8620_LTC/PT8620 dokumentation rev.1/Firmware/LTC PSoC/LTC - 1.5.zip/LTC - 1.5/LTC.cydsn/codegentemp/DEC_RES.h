/*******************************************************************************
* File Name: DEC_RES.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DEC_RES_H) /* Pins DEC_RES_H */
#define CY_PINS_DEC_RES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DEC_RES_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DEC_RES_Write(uint8 value) ;
void    DEC_RES_SetDriveMode(uint8 mode) ;
uint8   DEC_RES_ReadDataReg(void) ;
uint8   DEC_RES_Read(void) ;
uint8   DEC_RES_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DEC_RES_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DEC_RES_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DEC_RES_DM_RES_UP          PIN_DM_RES_UP
#define DEC_RES_DM_RES_DWN         PIN_DM_RES_DWN
#define DEC_RES_DM_OD_LO           PIN_DM_OD_LO
#define DEC_RES_DM_OD_HI           PIN_DM_OD_HI
#define DEC_RES_DM_STRONG          PIN_DM_STRONG
#define DEC_RES_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DEC_RES_MASK               DEC_RES__MASK
#define DEC_RES_SHIFT              DEC_RES__SHIFT
#define DEC_RES_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DEC_RES_PS                     (* (reg8 *) DEC_RES__PS)
/* Data Register */
#define DEC_RES_DR                     (* (reg8 *) DEC_RES__DR)
/* Port Number */
#define DEC_RES_PRT_NUM                (* (reg8 *) DEC_RES__PRT) 
/* Connect to Analog Globals */                                                  
#define DEC_RES_AG                     (* (reg8 *) DEC_RES__AG)                       
/* Analog MUX bux enable */
#define DEC_RES_AMUX                   (* (reg8 *) DEC_RES__AMUX) 
/* Bidirectional Enable */                                                        
#define DEC_RES_BIE                    (* (reg8 *) DEC_RES__BIE)
/* Bit-mask for Aliased Register Access */
#define DEC_RES_BIT_MASK               (* (reg8 *) DEC_RES__BIT_MASK)
/* Bypass Enable */
#define DEC_RES_BYP                    (* (reg8 *) DEC_RES__BYP)
/* Port wide control signals */                                                   
#define DEC_RES_CTL                    (* (reg8 *) DEC_RES__CTL)
/* Drive Modes */
#define DEC_RES_DM0                    (* (reg8 *) DEC_RES__DM0) 
#define DEC_RES_DM1                    (* (reg8 *) DEC_RES__DM1)
#define DEC_RES_DM2                    (* (reg8 *) DEC_RES__DM2) 
/* Input Buffer Disable Override */
#define DEC_RES_INP_DIS                (* (reg8 *) DEC_RES__INP_DIS)
/* LCD Common or Segment Drive */
#define DEC_RES_LCD_COM_SEG            (* (reg8 *) DEC_RES__LCD_COM_SEG)
/* Enable Segment LCD */
#define DEC_RES_LCD_EN                 (* (reg8 *) DEC_RES__LCD_EN)
/* Slew Rate Control */
#define DEC_RES_SLW                    (* (reg8 *) DEC_RES__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DEC_RES_PRTDSI__CAPS_SEL       (* (reg8 *) DEC_RES__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DEC_RES_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DEC_RES__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DEC_RES_PRTDSI__OE_SEL0        (* (reg8 *) DEC_RES__PRTDSI__OE_SEL0) 
#define DEC_RES_PRTDSI__OE_SEL1        (* (reg8 *) DEC_RES__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DEC_RES_PRTDSI__OUT_SEL0       (* (reg8 *) DEC_RES__PRTDSI__OUT_SEL0) 
#define DEC_RES_PRTDSI__OUT_SEL1       (* (reg8 *) DEC_RES__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DEC_RES_PRTDSI__SYNC_OUT       (* (reg8 *) DEC_RES__PRTDSI__SYNC_OUT) 


#if defined(DEC_RES__INTSTAT)  /* Interrupt Registers */

    #define DEC_RES_INTSTAT                (* (reg8 *) DEC_RES__INTSTAT)
    #define DEC_RES_SNAP                   (* (reg8 *) DEC_RES__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins DEC_RES_H */


/* [] END OF FILE */
