/*******************************************************************************
* File Name: Locked.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Locked_H) /* Pins Locked_H */
#define CY_PINS_Locked_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Locked_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Locked_Write(uint8 value) ;
void    Locked_SetDriveMode(uint8 mode) ;
uint8   Locked_ReadDataReg(void) ;
uint8   Locked_Read(void) ;
uint8   Locked_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Locked_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Locked_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Locked_DM_RES_UP          PIN_DM_RES_UP
#define Locked_DM_RES_DWN         PIN_DM_RES_DWN
#define Locked_DM_OD_LO           PIN_DM_OD_LO
#define Locked_DM_OD_HI           PIN_DM_OD_HI
#define Locked_DM_STRONG          PIN_DM_STRONG
#define Locked_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Locked_MASK               Locked__MASK
#define Locked_SHIFT              Locked__SHIFT
#define Locked_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Locked_PS                     (* (reg8 *) Locked__PS)
/* Data Register */
#define Locked_DR                     (* (reg8 *) Locked__DR)
/* Port Number */
#define Locked_PRT_NUM                (* (reg8 *) Locked__PRT) 
/* Connect to Analog Globals */                                                  
#define Locked_AG                     (* (reg8 *) Locked__AG)                       
/* Analog MUX bux enable */
#define Locked_AMUX                   (* (reg8 *) Locked__AMUX) 
/* Bidirectional Enable */                                                        
#define Locked_BIE                    (* (reg8 *) Locked__BIE)
/* Bit-mask for Aliased Register Access */
#define Locked_BIT_MASK               (* (reg8 *) Locked__BIT_MASK)
/* Bypass Enable */
#define Locked_BYP                    (* (reg8 *) Locked__BYP)
/* Port wide control signals */                                                   
#define Locked_CTL                    (* (reg8 *) Locked__CTL)
/* Drive Modes */
#define Locked_DM0                    (* (reg8 *) Locked__DM0) 
#define Locked_DM1                    (* (reg8 *) Locked__DM1)
#define Locked_DM2                    (* (reg8 *) Locked__DM2) 
/* Input Buffer Disable Override */
#define Locked_INP_DIS                (* (reg8 *) Locked__INP_DIS)
/* LCD Common or Segment Drive */
#define Locked_LCD_COM_SEG            (* (reg8 *) Locked__LCD_COM_SEG)
/* Enable Segment LCD */
#define Locked_LCD_EN                 (* (reg8 *) Locked__LCD_EN)
/* Slew Rate Control */
#define Locked_SLW                    (* (reg8 *) Locked__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Locked_PRTDSI__CAPS_SEL       (* (reg8 *) Locked__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Locked_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Locked__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Locked_PRTDSI__OE_SEL0        (* (reg8 *) Locked__PRTDSI__OE_SEL0) 
#define Locked_PRTDSI__OE_SEL1        (* (reg8 *) Locked__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Locked_PRTDSI__OUT_SEL0       (* (reg8 *) Locked__PRTDSI__OUT_SEL0) 
#define Locked_PRTDSI__OUT_SEL1       (* (reg8 *) Locked__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Locked_PRTDSI__SYNC_OUT       (* (reg8 *) Locked__PRTDSI__SYNC_OUT) 


#if defined(Locked__INTSTAT)  /* Interrupt Registers */

    #define Locked_INTSTAT                (* (reg8 *) Locked__INTSTAT)
    #define Locked_SNAP                   (* (reg8 *) Locked__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Locked_H */


/* [] END OF FILE */
