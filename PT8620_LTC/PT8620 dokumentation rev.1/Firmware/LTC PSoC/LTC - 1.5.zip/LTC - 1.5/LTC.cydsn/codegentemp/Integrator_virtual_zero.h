/*******************************************************************************
* File Name: Integrator_virtual_zero.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Integrator_virtual_zero_H) /* Pins Integrator_virtual_zero_H */
#define CY_PINS_Integrator_virtual_zero_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Integrator_virtual_zero_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Integrator_virtual_zero_Write(uint8 value) ;
void    Integrator_virtual_zero_SetDriveMode(uint8 mode) ;
uint8   Integrator_virtual_zero_ReadDataReg(void) ;
uint8   Integrator_virtual_zero_Read(void) ;
uint8   Integrator_virtual_zero_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Integrator_virtual_zero_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Integrator_virtual_zero_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Integrator_virtual_zero_DM_RES_UP          PIN_DM_RES_UP
#define Integrator_virtual_zero_DM_RES_DWN         PIN_DM_RES_DWN
#define Integrator_virtual_zero_DM_OD_LO           PIN_DM_OD_LO
#define Integrator_virtual_zero_DM_OD_HI           PIN_DM_OD_HI
#define Integrator_virtual_zero_DM_STRONG          PIN_DM_STRONG
#define Integrator_virtual_zero_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Integrator_virtual_zero_MASK               Integrator_virtual_zero__MASK
#define Integrator_virtual_zero_SHIFT              Integrator_virtual_zero__SHIFT
#define Integrator_virtual_zero_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Integrator_virtual_zero_PS                     (* (reg8 *) Integrator_virtual_zero__PS)
/* Data Register */
#define Integrator_virtual_zero_DR                     (* (reg8 *) Integrator_virtual_zero__DR)
/* Port Number */
#define Integrator_virtual_zero_PRT_NUM                (* (reg8 *) Integrator_virtual_zero__PRT) 
/* Connect to Analog Globals */                                                  
#define Integrator_virtual_zero_AG                     (* (reg8 *) Integrator_virtual_zero__AG)                       
/* Analog MUX bux enable */
#define Integrator_virtual_zero_AMUX                   (* (reg8 *) Integrator_virtual_zero__AMUX) 
/* Bidirectional Enable */                                                        
#define Integrator_virtual_zero_BIE                    (* (reg8 *) Integrator_virtual_zero__BIE)
/* Bit-mask for Aliased Register Access */
#define Integrator_virtual_zero_BIT_MASK               (* (reg8 *) Integrator_virtual_zero__BIT_MASK)
/* Bypass Enable */
#define Integrator_virtual_zero_BYP                    (* (reg8 *) Integrator_virtual_zero__BYP)
/* Port wide control signals */                                                   
#define Integrator_virtual_zero_CTL                    (* (reg8 *) Integrator_virtual_zero__CTL)
/* Drive Modes */
#define Integrator_virtual_zero_DM0                    (* (reg8 *) Integrator_virtual_zero__DM0) 
#define Integrator_virtual_zero_DM1                    (* (reg8 *) Integrator_virtual_zero__DM1)
#define Integrator_virtual_zero_DM2                    (* (reg8 *) Integrator_virtual_zero__DM2) 
/* Input Buffer Disable Override */
#define Integrator_virtual_zero_INP_DIS                (* (reg8 *) Integrator_virtual_zero__INP_DIS)
/* LCD Common or Segment Drive */
#define Integrator_virtual_zero_LCD_COM_SEG            (* (reg8 *) Integrator_virtual_zero__LCD_COM_SEG)
/* Enable Segment LCD */
#define Integrator_virtual_zero_LCD_EN                 (* (reg8 *) Integrator_virtual_zero__LCD_EN)
/* Slew Rate Control */
#define Integrator_virtual_zero_SLW                    (* (reg8 *) Integrator_virtual_zero__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Integrator_virtual_zero_PRTDSI__CAPS_SEL       (* (reg8 *) Integrator_virtual_zero__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Integrator_virtual_zero_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Integrator_virtual_zero__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Integrator_virtual_zero_PRTDSI__OE_SEL0        (* (reg8 *) Integrator_virtual_zero__PRTDSI__OE_SEL0) 
#define Integrator_virtual_zero_PRTDSI__OE_SEL1        (* (reg8 *) Integrator_virtual_zero__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Integrator_virtual_zero_PRTDSI__OUT_SEL0       (* (reg8 *) Integrator_virtual_zero__PRTDSI__OUT_SEL0) 
#define Integrator_virtual_zero_PRTDSI__OUT_SEL1       (* (reg8 *) Integrator_virtual_zero__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Integrator_virtual_zero_PRTDSI__SYNC_OUT       (* (reg8 *) Integrator_virtual_zero__PRTDSI__SYNC_OUT) 


#if defined(Integrator_virtual_zero__INTSTAT)  /* Interrupt Registers */

    #define Integrator_virtual_zero_INTSTAT                (* (reg8 *) Integrator_virtual_zero__INTSTAT)
    #define Integrator_virtual_zero_SNAP                   (* (reg8 *) Integrator_virtual_zero__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Integrator_virtual_zero_H */


/* [] END OF FILE */
