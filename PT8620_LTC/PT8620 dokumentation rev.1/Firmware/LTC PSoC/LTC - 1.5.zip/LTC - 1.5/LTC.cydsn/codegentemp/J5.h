/*******************************************************************************
* File Name: J5.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_J5_H) /* Pins J5_H */
#define CY_PINS_J5_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "J5_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    J5_Write(uint8 value) ;
void    J5_SetDriveMode(uint8 mode) ;
uint8   J5_ReadDataReg(void) ;
uint8   J5_Read(void) ;
uint8   J5_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define J5_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define J5_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define J5_DM_RES_UP          PIN_DM_RES_UP
#define J5_DM_RES_DWN         PIN_DM_RES_DWN
#define J5_DM_OD_LO           PIN_DM_OD_LO
#define J5_DM_OD_HI           PIN_DM_OD_HI
#define J5_DM_STRONG          PIN_DM_STRONG
#define J5_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define J5_MASK               J5__MASK
#define J5_SHIFT              J5__SHIFT
#define J5_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define J5_PS                     (* (reg8 *) J5__PS)
/* Data Register */
#define J5_DR                     (* (reg8 *) J5__DR)
/* Port Number */
#define J5_PRT_NUM                (* (reg8 *) J5__PRT) 
/* Connect to Analog Globals */                                                  
#define J5_AG                     (* (reg8 *) J5__AG)                       
/* Analog MUX bux enable */
#define J5_AMUX                   (* (reg8 *) J5__AMUX) 
/* Bidirectional Enable */                                                        
#define J5_BIE                    (* (reg8 *) J5__BIE)
/* Bit-mask for Aliased Register Access */
#define J5_BIT_MASK               (* (reg8 *) J5__BIT_MASK)
/* Bypass Enable */
#define J5_BYP                    (* (reg8 *) J5__BYP)
/* Port wide control signals */                                                   
#define J5_CTL                    (* (reg8 *) J5__CTL)
/* Drive Modes */
#define J5_DM0                    (* (reg8 *) J5__DM0) 
#define J5_DM1                    (* (reg8 *) J5__DM1)
#define J5_DM2                    (* (reg8 *) J5__DM2) 
/* Input Buffer Disable Override */
#define J5_INP_DIS                (* (reg8 *) J5__INP_DIS)
/* LCD Common or Segment Drive */
#define J5_LCD_COM_SEG            (* (reg8 *) J5__LCD_COM_SEG)
/* Enable Segment LCD */
#define J5_LCD_EN                 (* (reg8 *) J5__LCD_EN)
/* Slew Rate Control */
#define J5_SLW                    (* (reg8 *) J5__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define J5_PRTDSI__CAPS_SEL       (* (reg8 *) J5__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define J5_PRTDSI__DBL_SYNC_IN    (* (reg8 *) J5__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define J5_PRTDSI__OE_SEL0        (* (reg8 *) J5__PRTDSI__OE_SEL0) 
#define J5_PRTDSI__OE_SEL1        (* (reg8 *) J5__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define J5_PRTDSI__OUT_SEL0       (* (reg8 *) J5__PRTDSI__OUT_SEL0) 
#define J5_PRTDSI__OUT_SEL1       (* (reg8 *) J5__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define J5_PRTDSI__SYNC_OUT       (* (reg8 *) J5__PRTDSI__SYNC_OUT) 


#if defined(J5__INTSTAT)  /* Interrupt Registers */

    #define J5_INTSTAT                (* (reg8 *) J5__INTSTAT)
    #define J5_SNAP                   (* (reg8 *) J5__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins J5_H */


/* [] END OF FILE */
