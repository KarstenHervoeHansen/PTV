/*******************************************************************************
* File Name: Locked.c  
* Version 2.0
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "Locked.h"


/*******************************************************************************
* Function Name: Locked_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void Locked_Write(uint8 value) 
{
    uint8 staticBits = (Locked_DR & (uint8)(~Locked_MASK));
    Locked_DR = staticBits | ((uint8)(value << Locked_SHIFT) & Locked_MASK);
}


/*******************************************************************************
* Function Name: Locked_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  Locked_DM_STRONG     Strong Drive 
*  Locked_DM_OD_HI      Open Drain, Drives High 
*  Locked_DM_OD_LO      Open Drain, Drives Low 
*  Locked_DM_RES_UP     Resistive Pull Up 
*  Locked_DM_RES_DWN    Resistive Pull Down 
*  Locked_DM_RES_UPDWN  Resistive Pull Up/Down 
*  Locked_DM_DIG_HIZ    High Impedance Digital 
*  Locked_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void Locked_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(Locked_0, mode);
}


/*******************************************************************************
* Function Name: Locked_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro Locked_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 Locked_Read(void) 
{
    return (Locked_PS & Locked_MASK) >> Locked_SHIFT;
}


/*******************************************************************************
* Function Name: Locked_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 Locked_ReadDataReg(void) 
{
    return (Locked_DR & Locked_MASK) >> Locked_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(Locked_INTSTAT) 

    /*******************************************************************************
    * Function Name: Locked_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 Locked_ClearInterrupt(void) 
    {
        return (Locked_INTSTAT & Locked_MASK) >> Locked_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
