/*******************************************************************************
* File Name: FFD.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FFD_H) /* Pins FFD_H */
#define CY_PINS_FFD_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "FFD_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    FFD_Write(uint8 value) ;
void    FFD_SetDriveMode(uint8 mode) ;
uint8   FFD_ReadDataReg(void) ;
uint8   FFD_Read(void) ;
uint8   FFD_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define FFD_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define FFD_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define FFD_DM_RES_UP          PIN_DM_RES_UP
#define FFD_DM_RES_DWN         PIN_DM_RES_DWN
#define FFD_DM_OD_LO           PIN_DM_OD_LO
#define FFD_DM_OD_HI           PIN_DM_OD_HI
#define FFD_DM_STRONG          PIN_DM_STRONG
#define FFD_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define FFD_MASK               FFD__MASK
#define FFD_SHIFT              FFD__SHIFT
#define FFD_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define FFD_PS                     (* (reg8 *) FFD__PS)
/* Data Register */
#define FFD_DR                     (* (reg8 *) FFD__DR)
/* Port Number */
#define FFD_PRT_NUM                (* (reg8 *) FFD__PRT) 
/* Connect to Analog Globals */                                                  
#define FFD_AG                     (* (reg8 *) FFD__AG)                       
/* Analog MUX bux enable */
#define FFD_AMUX                   (* (reg8 *) FFD__AMUX) 
/* Bidirectional Enable */                                                        
#define FFD_BIE                    (* (reg8 *) FFD__BIE)
/* Bit-mask for Aliased Register Access */
#define FFD_BIT_MASK               (* (reg8 *) FFD__BIT_MASK)
/* Bypass Enable */
#define FFD_BYP                    (* (reg8 *) FFD__BYP)
/* Port wide control signals */                                                   
#define FFD_CTL                    (* (reg8 *) FFD__CTL)
/* Drive Modes */
#define FFD_DM0                    (* (reg8 *) FFD__DM0) 
#define FFD_DM1                    (* (reg8 *) FFD__DM1)
#define FFD_DM2                    (* (reg8 *) FFD__DM2) 
/* Input Buffer Disable Override */
#define FFD_INP_DIS                (* (reg8 *) FFD__INP_DIS)
/* LCD Common or Segment Drive */
#define FFD_LCD_COM_SEG            (* (reg8 *) FFD__LCD_COM_SEG)
/* Enable Segment LCD */
#define FFD_LCD_EN                 (* (reg8 *) FFD__LCD_EN)
/* Slew Rate Control */
#define FFD_SLW                    (* (reg8 *) FFD__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define FFD_PRTDSI__CAPS_SEL       (* (reg8 *) FFD__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define FFD_PRTDSI__DBL_SYNC_IN    (* (reg8 *) FFD__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define FFD_PRTDSI__OE_SEL0        (* (reg8 *) FFD__PRTDSI__OE_SEL0) 
#define FFD_PRTDSI__OE_SEL1        (* (reg8 *) FFD__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define FFD_PRTDSI__OUT_SEL0       (* (reg8 *) FFD__PRTDSI__OUT_SEL0) 
#define FFD_PRTDSI__OUT_SEL1       (* (reg8 *) FFD__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define FFD_PRTDSI__SYNC_OUT       (* (reg8 *) FFD__PRTDSI__SYNC_OUT) 


#if defined(FFD__INTSTAT)  /* Interrupt Registers */

    #define FFD_INTSTAT                (* (reg8 *) FFD__INTSTAT)
    #define FFD_SNAP                   (* (reg8 *) FFD__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins FFD_H */


/* [] END OF FILE */
