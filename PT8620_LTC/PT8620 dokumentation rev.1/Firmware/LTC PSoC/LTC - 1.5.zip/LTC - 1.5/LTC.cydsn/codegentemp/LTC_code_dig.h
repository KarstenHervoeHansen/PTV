/*******************************************************************************
* File Name: LTC_code_dig.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LTC_code_dig_H) /* Pins LTC_code_dig_H */
#define CY_PINS_LTC_code_dig_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LTC_code_dig_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    LTC_code_dig_Write(uint8 value) ;
void    LTC_code_dig_SetDriveMode(uint8 mode) ;
uint8   LTC_code_dig_ReadDataReg(void) ;
uint8   LTC_code_dig_Read(void) ;
uint8   LTC_code_dig_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define LTC_code_dig_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define LTC_code_dig_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define LTC_code_dig_DM_RES_UP          PIN_DM_RES_UP
#define LTC_code_dig_DM_RES_DWN         PIN_DM_RES_DWN
#define LTC_code_dig_DM_OD_LO           PIN_DM_OD_LO
#define LTC_code_dig_DM_OD_HI           PIN_DM_OD_HI
#define LTC_code_dig_DM_STRONG          PIN_DM_STRONG
#define LTC_code_dig_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define LTC_code_dig_MASK               LTC_code_dig__MASK
#define LTC_code_dig_SHIFT              LTC_code_dig__SHIFT
#define LTC_code_dig_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LTC_code_dig_PS                     (* (reg8 *) LTC_code_dig__PS)
/* Data Register */
#define LTC_code_dig_DR                     (* (reg8 *) LTC_code_dig__DR)
/* Port Number */
#define LTC_code_dig_PRT_NUM                (* (reg8 *) LTC_code_dig__PRT) 
/* Connect to Analog Globals */                                                  
#define LTC_code_dig_AG                     (* (reg8 *) LTC_code_dig__AG)                       
/* Analog MUX bux enable */
#define LTC_code_dig_AMUX                   (* (reg8 *) LTC_code_dig__AMUX) 
/* Bidirectional Enable */                                                        
#define LTC_code_dig_BIE                    (* (reg8 *) LTC_code_dig__BIE)
/* Bit-mask for Aliased Register Access */
#define LTC_code_dig_BIT_MASK               (* (reg8 *) LTC_code_dig__BIT_MASK)
/* Bypass Enable */
#define LTC_code_dig_BYP                    (* (reg8 *) LTC_code_dig__BYP)
/* Port wide control signals */                                                   
#define LTC_code_dig_CTL                    (* (reg8 *) LTC_code_dig__CTL)
/* Drive Modes */
#define LTC_code_dig_DM0                    (* (reg8 *) LTC_code_dig__DM0) 
#define LTC_code_dig_DM1                    (* (reg8 *) LTC_code_dig__DM1)
#define LTC_code_dig_DM2                    (* (reg8 *) LTC_code_dig__DM2) 
/* Input Buffer Disable Override */
#define LTC_code_dig_INP_DIS                (* (reg8 *) LTC_code_dig__INP_DIS)
/* LCD Common or Segment Drive */
#define LTC_code_dig_LCD_COM_SEG            (* (reg8 *) LTC_code_dig__LCD_COM_SEG)
/* Enable Segment LCD */
#define LTC_code_dig_LCD_EN                 (* (reg8 *) LTC_code_dig__LCD_EN)
/* Slew Rate Control */
#define LTC_code_dig_SLW                    (* (reg8 *) LTC_code_dig__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LTC_code_dig_PRTDSI__CAPS_SEL       (* (reg8 *) LTC_code_dig__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LTC_code_dig_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LTC_code_dig__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LTC_code_dig_PRTDSI__OE_SEL0        (* (reg8 *) LTC_code_dig__PRTDSI__OE_SEL0) 
#define LTC_code_dig_PRTDSI__OE_SEL1        (* (reg8 *) LTC_code_dig__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LTC_code_dig_PRTDSI__OUT_SEL0       (* (reg8 *) LTC_code_dig__PRTDSI__OUT_SEL0) 
#define LTC_code_dig_PRTDSI__OUT_SEL1       (* (reg8 *) LTC_code_dig__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LTC_code_dig_PRTDSI__SYNC_OUT       (* (reg8 *) LTC_code_dig__PRTDSI__SYNC_OUT) 


#if defined(LTC_code_dig__INTSTAT)  /* Interrupt Registers */

    #define LTC_code_dig_INTSTAT                (* (reg8 *) LTC_code_dig__INTSTAT)
    #define LTC_code_dig_SNAP                   (* (reg8 *) LTC_code_dig__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins LTC_code_dig_H */


/* [] END OF FILE */
