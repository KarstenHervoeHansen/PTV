/*******************************************************************************
* File Name: FH_G.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FH_G_H) /* Pins FH_G_H */
#define CY_PINS_FH_G_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "FH_G_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    FH_G_Write(uint8 value) ;
void    FH_G_SetDriveMode(uint8 mode) ;
uint8   FH_G_ReadDataReg(void) ;
uint8   FH_G_Read(void) ;
uint8   FH_G_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define FH_G_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define FH_G_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define FH_G_DM_RES_UP          PIN_DM_RES_UP
#define FH_G_DM_RES_DWN         PIN_DM_RES_DWN
#define FH_G_DM_OD_LO           PIN_DM_OD_LO
#define FH_G_DM_OD_HI           PIN_DM_OD_HI
#define FH_G_DM_STRONG          PIN_DM_STRONG
#define FH_G_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define FH_G_MASK               FH_G__MASK
#define FH_G_SHIFT              FH_G__SHIFT
#define FH_G_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define FH_G_PS                     (* (reg8 *) FH_G__PS)
/* Data Register */
#define FH_G_DR                     (* (reg8 *) FH_G__DR)
/* Port Number */
#define FH_G_PRT_NUM                (* (reg8 *) FH_G__PRT) 
/* Connect to Analog Globals */                                                  
#define FH_G_AG                     (* (reg8 *) FH_G__AG)                       
/* Analog MUX bux enable */
#define FH_G_AMUX                   (* (reg8 *) FH_G__AMUX) 
/* Bidirectional Enable */                                                        
#define FH_G_BIE                    (* (reg8 *) FH_G__BIE)
/* Bit-mask for Aliased Register Access */
#define FH_G_BIT_MASK               (* (reg8 *) FH_G__BIT_MASK)
/* Bypass Enable */
#define FH_G_BYP                    (* (reg8 *) FH_G__BYP)
/* Port wide control signals */                                                   
#define FH_G_CTL                    (* (reg8 *) FH_G__CTL)
/* Drive Modes */
#define FH_G_DM0                    (* (reg8 *) FH_G__DM0) 
#define FH_G_DM1                    (* (reg8 *) FH_G__DM1)
#define FH_G_DM2                    (* (reg8 *) FH_G__DM2) 
/* Input Buffer Disable Override */
#define FH_G_INP_DIS                (* (reg8 *) FH_G__INP_DIS)
/* LCD Common or Segment Drive */
#define FH_G_LCD_COM_SEG            (* (reg8 *) FH_G__LCD_COM_SEG)
/* Enable Segment LCD */
#define FH_G_LCD_EN                 (* (reg8 *) FH_G__LCD_EN)
/* Slew Rate Control */
#define FH_G_SLW                    (* (reg8 *) FH_G__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define FH_G_PRTDSI__CAPS_SEL       (* (reg8 *) FH_G__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define FH_G_PRTDSI__DBL_SYNC_IN    (* (reg8 *) FH_G__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define FH_G_PRTDSI__OE_SEL0        (* (reg8 *) FH_G__PRTDSI__OE_SEL0) 
#define FH_G_PRTDSI__OE_SEL1        (* (reg8 *) FH_G__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define FH_G_PRTDSI__OUT_SEL0       (* (reg8 *) FH_G__PRTDSI__OUT_SEL0) 
#define FH_G_PRTDSI__OUT_SEL1       (* (reg8 *) FH_G__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define FH_G_PRTDSI__SYNC_OUT       (* (reg8 *) FH_G__PRTDSI__SYNC_OUT) 


#if defined(FH_G__INTSTAT)  /* Interrupt Registers */

    #define FH_G_INTSTAT                (* (reg8 *) FH_G__INTSTAT)
    #define FH_G_SNAP                   (* (reg8 *) FH_G__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins FH_G_H */


/* [] END OF FILE */
