/*******************************************************************************
* File Name: GPS_PPS.c  
* Version 2.0
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "GPS_PPS.h"


/*******************************************************************************
* Function Name: GPS_PPS_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void GPS_PPS_Write(uint8 value) 
{
    uint8 staticBits = (GPS_PPS_DR & (uint8)(~GPS_PPS_MASK));
    GPS_PPS_DR = staticBits | ((uint8)(value << GPS_PPS_SHIFT) & GPS_PPS_MASK);
}


/*******************************************************************************
* Function Name: GPS_PPS_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  GPS_PPS_DM_STRONG     Strong Drive 
*  GPS_PPS_DM_OD_HI      Open Drain, Drives High 
*  GPS_PPS_DM_OD_LO      Open Drain, Drives Low 
*  GPS_PPS_DM_RES_UP     Resistive Pull Up 
*  GPS_PPS_DM_RES_DWN    Resistive Pull Down 
*  GPS_PPS_DM_RES_UPDWN  Resistive Pull Up/Down 
*  GPS_PPS_DM_DIG_HIZ    High Impedance Digital 
*  GPS_PPS_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void GPS_PPS_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(GPS_PPS_0, mode);
}


/*******************************************************************************
* Function Name: GPS_PPS_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro GPS_PPS_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 GPS_PPS_Read(void) 
{
    return (GPS_PPS_PS & GPS_PPS_MASK) >> GPS_PPS_SHIFT;
}


/*******************************************************************************
* Function Name: GPS_PPS_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 GPS_PPS_ReadDataReg(void) 
{
    return (GPS_PPS_DR & GPS_PPS_MASK) >> GPS_PPS_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(GPS_PPS_INTSTAT) 

    /*******************************************************************************
    * Function Name: GPS_PPS_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 GPS_PPS_ClearInterrupt(void) 
    {
        return (GPS_PPS_INTSTAT & GPS_PPS_MASK) >> GPS_PPS_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
