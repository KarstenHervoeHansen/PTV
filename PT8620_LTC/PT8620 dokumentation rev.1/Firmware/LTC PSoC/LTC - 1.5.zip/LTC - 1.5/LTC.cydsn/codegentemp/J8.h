/*******************************************************************************
* File Name: J8.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_J8_H) /* Pins J8_H */
#define CY_PINS_J8_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "J8_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    J8_Write(uint8 value) ;
void    J8_SetDriveMode(uint8 mode) ;
uint8   J8_ReadDataReg(void) ;
uint8   J8_Read(void) ;
uint8   J8_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define J8_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define J8_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define J8_DM_RES_UP          PIN_DM_RES_UP
#define J8_DM_RES_DWN         PIN_DM_RES_DWN
#define J8_DM_OD_LO           PIN_DM_OD_LO
#define J8_DM_OD_HI           PIN_DM_OD_HI
#define J8_DM_STRONG          PIN_DM_STRONG
#define J8_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define J8_MASK               J8__MASK
#define J8_SHIFT              J8__SHIFT
#define J8_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define J8_PS                     (* (reg8 *) J8__PS)
/* Data Register */
#define J8_DR                     (* (reg8 *) J8__DR)
/* Port Number */
#define J8_PRT_NUM                (* (reg8 *) J8__PRT) 
/* Connect to Analog Globals */                                                  
#define J8_AG                     (* (reg8 *) J8__AG)                       
/* Analog MUX bux enable */
#define J8_AMUX                   (* (reg8 *) J8__AMUX) 
/* Bidirectional Enable */                                                        
#define J8_BIE                    (* (reg8 *) J8__BIE)
/* Bit-mask for Aliased Register Access */
#define J8_BIT_MASK               (* (reg8 *) J8__BIT_MASK)
/* Bypass Enable */
#define J8_BYP                    (* (reg8 *) J8__BYP)
/* Port wide control signals */                                                   
#define J8_CTL                    (* (reg8 *) J8__CTL)
/* Drive Modes */
#define J8_DM0                    (* (reg8 *) J8__DM0) 
#define J8_DM1                    (* (reg8 *) J8__DM1)
#define J8_DM2                    (* (reg8 *) J8__DM2) 
/* Input Buffer Disable Override */
#define J8_INP_DIS                (* (reg8 *) J8__INP_DIS)
/* LCD Common or Segment Drive */
#define J8_LCD_COM_SEG            (* (reg8 *) J8__LCD_COM_SEG)
/* Enable Segment LCD */
#define J8_LCD_EN                 (* (reg8 *) J8__LCD_EN)
/* Slew Rate Control */
#define J8_SLW                    (* (reg8 *) J8__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define J8_PRTDSI__CAPS_SEL       (* (reg8 *) J8__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define J8_PRTDSI__DBL_SYNC_IN    (* (reg8 *) J8__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define J8_PRTDSI__OE_SEL0        (* (reg8 *) J8__PRTDSI__OE_SEL0) 
#define J8_PRTDSI__OE_SEL1        (* (reg8 *) J8__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define J8_PRTDSI__OUT_SEL0       (* (reg8 *) J8__PRTDSI__OUT_SEL0) 
#define J8_PRTDSI__OUT_SEL1       (* (reg8 *) J8__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define J8_PRTDSI__SYNC_OUT       (* (reg8 *) J8__PRTDSI__SYNC_OUT) 


#if defined(J8__INTSTAT)  /* Interrupt Registers */

    #define J8_INTSTAT                (* (reg8 *) J8__INTSTAT)
    #define J8_SNAP                   (* (reg8 *) J8__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins J8_H */


/* [] END OF FILE */
