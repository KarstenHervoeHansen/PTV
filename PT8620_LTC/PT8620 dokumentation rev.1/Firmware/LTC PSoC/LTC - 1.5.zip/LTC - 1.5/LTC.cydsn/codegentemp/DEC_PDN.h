/*******************************************************************************
* File Name: DEC_PDN.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DEC_PDN_H) /* Pins DEC_PDN_H */
#define CY_PINS_DEC_PDN_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DEC_PDN_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DEC_PDN_Write(uint8 value) ;
void    DEC_PDN_SetDriveMode(uint8 mode) ;
uint8   DEC_PDN_ReadDataReg(void) ;
uint8   DEC_PDN_Read(void) ;
uint8   DEC_PDN_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DEC_PDN_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DEC_PDN_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DEC_PDN_DM_RES_UP          PIN_DM_RES_UP
#define DEC_PDN_DM_RES_DWN         PIN_DM_RES_DWN
#define DEC_PDN_DM_OD_LO           PIN_DM_OD_LO
#define DEC_PDN_DM_OD_HI           PIN_DM_OD_HI
#define DEC_PDN_DM_STRONG          PIN_DM_STRONG
#define DEC_PDN_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DEC_PDN_MASK               DEC_PDN__MASK
#define DEC_PDN_SHIFT              DEC_PDN__SHIFT
#define DEC_PDN_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DEC_PDN_PS                     (* (reg8 *) DEC_PDN__PS)
/* Data Register */
#define DEC_PDN_DR                     (* (reg8 *) DEC_PDN__DR)
/* Port Number */
#define DEC_PDN_PRT_NUM                (* (reg8 *) DEC_PDN__PRT) 
/* Connect to Analog Globals */                                                  
#define DEC_PDN_AG                     (* (reg8 *) DEC_PDN__AG)                       
/* Analog MUX bux enable */
#define DEC_PDN_AMUX                   (* (reg8 *) DEC_PDN__AMUX) 
/* Bidirectional Enable */                                                        
#define DEC_PDN_BIE                    (* (reg8 *) DEC_PDN__BIE)
/* Bit-mask for Aliased Register Access */
#define DEC_PDN_BIT_MASK               (* (reg8 *) DEC_PDN__BIT_MASK)
/* Bypass Enable */
#define DEC_PDN_BYP                    (* (reg8 *) DEC_PDN__BYP)
/* Port wide control signals */                                                   
#define DEC_PDN_CTL                    (* (reg8 *) DEC_PDN__CTL)
/* Drive Modes */
#define DEC_PDN_DM0                    (* (reg8 *) DEC_PDN__DM0) 
#define DEC_PDN_DM1                    (* (reg8 *) DEC_PDN__DM1)
#define DEC_PDN_DM2                    (* (reg8 *) DEC_PDN__DM2) 
/* Input Buffer Disable Override */
#define DEC_PDN_INP_DIS                (* (reg8 *) DEC_PDN__INP_DIS)
/* LCD Common or Segment Drive */
#define DEC_PDN_LCD_COM_SEG            (* (reg8 *) DEC_PDN__LCD_COM_SEG)
/* Enable Segment LCD */
#define DEC_PDN_LCD_EN                 (* (reg8 *) DEC_PDN__LCD_EN)
/* Slew Rate Control */
#define DEC_PDN_SLW                    (* (reg8 *) DEC_PDN__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DEC_PDN_PRTDSI__CAPS_SEL       (* (reg8 *) DEC_PDN__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DEC_PDN_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DEC_PDN__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DEC_PDN_PRTDSI__OE_SEL0        (* (reg8 *) DEC_PDN__PRTDSI__OE_SEL0) 
#define DEC_PDN_PRTDSI__OE_SEL1        (* (reg8 *) DEC_PDN__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DEC_PDN_PRTDSI__OUT_SEL0       (* (reg8 *) DEC_PDN__PRTDSI__OUT_SEL0) 
#define DEC_PDN_PRTDSI__OUT_SEL1       (* (reg8 *) DEC_PDN__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DEC_PDN_PRTDSI__SYNC_OUT       (* (reg8 *) DEC_PDN__PRTDSI__SYNC_OUT) 


#if defined(DEC_PDN__INTSTAT)  /* Interrupt Registers */

    #define DEC_PDN_INTSTAT                (* (reg8 *) DEC_PDN__INTSTAT)
    #define DEC_PDN_SNAP                   (* (reg8 *) DEC_PDN__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins DEC_PDN_H */


/* [] END OF FILE */
