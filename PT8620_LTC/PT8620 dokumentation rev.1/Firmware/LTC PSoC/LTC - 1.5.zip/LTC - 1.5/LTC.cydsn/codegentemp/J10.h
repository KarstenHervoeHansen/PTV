/*******************************************************************************
* File Name: J10.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_J10_H) /* Pins J10_H */
#define CY_PINS_J10_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "J10_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    J10_Write(uint8 value) ;
void    J10_SetDriveMode(uint8 mode) ;
uint8   J10_ReadDataReg(void) ;
uint8   J10_Read(void) ;
uint8   J10_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define J10_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define J10_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define J10_DM_RES_UP          PIN_DM_RES_UP
#define J10_DM_RES_DWN         PIN_DM_RES_DWN
#define J10_DM_OD_LO           PIN_DM_OD_LO
#define J10_DM_OD_HI           PIN_DM_OD_HI
#define J10_DM_STRONG          PIN_DM_STRONG
#define J10_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define J10_MASK               J10__MASK
#define J10_SHIFT              J10__SHIFT
#define J10_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define J10_PS                     (* (reg8 *) J10__PS)
/* Data Register */
#define J10_DR                     (* (reg8 *) J10__DR)
/* Port Number */
#define J10_PRT_NUM                (* (reg8 *) J10__PRT) 
/* Connect to Analog Globals */                                                  
#define J10_AG                     (* (reg8 *) J10__AG)                       
/* Analog MUX bux enable */
#define J10_AMUX                   (* (reg8 *) J10__AMUX) 
/* Bidirectional Enable */                                                        
#define J10_BIE                    (* (reg8 *) J10__BIE)
/* Bit-mask for Aliased Register Access */
#define J10_BIT_MASK               (* (reg8 *) J10__BIT_MASK)
/* Bypass Enable */
#define J10_BYP                    (* (reg8 *) J10__BYP)
/* Port wide control signals */                                                   
#define J10_CTL                    (* (reg8 *) J10__CTL)
/* Drive Modes */
#define J10_DM0                    (* (reg8 *) J10__DM0) 
#define J10_DM1                    (* (reg8 *) J10__DM1)
#define J10_DM2                    (* (reg8 *) J10__DM2) 
/* Input Buffer Disable Override */
#define J10_INP_DIS                (* (reg8 *) J10__INP_DIS)
/* LCD Common or Segment Drive */
#define J10_LCD_COM_SEG            (* (reg8 *) J10__LCD_COM_SEG)
/* Enable Segment LCD */
#define J10_LCD_EN                 (* (reg8 *) J10__LCD_EN)
/* Slew Rate Control */
#define J10_SLW                    (* (reg8 *) J10__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define J10_PRTDSI__CAPS_SEL       (* (reg8 *) J10__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define J10_PRTDSI__DBL_SYNC_IN    (* (reg8 *) J10__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define J10_PRTDSI__OE_SEL0        (* (reg8 *) J10__PRTDSI__OE_SEL0) 
#define J10_PRTDSI__OE_SEL1        (* (reg8 *) J10__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define J10_PRTDSI__OUT_SEL0       (* (reg8 *) J10__PRTDSI__OUT_SEL0) 
#define J10_PRTDSI__OUT_SEL1       (* (reg8 *) J10__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define J10_PRTDSI__SYNC_OUT       (* (reg8 *) J10__PRTDSI__SYNC_OUT) 


#if defined(J10__INTSTAT)  /* Interrupt Registers */

    #define J10_INTSTAT                (* (reg8 *) J10__INTSTAT)
    #define J10_SNAP                   (* (reg8 *) J10__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins J10_H */


/* [] END OF FILE */
