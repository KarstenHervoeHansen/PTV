/*******************************************************************************
* File Name: DEC_HSYNC.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DEC_HSYNC_H) /* Pins DEC_HSYNC_H */
#define CY_PINS_DEC_HSYNC_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DEC_HSYNC_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DEC_HSYNC_Write(uint8 value) ;
void    DEC_HSYNC_SetDriveMode(uint8 mode) ;
uint8   DEC_HSYNC_ReadDataReg(void) ;
uint8   DEC_HSYNC_Read(void) ;
uint8   DEC_HSYNC_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DEC_HSYNC_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DEC_HSYNC_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DEC_HSYNC_DM_RES_UP          PIN_DM_RES_UP
#define DEC_HSYNC_DM_RES_DWN         PIN_DM_RES_DWN
#define DEC_HSYNC_DM_OD_LO           PIN_DM_OD_LO
#define DEC_HSYNC_DM_OD_HI           PIN_DM_OD_HI
#define DEC_HSYNC_DM_STRONG          PIN_DM_STRONG
#define DEC_HSYNC_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DEC_HSYNC_MASK               DEC_HSYNC__MASK
#define DEC_HSYNC_SHIFT              DEC_HSYNC__SHIFT
#define DEC_HSYNC_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DEC_HSYNC_PS                     (* (reg8 *) DEC_HSYNC__PS)
/* Data Register */
#define DEC_HSYNC_DR                     (* (reg8 *) DEC_HSYNC__DR)
/* Port Number */
#define DEC_HSYNC_PRT_NUM                (* (reg8 *) DEC_HSYNC__PRT) 
/* Connect to Analog Globals */                                                  
#define DEC_HSYNC_AG                     (* (reg8 *) DEC_HSYNC__AG)                       
/* Analog MUX bux enable */
#define DEC_HSYNC_AMUX                   (* (reg8 *) DEC_HSYNC__AMUX) 
/* Bidirectional Enable */                                                        
#define DEC_HSYNC_BIE                    (* (reg8 *) DEC_HSYNC__BIE)
/* Bit-mask for Aliased Register Access */
#define DEC_HSYNC_BIT_MASK               (* (reg8 *) DEC_HSYNC__BIT_MASK)
/* Bypass Enable */
#define DEC_HSYNC_BYP                    (* (reg8 *) DEC_HSYNC__BYP)
/* Port wide control signals */                                                   
#define DEC_HSYNC_CTL                    (* (reg8 *) DEC_HSYNC__CTL)
/* Drive Modes */
#define DEC_HSYNC_DM0                    (* (reg8 *) DEC_HSYNC__DM0) 
#define DEC_HSYNC_DM1                    (* (reg8 *) DEC_HSYNC__DM1)
#define DEC_HSYNC_DM2                    (* (reg8 *) DEC_HSYNC__DM2) 
/* Input Buffer Disable Override */
#define DEC_HSYNC_INP_DIS                (* (reg8 *) DEC_HSYNC__INP_DIS)
/* LCD Common or Segment Drive */
#define DEC_HSYNC_LCD_COM_SEG            (* (reg8 *) DEC_HSYNC__LCD_COM_SEG)
/* Enable Segment LCD */
#define DEC_HSYNC_LCD_EN                 (* (reg8 *) DEC_HSYNC__LCD_EN)
/* Slew Rate Control */
#define DEC_HSYNC_SLW                    (* (reg8 *) DEC_HSYNC__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DEC_HSYNC_PRTDSI__CAPS_SEL       (* (reg8 *) DEC_HSYNC__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DEC_HSYNC_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DEC_HSYNC__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DEC_HSYNC_PRTDSI__OE_SEL0        (* (reg8 *) DEC_HSYNC__PRTDSI__OE_SEL0) 
#define DEC_HSYNC_PRTDSI__OE_SEL1        (* (reg8 *) DEC_HSYNC__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DEC_HSYNC_PRTDSI__OUT_SEL0       (* (reg8 *) DEC_HSYNC__PRTDSI__OUT_SEL0) 
#define DEC_HSYNC_PRTDSI__OUT_SEL1       (* (reg8 *) DEC_HSYNC__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DEC_HSYNC_PRTDSI__SYNC_OUT       (* (reg8 *) DEC_HSYNC__PRTDSI__SYNC_OUT) 


#if defined(DEC_HSYNC__INTSTAT)  /* Interrupt Registers */

    #define DEC_HSYNC_INTSTAT                (* (reg8 *) DEC_HSYNC__INTSTAT)
    #define DEC_HSYNC_SNAP                   (* (reg8 *) DEC_HSYNC__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins DEC_HSYNC_H */


/* [] END OF FILE */
