/*******************************************************************************
* File Name: FF_COMP.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FF_COMP_H) /* Pins FF_COMP_H */
#define CY_PINS_FF_COMP_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "FF_COMP_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    FF_COMP_Write(uint8 value) ;
void    FF_COMP_SetDriveMode(uint8 mode) ;
uint8   FF_COMP_ReadDataReg(void) ;
uint8   FF_COMP_Read(void) ;
uint8   FF_COMP_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define FF_COMP_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define FF_COMP_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define FF_COMP_DM_RES_UP          PIN_DM_RES_UP
#define FF_COMP_DM_RES_DWN         PIN_DM_RES_DWN
#define FF_COMP_DM_OD_LO           PIN_DM_OD_LO
#define FF_COMP_DM_OD_HI           PIN_DM_OD_HI
#define FF_COMP_DM_STRONG          PIN_DM_STRONG
#define FF_COMP_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define FF_COMP_MASK               FF_COMP__MASK
#define FF_COMP_SHIFT              FF_COMP__SHIFT
#define FF_COMP_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define FF_COMP_PS                     (* (reg8 *) FF_COMP__PS)
/* Data Register */
#define FF_COMP_DR                     (* (reg8 *) FF_COMP__DR)
/* Port Number */
#define FF_COMP_PRT_NUM                (* (reg8 *) FF_COMP__PRT) 
/* Connect to Analog Globals */                                                  
#define FF_COMP_AG                     (* (reg8 *) FF_COMP__AG)                       
/* Analog MUX bux enable */
#define FF_COMP_AMUX                   (* (reg8 *) FF_COMP__AMUX) 
/* Bidirectional Enable */                                                        
#define FF_COMP_BIE                    (* (reg8 *) FF_COMP__BIE)
/* Bit-mask for Aliased Register Access */
#define FF_COMP_BIT_MASK               (* (reg8 *) FF_COMP__BIT_MASK)
/* Bypass Enable */
#define FF_COMP_BYP                    (* (reg8 *) FF_COMP__BYP)
/* Port wide control signals */                                                   
#define FF_COMP_CTL                    (* (reg8 *) FF_COMP__CTL)
/* Drive Modes */
#define FF_COMP_DM0                    (* (reg8 *) FF_COMP__DM0) 
#define FF_COMP_DM1                    (* (reg8 *) FF_COMP__DM1)
#define FF_COMP_DM2                    (* (reg8 *) FF_COMP__DM2) 
/* Input Buffer Disable Override */
#define FF_COMP_INP_DIS                (* (reg8 *) FF_COMP__INP_DIS)
/* LCD Common or Segment Drive */
#define FF_COMP_LCD_COM_SEG            (* (reg8 *) FF_COMP__LCD_COM_SEG)
/* Enable Segment LCD */
#define FF_COMP_LCD_EN                 (* (reg8 *) FF_COMP__LCD_EN)
/* Slew Rate Control */
#define FF_COMP_SLW                    (* (reg8 *) FF_COMP__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define FF_COMP_PRTDSI__CAPS_SEL       (* (reg8 *) FF_COMP__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define FF_COMP_PRTDSI__DBL_SYNC_IN    (* (reg8 *) FF_COMP__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define FF_COMP_PRTDSI__OE_SEL0        (* (reg8 *) FF_COMP__PRTDSI__OE_SEL0) 
#define FF_COMP_PRTDSI__OE_SEL1        (* (reg8 *) FF_COMP__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define FF_COMP_PRTDSI__OUT_SEL0       (* (reg8 *) FF_COMP__PRTDSI__OUT_SEL0) 
#define FF_COMP_PRTDSI__OUT_SEL1       (* (reg8 *) FF_COMP__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define FF_COMP_PRTDSI__SYNC_OUT       (* (reg8 *) FF_COMP__PRTDSI__SYNC_OUT) 


#if defined(FF_COMP__INTSTAT)  /* Interrupt Registers */

    #define FF_COMP_INTSTAT                (* (reg8 *) FF_COMP__INTSTAT)
    #define FF_COMP_SNAP                   (* (reg8 *) FF_COMP__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins FF_COMP_H */


/* [] END OF FILE */
