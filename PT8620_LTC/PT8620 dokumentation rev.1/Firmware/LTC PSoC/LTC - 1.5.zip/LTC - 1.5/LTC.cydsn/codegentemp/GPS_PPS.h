/*******************************************************************************
* File Name: GPS_PPS.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_GPS_PPS_H) /* Pins GPS_PPS_H */
#define CY_PINS_GPS_PPS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "GPS_PPS_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    GPS_PPS_Write(uint8 value) ;
void    GPS_PPS_SetDriveMode(uint8 mode) ;
uint8   GPS_PPS_ReadDataReg(void) ;
uint8   GPS_PPS_Read(void) ;
uint8   GPS_PPS_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define GPS_PPS_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define GPS_PPS_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define GPS_PPS_DM_RES_UP          PIN_DM_RES_UP
#define GPS_PPS_DM_RES_DWN         PIN_DM_RES_DWN
#define GPS_PPS_DM_OD_LO           PIN_DM_OD_LO
#define GPS_PPS_DM_OD_HI           PIN_DM_OD_HI
#define GPS_PPS_DM_STRONG          PIN_DM_STRONG
#define GPS_PPS_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define GPS_PPS_MASK               GPS_PPS__MASK
#define GPS_PPS_SHIFT              GPS_PPS__SHIFT
#define GPS_PPS_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define GPS_PPS_PS                     (* (reg8 *) GPS_PPS__PS)
/* Data Register */
#define GPS_PPS_DR                     (* (reg8 *) GPS_PPS__DR)
/* Port Number */
#define GPS_PPS_PRT_NUM                (* (reg8 *) GPS_PPS__PRT) 
/* Connect to Analog Globals */                                                  
#define GPS_PPS_AG                     (* (reg8 *) GPS_PPS__AG)                       
/* Analog MUX bux enable */
#define GPS_PPS_AMUX                   (* (reg8 *) GPS_PPS__AMUX) 
/* Bidirectional Enable */                                                        
#define GPS_PPS_BIE                    (* (reg8 *) GPS_PPS__BIE)
/* Bit-mask for Aliased Register Access */
#define GPS_PPS_BIT_MASK               (* (reg8 *) GPS_PPS__BIT_MASK)
/* Bypass Enable */
#define GPS_PPS_BYP                    (* (reg8 *) GPS_PPS__BYP)
/* Port wide control signals */                                                   
#define GPS_PPS_CTL                    (* (reg8 *) GPS_PPS__CTL)
/* Drive Modes */
#define GPS_PPS_DM0                    (* (reg8 *) GPS_PPS__DM0) 
#define GPS_PPS_DM1                    (* (reg8 *) GPS_PPS__DM1)
#define GPS_PPS_DM2                    (* (reg8 *) GPS_PPS__DM2) 
/* Input Buffer Disable Override */
#define GPS_PPS_INP_DIS                (* (reg8 *) GPS_PPS__INP_DIS)
/* LCD Common or Segment Drive */
#define GPS_PPS_LCD_COM_SEG            (* (reg8 *) GPS_PPS__LCD_COM_SEG)
/* Enable Segment LCD */
#define GPS_PPS_LCD_EN                 (* (reg8 *) GPS_PPS__LCD_EN)
/* Slew Rate Control */
#define GPS_PPS_SLW                    (* (reg8 *) GPS_PPS__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define GPS_PPS_PRTDSI__CAPS_SEL       (* (reg8 *) GPS_PPS__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define GPS_PPS_PRTDSI__DBL_SYNC_IN    (* (reg8 *) GPS_PPS__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define GPS_PPS_PRTDSI__OE_SEL0        (* (reg8 *) GPS_PPS__PRTDSI__OE_SEL0) 
#define GPS_PPS_PRTDSI__OE_SEL1        (* (reg8 *) GPS_PPS__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define GPS_PPS_PRTDSI__OUT_SEL0       (* (reg8 *) GPS_PPS__PRTDSI__OUT_SEL0) 
#define GPS_PPS_PRTDSI__OUT_SEL1       (* (reg8 *) GPS_PPS__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define GPS_PPS_PRTDSI__SYNC_OUT       (* (reg8 *) GPS_PPS__PRTDSI__SYNC_OUT) 


#if defined(GPS_PPS__INTSTAT)  /* Interrupt Registers */

    #define GPS_PPS_INTSTAT                (* (reg8 *) GPS_PPS__INTSTAT)
    #define GPS_PPS_SNAP                   (* (reg8 *) GPS_PPS__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins GPS_PPS_H */


/* [] END OF FILE */
