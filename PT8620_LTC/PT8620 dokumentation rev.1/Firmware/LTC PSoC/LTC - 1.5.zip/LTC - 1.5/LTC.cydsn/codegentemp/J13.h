/*******************************************************************************
* File Name: J13.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_J13_H) /* Pins J13_H */
#define CY_PINS_J13_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "J13_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    J13_Write(uint8 value) ;
void    J13_SetDriveMode(uint8 mode) ;
uint8   J13_ReadDataReg(void) ;
uint8   J13_Read(void) ;
uint8   J13_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define J13_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define J13_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define J13_DM_RES_UP          PIN_DM_RES_UP
#define J13_DM_RES_DWN         PIN_DM_RES_DWN
#define J13_DM_OD_LO           PIN_DM_OD_LO
#define J13_DM_OD_HI           PIN_DM_OD_HI
#define J13_DM_STRONG          PIN_DM_STRONG
#define J13_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define J13_MASK               J13__MASK
#define J13_SHIFT              J13__SHIFT
#define J13_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define J13_PS                     (* (reg8 *) J13__PS)
/* Data Register */
#define J13_DR                     (* (reg8 *) J13__DR)
/* Port Number */
#define J13_PRT_NUM                (* (reg8 *) J13__PRT) 
/* Connect to Analog Globals */                                                  
#define J13_AG                     (* (reg8 *) J13__AG)                       
/* Analog MUX bux enable */
#define J13_AMUX                   (* (reg8 *) J13__AMUX) 
/* Bidirectional Enable */                                                        
#define J13_BIE                    (* (reg8 *) J13__BIE)
/* Bit-mask for Aliased Register Access */
#define J13_BIT_MASK               (* (reg8 *) J13__BIT_MASK)
/* Bypass Enable */
#define J13_BYP                    (* (reg8 *) J13__BYP)
/* Port wide control signals */                                                   
#define J13_CTL                    (* (reg8 *) J13__CTL)
/* Drive Modes */
#define J13_DM0                    (* (reg8 *) J13__DM0) 
#define J13_DM1                    (* (reg8 *) J13__DM1)
#define J13_DM2                    (* (reg8 *) J13__DM2) 
/* Input Buffer Disable Override */
#define J13_INP_DIS                (* (reg8 *) J13__INP_DIS)
/* LCD Common or Segment Drive */
#define J13_LCD_COM_SEG            (* (reg8 *) J13__LCD_COM_SEG)
/* Enable Segment LCD */
#define J13_LCD_EN                 (* (reg8 *) J13__LCD_EN)
/* Slew Rate Control */
#define J13_SLW                    (* (reg8 *) J13__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define J13_PRTDSI__CAPS_SEL       (* (reg8 *) J13__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define J13_PRTDSI__DBL_SYNC_IN    (* (reg8 *) J13__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define J13_PRTDSI__OE_SEL0        (* (reg8 *) J13__PRTDSI__OE_SEL0) 
#define J13_PRTDSI__OE_SEL1        (* (reg8 *) J13__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define J13_PRTDSI__OUT_SEL0       (* (reg8 *) J13__PRTDSI__OUT_SEL0) 
#define J13_PRTDSI__OUT_SEL1       (* (reg8 *) J13__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define J13_PRTDSI__SYNC_OUT       (* (reg8 *) J13__PRTDSI__SYNC_OUT) 


#if defined(J13__INTSTAT)  /* Interrupt Registers */

    #define J13_INTSTAT                (* (reg8 *) J13__INTSTAT)
    #define J13_SNAP                   (* (reg8 *) J13__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins J13_H */


/* [] END OF FILE */
