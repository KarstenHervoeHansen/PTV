/*******************************************************************************
* File Name: MasterReset.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MasterReset_H) /* Pins MasterReset_H */
#define CY_PINS_MasterReset_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "MasterReset_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    MasterReset_Write(uint8 value) ;
void    MasterReset_SetDriveMode(uint8 mode) ;
uint8   MasterReset_ReadDataReg(void) ;
uint8   MasterReset_Read(void) ;
uint8   MasterReset_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define MasterReset_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define MasterReset_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define MasterReset_DM_RES_UP          PIN_DM_RES_UP
#define MasterReset_DM_RES_DWN         PIN_DM_RES_DWN
#define MasterReset_DM_OD_LO           PIN_DM_OD_LO
#define MasterReset_DM_OD_HI           PIN_DM_OD_HI
#define MasterReset_DM_STRONG          PIN_DM_STRONG
#define MasterReset_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define MasterReset_MASK               MasterReset__MASK
#define MasterReset_SHIFT              MasterReset__SHIFT
#define MasterReset_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define MasterReset_PS                     (* (reg8 *) MasterReset__PS)
/* Data Register */
#define MasterReset_DR                     (* (reg8 *) MasterReset__DR)
/* Port Number */
#define MasterReset_PRT_NUM                (* (reg8 *) MasterReset__PRT) 
/* Connect to Analog Globals */                                                  
#define MasterReset_AG                     (* (reg8 *) MasterReset__AG)                       
/* Analog MUX bux enable */
#define MasterReset_AMUX                   (* (reg8 *) MasterReset__AMUX) 
/* Bidirectional Enable */                                                        
#define MasterReset_BIE                    (* (reg8 *) MasterReset__BIE)
/* Bit-mask for Aliased Register Access */
#define MasterReset_BIT_MASK               (* (reg8 *) MasterReset__BIT_MASK)
/* Bypass Enable */
#define MasterReset_BYP                    (* (reg8 *) MasterReset__BYP)
/* Port wide control signals */                                                   
#define MasterReset_CTL                    (* (reg8 *) MasterReset__CTL)
/* Drive Modes */
#define MasterReset_DM0                    (* (reg8 *) MasterReset__DM0) 
#define MasterReset_DM1                    (* (reg8 *) MasterReset__DM1)
#define MasterReset_DM2                    (* (reg8 *) MasterReset__DM2) 
/* Input Buffer Disable Override */
#define MasterReset_INP_DIS                (* (reg8 *) MasterReset__INP_DIS)
/* LCD Common or Segment Drive */
#define MasterReset_LCD_COM_SEG            (* (reg8 *) MasterReset__LCD_COM_SEG)
/* Enable Segment LCD */
#define MasterReset_LCD_EN                 (* (reg8 *) MasterReset__LCD_EN)
/* Slew Rate Control */
#define MasterReset_SLW                    (* (reg8 *) MasterReset__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define MasterReset_PRTDSI__CAPS_SEL       (* (reg8 *) MasterReset__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define MasterReset_PRTDSI__DBL_SYNC_IN    (* (reg8 *) MasterReset__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define MasterReset_PRTDSI__OE_SEL0        (* (reg8 *) MasterReset__PRTDSI__OE_SEL0) 
#define MasterReset_PRTDSI__OE_SEL1        (* (reg8 *) MasterReset__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define MasterReset_PRTDSI__OUT_SEL0       (* (reg8 *) MasterReset__PRTDSI__OUT_SEL0) 
#define MasterReset_PRTDSI__OUT_SEL1       (* (reg8 *) MasterReset__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define MasterReset_PRTDSI__SYNC_OUT       (* (reg8 *) MasterReset__PRTDSI__SYNC_OUT) 


#if defined(MasterReset__INTSTAT)  /* Interrupt Registers */

    #define MasterReset_INTSTAT                (* (reg8 *) MasterReset__INTSTAT)
    #define MasterReset_SNAP                   (* (reg8 *) MasterReset__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins MasterReset_H */


/* [] END OF FILE */
