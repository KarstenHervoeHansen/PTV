/*******************************************************************************
* File Name: MasterReset.c  
* Version 2.0
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "MasterReset.h"


/*******************************************************************************
* Function Name: MasterReset_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void MasterReset_Write(uint8 value) 
{
    uint8 staticBits = (MasterReset_DR & (uint8)(~MasterReset_MASK));
    MasterReset_DR = staticBits | ((uint8)(value << MasterReset_SHIFT) & MasterReset_MASK);
}


/*******************************************************************************
* Function Name: MasterReset_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  MasterReset_DM_STRONG     Strong Drive 
*  MasterReset_DM_OD_HI      Open Drain, Drives High 
*  MasterReset_DM_OD_LO      Open Drain, Drives Low 
*  MasterReset_DM_RES_UP     Resistive Pull Up 
*  MasterReset_DM_RES_DWN    Resistive Pull Down 
*  MasterReset_DM_RES_UPDWN  Resistive Pull Up/Down 
*  MasterReset_DM_DIG_HIZ    High Impedance Digital 
*  MasterReset_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void MasterReset_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(MasterReset_0, mode);
}


/*******************************************************************************
* Function Name: MasterReset_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro MasterReset_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 MasterReset_Read(void) 
{
    return (MasterReset_PS & MasterReset_MASK) >> MasterReset_SHIFT;
}


/*******************************************************************************
* Function Name: MasterReset_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 MasterReset_ReadDataReg(void) 
{
    return (MasterReset_DR & MasterReset_MASK) >> MasterReset_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(MasterReset_INTSTAT) 

    /*******************************************************************************
    * Function Name: MasterReset_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 MasterReset_ClearInterrupt(void) 
    {
        return (MasterReset_INTSTAT & MasterReset_MASK) >> MasterReset_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
