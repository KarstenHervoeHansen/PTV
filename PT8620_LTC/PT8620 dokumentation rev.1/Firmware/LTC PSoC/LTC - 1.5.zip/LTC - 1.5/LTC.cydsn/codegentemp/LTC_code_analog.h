/*******************************************************************************
* File Name: LTC_code_analog.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LTC_code_analog_H) /* Pins LTC_code_analog_H */
#define CY_PINS_LTC_code_analog_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LTC_code_analog_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    LTC_code_analog_Write(uint8 value) ;
void    LTC_code_analog_SetDriveMode(uint8 mode) ;
uint8   LTC_code_analog_ReadDataReg(void) ;
uint8   LTC_code_analog_Read(void) ;
uint8   LTC_code_analog_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define LTC_code_analog_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define LTC_code_analog_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define LTC_code_analog_DM_RES_UP          PIN_DM_RES_UP
#define LTC_code_analog_DM_RES_DWN         PIN_DM_RES_DWN
#define LTC_code_analog_DM_OD_LO           PIN_DM_OD_LO
#define LTC_code_analog_DM_OD_HI           PIN_DM_OD_HI
#define LTC_code_analog_DM_STRONG          PIN_DM_STRONG
#define LTC_code_analog_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define LTC_code_analog_MASK               LTC_code_analog__MASK
#define LTC_code_analog_SHIFT              LTC_code_analog__SHIFT
#define LTC_code_analog_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LTC_code_analog_PS                     (* (reg8 *) LTC_code_analog__PS)
/* Data Register */
#define LTC_code_analog_DR                     (* (reg8 *) LTC_code_analog__DR)
/* Port Number */
#define LTC_code_analog_PRT_NUM                (* (reg8 *) LTC_code_analog__PRT) 
/* Connect to Analog Globals */                                                  
#define LTC_code_analog_AG                     (* (reg8 *) LTC_code_analog__AG)                       
/* Analog MUX bux enable */
#define LTC_code_analog_AMUX                   (* (reg8 *) LTC_code_analog__AMUX) 
/* Bidirectional Enable */                                                        
#define LTC_code_analog_BIE                    (* (reg8 *) LTC_code_analog__BIE)
/* Bit-mask for Aliased Register Access */
#define LTC_code_analog_BIT_MASK               (* (reg8 *) LTC_code_analog__BIT_MASK)
/* Bypass Enable */
#define LTC_code_analog_BYP                    (* (reg8 *) LTC_code_analog__BYP)
/* Port wide control signals */                                                   
#define LTC_code_analog_CTL                    (* (reg8 *) LTC_code_analog__CTL)
/* Drive Modes */
#define LTC_code_analog_DM0                    (* (reg8 *) LTC_code_analog__DM0) 
#define LTC_code_analog_DM1                    (* (reg8 *) LTC_code_analog__DM1)
#define LTC_code_analog_DM2                    (* (reg8 *) LTC_code_analog__DM2) 
/* Input Buffer Disable Override */
#define LTC_code_analog_INP_DIS                (* (reg8 *) LTC_code_analog__INP_DIS)
/* LCD Common or Segment Drive */
#define LTC_code_analog_LCD_COM_SEG            (* (reg8 *) LTC_code_analog__LCD_COM_SEG)
/* Enable Segment LCD */
#define LTC_code_analog_LCD_EN                 (* (reg8 *) LTC_code_analog__LCD_EN)
/* Slew Rate Control */
#define LTC_code_analog_SLW                    (* (reg8 *) LTC_code_analog__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LTC_code_analog_PRTDSI__CAPS_SEL       (* (reg8 *) LTC_code_analog__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LTC_code_analog_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LTC_code_analog__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LTC_code_analog_PRTDSI__OE_SEL0        (* (reg8 *) LTC_code_analog__PRTDSI__OE_SEL0) 
#define LTC_code_analog_PRTDSI__OE_SEL1        (* (reg8 *) LTC_code_analog__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LTC_code_analog_PRTDSI__OUT_SEL0       (* (reg8 *) LTC_code_analog__PRTDSI__OUT_SEL0) 
#define LTC_code_analog_PRTDSI__OUT_SEL1       (* (reg8 *) LTC_code_analog__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LTC_code_analog_PRTDSI__SYNC_OUT       (* (reg8 *) LTC_code_analog__PRTDSI__SYNC_OUT) 


#if defined(LTC_code_analog__INTSTAT)  /* Interrupt Registers */

    #define LTC_code_analog_INTSTAT                (* (reg8 *) LTC_code_analog__INTSTAT)
    #define LTC_code_analog_SNAP                   (* (reg8 *) LTC_code_analog__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins LTC_code_analog_H */


/* [] END OF FILE */
