/*******************************************************************************
* File Name: F4_M.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_F4_M_H) /* Pins F4_M_H */
#define CY_PINS_F4_M_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "F4_M_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    F4_M_Write(uint8 value) ;
void    F4_M_SetDriveMode(uint8 mode) ;
uint8   F4_M_ReadDataReg(void) ;
uint8   F4_M_Read(void) ;
uint8   F4_M_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define F4_M_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define F4_M_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define F4_M_DM_RES_UP          PIN_DM_RES_UP
#define F4_M_DM_RES_DWN         PIN_DM_RES_DWN
#define F4_M_DM_OD_LO           PIN_DM_OD_LO
#define F4_M_DM_OD_HI           PIN_DM_OD_HI
#define F4_M_DM_STRONG          PIN_DM_STRONG
#define F4_M_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define F4_M_MASK               F4_M__MASK
#define F4_M_SHIFT              F4_M__SHIFT
#define F4_M_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define F4_M_PS                     (* (reg8 *) F4_M__PS)
/* Data Register */
#define F4_M_DR                     (* (reg8 *) F4_M__DR)
/* Port Number */
#define F4_M_PRT_NUM                (* (reg8 *) F4_M__PRT) 
/* Connect to Analog Globals */                                                  
#define F4_M_AG                     (* (reg8 *) F4_M__AG)                       
/* Analog MUX bux enable */
#define F4_M_AMUX                   (* (reg8 *) F4_M__AMUX) 
/* Bidirectional Enable */                                                        
#define F4_M_BIE                    (* (reg8 *) F4_M__BIE)
/* Bit-mask for Aliased Register Access */
#define F4_M_BIT_MASK               (* (reg8 *) F4_M__BIT_MASK)
/* Bypass Enable */
#define F4_M_BYP                    (* (reg8 *) F4_M__BYP)
/* Port wide control signals */                                                   
#define F4_M_CTL                    (* (reg8 *) F4_M__CTL)
/* Drive Modes */
#define F4_M_DM0                    (* (reg8 *) F4_M__DM0) 
#define F4_M_DM1                    (* (reg8 *) F4_M__DM1)
#define F4_M_DM2                    (* (reg8 *) F4_M__DM2) 
/* Input Buffer Disable Override */
#define F4_M_INP_DIS                (* (reg8 *) F4_M__INP_DIS)
/* LCD Common or Segment Drive */
#define F4_M_LCD_COM_SEG            (* (reg8 *) F4_M__LCD_COM_SEG)
/* Enable Segment LCD */
#define F4_M_LCD_EN                 (* (reg8 *) F4_M__LCD_EN)
/* Slew Rate Control */
#define F4_M_SLW                    (* (reg8 *) F4_M__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define F4_M_PRTDSI__CAPS_SEL       (* (reg8 *) F4_M__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define F4_M_PRTDSI__DBL_SYNC_IN    (* (reg8 *) F4_M__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define F4_M_PRTDSI__OE_SEL0        (* (reg8 *) F4_M__PRTDSI__OE_SEL0) 
#define F4_M_PRTDSI__OE_SEL1        (* (reg8 *) F4_M__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define F4_M_PRTDSI__OUT_SEL0       (* (reg8 *) F4_M__PRTDSI__OUT_SEL0) 
#define F4_M_PRTDSI__OUT_SEL1       (* (reg8 *) F4_M__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define F4_M_PRTDSI__SYNC_OUT       (* (reg8 *) F4_M__PRTDSI__SYNC_OUT) 


#if defined(F4_M__INTSTAT)  /* Interrupt Registers */

    #define F4_M_INTSTAT                (* (reg8 *) F4_M__INTSTAT)
    #define F4_M_SNAP                   (* (reg8 *) F4_M__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins F4_M_H */


/* [] END OF FILE */
