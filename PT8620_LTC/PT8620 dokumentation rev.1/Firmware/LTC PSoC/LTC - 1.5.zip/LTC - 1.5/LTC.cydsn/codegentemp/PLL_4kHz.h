/*******************************************************************************
* File Name: PLL_4kHz.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PLL_4kHz_H) /* Pins PLL_4kHz_H */
#define CY_PINS_PLL_4kHz_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PLL_4kHz_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    PLL_4kHz_Write(uint8 value) ;
void    PLL_4kHz_SetDriveMode(uint8 mode) ;
uint8   PLL_4kHz_ReadDataReg(void) ;
uint8   PLL_4kHz_Read(void) ;
uint8   PLL_4kHz_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PLL_4kHz_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PLL_4kHz_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PLL_4kHz_DM_RES_UP          PIN_DM_RES_UP
#define PLL_4kHz_DM_RES_DWN         PIN_DM_RES_DWN
#define PLL_4kHz_DM_OD_LO           PIN_DM_OD_LO
#define PLL_4kHz_DM_OD_HI           PIN_DM_OD_HI
#define PLL_4kHz_DM_STRONG          PIN_DM_STRONG
#define PLL_4kHz_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PLL_4kHz_MASK               PLL_4kHz__MASK
#define PLL_4kHz_SHIFT              PLL_4kHz__SHIFT
#define PLL_4kHz_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PLL_4kHz_PS                     (* (reg8 *) PLL_4kHz__PS)
/* Data Register */
#define PLL_4kHz_DR                     (* (reg8 *) PLL_4kHz__DR)
/* Port Number */
#define PLL_4kHz_PRT_NUM                (* (reg8 *) PLL_4kHz__PRT) 
/* Connect to Analog Globals */                                                  
#define PLL_4kHz_AG                     (* (reg8 *) PLL_4kHz__AG)                       
/* Analog MUX bux enable */
#define PLL_4kHz_AMUX                   (* (reg8 *) PLL_4kHz__AMUX) 
/* Bidirectional Enable */                                                        
#define PLL_4kHz_BIE                    (* (reg8 *) PLL_4kHz__BIE)
/* Bit-mask for Aliased Register Access */
#define PLL_4kHz_BIT_MASK               (* (reg8 *) PLL_4kHz__BIT_MASK)
/* Bypass Enable */
#define PLL_4kHz_BYP                    (* (reg8 *) PLL_4kHz__BYP)
/* Port wide control signals */                                                   
#define PLL_4kHz_CTL                    (* (reg8 *) PLL_4kHz__CTL)
/* Drive Modes */
#define PLL_4kHz_DM0                    (* (reg8 *) PLL_4kHz__DM0) 
#define PLL_4kHz_DM1                    (* (reg8 *) PLL_4kHz__DM1)
#define PLL_4kHz_DM2                    (* (reg8 *) PLL_4kHz__DM2) 
/* Input Buffer Disable Override */
#define PLL_4kHz_INP_DIS                (* (reg8 *) PLL_4kHz__INP_DIS)
/* LCD Common or Segment Drive */
#define PLL_4kHz_LCD_COM_SEG            (* (reg8 *) PLL_4kHz__LCD_COM_SEG)
/* Enable Segment LCD */
#define PLL_4kHz_LCD_EN                 (* (reg8 *) PLL_4kHz__LCD_EN)
/* Slew Rate Control */
#define PLL_4kHz_SLW                    (* (reg8 *) PLL_4kHz__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PLL_4kHz_PRTDSI__CAPS_SEL       (* (reg8 *) PLL_4kHz__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PLL_4kHz_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PLL_4kHz__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PLL_4kHz_PRTDSI__OE_SEL0        (* (reg8 *) PLL_4kHz__PRTDSI__OE_SEL0) 
#define PLL_4kHz_PRTDSI__OE_SEL1        (* (reg8 *) PLL_4kHz__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PLL_4kHz_PRTDSI__OUT_SEL0       (* (reg8 *) PLL_4kHz__PRTDSI__OUT_SEL0) 
#define PLL_4kHz_PRTDSI__OUT_SEL1       (* (reg8 *) PLL_4kHz__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PLL_4kHz_PRTDSI__SYNC_OUT       (* (reg8 *) PLL_4kHz__PRTDSI__SYNC_OUT) 


#if defined(PLL_4kHz__INTSTAT)  /* Interrupt Registers */

    #define PLL_4kHz_INTSTAT                (* (reg8 *) PLL_4kHz__INTSTAT)
    #define PLL_4kHz_SNAP                   (* (reg8 *) PLL_4kHz__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins PLL_4kHz_H */


/* [] END OF FILE */
