/*******************************************************************************
* File Name: DEC_VSYNC.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DEC_VSYNC_H) /* Pins DEC_VSYNC_H */
#define CY_PINS_DEC_VSYNC_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DEC_VSYNC_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    DEC_VSYNC_Write(uint8 value) ;
void    DEC_VSYNC_SetDriveMode(uint8 mode) ;
uint8   DEC_VSYNC_ReadDataReg(void) ;
uint8   DEC_VSYNC_Read(void) ;
uint8   DEC_VSYNC_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define DEC_VSYNC_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define DEC_VSYNC_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define DEC_VSYNC_DM_RES_UP          PIN_DM_RES_UP
#define DEC_VSYNC_DM_RES_DWN         PIN_DM_RES_DWN
#define DEC_VSYNC_DM_OD_LO           PIN_DM_OD_LO
#define DEC_VSYNC_DM_OD_HI           PIN_DM_OD_HI
#define DEC_VSYNC_DM_STRONG          PIN_DM_STRONG
#define DEC_VSYNC_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define DEC_VSYNC_MASK               DEC_VSYNC__MASK
#define DEC_VSYNC_SHIFT              DEC_VSYNC__SHIFT
#define DEC_VSYNC_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DEC_VSYNC_PS                     (* (reg8 *) DEC_VSYNC__PS)
/* Data Register */
#define DEC_VSYNC_DR                     (* (reg8 *) DEC_VSYNC__DR)
/* Port Number */
#define DEC_VSYNC_PRT_NUM                (* (reg8 *) DEC_VSYNC__PRT) 
/* Connect to Analog Globals */                                                  
#define DEC_VSYNC_AG                     (* (reg8 *) DEC_VSYNC__AG)                       
/* Analog MUX bux enable */
#define DEC_VSYNC_AMUX                   (* (reg8 *) DEC_VSYNC__AMUX) 
/* Bidirectional Enable */                                                        
#define DEC_VSYNC_BIE                    (* (reg8 *) DEC_VSYNC__BIE)
/* Bit-mask for Aliased Register Access */
#define DEC_VSYNC_BIT_MASK               (* (reg8 *) DEC_VSYNC__BIT_MASK)
/* Bypass Enable */
#define DEC_VSYNC_BYP                    (* (reg8 *) DEC_VSYNC__BYP)
/* Port wide control signals */                                                   
#define DEC_VSYNC_CTL                    (* (reg8 *) DEC_VSYNC__CTL)
/* Drive Modes */
#define DEC_VSYNC_DM0                    (* (reg8 *) DEC_VSYNC__DM0) 
#define DEC_VSYNC_DM1                    (* (reg8 *) DEC_VSYNC__DM1)
#define DEC_VSYNC_DM2                    (* (reg8 *) DEC_VSYNC__DM2) 
/* Input Buffer Disable Override */
#define DEC_VSYNC_INP_DIS                (* (reg8 *) DEC_VSYNC__INP_DIS)
/* LCD Common or Segment Drive */
#define DEC_VSYNC_LCD_COM_SEG            (* (reg8 *) DEC_VSYNC__LCD_COM_SEG)
/* Enable Segment LCD */
#define DEC_VSYNC_LCD_EN                 (* (reg8 *) DEC_VSYNC__LCD_EN)
/* Slew Rate Control */
#define DEC_VSYNC_SLW                    (* (reg8 *) DEC_VSYNC__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DEC_VSYNC_PRTDSI__CAPS_SEL       (* (reg8 *) DEC_VSYNC__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DEC_VSYNC_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DEC_VSYNC__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DEC_VSYNC_PRTDSI__OE_SEL0        (* (reg8 *) DEC_VSYNC__PRTDSI__OE_SEL0) 
#define DEC_VSYNC_PRTDSI__OE_SEL1        (* (reg8 *) DEC_VSYNC__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DEC_VSYNC_PRTDSI__OUT_SEL0       (* (reg8 *) DEC_VSYNC__PRTDSI__OUT_SEL0) 
#define DEC_VSYNC_PRTDSI__OUT_SEL1       (* (reg8 *) DEC_VSYNC__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DEC_VSYNC_PRTDSI__SYNC_OUT       (* (reg8 *) DEC_VSYNC__PRTDSI__SYNC_OUT) 


#if defined(DEC_VSYNC__INTSTAT)  /* Interrupt Registers */

    #define DEC_VSYNC_INTSTAT                (* (reg8 *) DEC_VSYNC__INTSTAT)
    #define DEC_VSYNC_SNAP                   (* (reg8 *) DEC_VSYNC__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins DEC_VSYNC_H */


/* [] END OF FILE */
