/*******************************************************************************
* File Name: TCodeCLK.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_TCodeCLK_H) /* Pins TCodeCLK_H */
#define CY_PINS_TCodeCLK_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "TCodeCLK_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    TCodeCLK_Write(uint8 value) ;
void    TCodeCLK_SetDriveMode(uint8 mode) ;
uint8   TCodeCLK_ReadDataReg(void) ;
uint8   TCodeCLK_Read(void) ;
uint8   TCodeCLK_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define TCodeCLK_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define TCodeCLK_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define TCodeCLK_DM_RES_UP          PIN_DM_RES_UP
#define TCodeCLK_DM_RES_DWN         PIN_DM_RES_DWN
#define TCodeCLK_DM_OD_LO           PIN_DM_OD_LO
#define TCodeCLK_DM_OD_HI           PIN_DM_OD_HI
#define TCodeCLK_DM_STRONG          PIN_DM_STRONG
#define TCodeCLK_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define TCodeCLK_MASK               TCodeCLK__MASK
#define TCodeCLK_SHIFT              TCodeCLK__SHIFT
#define TCodeCLK_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define TCodeCLK_PS                     (* (reg8 *) TCodeCLK__PS)
/* Data Register */
#define TCodeCLK_DR                     (* (reg8 *) TCodeCLK__DR)
/* Port Number */
#define TCodeCLK_PRT_NUM                (* (reg8 *) TCodeCLK__PRT) 
/* Connect to Analog Globals */                                                  
#define TCodeCLK_AG                     (* (reg8 *) TCodeCLK__AG)                       
/* Analog MUX bux enable */
#define TCodeCLK_AMUX                   (* (reg8 *) TCodeCLK__AMUX) 
/* Bidirectional Enable */                                                        
#define TCodeCLK_BIE                    (* (reg8 *) TCodeCLK__BIE)
/* Bit-mask for Aliased Register Access */
#define TCodeCLK_BIT_MASK               (* (reg8 *) TCodeCLK__BIT_MASK)
/* Bypass Enable */
#define TCodeCLK_BYP                    (* (reg8 *) TCodeCLK__BYP)
/* Port wide control signals */                                                   
#define TCodeCLK_CTL                    (* (reg8 *) TCodeCLK__CTL)
/* Drive Modes */
#define TCodeCLK_DM0                    (* (reg8 *) TCodeCLK__DM0) 
#define TCodeCLK_DM1                    (* (reg8 *) TCodeCLK__DM1)
#define TCodeCLK_DM2                    (* (reg8 *) TCodeCLK__DM2) 
/* Input Buffer Disable Override */
#define TCodeCLK_INP_DIS                (* (reg8 *) TCodeCLK__INP_DIS)
/* LCD Common or Segment Drive */
#define TCodeCLK_LCD_COM_SEG            (* (reg8 *) TCodeCLK__LCD_COM_SEG)
/* Enable Segment LCD */
#define TCodeCLK_LCD_EN                 (* (reg8 *) TCodeCLK__LCD_EN)
/* Slew Rate Control */
#define TCodeCLK_SLW                    (* (reg8 *) TCodeCLK__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define TCodeCLK_PRTDSI__CAPS_SEL       (* (reg8 *) TCodeCLK__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define TCodeCLK_PRTDSI__DBL_SYNC_IN    (* (reg8 *) TCodeCLK__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define TCodeCLK_PRTDSI__OE_SEL0        (* (reg8 *) TCodeCLK__PRTDSI__OE_SEL0) 
#define TCodeCLK_PRTDSI__OE_SEL1        (* (reg8 *) TCodeCLK__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define TCodeCLK_PRTDSI__OUT_SEL0       (* (reg8 *) TCodeCLK__PRTDSI__OUT_SEL0) 
#define TCodeCLK_PRTDSI__OUT_SEL1       (* (reg8 *) TCodeCLK__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define TCodeCLK_PRTDSI__SYNC_OUT       (* (reg8 *) TCodeCLK__PRTDSI__SYNC_OUT) 


#if defined(TCodeCLK__INTSTAT)  /* Interrupt Registers */

    #define TCodeCLK_INTSTAT                (* (reg8 *) TCodeCLK__INTSTAT)
    #define TCodeCLK_SNAP                   (* (reg8 *) TCodeCLK__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins TCodeCLK_H */


/* [] END OF FILE */
