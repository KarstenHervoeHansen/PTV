//*******************************************************************
// handles commands received by the 5V UART - used for debugging only
//*******************************************************************

extern void HandleSerialCommand(void);

//[] END OF FILE
