#include <C8051F120.h>
#include <string.h>
#include "uart_1.h"
#include "main.h"

//buffers og pointers til seriel indl�sning
#define RX1_SERBUFLEN  8
unsigned char xdata rx1_serbuf[RX1_SERBUFLEN];
unsigned char rx1_inptr=0, rx1_outptr=0;



Tserbuffer RX1Buffer[ RX1BUFSIZE ];
Tserbuffer * RX1RDPtr;
Tserbuffer * RX1WTPtr;
unsigned int RX1count;						// number of data to be recieved by host (Unsigned INT)
bit RX1Ready;								// RX buffer has room

unsigned char RX1Timeout;					// When timeout a whole u-Blox packet has been received.
unsigned char NTPResetDelay;				// When timeout a whole u-Blox packet has been received.

//	Write 1 byte to UART1.
void putch(unsigned char c)
{
	unsigned char SFRPAGE_Save;

	SFRPAGE_Save = SFRPAGE;    // Save Current SFR page

	SFRPAGE = UART1_PAGE;
	SBUF1 = c;
	while (TI1 == 0);
	TI1   = 0;
	SFRPAGE = SFRPAGE_Save;    // Restore SFR page
}

//	UART1 interrupt handler.
void UART1(void) interrupt 20 using 1
{
	if (RI1)
		{
			RI1 = 0;
		    rx1_serbuf[rx1_inptr] = SBUF1;
		    rx1_inptr++;
		    if (rx1_inptr == RX1_SERBUFLEN)
	        rx1_inptr = 0;

/*
			//pos = TXBUFSIZE - (TXWTPtr - TXBuffer);	// consider on wrap around of ring buffer
			if (RXReady)
			{
				RXTimeout = 1;
				if (RXWTPtr > (RXBUFSIZE + RX1Buffer - 1))
				{
					RXWTPtr = RX1Buffer;
				}
	
				*RXWTPtr = SBUF1;

				RXWTPtr++;
				RXcount++;
				RXReady = (RXcount != 0);
			}
*/
//			SNTP_Enable = 1;
		}
	//if (TI1 == 1){TI1 = 0;}

}

void Flush_COMbuffers( void )
{
	unsigned char i;

	RX1WTPtr = RX1Buffer;
    for (i = 0; i < RX1BUFSIZE; i++)
	{
		*RX1WTPtr = 0xFF;	
		RX1WTPtr++;
	}

	RX1RDPtr = RX1Buffer;
	RX1WTPtr = RX1Buffer;
	RX1count = 0;
	RX1Ready = 1;

}

unsigned char COMGetByte( void )
{
	unsigned char dt;

	dt = *RX1RDPtr;
	if ( RX1RDPtr == (RX1Buffer + (RX1BUFSIZE - 1)) )	// at the end of the buffer
		RX1RDPtr = RX1Buffer;					// go to the head of the buffer
	else
		RX1RDPtr++;

	RX1count--;
	RX1Ready = (RX1count != 0);

	return dt;
}
/*
unsigned char getch(unsigned char * c)
{
  unsigned char timer=0;

  while (RXcount == 0)
  {
  	timer++;
    if (timer==255)
      {
      *c  = 0;   // zero the holder to signal timeout
      return (0);
      }
    }

  *c = COMGetByte();
  return (1);
}
*/
unsigned char getch(unsigned char * c)
{
  unsigned char timer=0;

  while (rx1_inptr == rx1_outptr)
  {
  	timer++;
    if (timer==255)
      {
      *c  = 0;   // zero the holder to signal timeout
      return (0);
      }
    }

  EIE2 = 0x40;
  *c = rx1_serbuf[rx1_outptr];
  rx1_outptr++;
  if (rx1_outptr == RX1_SERBUFLEN)
    rx1_outptr = 0;
  EIE2 = 0x40;
  return (1);
}
   