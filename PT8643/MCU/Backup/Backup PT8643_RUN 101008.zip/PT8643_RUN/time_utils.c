#include "time_utils.h"

// Daycount in month 1 --> 12. (Leap year is handeled in calculations.)
unsigned char code DayTable[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

// Days between 1/1/0001 and 1/1/1900
unsigned int code DateDelta = 693596;

unsigned char IsLeapYear(unsigned int year)
{
	if ( (year % 4 == 0) && ((year % 100 != 0) || (year % 400 == 0)) )
	{ return(1); } else { return(0); } 
}

unsigned int DaysFrom1900(unsigned int year, unsigned char month, day)
{
	unsigned char c;

	unsigned int i;

    for (c = 0; c < month - 1; c++)
	{
		day = day + DayTable[c];	
	}

    year = year - 1;

    i = (year * 365) + (year / 4) - (year / 100) + (year / 400) + day - DateDelta;
	
    return (i);
}

unsigned long SecsFromMidnight(char hour, min, sec)
{
	unsigned long i, j;
	
	j = hour; // Hour can not be used directly in the calculation, since the value will be changed during calculation and an overflow can occour.
	i = (j * 3600) + (min * 60) + sec;

    return (i);
}

unsigned long SecsFrom1900(unsigned int year, unsigned char month, day, hour, min, sec, gps_leapseconds)
{
	unsigned long i;

	i = DaysFrom1900(year, month, day) * 86400L;

	i += SecsFromMidnight(hour, min, sec);
//	i += gps_leapseconds + 9;	// Between 1-1-1970 and 14-01-2010 a total of 24 leap seconds has been added to UTC_Time (GMT).
								// Because GPS_Time started 1-1-1980 the first 9 leap seconds from the 70's has to be added 
								// to the leap seconds retreived from the GPS receiver.
	
	i++; // <----------------------------TEST
	return(i);
}


