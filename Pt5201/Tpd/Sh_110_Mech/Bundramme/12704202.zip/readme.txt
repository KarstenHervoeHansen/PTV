
�ndret:	ti 06-06-00 15:47
sh.110-1  12704202_110-1.pdf
12704202.dwg
12704202.dxf (AutoCad 14)

                             postscript    windows
Fonte som bruges er: ariab - ariab.shx  -  Arial MT Bold
                     arie  - arie.shx   -  Arial MT Extra Bold
                     arim  - arim.shx   -  Arial MT Medium   

For farvespecifikation se 4008 140 00000