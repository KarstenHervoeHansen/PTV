
�ndret:	ti 06-06-00 16:09
sh.110-1  12704193 _110-1.pdf
sh.110-2  12704193 _110-2.pdf
sh.115-1  12704193 _115-1.pdf
12704193.dwg
12704193.dxf (AutoCad 14)


                             postscript    windows
Fonte som bruges er: arim  - arim.shx   -  Arial MT Medium      (PT nr. +tekst)
                     arie  - arie.shx   -  Arial MT Extra Bold  (ProTeleVision)
                     ariab - ariab.shx  -  Arial MT Bold        (resten af teksten)
                        

For farvespecifikation se 4008 140 00000