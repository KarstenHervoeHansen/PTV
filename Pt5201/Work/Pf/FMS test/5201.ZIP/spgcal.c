
/*
PT5210 rettelser:
970306 	Kommando GI? indf�rt: l�s SW version i SPG: 
    	GI? returnerer SW ver fra version 020, tidligere udgaver
 		returnerer intet. Her bruges GI til field 1/5 skift i PAL.
 		Med SW ver 020 er GI erstattet af GJ og GJ erstattet af GK.

970603  Test af synclevel rettes fra 150 mV til 180 mV (PAL), og
		fra 20 IRE til 24 IRE (NTSC) efter aftale med BL� og SNJ.
		Dett g�res for at undg� fejl, som kan optr�de pga af hysteresis
		(120-165 mV) i detekteringen af sync.
		
970922  AutoHPH data l�ses og vises p� sk�rm ved fieldskift 1/5 i PAL og
        1/3 i NTSC. Dette har ingen indflydelse p� kalibreringen.
 

981124  MakeSPGReset rettet s�ledes, at l�ste data fra SPG'en vises, 
        hvis reset af SPG fejler. Dette har ingen indflydelse p� kalibreringen.

PT5201 rettelser:
 
 */


/* HP34970 switch channel select xyz:
	x = board no		1=20-ch-mux (hp34901) 	2=dual 4-ch-rfmux (hp34905)
	hp34901:
	yz = relay no 1-20		
	hp34905:
	y = channel no		1=ch1				2=ch2
	z = relay no 1-4		
*/



#include "hp34970a.h"
#include "refosc.h"
#include <gpib.h>
#include "hp34401a.h"
#include "hp5313xa.h"
#include "refosc.h"
#include "spgphase.h"
#include <ansi_c.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include <userint.h>
#include "spghph.h"
#include "spggenl.h"
#include "cviutil.h"
#include "vlmutil.h"
#include "bbcal.h"
#include "sditest.h"
#include "pt5201.h"
#include "def.h"


// SPG har intern RS-232 adresse = 15h = 21d
 
const int GenlWaitInterval = 1;  			// sec
const double AutoHPHWaitInterval = 0.6;		// sec

const double FreqNom = 4.5e6;			// Hz
const double FreqTol = 0.3;			// Hz

const double TP30MeasDelay = 1.0;	// Tid fra genlock=TRUE indtil m�ling i TP01
const double TP30max = 0.0;			// max sp�nding i TP30 ved intern
const double TP30min = -2.0;			// min sp�nding i TP30 ved intern
												
const double TP31max = 1.7;			// max sp�nding i TP31 ved intern
const double TP31min = 1.3;			// min sp�nding i TP31 ved intern

const unsigned int hphminmaxdiff = 200;	// max forskel ved HPH m�ling

const int	NumberOfOkMeas = 4,			// Number of OK measurements when calibrating ref-osc
				MaxNumberOfMeas = 15;		// Max number of measurements when calibrating ref-osc

int SPGSWRev;

int	SPGdone,
		TV;
 
double TP01Voltage;	// VCO sp�nding m�le i TP01

int GenlockStatus,	// TRUE hvis apparatet er l�st til extern ref
    VCOVoltageOk,		// TRUE hvis sp�nding i TP01 er indenfor �vre/nedre gr�nse
    FreqCalOk;			// Freq cal of 13MHz-TCXO or 27MHZ-ref-osc
int SPGGenlValue,
	 SPGGenlOffsetValue;
	
int WriteSPGCalDate(void);
int MakeSPGGenlockCal(int TVSys);
int BasicTotalTest(int TestNo);
char *ReadSPGKUNumber (void);

//****************************************************************************
void WriteDacV74(int dacvalue){

 Fmt(DUTStr,"%s<:FACT:V24C:COMM 21,'GX%i';",dacvalue);	// SPG-address = 15h
 WriteCOMPort(DUTCOM, DUTStr);
#if DEBUG
 SetCtrlVal (ocxoPNL, OCXO_PNL_COMSTR, DUTStr);  // kun ved debug
#endif 

}


//*******************************************************************************
char *ReadSPGSWVer (void) {
  // read SPG SW-version from SPG-�P

 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:GENL:VERS?;");
 Delay(0.05);
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (strlen(strread) > 1)
  CopyString(strread,0,strread,strlen(strread)-3,3);
  else
   Fmt(strread,"%s<???");

return strread;
}


//****************************************************************************
int GetGenlockStatus(void){
// status = tilstand af UNLOCKED LED l�ses i SPG'en
char *strread;
int gs;
 
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GS?';");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (strlen(strread) > 0)
  Scan(strread,"%s>%i",&gs);
  else
  gs = 0;
 gs = gs & 0x06;	 // udmask bit 1,2    (bit 0,3-7=0)
 
return gs;
} // GetGenlockStatus
 


//****************************************************************************
int CheckGenlockVCOVoltage(float upperlim, float lowerlim, double wait, double *VCOmeas){
/* M�ling af VCO sp�ndingen til 27MHz oscillatoren i internal mode.
   Der m�les i TP30 2 gange efter hinanden med 0.2 sek interval. Sidste m�ling anvendes.
   wait = tid inden 1. m�ling udf�res
*/   
double meas;
int VCOstatus;
 Delay(wait);
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
 Delay(0.2);
 ErrIEEE = hp34401a_singleMeas (hp34401, &meas);
 EnableBreakOnLibraryErrors();
 VCOstatus = ((meas <= upperlim) && (meas >= lowerlim));
 *VCOmeas = meas;
return VCOstatus;
} // CheckGenlockVCOVoltage



 
//****************************************************************************
int MakeSPGGenlockInput(void){
// Der testes med genlock til PAL.
// Test #3-8 foreg�r i MakeSPGGenlockSystem

char *SDIKU;
int button_pressed;


 DisplayPanel (spggenlPNL);
 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 ProcessDrawEvents();


 Set5640Standard("G");
 Set5640Standard("M");
 
 GenlBOk = TRUE;
 GenlA_BOk = TRUE;

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spggenlPNL);
  GenlInputOk = FALSE;
  return FALSE;
  }


 InitPT5201();

// Genlock for input  (PAL) --------------------------------------------------
 SetPanelAttribute (spggenlPNL, ATTR_TITLE, " Genlock test ");

 WriteCOMPort(DUTCOM,":INP:GENL:SYST PALB;"); 
 Delay(1.0); 
 
 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," GENL SIGNAL forbindes til DUT GENLOCK\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," DUT GENLOCK forbindes til 5662 CH-A\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Kontroller at lysdioden GENLOCK er t�ndt\n\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," Afbryd:   Tast F9\n");

 WaitForContinue();
 if (GenlA_BOk == FALSE){
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 // Check at DUT er genlocked
 Repeat = TRUE;
 GenlockStatus = GetGenlockStatus();
   while ((GenlockStatus != DUT_LOCKED) && (GenlA_BOk == TRUE)) {

    button_pressed = GenericMessagePopup ("DUT genlock",
									      "Genlock PAL burst til A-B input ikke l�st", "OK", "Afvist", "",
									      0, -1, 0,
									      VAL_GENERIC_POPUP_BTN1,
									      VAL_GENERIC_POPUP_BTN2,
									      VAL_GENERIC_POPUP_BTN3);
     switch (button_pressed) {
      case 1: GenlA_BOk = TRUE; Repeat = FALSE; break;
      case 2: GenlA_BOk = FALSE; Repeat = FALSE; break;
     }

    GenlockStatus = GetGenlockStatus();
   } //while

  if (GenlA_BOk == FALSE) {
   MessagePopup (" Genlock test", " FEJLET ");
   HidePanel(spggenlPNL);
   SetGenlockSignal(GENL_OFF);
   return FALSE;
  }


 SetGenlockSignal(GENL_OFF);

 GenlInputOk = GenlBOk & GenlA_BOk;

 HidePanel(spggenlPNL);
 

return TRUE;
} // MakeSPGGenlockInput





//****************************************************************************
int MakeSPGGenlockSystem(void){
/* 
 TEST 2,3,4 er en test af genlocksystemet med f�lgende signaler: PAL, NTSC og
 10MHz.
 For PAL, NTSC og 10MHz genlock testes om der genlockes ved � 6dB.
 Frekvenssignalet 10MHz d�mpes med et d�mpeled monteret i genlock mux'en (i BNC-stik panalet).
 Genlock med PAL og NTSC programmeres med PM5640. PAL og NTSC testes desuden 
 med Hum og Noise.
*/


// 2. TEST   Genlock PAL --------------------------------

int button_pressed;
int handle_returned, controlID_returned;
int fhandle,
    bytes_written,
    n;

 DisplayPanel (spggenlPNL);
 
 GenlPALOk = TRUE;
 GenlNTSCOk = TRUE;
 Genl10MHzOk = TRUE;
 
 SetPanelAttribute (spggenlPNL, ATTR_TITLE, " Genlock Test  (input A) ");
// ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");
 ProcessDrawEvents();

 ErrIEEE = hp34401a_conf (hp34401, 1, VI_ON, 5, 1);
 

 ResetTextBox(spggenlPNL, SPGGEN_PNL_GENLTXTBOX,"");

 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spggenlPNL);
  GenlSystemOk = FALSE;
  return FALSE;
  }

 WriteCOMPort(DUTCOM,":INP:GENL:SYST:PALB;");
 Delay(xd);
 Set5640Standard("G");
 Set5640Pattern("G", 290);




// PAL -------- Hum, Noise, Burst=150mV, Sync=180mV --------------------------------------------
 Set5640BurstLevel("G", 300 * 0.5);
 Set5640SyncLevel("G", 300 * 0.6);
 Set5640Hum("G", 1000);
 Set5640Noise("G", -40);
 SetGenlockSignal(GENL_PAL);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   Burst=150mV  Sync=180mV  Hum=1000mV   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while
 

 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");

 
 if (GenlockStatus != DUT_LOCKED){
  Set5640Standard("G");
  GenlPALOk = FALSE;
  MessagePopup (" Genlock fejl"," PAL genlock fejlet ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }




// PAL -------- Hum, Noise, Burst, Sync + 6dB --------------------------------------------------
 Set5640BurstLevel("G", 300 * 2);
 Set5640SyncLevel("G", 300 * 2);
 Set5640Hum("G", 1000);
 Set5640Noise("G", -40);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," PAL:   Burst+Sync=600mV   Hum=1000mV   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while


 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
  

 if (GenlockStatus != DUT_LOCKED){
  Set5640Standard("G");
  GenlPALOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock PAL fejlet ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (GenlPALOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  Set5640Standard("G");
  HidePanel(spggenlPNL);
  return FALSE;
 }
 



 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST NTSC;");
 Delay(xd);
 Set5640Standard("M");
 Set5640Pattern("M", 290);

// 3. TEST    NTSC -------- Hum, Noise, Burst, Sync - 6dB --------------------------------
 Set5640BurstLevel("M", 40 * 0.5);
 Set5640SyncLevel("M", 40 * 0.6);
 Set5640Hum("M", 100);
 Set5640Noise("M", -40);
 SetGenlockSignal(GENL_NTSC);
 Delay(1.0);
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  Burst=20IRE  Sync=24IRE  Hum=100IRE   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");


 if (GenlockStatus != DUT_LOCKED){
  Set5640Standard("M");
  GenlNTSCOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock NTSC fejlet ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

// NTSC -------- Hum, Noise, Burst, Sync + 6dB ------------------------------------------
 Set5640BurstLevel("M", 40 * 2);
 Set5640SyncLevel("M", 40 * 2);
 Set5640Hum("M", 100);
 Set5640Noise("M", -40);
 Delay(1.0);

 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," NTSC:  Burst+Sync=80IRE   Hum=100IRE   Noise=-40dB  ");
 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");


 if (GenlockStatus != DUT_LOCKED){
  Set5640Standard("M");
  GenlNTSCOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock NTSC fejlet");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }
 
 Set5640Standard("G");
 Set5640Standard("M");


 GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
 
 if (GenlNTSCOk == FALSE){
  SetGenlockSignal(GENL_OFF);
  HidePanel(spggenlPNL);
  return FALSE;
 }





// 3. TEST   Genlock 10 MHz --- + 6dB --------------------------------------------------------
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," 10 MHz = +6dB ");
 SetGenlockSignal(GENL_10M_HIGH);
 
 WriteCOMPort(DUTCOM,":INP:GENL:SYST F10MHZ;");

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 
 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
 

 if (GenlockStatus != DUT_LOCKED){
  Genl10MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock 10 MHz fejlet ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }

  // get system date 
  dato = GetDate(1);
 
  // get system time
  tt = TimeStr();
  
  
  // check om logfil findes, ellers opret en ny logfil. LogDest angiver drev+sti til logfil.
  fhandle = OpenFile (SPGLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
  Fmt(wrtbuf,"%s<%s,%s,KU%s,10MHz lock: TP01 = %f[p2w5]V,%i\n",dato,tt,KUStr,TP01Voltage,AppType);
  bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
  CloseFile(fhandle);

 
// 10 MHz -------- - 6dB --------------------------------------------
 
 SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," 10 MHz = -6dB ");
 SetGenlockSignal(GENL_10M_LOW);
 
 WriteCOMPort(DUTCOM,":INP:GENL:INP A;");
 Delay(xd);
 WriteCOMPort(DUTCOM,"SYST F10MHZ;");

 Delay(1.0);
 n = 0;
 GenlockStatus = GetGenlockStatus();
 
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  n++;
  Delay(GenlWaitInterval);
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," *");
  ProcessDrawEvents();
 }//while

 if (GenlockStatus == DUT_LOCKED)
  SetCtrlVal(spggenlPNL, SPGGEN_PNL_GENLTXTBOX," OK");
 

 if (GenlockStatus != DUT_LOCKED){
  Genl10MHzOk = FALSE;
  MessagePopup (" Genlock fejl"," Genlock 10 MHz fejlet ");
  HidePanel(spggenlPNL);
  SetGenlockSignal(GENL_OFF);
  return FALSE;
 }


 SetGenlockSignal(GENL_OFF);


 // check samlet genlock test
 GenlSystemOk = GenlPALOk && GenlNTSCOk && Genl10MHzOk;
 
 if (GenlSystemOk == TRUE)
  MessagePopup (" Genlock Test"," OK");
 
 Set5640Standard("G");
 Set5640Standard("M");
 HidePanel(spggenlPNL);

   
return TRUE;
} //MakeSPGGenlockSystem






//--------------------------------------------------------------------------------
int MakeSPGHPHCal(void){
int handle_returned, controlID_returned,
	 svar, button_pressed,n;
unsigned int hph[20],
			 hh,
			 hphmean,
			 hphmax,
			 hphmin,
			 hphdiff,
			 hphreadg,
			 hphreadm;
char MsgStr[150];

 DisplayPanel (spghphPNL);
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"");

 SelectPM3094Setup(1);
 SetCtrlVal (spghphPNL, SPGHPH_PNL_SCOPSETUP, " PM3094: FRONTS = F1");

 ProcessDrawEvents();
 
 
 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (spghphPNL);
  AutoHPH_PALOk = FALSE;
  AutoHPH_PALOk = FALSE;
  return FALSE;
 }
	

 InitPT5201();


 AutoHPH_PALOk = TRUE;
 AutoHPH_NTSCOk = TRUE;

//goto ntsc;


 Set5640Standard("G");
 Set5640Standard("M");


 
 
 // Auto HPH for PAL --------------------------------
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");
 SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, "");

 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind PT5210 BB til DUT GENLOCK\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind DUT GENLOCK med scop CH-1\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forbind DUT BB1 med scop CH-2\n\n\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," OBS: Scop CH-1 og CH-2 skal v�re afsluttet i 75 ohm\n\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Afbryd:   Tast F9\n");


 
 WaitForContinue();
 if (AutoHPH_PALOk == FALSE){
  HidePanel(spghphPNL);
  return FALSE;
 }


 // Set black-burst from PT5210 = PAL_ID
 WriteCOMPort(PT5210COM,":OUTP:BB1:SYST PAL_ID; SCHP 0;");

 // Set DUT genlock = PAL burst
 WriteCOMPort(DUTCOM,":INP:GENL:SYST PALB;");
 Delay(xd);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 52,'HK780126480';");	// BB1 with PAL_ID
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GZ';");
 
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Genlock=PAL burst         BB1=PAL_ID\n");
 Delay(1);
 
 // Check at DUT er genlocked
 n = 0;
 GenlockStatus = GetGenlockStatus();
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," *");
  n++;
  Delay(GenlWaitInterval);
  ProcessDrawEvents();
 }//while
 
 if (GenlockStatus != DUT_LOCKED){
  Fmt(MsgStr,"%s<PAL genlock ikke l�st    Status=%x (hex)",GenlockStatus);
  MessagePopup ("Genlock fejl",MsgStr);
  HidePanel(spghphPNL);
  return FALSE;
 }

 // setup for internal commands
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GA';");

 Delay(1);
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 FlushInQ(DUTCOM);
 
 // disse 3 m�linger gemmes ikke
 for (n = 0; n < 3; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }

  Delay(0.03);
  WriteCOMPort(DUTCOM,"COMM 21,'GA';"); 
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]",hh);
  Fmt(MsgStr,"%s[a]<\n");
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
 }
 

 // disse m�linger gemmes og middelv�rdi beregnes
 for (n = 0; n < 7; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  
  Delay(0.03);
  WriteCOMPort(DUTCOM,"COMM 21,'GA';");
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]\n",hh);
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
  hh = hh & 0x00ffffff;
  hph[n] = hh;
 } // for
 
 // find hph min
 hphmin = 0xffffffff;
 for (n = 0; n < 7; n++) {
  if (hph[n] < hphmin)
   hphmin = hph[n];
 }
 hphmin = hphmin | 0xff000000;   // set 8 MSB bits

 // find hph max
 hphmax = 0x0;
 for (n = 0; n < 7; n++) {
  if (hph[n] > hphmax)
   hphmax = hph[n];
 }
 hphmax = hphmax | 0xff000000;   // set 8 MSB bits
 
 hphdiff = hphmax - hphmin;
 
 
 // calculate mean
 hphmean = 0;
 for (n = 0; n < 7; n++) 
   hphmean = hphmean + hph[n];
 hphmean = hphmean / 7;
 hphmean = hphmean | 0xff000000;   // set 8 MSB bits in PT5210/5230 only

 Fmt(MsgStr,"%s<%i[u]",hphmin);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmax);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmean);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,MsgStr);

 if (hphdiff > hphminmaxdiff) {
  Fmt(MsgStr,"%s< Forskel mellem Max og Min er for stor (max forskel: ");
  Fmt(MsgStr,"%s[a]<%i",hphminmaxdiff);
  Fmt(MsgStr,"%s[a]<)\n Kalibrering stoppet");
  MessagePopup (" SPG Kalibreringsfejl: Auto HPH for PAL", MsgStr);
  AutoHPH_PALOk = FALSE;
  HidePanel(spghphPNL);
  return FALSE;
 }
 
 
 
 //AutoHPH_PALOk = TRUE;

 if (AutoHPH_PALOk == TRUE) {
  Fmt(DUTStr,"%s<COMM 21,'GV%i[u]';",hphmean);
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.3);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  if (hphmean != hh)
   AutoHPH_PALOk = FALSE;
 } 
 

  if (AutoHPH_PALOk == FALSE) {
   MessagePopup (" SPG: Auto HPH kalibrering for PAL fejlet", " Middelv�rdi ikke gemt korrekt i SPG\n Kalibrering stoppes");
   HidePanel(spghphPNL);
   return FALSE;
  }

 
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Linie 7 puls i CH-1 skal v�re i samme field som linie 7 puls i CH-2\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Field 1/5 kan skiftes med tasten 'Skift field 1/5'\n");
 
 Repeat = TRUE;
 while (Repeat == TRUE){

  button_pressed = GenericMessagePopup ("SPG kalibrering:  Field 1/5 for PAL",
									    "OK?", "OK", "Afvist", "Skift field 1/5",
									    0, -1, 0,
									    VAL_GENERIC_POPUP_BTN1,
									    VAL_GENERIC_POPUP_BTN2,
									    VAL_GENERIC_POPUP_BTN3);
   switch (button_pressed) {
    case 1: AutoHPH_PALOk = TRUE; Repeat = FALSE; break;
    case 2: AutoHPH_PALOk = FALSE; Repeat = FALSE; break;
    case 3: WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GJ';");	// invert G-frame 
            Delay(0.03);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadg);
            Delay(0.03);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 21,'GU?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadm);
            Fmt(MsgStr,"%s<GA?=%i[u]  GU?=%i[u]",hphreadg,hphreadm);
				SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, MsgStr);
    		break;
   }

 } //while
 
 
 // if OK   store in NVRAM after hph-NTSC-calibration
 

  if (AutoHPH_PALOk == FALSE) {
    HidePanel(spghphPNL);
   return FALSE;
  }


// label
ntsc:
 
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");
 SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, "");


 Set5640Standard("G");
 Set5640Standard("M");
 

 // Auto HPH for NTSC --------------------------------

 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
   
 // Set black-burst from PT5210 = NTSC
 WriteCOMPort(PT5210COM,":OUTP:BB1:SYST NTSC; SCHP 0;");
 Delay(0.03);

 // Set DUT BB1 = NTSC with ID in line 11
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 52,'HM95760800';");	// BB1 with NTSC
 Delay(0.03);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 52,'HN1';");	//ID-pulse in linie 11

 // Set DUT genlock to input-AB NTSC burst
 WriteCOMPort(DUTCOM,":INP:GENL:SYST NTSC;");
 Delay(xd);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Genlock: NTSC\n");
 Delay(1);

 // Check at DUT er genlocked 
 n = 0;
 GenlockStatus = GetGenlockStatus();
 while ((GenlockStatus != DUT_LOCKED) & (n < 10)){
  GenlockStatus = GetGenlockStatus();
  SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," *");
  n++;
  Delay(GenlWaitInterval);
  ProcessDrawEvents();
 }//while
 
 if (GenlockStatus != DUT_LOCKED){
  Fmt(MsgStr,"%s<NTSC genlock ikke l�st    Status=%x (hex)",GenlockStatus);
  MessagePopup ("Genlock fejl",MsgStr);
  HidePanel(spghphPNL);
  return FALSE;
 }


// setup for internal commands
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GU';");

 Delay(1);
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 FlushInQ(DUTCOM);
 
 // disse 3 m�linger gemmes ikke
 for (n = 0; n < 3; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_NTSCOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  Delay(0.03);
  WriteCOMPort(DUTCOM,"COMM 21,'GU';"); 
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GU?';"); 
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]\n",hh);
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
 }
 

 // disse 7 m�linger gemmes og middelv�rdi beregnes
 for (n = 0; n < 7; n++) {
  GetUserEvent (NOWAIT, &handle_returned, &controlID_returned);
   if (AutoHPH_NTSCOk == FALSE) {
    HidePanel(spghphPNL); 
    return FALSE;
   }
  Delay(0.03);
  WriteCOMPort(DUTCOM,"COMM 21,'GU';");
  Delay(AutoHPHWaitInterval);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GU?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  Fmt(MsgStr,"%s<%i[u]\n",hh);
  SetCtrlVal(spghphPNL, SPGHPH_PNL_MEASDATA,MsgStr);
  hh = hh & 0x00ffffff;
  hph[n] = hh;
 }
 
 // find hph min
 hphmin = 0xffffffff;
 for (n = 0; n < 7; n++) {
  if (hph[n] < hphmin)
   hphmin = hph[n];
 }
 hphmin = hphmin | 0xff000000;   // set 8 MSB bits

 // find hph max
 hphmax = 0x0;
 for (n = 0; n < 7; n++) {
  if (hph[n] > hphmax)
   hphmax = hph[n];
 }
 hphmax = hphmax | 0xff000000;   // set 8 MSB bits
 
 hphdiff = hphmax - hphmin;

 
 // calculate mean
 hphmean = 0;
 for (n = 0; n < 7; n++) 
   hphmean = hphmean + hph[n];
 hphmean = hphmean / 7;
 hphmean = hphmean | 0xff000000;   // set 8 MSB bits

 Fmt(MsgStr,"%s<%i[u]",hphmin);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmax);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,MsgStr);
 Fmt(MsgStr,"%s<%i[u]",hphmean);
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,MsgStr);
 
 if (hphdiff > hphminmaxdiff) {
  Fmt(MsgStr,"%s< Forskel mellem Max og Min er for stor (max forskel: %i)\n Kalibrering stoppet",hphminmaxdiff);
  MessagePopup (" SPG Kalibreringsfejl: Auto HPH for NTSC", MsgStr);
  AutoHPH_NTSCOk = FALSE;
  HidePanel(spghphPNL);
  return FALSE;
 }

 AutoHPH_NTSCOk = TRUE;

 if (AutoHPH_NTSCOk == TRUE) {
  Fmt(DUTStr,"%s<COMM 21,'GY%i[u]';",hphmean);
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.3);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GU?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hh);
  if (hphmean != hh)
   AutoHPH_NTSCOk = FALSE;
 } 
 

  if (AutoHPH_NTSCOk == FALSE) {
   MessagePopup (" SPG: Auto HPH kalibrering for NTSC fejlet","Middelv�rdi ikke gemt korrekt i SPG\n Kalibrering stoppes");
   HidePanel(spghphPNL);
   return FALSE;
  }



 SelectPM3094Setup(2);
 SetCtrlVal (spghphPNL, SPGHPH_PNL_SCOPSETUP, " PM3094: FRONTS = F2");

 
 ResetTextBox(spghphPNL, SPGHPH_PNL_TXTBOX,"\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Linie 11 puls i CH-1 skal v�re i samme field som linie 11 puls i CH-2\n");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_TXTBOX," Field 1/3 kan skiftes med tasten 'Skift field 1/3'\n");
 
 Repeat = TRUE;
 while (Repeat == TRUE){

  button_pressed = GenericMessagePopup ("SPG kalibrering:  Field 1/3 for NTSC",
									    "OK?", "OK", "Afvist", "Skift field 1/3",
									    0, -1, 0,
									    VAL_GENERIC_POPUP_BTN1,
									    VAL_GENERIC_POPUP_BTN2,
									    VAL_GENERIC_POPUP_BTN3);
   switch (button_pressed) {
    case 1: AutoHPH_NTSCOk = TRUE; Repeat = FALSE; break;
    case 2: AutoHPH_NTSCOk = FALSE; Repeat = FALSE; break;
    case 3: WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GK';");	// invert M-frame 
            Delay(0.03);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadg);
            Delay(0.03);
            FlushInQ(DUTCOM);
            WriteCOMPort(DUTCOM,"COMM 21,'GU?';");
            strread = ReadlnCOMPort(DUTCOM,0.5);
            Scan(strread,"%s>%i[u]",&hphreadm);
            Fmt(MsgStr,"%s<GA?=%i[u]  GU?=%i[u]",hphreadg,hphreadm);
				SetCtrlVal (spghphPNL, SPGHPH_PNL_READHPH, MsgStr);
    		break;
   }

 } //while
 
 ResetTextBox(spghphPNL, SPGHPH_PNL_MEASDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MINDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MAXDATA,"");
 SetCtrlVal(spghphPNL, SPGHPH_PNL_MEANDATA,"");


 // if OK store hph-zero values for PAL and NTSC in NVRAM
 if (AutoHPH_NTSCOk == TRUE){
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GA?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hphreadg);
  Delay(0.03);
  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,"COMM 21,'GU?';");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%i[u]",&hphreadm);
  Delay(0.03);

  Fmt(DUTStr,"%s<:FACT:GENL:HPHZ %i[u],%i[u];",hphreadg,hphreadm);	// save hph zero in NVRAM
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.03);
  WriteCOMPort(DUTCOM,":FACT:GENL:PHAS 0,0;");						// save G/M-phases=0 in NVRAM
  Delay(0.03);

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:GENL:HPHZ?;");	// read from NVRAM
  strread = ReadlnCOMPort(DUTCOM,0.5);
  Scan(strread,"%s>%2i[ux]",hph);
  
	if ((hphreadg != hph[0]) || (hphreadm != hph[1])){	// compare read NVRAM-values with saved values
    Fmt(MsgStr,"%s<PAL:    Gemt=%i[u]  L�st=%i[u]\nNTSC: Gemt=%i[u]  L�st=%i[u]",hphreadg,hph[0],hphreadm,hph[1]);
  	 MessagePopup (" Auto HPH kalibreringsfejl",MsgStr);
    AutoHPH_PALOk = AutoHPH_NTSCOk = FALSE;
 	 HidePanel (spghphPNL);
    return FALSE;
	}
	else{

    WriteSPGCalDate();
	 WriteFMSUpdate();
	 
	 kustr =  ReadKUStr();
	 
    dato = GetDate(1);	// get system date YYMMDD
 	 
    tt = TimeStr();		// get system time
	
	// check om logfil findes, ellers opret en ny logfil. LogDest angiver drev+sti til logfil.
	fhandle = OpenFile (SPGLogFile[LogDest], VAL_WRITE_ONLY, VAL_APPEND, VAL_ASCII);
	Fmt(wrtbuf,"%s<%s,%s,%s,%i[u],%i[u]\n",dato,tt,kustr,hphreadg,hphreadm);
	bytes_written = WriteFile (fhandle, wrtbuf, strlen(wrtbuf));
	CloseFile(fhandle);
  
  
	}

 } 



 HidePanel (spghphPNL);
 
return AutoHPH_NTSCOk;
} //MakeSPGHPHCal







//*****************************************************************************
void SetSPGGenlockValue(int genlval){
char SPGGenlStr[11];

 if (TV == PAL)
   Fmt(DUTStr,"%s<COMM 21,'GF%i';",genlval);
  else
   Fmt(DUTStr,"%s<COMM 21,'GG%i';",genlval);

 WriteCOMPort(DUTCOM,DUTStr);
 Delay(0.05);
} //SetSPGGenlockValue







//*****************************************************************************
int MakeREFCal(int Freq){	  // Freq = FREQ27 or FREQ13
/*	Calibrate 27.0MHz VCXO-ref or 13.0MHz TCXO-ref
	The freq is measured as 4.5MHz from BB1-output
	Check voltage at TP30 when calibrating 27MHz X-TAL ref
	Check voltage at TP31 when calibrating 13MHz TCXO ref
*/	

char  TPTxt[30];
ViChar mm[30];
int handle_returned, controlID_returned;
int V74dac, MeasInsideTol, NumberOfMeas, TPVoltOk, Step, dacread;
ViReal64 freqmeas1,freqmeas2;
double diff,tpmeas, tpmax, tpmin, HzPerDacStep;

 if (CheckHP53132ExtRef() == FALSE){
   HidePanel(ocxoPNL);
   F13Ok = FALSE;
   return F13Ok;
   } 
   
   
 if (GPSStatusOk == FALSE){      // see  CheckXLDCRef(void) in cviutil.c
   Fmt(MsgStr,"%s< TrueTime GPS modtager virker ikke korrekt:\n %s",GPSStatusStr);
   MessagePopup (" Fejl ved reference til counter HP53132 ",MsgStr);
   HidePanel(ocxoPNL);
   F27Ok = FALSE;
   F13Ok = FALSE;
   return F13Ok;
 }
   

 // set password = off & check RS-232 forbindelse
 if (WriteProtect(OFF,FALSE) == FALSE){
  HidePanel (ocxoPNL);
  F27Ok = FALSE;
  F13Ok = FALSE;
  return FALSE;
  }
 
 ResetTextBox(ocxoPNL, OCXO_PNL_TXTBOX,"");

 if (Freq == FREQ27){
 	tpmax = TP30max;
 	tpmin = TP30min;
 	Fmt(TPTxt,"%s<TP30:  %f[p1] - %f[p1] Volt",tpmin,tpmax);
   SetPanelAttribute (ocxoPNL, ATTR_TITLE, " 27 MHz VCXO ref kalibrering ");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind kabel fra HP53132 CH-A til BB1\n");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind DMM-probe til TP30\n\n");
 	Fmt(MsgStr," Sp�ndingen i TP30 skal v�re mellem %f[p2] og %f[p2] VDC\n\n",tpmin,tpmax);
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX,MsgStr);
   F27Ok = TRUE;
  } 
 else if (Freq == FREQ13){
 	tpmax = TP31max;
 	tpmin = TP31min;
 	Fmt(TPTxt,"%s<TP31:  %f[p1] - %f[p1] Volt",tpmin,tpmax);
   SetPanelAttribute (ocxoPNL, ATTR_TITLE, " 13 MHz TCXO ref kalibrering ");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind kabel fra HP53132 CH-A til BB1\n");
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forbind DMM-probe til TP31\n\n");
 	Fmt(MsgStr," Sp�ndingen i TP31 skal v�re mellem %f[p2] og %f[p2] VDC\n\n",tpmin,tpmax);
   SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX,MsgStr);
   F13Ok = TRUE;
  } 

 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," HUSK: Apparatet skal have v�ret t�ndt i MINDST 15 minutter\n\n");
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Forts�t:  Tast F4\n");
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," Afbryd:   Tast F9\n\n");

 SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 500.0);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -500.0);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_MAX_VALUE, tpmax + 0.4);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_MIN_VALUE, tpmin - 0.4);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_DEC1, ATTR_VISIBLE, TRUE);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_LABEL_TEXT, TPTxt);
 Fmt(MsgStr,"%s< � %f[p1] Hz",FreqTol);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_LABEL_TEXT, MsgStr);
 SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_RED);


 WriteCOMPort(DUTCOM,":INP:GENL:SYST INT;");
 WriteCOMPort(DUTCOM,":FACT:BB1:SIGN F45MHZ;");	// BB1 outputs 4.5MHz
 

 WaitForContinue();

 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," M�linger ");

#if IEEEBUS
 hp34970a_voltageMeasure (hp34970, "102", HP34970A_VM_VTYPE_DC,
								  HP34970A_VM_VRANGE_10V,
								  HP34970A_VM_RES_5_5DIG, mm);

 hp34970a_voltageSetup (hp34970, "102", HP34970A_VS_VTYPE_DC,
								HP34970A_VS_VRANGE_10V, HP34970A_VS_RES_5_5DIG);
 ReadDCVolt(&tpmeas);


// Channel 1 for counter HP53132 (channel select string: see top of file)
 hp34970a_switch (hp34970, "211", HP34970A_SW_POS_CLOSE,
								 HP34970A_SW_MODE_EXCLUSIVE);

 DevClear (0, 3);
 ErrIEEE = hp5313xa_init ("GPIB::3", VI_OFF, VI_ON, 2, &hp53132);
 Delay(0.1);
 ErrIEEE = hp5313xa_freqPeriodRatio (hp53132, 1, 1, 9, VI_ON, 1);
#endif 


// 1. m�ling af frekvens
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," *");
 V74dac = 1200;
 WriteDacV74(V74dac);
 Delay(1.0);
#if IEEEBUS
 DisableBreakOnLibraryErrors();                                                       
 hp5313xa_writeInstrData (hp53132, ":READ?");
 Delay(1.5);
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," *");
 ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeas1);
 if (ErrIEEE == 0xBFFF0015)  //Timeout
  freqmeas1 = 0.0;
 EnableBreakOnLibraryErrors();
 SetCtrlVal (ocxoPNL, OCXO_PNL_SLIDE, freqmeas1 - FreqNom);
 Fmt(MsgStr,"%s<%f[p1]",freqmeas1);
 SetCtrlVal (ocxoPNL, OCXO_PNL_FREQ, MsgStr);
 ProcessDrawEvents();
#else
 freqmeas1 = 4.5e6 + 63;
 Delay(0.1);
#endif
 
 
// 2. m�ling af frekvens
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," *");
 V74dac = 1500;
 WriteDacV74(V74dac);
 Delay(1.0);
#if IEEEBUS
 DisableBreakOnLibraryErrors();                                                       
 hp5313xa_writeInstrData (hp53132, ":READ?");
 Delay(1.5);
 SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," *");
 ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeas2);
 if (ErrIEEE == 0xBFFF0015)  //Timeout
  freqmeas2 = 0.0;
 EnableBreakOnLibraryErrors();
 SetCtrlVal (ocxoPNL, OCXO_PNL_SLIDE, freqmeas2 - FreqNom);
 Fmt(MsgStr,"%s<%f[p1]",freqmeas2);
 SetCtrlVal (ocxoPNL, OCXO_PNL_FREQ, MsgStr);
 ProcessDrawEvents();
#else
 freqmeas2 = 4.5e6 - 60;
 Delay(0.1);
#endif
 
 HzPerDacStep = (freqmeas1 - freqmeas2) / 300;
 V74dac = 1200 + ((freqmeas1 - FreqNom) / HzPerDacStep);
 WriteDacV74(V74dac);
 
 if (HzPerDacStep < 0.05){
	MessagePopup("TCXO-kalibrering fejlet","Dac V74 reagerer ikke");
	HidePanel(ocxoPNL);
	return F13Ok = FreqCalOk = FALSE;
 }
 

 NumberOfMeas = 0;
 MeasInsideTol = 0;
 FreqCalOk = FALSE;
 done = FALSE;
 Step = 2;
 
 
 while ((done == FALSE) && 
 		  (FreqCalOk == FALSE) && 
 		  (NumberOfMeas <= MaxNumberOfMeas)){

		if (fabs(freqmeas1 - FreqNom) > 1)
		  Step = 3;
		 else
		  Step = 1;

		 if (freqmeas1 > FreqNom)
		 V74dac += Step; 
		  else
		 V74dac -= Step;
		
		
	   WriteDacV74(V74dac);
 
	    // M�ling i TP31
	  #if IEEEBUS
	   DisableBreakOnLibraryErrors();
		ReadDCVolt(&tpmeas);
	   EnableBreakOnLibraryErrors();
	  #else
	   tpmeas = 1.4;
	   Delay(0.1);
	  #endif
	  
	  NumberOfMeas += 1;
	  
	    // M�ling af frekvens
	  #if IEEEBUS
	   DisableBreakOnLibraryErrors();                                                       
	   hp5313xa_writeInstrData (hp53132, ":READ?");
	   Delay(1.5);
	   ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeas1);
		SetCtrlVal(ocxoPNL, OCXO_PNL_TXTBOX," *");
	   if (ErrIEEE == 0xBFFF0015)  //Timeout
	    freqmeas1 = 0.0;
	   EnableBreakOnLibraryErrors();
	  #else
	   freqmeas1 = 4.5e6 + 10;
	   Delay(0.1);
	  #endif


	    // min max slide values
	    diff = fabs(freqmeas1 - FreqNom);
	    if (diff <= 8) {
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 10.0);
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -10.0);
	     }
	     else
	    if (diff <= 80) {
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 100.0);
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -100.0);
	     }
	     else
	    if (diff <= 400) {
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 500.0);
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -500.0);
	     }
	     else {
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MAX_VALUE, 2000.0);
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_MIN_VALUE, -2000.0);
	     }

	    SetCtrlVal (ocxoPNL, OCXO_PNL_SLIDE, freqmeas1 - FreqNom);
	    Fmt(MsgStr,"%s<%f[p1]",freqmeas1);
	    SetCtrlVal (ocxoPNL, OCXO_PNL_FREQ, MsgStr);

	    SetCtrlVal (ocxoPNL, OCXO_PNL_VCOVOLT, tpmeas);

	    ProcessDrawEvents();

	    if (fabs(freqmeas1 - FreqNom) > FreqTol) {
	      MeasInsideTol = 0;
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_FILL_COLOR, VAL_RED);
	  		SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_RED);
	     }
	     else {
	      MeasInsideTol += 1;
	      SetCtrlAttribute (ocxoPNL, OCXO_PNL_SLIDE, ATTR_FILL_COLOR, VAL_GREEN);
	  		SetCtrlAttribute (ocxoPNL, OCXO_PNL_FREQ, ATTR_TEXT_COLOR, VAL_GREEN);
	     }

	    if ((tpmeas < tpmax) && (tpmeas > tpmin)){
	      TPVoltOk = TRUE;
	  		SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_FILL_COLOR, VAL_GREEN);
	     }
	     else {
	      TPVoltOk = FALSE;
	  		SetCtrlAttribute (ocxoPNL, OCXO_PNL_VCOVOLT, ATTR_FILL_COLOR,VAL_RED);
	     }
	     
	     
 		  FreqCalOk = ((MeasInsideTol >= NumberOfOkMeas) && 
 		  					(TPVoltOk == TRUE));
	     
	                                                                                        
	    GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
 } // while
 
 if (done == TRUE){
	MessagePopup("TCXO-kalibrering","Stoppet af bruger");
	FreqCalOk = FALSE;
 }
 
 if (NumberOfMeas > MaxNumberOfMeas){
	Fmt(MsgStr,"%s<Antal m�linger %i  (Max = %i)",NumberOfMeas,MaxNumberOfMeas);
	MessagePopup("TCXO-kalibrering fejlet",MsgStr);
	FreqCalOk = FALSE;
 }
 
 if (FreqCalOk == TRUE){
  GetDate(2);
  // Save in user ref
  Fmt(DUTStr,"%s<:FACT:GENL:UREF:DATE %s,%s,%s;",YearStr,MonthStr,DayStr);
  WriteCOMPort(DUTCOM,DUTStr);
  Fmt(DUTStr,"%s<:FACT:GENL:UREF:DAC %i;",V74dac);
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.03);
  WriteCOMPort(DUTCOM,":FACT:GENL:UREF:DAC?;");

  // Check saved user ref
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 0)
    Scan(strread,"%s>%i",&dacread);
   else
    dacread = 0;
    
   if (dacread != V74dac){
	 Fmt(MsgStr,"%s< User kalibreringsv�rdi ikke gemt korrekt i NVRAM\n Gemt=%i L�st=%i",V74dac,dacread);
	 MessagePopup("TCXO-kalibrering fejlet",MsgStr);
	} 

  // Save in factory ref
  Fmt(DUTStr,"%s<:FACT:GENL:FREF:DATE %s,%s,%s;",YearStr,MonthStr,DayStr);
  WriteCOMPort(DUTCOM,DUTStr);
  Fmt(DUTStr,"%s<:FACT:GENL:FREF:DAC %i;",V74dac);
  WriteCOMPort(DUTCOM,DUTStr);
  Delay(0.03);

  // Check saved factory ref
  WriteCOMPort(DUTCOM,":FACT:GENL:FREF:DAC?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 0)
    Scan(strread,"%s>%i",&dacread);
   else
    dacread = 0;
    
   if (dacread != V74dac){
	 Fmt(MsgStr,"%s< Factory kalibreringsv�rdi ikke gemt korrekt i NVRAM\n Gemt=%i L�st=%i",V74dac,dacread);
	 MessagePopup("TCXO-kalibrering fejlet",MsgStr);
	} 
  


  // Save last update = last calibration date
  Delay(0.03);
  Fmt(DUTStr,"%s<:FACT:MAIN:FMSD:UPD %s,%s,%s;",YearStr,MonthStr,DayStr);
  WriteCOMPort(DUTCOM,DUTStr);
 }
 
 WriteCOMPort(DUTCOM,":FACT:BB1:SIGN NORM;");

 HidePanel(ocxoPNL);


 if (Freq == 27)
   return F27Ok = FreqCalOk;
  else
   return F13Ok = FreqCalOk;
}




					   

//--------------------------------------------------------------------------------
int MakeSPGReset(void){ 
int button_pressed;
int hphz[2],phase[2];
char *strread, msgstr[100], hphzstr[30], phasestr[30];

 if (WriteProtect(OFF,FALSE) == FALSE){
  SPGResetOk = FALSE;
  return FALSE;
  }

 button_pressed = ConfirmPopup ("Reset SPG", "ADVARSEL: Reset bruges normalt kun p� nyproducerede SPG'er\nKalibreringsdata nulstilles");

 if (button_pressed == NO){
  SPGResetOk = SPGNOTRESET;
  return SPGResetOk;
 }

 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GZ';");
 Delay(0.05);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GF0';");	// genlock phase G
 Delay(0.05);
 WriteCOMPort(DUTCOM,":FACT:V24C:COMM 21,'GG0';");	// genlock phase M
 Delay(0.05);
 WriteCOMPort(DUTCOM,":FACT:GENL:HPHZ 196290,196290;");	// hph zero default values
 Delay(0.05);
 WriteCOMPort(DUTCOM,":FACT:GENL:PHAS 0,0;");	// h-genlock phase default values
 Delay(0.05);
 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:GENL:HPHZ?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (StringLength(strread) > 0){
   Fmt(hphzstr,"%s<%s,", strread);
   Scan(hphzstr,"%s>%2i[x]",hphz);
   }
  else {
   hphz[0] = 0; 
   hphz[1] = 0; 
  }

 FlushInQ(DUTCOM);
 WriteCOMPort(DUTCOM,":FACT:GENL:PHAS?;");
 strread = ReadlnCOMPort(DUTCOM,0.5);
 if (StringLength(strread) > 0){
   Fmt(phasestr,"%s<%s,", strread);
   Scan(phasestr,"%s>%2i[x]",phase);
   }
  else {
   phase[0] = 0; 
   phase[1] = 0; 
  }
  
 if (RS232Timeout == TRUE)
   Fmt(msgstr,"%s< Timeout ved l�sning fra SPG");
  else
   Fmt(msgstr,"%s< Data l�st: %s%s\n Forventet: 196290,196290,0,0",hphzstr,phasestr);

 SPGResetOk = FALSE;
 if ((hphz[0] == 196290) && (hphz[1] == 196290) && (phase[0] == 0) && (phase[1] == 0))
  SPGResetOk = TRUE;
  
 if (SPGResetOk == TRUE)
   MessagePopup ("Reset SPG", "Kalibreringsdata er nu nulstillet");
  else
   MessagePopup ("Reset af kalibreringsdata FEJLET",msgstr);


return SPGResetOk;
}


//----------------------------------------------------------------------------------
int WriteSPGCalDate(void){

 GetDate(2);
 Fmt(DUTStr,"%s<:FACT:GENL:DATE %s,%s,%s;",YearStr,MonthStr,DayStr);
 WriteCOMPort(DUTCOM, DUTStr);
 Delay(0.05);

return TRUE;
}


//********************************************************************************
int MeasWithHP53132(void){
ViReal64 freqmeas;
int handle_returned, controlID_returned;

 ResetTextBox(cntPNL, COUNT_PNL_TXTBOX,"");
 SetCtrlVal(cntPNL, COUNT_PNL_TXTBOX," M�ling med counter HP53132\n\n");
 DisplayPanel(cntPNL);


#if IEEEBUS
// Channel 1 for counter HP53132 (channel select string: see top of file)
 hp34970a_switch (hp34970, "211", HP34970A_SW_POS_CLOSE,
								 HP34970A_SW_MODE_EXCLUSIVE);

 DevClear (0, 3);
 ErrIEEE = hp5313xa_init ("GPIB::3", VI_OFF, VI_ON, 2, &hp53132);
 Delay(0.1);
 ErrIEEE = hp5313xa_freqPeriodRatio (hp53132, 1, 1, 9, VI_ON, 1);
#endif 

 done = FALSE;

 while (done == FALSE){
  GetUserEvent(NOWAIT,&handle_returned, &controlID_returned);
  DisableBreakOnLibraryErrors();                                                       
  hp5313xa_writeInstrData (hp53132, ":READ?");
  Delay(1.5);
  ErrIEEE = hp5313xa_mathRes (hp53132, &freqmeas);
  if (ErrIEEE == 0xBFFF0015)  //Timeout
   freqmeas = 0.0;
  EnableBreakOnLibraryErrors();

  Fmt(MsgStr,"%s<%f[p1]",freqmeas);
  SetCtrlVal (cntPNL, COUNT_PNL_FREQ, MsgStr);

 }

 HidePanel(cntPNL);


return TRUE;
}




char dstr[10];
//----------------------------------------------------------------------------------
char *ReadSPGCalDate (void) {
// read SPG kalibrerings dato
int dd[3];

  FlushInQ(DUTCOM);
  WriteCOMPort(DUTCOM,":FACT:GENL:DATE?;");
  strread = ReadlnCOMPort(DUTCOM,0.5);
  if (strlen(strread) > 1){
   Scan(strread,"%s>%3i[x]",dd);
   Fmt(dstr,"%s<%i[w2p0]%i[w2p0]%i[w2p0]",dd[0],dd[1],dd[2]);	//yymmdd
  } 
  else
   Fmt(dstr,"%s<??????");	//yymmdd

 return dstr;
}







/*
//----------------------------------------------------------------------------------
int BasicTotalTest(int TestNo){

	VoltOk = FALSE;
	FanOk = FALSE;
	OvenOk = FALSE;
	F135Ok = FALSE;
	GenlInputOk = FALSE;
	GenlSystemOk = FALSE;
	SPGCalOk = FALSE;
	BBCalOk = FALSE;
	SPGResetOk = FALSE;
	
	
	if (TestNo == TOTMENU_BASIC_RESETSPG)
	 MakeSPGReset();

	if ((TestNo == TOTMENU_BASIC_PS) || (SPGResetOk == TRUE) || (SPGResetOk == SPGNOTRESET))
	 CalPowerSupply();

	if ((TestNo == TOTMENU_BASIC_FAN) || (VoltOk == TRUE))
	 CheckFan();

	if ((TestNo == TOTMENU_BASIC_OVEN) || (FanOk == TRUE))
	 CheckOven();

	if ((TestNo == TOTMENU_BASIC_F27) || (OvenOk == TRUE))
	 MakeOCXOCal(27);

	if ((TestNo == TOTMENU_BASIC_GENL) || (F135Ok == TRUE)){
	 if (MakeSPGGenlockInput() == TRUE)
	  MakeSPGGenlockSystem();
	} 

	if ((TestNo == TOTMENU_BASIC_SPG) || ( (GenlInputOk == TRUE) && (GenlSystemOk == TRUE) )){
	 if (MakeSPGHPHCal() == TRUE)
	  if (MakeSPGGenlockCal(PAL) == TRUE)
	   MakeSPGGenlockCal(NTSC);
	}   

	if ((TestNo == TOTMENU_BASIC_BB1) || (SPGCalOk == TRUE)){
	 if (MakeSyncOffsetCal(1,SYNC_CAL,0) == TRUE)
	  if (MakeSyncOffsetCal(1,OFFSET_CAL,0) == TRUE)
	   if (MakePhaseCal(1,PAL) == TRUE)
	    MakePhaseCal(1,NTSC);
	}    

	if ((TestNo == TOTMENU_BASIC_BB2) || (BBCalOk == TRUE)){
	 if (MakeSyncOffsetCal(2,SYNC_CAL,0) == TRUE)
	  if (MakeSyncOffsetCal(2,OFFSET_CAL,0) == TRUE)
	   if (MakePhaseCal(2,PAL) == TRUE)
	    MakePhaseCal(2,NTSC);
	}
	
return TRUE;
}

*/


//----------------------------------------------------------------------------------
int CVICALLBACK OkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	Cont = TRUE; break;
	}	
		
return 0;
}



int CVICALLBACK SPGOkCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	SPGdone = TRUE;
							if (TV == PAL)
							  SPGGenlPhasePALOk = TRUE;
							 else
 							  SPGGenlPhaseNTSCOk = TRUE;
 							break;
	}
	return 0;
}



int CVICALLBACK ExitSPGCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:	Cont = TRUE; 
							AutoHPH_PALOk = FALSE; 
							AutoHPH_NTSCOk = FALSE; 
 							GenlBOk = FALSE;
 							GenlA_BOk = FALSE;
 							GenlPALOk = FALSE;
 							GenlNTSCOk = FALSE;
 							Genl10MHzOk = FALSE;
							SPGdone = TRUE;
							if (TV == PAL)
							  SPGGenlPhasePALOk = FALSE;
							 else
							  SPGGenlPhaseNTSCOk = FALSE;
							break;
		
		
	}
	return 0;
}



int CVICALLBACK SPGPilopCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SPGGenlValue = SPGGenlValue + 2;
			SetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}

int CVICALLBACK SPGPilnedCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SPGGenlValue = SPGGenlValue - 2;
			SetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}

int CVICALLBACK SPGSlideCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2) {
	switch (event) {
		case EVENT_VAL_CHANGED:
			GetCtrlVal(spgphasePNL,SPGPHA_PNL_SLIDE,&SPGGenlValue);
			SetSPGGenlockValue(SPGGenlValue + SPGGenlOffsetValue);
			break;
	}
	return 0;
}


//-----------  Call back ved afslutning af valg af genlock signaler -----------
int CVICALLBACK ReturnSelGenlCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			 HidePanel(selgenlPNL);
			break;
	}
	return 0;
}

//-----------  Call back ved valg af genlock signaler ----(se spggenl.uir)-----------
int CVICALLBACK GenlSignalCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
int stsel,stattn;
	switch (event) {
		case EVENT_VAL_CHANGED:
			GetCtrlVal (selgenlPNL, SELGEN_PNL_GENLRING, &stsel);
			GetCtrlVal (selgenlPNL, SELGEN_PNL_GENLATTN, &stattn);
			if ((stsel >= 0) && (stsel <=2))
			  SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);
			 else
			  SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE);
			 switch (stsel){
			  case 0: SetGenlockSignal(GENL_OFF);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 1: SetGenlockSignal(GENL_PAL); 
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 2: SetGenlockSignal(GENL_NTSC);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, TRUE);break;
			  case 3: if (stattn == TRUE)
			            SetGenlockSignal(GENL_443_LOW);
			           else
			            SetGenlockSignal(GENL_443_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			  case 4: if (stattn == TRUE)
			            SetGenlockSignal(GENL_358_LOW);
			           else
			            SetGenlockSignal(GENL_358_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			  case 5: if (stattn == TRUE)
			            SetGenlockSignal(GENL_10M_LOW);
			           else
			            SetGenlockSignal(GENL_10M_HIGH);
			          SetCtrlAttribute (selgenlPNL, SELGEN_PNL_GENLATTN, ATTR_DIMMED, FALSE); break; 
			 } // switch
			break;  // switch
	}
	return 0;
}

int CVICALLBACK RefOscCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if (control == OCXO_PNL_REFOSCOK_BTN){
			 Cont = TRUE; done = TRUE; F27Ok = TRUE; F13Ok = TRUE;
			 }
			 else if (control == OCXO_PNL_REFOSCERR_BTN){
			 Cont = TRUE; done = TRUE; F27Ok = FALSE; F13Ok = FALSE; FreqCalOk = FALSE;
			 }

			break;
	}
	return 0;
}

int CVICALLBACK F45MHzCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if (control == COUNT_PNL_F45MHZ_BTN)
		    WriteCOMPort(DUTCOM,":FACT:BB1:SIGN F45MHZ;");

			if (control ==	COUNT_PNL_F45EXIT_BTN)
			 done = TRUE;
			break;
	}
	return 0;
}

