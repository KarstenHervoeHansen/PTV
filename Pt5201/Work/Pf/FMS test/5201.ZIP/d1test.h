
extern int d1JitterPNL;

extern int MakeD1JitterTest(int D1No);
extern int MakeD1AMPSTest(int D1No);
extern int MakeD1RLossTest(int D1No);


