	
extern int TV;	

extern int MakeSPGGenlockCal(int TVSys);
extern int MakeSPGGenlockSystem(void);
extern int MakeSPGGenlockInput(void);
extern int MakeSPGHPHCal(void);
extern int MakeREFCal(int Freq);
extern int MakeSPGReset(void);
extern int MeasWithHP53132(void);


extern char *ReadSPGSWVer (void);
extern char *ReadSPGCalDate (void);

extern int BasicTotalTest(int Sel);
