#include "hp34970a.h"
/*
Main file for PT5201 testprogram
File: pt5201.c

Oprettet: 000224 Peter Frederiksen, PTV

Rettelser:


*/

#define TESTSWVER  "Ver. 000629        7108 100 74801"


#include "hp34401a.h"
#include "hp5313xa.h"
#include <ansi_c.h>
#include <gpib.h>
#include <rs232.h>
#include <formatio.h>
#include <utility.h>
#include <cvirte.h>		/* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>

// header files for uir files
#include "pt5201.h"
#include "bb_sync.h"
#include "phase.h"
#include "sdi.h"
#include "vlm.h"
#include "cfg.h"
#include "spghph.h"
#include "spggenl.h"
#include "spgphase.h"
#include "aes.h"
#include "refosc.h"
#include "vcc.h"



// general utilities
#include "cviutil.h"
#include "def.h"		// define statements

// calibration utilities
#include "vlmutil.h"
#include "bbcal.h"
#include "spgcal.h"
#include "sditest.h"
#include "aescal.h"
#include "config.h"
#include "clktest.h"





int main (int argc, char *argv[])
{
int ConfirmReply;
int sm,sg;
char ff[MAX_FILENAME_LEN];
int button_pressed;




if (argc > 1){
 if ((strcmp(argv[1],"5201") == 0) || (strcmp(argv[1],"PT5201") == 0))
   AppType = PT5201;
  else
   AppType = PT5201;
} //if 


#if IEEEBUS
   IEEEboard = ibfind ("gpib0");
	devicePM5640G = ibdev (0, PM5640GIEEEADDR, NO_SAD, T3s, 1, 0);
	sg = iberr;
	devicePM5640M = ibdev (0, PM5640MIEEEADDR, NO_SAD, T3s, 1, 0);
	sm = iberr;
#endif
	

	if (InitCVIRTE (0, argv, 0) == 0)	/* Needed if linking in external compiler; harmless otherwise */
		return -1;	/* out of memory */
	if ((mainPNL = LoadPanel (0, "pt5201.uir", MAIN_PNL)) < 0)
	 	 return -1;
	if ((syncPNL = LoadPanel (mainPNL, "bb_sync.uir", SYNC_PNL)) < 0)
		return -1;
	if ((vlmPNL = LoadPanel (mainPNL, "vlm.uir", VLM_PNL)) < 0)
		return -1;
	if ((spghphPNL = LoadPanel (mainPNL, "spghph.uir", SPGHPH_PNL)) < 0)
		return -1;
	if ((spggenlPNL = LoadPanel (mainPNL, "spggenl.uir", SPGGEN_PNL)) < 0)
		return -1;
	if ((selgenlPNL = LoadPanel (0, "spggenl.uir", SELGEN_PNL)) < 0)
		return -1;
	if ((phasePNL = LoadPanel (mainPNL, "phase.uir", PHASEPNL)) < 0)
		return -1;
	if ((spgphasePNL = LoadPanel (mainPNL, "spgphase.uir", SPGPHA_PNL)) < 0)
		return -1;
	if ((aesPNL = LoadPanel (mainPNL, "aes.uir", AES_PNL)) < 0)
		return -1;
	if ((anPNL = LoadPanel (mainPNL, "aes.uir", ANALOG_PNL)) < 0)
		return -1;
	if ((anmeasPNL = LoadPanel (mainPNL, "aes.uir", ANMEAS_PNL)) < 0)
		return -1;
	if ((amspPNL = LoadPanel (mainPNL, "sdi.uir", AMSP_PNL)) < 0)
		return -1;
	if ((jitPNL = LoadPanel (mainPNL, "sdi.uir", JIT_PNL)) < 0)
		return -1;
	if ((rlossPNL = LoadPanel (mainPNL, "sdi.uir", RLOSS_PNL)) < 0)
		return -1;
	if ((sdigenlPNL = LoadPanel (mainPNL, "sdi.uir", SDIGEN_PNL)) < 0)
		return -1;
	if ((sdiPNL = LoadPanel (mainPNL, "sdi.uir", SDI_PNL)) < 0)
		return -1;
	if ((pattPNL = LoadPanel (mainPNL, "sdi.uir", PATT_PNL)) < 0)
		return -1;
	if ((configPNL = LoadPanel (mainPNL, "cfg.uir", CONFIG)) < 0)  // config panel
		return -1;
	if ((instrPNL = LoadPanel (mainPNL, "cfg.uir", INSTR_PNL)) < 0)
		return -1;
	if ((vccPNL = LoadPanel (mainPNL, "vcc.uir", VCC_PNL)) < 0)
		return -1;
	if ((ocxoPNL = LoadPanel (mainPNL, "refosc.uir", OCXO_PNL)) < 0)
		return -1;
	if ((cntPNL = LoadPanel (mainPNL, "refosc.uir", COUNT_PNL)) < 0)
		return -1;
		
 mainmenuhandle = LoadMenuBar (mainPNL, "pt5201.uir", MAINMENU);
 
 SetCtrlAttribute (phasePNL, PHASEPNL_COMM, ATTR_VISIBLE, TRUE);    // =TRUE ved debug phase kalibrering
																   // BB & Analog TPG

 SetCtrlVal (mainPNL, MAIN_PNL_SWVER, TESTSWVER);				   // Test SW rev
 SetCtrlVal (mainPNL, MAIN_PNL_NAME1, "PT5201");
 SetCtrlVal (mainPNL, MAIN_PNL_NAME2, "Compact VariTime Sync Generator");
 
 // GPS receiver
 SetCtrlAttribute (mainPNL, MAIN_PNL_GPS_TIMER, ATTR_INTERVAL, 50.0); // Timer interval
 GPSCheckNo = 0;
 CheckXLDCRef();


 // Init PC DIO24 interface ----------------------
 outp(IOAddr+3,0x80);	   //set mode 
 outp(IOAddr+0,0xFF);	   //port A 
 outp(IOAddr+1,0xFF);	   //port B 
 outp(IOAddr+2,0xFF);	   //port C 
 
 // Init Video Level Meter ----------------------------
 vlm_StartLine = 100;
 vlm_NoOfLines = 100;
 vlm_StartPos = 31.0;
 vlm_Delay = 2.0;
 
 // Remote Control PM5662G/M   (PC DIO24 PortB) ------
 PCDIOPortBStatus = 0xFF;
 

 Err232 = OpenComConfig (DUTCOM, COMname[DUTCOM-1], 9600, 0, 8, 2, 500, 500);

#if AT232
 if (OpenComConfig (VCACOM, COMname[VCACOM-1], 19200, 0, 8, 2, 5000, 500) != 0){
	MessagePopup (" Kan ikke �bne COM5 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }

 if (OpenComConfig (PT5210COM, COMname[PT5210COM-1], 9600, 0, 8, 2, 500, 500) != 0){
	MessagePopup (" Kan ikke �bne COM6 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }
 
 if (OpenComConfig (PM3094COM, COMname[PM3094COM-1], 9600, 0, 8, 2, 500, 500) != 0){
	MessagePopup (" Kan ikke �bne COM7 port", " Afslut program - sluk/t�nd PC - start igen");
	return FALSE;
 }
#endif

 
 DisplayPanel (mainPNL);

 if (ReadVLMGain() == FALSE)		// file = VLMGAIN.DAT
  return FALSE;

 if (ReadTestSetup() == FALSE)		// file = TSTSETUP.DAT
  return FALSE;

 

 if (GPSStatusOk == FALSE)
  MessagePopup(" TrueTime GPS modtager fejler"," HP53132 m� IKKE anvendes til reference kalibrering !!\n Kontakt evt instrument service");
 
 
 //Check if connected to LAN
  LogDest = LANLOG;
  if (GetFirstFile ("M:\\MEASDATA", 1, 0, 0, 0, 0, 1, ff) != 0){
	button_pressed = GenericMessagePopup (" Ingen forbindelse til LAN  (M-drev)",
										  " Genstart Windows og husk at logge p� LAN med navn = 'PROD_5210'",
										  "Afbryd og genstart Windows","Log til lokal harddisk","", 0, -1, 0,
										  VAL_GENERIC_POPUP_BTN1,
										  VAL_GENERIC_POPUP_BTN1,
										  VAL_GENERIC_POPUP_BTN2);

   if (button_pressed == 1)
    return FALSE;
   if (button_pressed == 2){
    LogDest = LOCALLOG;
    MessagePopup(" Kalibreringsdata"," Kalibreringsdata logges til C-drev\n Husk at overf�re data til logfil i 'M:\\MEASDATA\\.....' n�r LAN igen er ok");
   } 
  } 


 

 // Check IEEE connection to HP34970 Switch Unit/DMM and HP53132 Counter
 DisableBreakOnLibraryErrors();
 DevClear (0, 22);
 Delay(0.2);

#if IEEEBUS
 DevClear (0, 3);
 Delay(0.2);
 ErrIEEE = hp5313xa_init ("GPIB::3", VI_OFF, VI_ON, 2, &hp53132);
 
	if (ErrIEEE) {
	 MessagePopup (" IEEE fejl  (adresse 3)", "Ingen kontakt med counter HP53132\n\nCheck: IEEE-kabel\n            at instrumentet er t�ndt");
	 return FALSE;
	}

 CheckHP53132ExtRef();
#endif



#if IEEEBUS
 DisableBreakOnLibraryErrors();
 ErrIEEE = hp34970a_init ("GPIB::9", VI_OFF, VI_ON, &hp34970);
 if (ErrIEEE) {
	 MessagePopup (" IEEE fejl  (adresse 9)", "Ingen kontakt med Data Acquisition HP34970\n\nCheck: IEEE-kabel\n            at instrumentet er t�ndt");
  return FALSE;
	}
 EnableBreakOnLibraryErrors();
#endif 


 SetGenlockSignal(GENL_OFF);

	
 RunUserInterface ();
 return 0;
}



// Select Black Burst 1-3 calibration & test
void CVICALLBACK BBCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem) {
	 case MAINMENU_BB_BB1_TOTAL: BBNo = 1; break;	// BBNo is global
	 case MAINMENU_BB_BB2_TOTAL: BBNo = 2; break;
	 case MAINMENU_BB_BB3_TOTAL: BBNo = 3; break;
	}

//	MakePhaseCal(PAL);

	 if (MakeSyncOffsetCal(SYNC_CAL) == TRUE)	   // 1,2,3 BB
	  if (MakeSyncOffsetCal(OFFSET_CAL) == TRUE)
	   if (MakePhaseCal(PAL) == TRUE)
	        MakePhaseCal(NTSC);		
}




void CVICALLBACK SDITestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
int menuSel;													  
	switch (menuItem) {
		case MAINMENU_SDI_JITAMSP: if (SDIJitterTest() == TRUE)
												SDIAmplSpecTest();break;
										  
		case MAINMENU_SDI_RLOSS:  SDIReturnLossTest(); break;

		case MAINMENU_SDI_EMBAUDIO  : CheckSDIEmbAudio_EDH(); break;
		
	}
}



void CVICALLBACK AnalogTPGCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem){
	  case MAINMENU_COLORBAR_LEVEL:								  // Color Bar Generator
	  		 BBNo = 4;	
       	 MakeSyncOffsetCal(SYNC_CAL);
	       break;

	  case MAINMENU_COLORBAR_PHASE:
		 	 if (MakeTPGPhaseCal(PAL) == TRUE)
	      	 MakeTPGPhaseCal(NTSC);
	       break;

	  case MAINMENU_COLORBAR_PATTERN:
	  		 CheckTPGPattern();
	       break;

	 }   	
}



// menu on mainPNL
void CVICALLBACK SPGTestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem) {
		case MAINMENU_SPG_HPHGENL:		(MakeSPGHPHCal() == TRUE); break;
		case MAINMENU_SPG_TESTGENLOCK: 	if (MakeSPGGenlockInput() == TRUE)
										 MakeSPGGenlockSystem(); break;
//		case MAINMENU_SPG_INT27REF: 	MakeREFCal(27); break;	   // 27.0 MHz X-TAL ikke klar
		case MAINMENU_SPG_INT13REF: 	MakeREFCal(13); break;		// 13.0 MHz TCXO
		case MAINMENU_SPG_RESETSPG: 	MakeSPGReset(); break;
	}	
}


// menu on mainPNL
void CVICALLBACK AudioTestCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem) {
		case MAINMENU_AUDIO_AES: TestAESAudioGen();  break;
		case MAINMENU_AUDIO_WCLK:  TestWordClockOutput();  break;
		case MAINMENU_AUDIO_ANCAL: if ((CalAnalogAudioLevel(LEFTCHANNEL)) == TRUE)
												 CalAnalogAudioLevel(RIGHTCHANNEL); break;
		case MAINMENU_AUDIO_ANLEVMEAS : AnalogAudioLevelCheck(); break;
		case MAINMENU_AUDIO_ANFREQMEAS : AnalogAudioFreqCheck(); break;

		
	}
}


// menu on mainPNL
void CVICALLBACK DiverseCallBack (int menuBar, int menuItem, void *callbackData,
	int panel) {
		
	switch (menuItem){
		case MAINMENU_DIVERSE_VLM : RunVLMMeasurement();break;
		case MAINMENU_DIVERSE_AUDIOLEVEL : MeasAnalogAudioLevel();break;
		case MAINMENU_DIVERSE_CALDATA : ReadCalData(); break;     	// see config.c
		case MAINMENU_DIVERSE_CALFILES : ShowCalFiles(); break;
		case MAINMENU_DIVERSE_SETUP5211 : SetupPT5211(); break;   	// see sditest.c
		case MAINMENU_DIVERSE_POWERCHECK33 : CheckPowerSupply(33); break;		// se bbcal.c
		case MAINMENU_DIVERSE_POWERCHECK50 : CheckPowerSupply(50); break;		// se bbcal.c
		case MAINMENU_DIVERSE_POWERCHECK50M : CheckPowerSupply(-50); break;	// se bbcal.c
		case MAINMENU_DIVERSE_WPON: WriteProtect(ON,TRUE); break;
		case MAINMENU_DIVERSE_WPOFF: WriteProtect(OFF,TRUE); break;
		case MAINMENU_DIVERSE_HP53132: MeasWithHP53132(); break;
		case MAINMENU_DIVERSE_INSTR: ShowInstrumentSetup(); break;	  //see cviutil.c
		case MAINMENU_DIVERSE_SELGENLSIGNAL: DisplayPanel(selgenlPNL); break; // see spgcal.c + spggenl.uir
		case MAINMENU_DIVERSE_SYS5201: SetStartupSystem5201();	break; // see bbcal.c
		case MAINMENU_DIVERSE_EXITPROGRAM:  
											CloseCom(DUTCOM);
											#if AT232
											CloseCom(VCACOM);
											CloseCom(PM3094COM);
											CloseCom(PT5210COM);
											#endif	
											#if IEEEBUS
											hp5313xa_close (hp53132);
											#endif	
											QuitUserInterface (0);
											break;
	}
}


/*
// menu on totPNL
void CVICALLBACK TotCallBack (int menuBar, int menuItem, void *callbackData,
	int panel) {
	Cont = TRUE;
	switch (menuItem){
		 case TOTMENU_BASIC_RESETSPG:
		 case TOTMENU_BASIC_PS:
		 case TOTMENU_BASIC_FAN:
		 case TOTMENU_BASIC_OVEN:
		 case TOTMENU_BASIC_F27:
		 case TOTMENU_BASIC_GENL:
		 case TOTMENU_BASIC_SPG:
		 case TOTMENU_BASIC_BB1:
		 case TOTMENU_BASIC_BB2:
		 						BasicTotalTest(menuItem); break;   // se spgcal.c
		 						
		 
		 case TOTMENU_ANL_TPG2_8601_NCO:     AnalogTPGTotalTest(ANLTPG2_8601,1); break;  // se bbcal.c
		 case TOTMENU_ANL_TPG2_8601_LEVEL:   AnalogTPGTotalTest(ANLTPG2_8601,2); break;
		 case TOTMENU_ANL_TPG2_8601_FILTER:  AnalogTPGTotalTest(ANLTPG2_8601,3); break;
		 case TOTMENU_ANL_TPG2_8601_PHASE:   AnalogTPGTotalTest(ANLTPG2_8601,4); break;
		 case TOTMENU_ANL_TPG2_8601_PATTERN: AnalogTPGTotalTest(ANLTPG2_8601,5); break;

		 case TOTMENU_SDI_TSG2_TIMING:      SDITotalTest(SDITSG2,1); break;      //  PT8639
		 case TOTMENU_SDI_TSG2_JITAMSP:     SDITotalTest(SDITSG2,2); break;
		 case TOTMENU_SDI_TSG2_RLOSS:       SDITotalTest(SDITSG2,3); break;
		 case TOTMENU_SDI_TSG2_EMBAUDEDH:   SDITotalTest(SDITSG2,4); break;
		 case TOTMENU_SDI_TSG2_PATT:        SDITotalTest(SDITSG2,5); break;


		 case TOTMENU_AES_AES1:             PT8635TotalTest(1); break;		   // se aescal.c
		 case TOTMENU_AES_AES2:             PT8635TotalTest(2); break;
		 case TOTMENU_AES_WC1:              PT8635TotalTest(3); break;
		 case TOTMENU_AES_WC2:              PT8635TotalTest(4); break;
		 case TOTMENU_AES_PT5210MODE:       PT8635TotalTest(5); break;

	} 
		
}




void CVICALLBACK AnalogTPGCallBack (int menuBar, int menuItem, void *callbackData,
		int panel) {
	switch (menuItem){
	  case MAINMENU_ANL_TPG2_8601_LEVEL:								  // 8601
       		if (MakeSyncOffsetCal(ANLTPG2_8601,SYNC_CAL,FALSE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG2_8601,OFFSET_CAL,FALSE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_LEVEL:								  // 8631
       		if (MakeSyncOffsetCal(ANLTPG2_8631,SYNC_CAL,TRUE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG2_8631,OFFSET_CAL,FALSE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_LEVEL:								  // 8631
       		if (MakeSyncOffsetCal(ANLTPG5_8631,SYNC_CAL,TRUE) == TRUE)
			 MakeSyncOffsetCal(ANLTPG5_8631,OFFSET_CAL,FALSE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG2_8601,PAL,FALSE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG2_8601,NTSC,FALSE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG2_8631,PAL,TRUE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG2_8631,NTSC,FALSE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_PHASE:
		 	if (MakeANLTPGPhaseCal(ANLTPG5_8631,PAL,TRUE) == TRUE)
	      	 MakeANLTPGPhaseCal(ANLTPG5_8631,NTSC,FALSE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_PATTERN:
	  		CheckANLTPGPattern(ANLTPG2_8601,TRUE);
	       break;
	  case MAINMENU_ANL_TPG2_8631_PATTERN:
	  		CheckANLTPGPattern(ANLTPG2_8631,TRUE);
	       break;
	  case MAINMENU_ANL_TPG5_8631_PATTERN:
	  		CheckANLTPGPattern(ANLTPG5_8631,TRUE);
	       break;

	  case MAINMENU_ANL_TPG2_8601_NCO:
	  		JusterNCO(ANLTPG2_8601);
	       break;
	  case MAINMENU_ANL_TPG2_8631_NCO:
	  		JusterNCO(ANLTPG2_8631);
	       break;
	  case MAINMENU_ANL_TPG5_8631_NCO:
	  		JusterNCO(ANLTPG5_8631);
	       break;

	  case MAINMENU_ANL_TPG2_8601_FILTER:
	  		JusterFilter(ANLTPG2_8601);
	       break;
	  case MAINMENU_ANL_TPG2_8631_FILTER:
	  		JusterFilter(ANLTPG2_8631);
	       break;
	  case MAINMENU_ANL_TPG5_8631_FILTER:
	  		JusterFilter(ANLTPG5_8631);
	       break;
	       
	  case MAINMENU_ANL_RESET_TPG2:	ResetANL(ANLTPG2_8601); break;		// PT8601   se sditest.c
	 }   	
}

*/

// ---------- Ctrl-X on mainPNL ----------------------------------------------------
int CVICALLBACK ExitBtn (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2){ 

	switch (event) {
		case EVENT_COMMIT:
			CloseCom(DUTCOM);
#if AT232
			CloseCom(VCACOM);
			CloseCom(PM3094COM);
			CloseCom(PT5210COM);
#endif	
#if IEEEBUS
			hp5313xa_close (hp53132);
#endif	
#if HP34970
			hp34970a_close (hp34970);
#endif

			QuitUserInterface (0);
			break;
	}
	return 0;
}






// --------- F11 og F12 on mainPNL ----------------------------------------------------
int CVICALLBACK MenuSelectCallBack (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			 switch (control){
              case MAIN_PNL_MAINSELBTN:  EmptyMenuBar (totalmenuhandle);
 									     mainmenuhandle = LoadMenuBar (mainPNL, "pt5201.uir", MAINMENU);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_MAINSELBTN, ATTR_DIMMED, TRUE);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_TOTALSELBTN, ATTR_DIMMED, FALSE);
 									     
             				break;
/*              case MAIN_PNL_TOTALSELBTN: EmptyMenuBar (mainmenuhandle);
 									     totalmenuhandle = LoadMenuBar (mainPNL, "pt5201.uir", TOTMENU);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_MAINSELBTN, ATTR_DIMMED, FALSE);
 										 SetCtrlAttribute (mainPNL, MAIN_PNL_TOTALSELBTN, ATTR_DIMMED, TRUE);
             				break;*/
			 }
			break;
	}
	return 0;
}
