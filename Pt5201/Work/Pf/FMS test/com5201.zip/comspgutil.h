#define TRUE 1
#define FALSE 0

extern int RS232Timeout; 
extern int COMbytes_read;


extern char *ReadlnCOMPort(int PortNo, double Timeout);
extern void WriteCOMPort(int PortNo, char TransmitStr[]);

