/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2000. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_F5_TEXT                   2
#define  PANEL_F5_BTN                    3       /* callback function: FKeyCallback */
#define  PANEL_F6_TEXT                   4
#define  PANEL_F6_BTN                    5       /* callback function: FKeyCallback */
#define  PANEL_F8_TEXT                   6
#define  PANEL_F8_BTN                    7       /* callback function: FKeyCallback */
#define  PANEL_F7_TEXT                   8
#define  PANEL_F7_BTN                    9       /* callback function: FKeyCallback */
#define  PANEL_F1_TEXT                   10
#define  PANEL_F1_BTN                    11      /* callback function: FKeyCallback */
#define  PANEL_F2_TEXT                   12
#define  PANEL_F2_BTN                    13      /* callback function: FKeyCallback */
#define  PANEL_F4_TEXT                   14
#define  PANEL_F4_BTN                    15      /* callback function: FKeyCallback */
#define  PANEL_F3_TEXT                   16
#define  PANEL_F3_BTN                    17      /* callback function: FKeyCallback */
#define  PANEL_SENDSTR                   18
#define  PANEL_RCVSTR                    19
#define  PANEL_EXIT_BTN                  20      /* callback function: ExitCallback */
#define  PANEL_COMTEXT                   21
#define  PANEL_OPENCOM                   22      /* callback function: ComCallback */
#define  PANEL_CLOSECOM                  23      /* callback function: ComCallback */
#define  PANEL_COMLED                    24
#define  PANEL_COMDEC                    25


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK ComCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ExitCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FKeyCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
