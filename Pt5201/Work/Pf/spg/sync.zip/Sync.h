/*
********************************************************************
* Project	: PT5210  SYNC
* Filename	: SYNC.H
* Version	: 1.2	961030
* Purpose	: Variables definitions
* Org.date	: 960506
* Author	: PRC
Special:   This file should be included after the file 'equ.h'.
********************************************************************
HISTORY:

970120 Changed name from vars.c.
970114 RELEASED 1.1
*/



// BUFFER
near UC combuf[8];	//buffer for commands from master uP


// BYTE VARIABLES IN BIT AREA
// UC saves;
volatile UC doflags @ 0x20;
volatile UC outs @ 0x21;
volatile UC modebits @ 0x23;

// OTHER BITS
bit alian;	//
bit bulocken;	//
bit cntenab;	// line counter enable
bit epapu;	// white bar is on active linie
bit level;  	// level shift bit (='1' if sync level > min limit)
bit lockdet;	//
bit minus;	// flag for negative medium result
bit window;	// flag for field pulse in window

// BYTE/INT VARIABLES
NUC atel;	// taeller rundt til 5 paa line  		| disse 3 signaler
NUC black;	// gennemsnits sort vaerdi
NUC blackav;	// black value average
NUC btel;	// taeller rundt til 125 paa carry fra a	| udgoer tilsammen en
NUC buam;
NUC buamav;	//
NUI buph;
NUC cvartel;	// taeller varighed til outdata loades fra tabel
NUC dpoint;	// data pointer in table
volatile NUI eph;	// external burst phase
NUC errpre;	// error preset variable
NUC ftel;	// taeller rundt til 4 paa carry fra b	| 8 field linie taeller
NUC genmode;	// genlock mode
NUI genphase_g;	// wanted genlock fase, updated from frontplate
NUI genphase_m;	// wanted genlock fase M
NUI genphase_d6; // wanted genlock fase D1/625
NUI genphase_d5; // wanted genlock fase D1/525
NUC godgren;	// indicates which branch in SCH was last used
NUI hpos;	// position of extern line
NUI htel;	// H-counter
NUI i;	 	// local variable
NUI j;	 	// local variable
NUC levelcnt;	// counter for good/bad fields
NUC linadd;	// correction value for LINTYP output
NUC lintyp;	// last read line type
volatile NUI oldph;	// old ext. burst phase
volatile NUI diffph;	// actual phase difference between 2 samples (see 'burstlock')
NUC oldread;	// last legal kommun. port read value
NUI outf;	// output freq.
NUI outf_todac;	// outf to dac V74
NUC palav;	//
NUC papua;	// pal pulse ampl.
NUC papulock;	// taeller til at finde ud af om der er 8 fields puls
NUI phdet;	// phasedet. var. for use in freq.lock
NUI phdet_todac;	// phdet send to dac V74
NUC phgod;	// filter counter for line7
NUI internrefV74;	// ref for dac V74 when PT5201 is in internal mode
NUC savacc;	// store for accu
NUC schgod;	// filter counter for SCH routine
NUC schph;	// sch fase paa input signal
NUC sersave;	// storage for V24 received byte
NUC speeddel; 	// counter for button speeder delay
NUC speedval; 	// button speeder rate
NUC sphgod;	// filter counter for line7
NUI subcpot;	// wanted subc genlock phase, derived from genphase
NUI subcref;	// subc phase in aktual line
NUC sync;	// gennemsnits sync vaerdi
NUC trig;	// trigger niveau for 50 % sync		
NUC verr;	// taeller der taeller ned paa gode fields
NUI x;		// immediate result from burstfase
NUI y;		// immediate result from burstfase
NUI z;		// immediate result from burstfase

NUC lockcnt;		// lock counter for freq lock check
NUC phdet_ok;
volatile NUC ss1,ss2,ss3,ss4,ss5;

// BITS IN BYTE: DOFLAGS(@20)
volatile bit	doline7		@ 0x101;
volatile bit	dosch			@ 0x102;
volatile bit	dolock		@ 0x103;
volatile bit	domode		@ 0x104;
volatile bit	docomm		@ 0x105;
volatile bit	nsf			@ 0x106;

// BITS IN BYTE outs (@21): 
volatile bit	syncav		@ 0x108;
volatile bit	lockbit		@ 0x109;
volatile bit	spgint		@ 0x10a;
volatile bit	buav			@ 0x10b;
volatile bit	pal			@ 0x10c;
volatile bit	slowlock		@ 0x10d;
volatile bit	tcxomounted	@ 0x10e;
volatile bit	freqlock		@ 0x10f;		// 10MHz locked

// BITS IN BYTE savesb(@22): 
volatile bit genlocken @ 0x110;
volatile bit pplocken  @ 0x111;

// BITS IN BYTE MODEBITS (@23): 
volatile bit	g_sel			@ 0x118;
volatile bit	int10_sel	@ 0x119;
volatile bit	freq_sel		@ 0x11a;
volatile bit	a10m_sel		@ 0x11b;
volatile bit	d1_sel		@ 0x11c;
volatile bit	intern_sel	@ 0x11d;
volatile bit	bulock_sel	@ 0x11e;

// Input port addresses ************************************************
volatile UI * dualptr1;
volatile UI * dualptr2;
UI dualport[2048] @ 0x08000;	// word addr=4000h  	dualport ram V85;
UI *dual = dualport;

volatile UI hposport  @	0x00402;	// HPOS port in PLD bit 15..0 
											// word addr = 201h  (addr must > 200h)
											// bit 15..11 = '0'
volatile UI statusport @ 0x04000;	// word addr = 2000h 
												// bit 14:  13.5MHz locked to TCXO
												// bit 15:  lockdetect

// Output port addresses ***********************************************
volatile UI dacV74 @	0x0C000;		// word addr = 6000h  	dac V74
volatile UI outport @ 0x08000;	// word addr = 4000h		output port in PLD
volatile UI typeport @ 0x04000;	// word addr = 2000h		linietype port in PLD




// VARIABLES 24BIT
near long hinput;	 // maalt horisontal fase af input signal
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near long href;	 // oensket horisontal fase af input signal
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near long hphzero_g;	//calibrerings data til indstilling af genlock fase
near long hphzero_m;	// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near long phdiff;		//fase difference mellem input og oensket fase
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen


// PORT1 CONTROL BIT
sbit P1_6 @ 0x38E;	// GSELECT
sbit P1_7 @ 0x38F;	// FREQSEL (active low)


// TABLES
code UC * near tableph;
extern code UC fase[];

code UC * near tablepyt;
extern code UC pytg[];
extern code UC pytm[];

code UC *near tableam;
extern code UC divi[];

code UI * near fasekor;
extern code UI fasekorg[];
extern code UI fasekorm[];

code UI * near fasepos;
extern code UI faseposg[];
extern code UI faseposm[];
