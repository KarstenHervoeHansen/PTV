/*
********************************************************************
* Project	: PT5210/5201  SYNC
* Filename	: LOCK.C
* Version	: 1.2
* Purpose	: Genlock routines
* Org.date	: 960430
* Author		: PRC
********************************************************************
HISTORY:
000329 Redesign for PT5201
970219 HLOCK speeded up.
970114 RELEASED 1.1
*/
#include	<xa.h>
#include	"equ.h"
#include	"ext.h"

extern void burstlock(void);

extern unsigned int dualport[2048];
extern bit genlocken;

banked interrupt void lock(void)
{  SWR &= ~lockreq;		// turn off request 
 if (!freq_sel){		// NOT FREQUENCY-LOCK
   if (!genlocken)
	 goto SETINT;

   if (verr>0)
	 goto SETINT;

   if (d1_sel)
	 goto BULOD1;

   burstfase();

   if (blackav<=syg1)
	 goto SETINT;
	 
   if (g_sel){
	 if (!syncav && blackav<=syg2_g)  
	  goto SETINT;
	}
   else if (!syncav && blackav<=syg2_m)  
    goto SETINT;

    // CKSLOW:
   if (slowlock)
      goto SETSLOW;
   if (!bulocken)
      goto NOBU;
   if (g_sel){
    if (buamav<=buamg1_g)  
     goto NOBU;
    if (!buav && buamav<=buamg2_g)  
     goto NOBU;
   }
   else{
    if (buamav<=buamg1_m)  
     goto NOBU;
    if (!buav && buamav<=buamg2_m)  
     goto NOBU;
   }
   // PALG:
   if (lockdet){
     errpre= 3;
     outs= palglock;
   }
   else{
     errpre= 1;
     outs= palgunl;
   }
   // BULO:
   burstlock();
   goto OUTLOCK;

BULOD1:
   outs= d1lock;
   goto OUTLOCK;
   
NOBU:
   if (lockdet=1){
     errpre= 3;
     outs= hlocked;
   }
   else{
     errpre= 1;
     outs= hunl;
   }
// HLOC:
   hlock();
   goto OUTLOCK;

SETSLOW:
   outs= slowerr;	
   intern();
   goto OUTLOCK;
    
SETINT:
   outs= internl;  // internl = 0x04 = bit2
   intern();   // set dac V74

OUTLOCK:
   if (level)  
    outport= outs | 0x20;	// LEVEL-signal bit 5
   else  
    outport= outs & ~0x20;
   
   dolock= 0;
 }

 else{			// frequency-lock selected
  if (!genlocken)
   goto SETINTF;
  	freqfase();
	if (ns)	// freq outside limits (see: PLD-design)
	 goto SETINTF;
  	
// BULO:
   burstlock();

   if (oldph > eph)		// check phase diff
    diffph = oldph - eph;
   else
    diffph = eph - oldph;

    // phdet = typical value 1860
    if ((diffph < 150) && (phdet_ok == 1))
     outs = flock;
     else
     outs = 0x0B;

    goto OUTLOCKF;

   
   
SETINTF:
   outs= internl;
   intern();

OUTLOCKF:
   outport= outs;
   dolock= 0;
 }

} // END of 1.6: lock *****


//************************************************************************
// called from 'interrupt void line_int(void)'   see: line.c
void checkfreqlock(void){

 lockcnt += 1;
 if (lockcnt == 10){	// number of frames
	lockcnt = 0;

 if ((phdet_todac < phdet_dacmax) && (phdet_todac > phdet_dacmin))
  phdet_ok = 1;
  else
  phdet_ok = 0;
	

 } // if (lockcnt...

} 



// ************************************************************
void burstfase(void)
{  UC s1,s2,s3,s4;
	UI *dualptr;	// pointer to dual-port RAM V85
   UC y,x;
   UI i;
   UC z;
   static bit yneg;
   
   if (g_sel){
      i= hpos + bupos_g;
      if (i>hlen_g)  i -= hlen_g;
   }
   else{
      i= hpos + bupos_m;
      if (i>hlen_m)  i -= hlen_m;
   }

   if (i>255)  
    i -= 4;

   // Get data from DUAL-port RAM:
	dualptr = &dualport[i];
   s1= *dualptr++;
   s2= *dualptr++;
   s3= *dualptr++;
   s4= *dualptr;
   if (g_sel)   
    black= (s1+s2+s3) /3;
   else  
    black= (s1+s2+s3+s4) /4;

   if (black > blackav){
      if (blackav!=255)
	  blackav += 1;
   }
   else if (blackav!=0)
	 blackav -= 1;

   // MAKEN:
   if (s4 > s2){
     y= s4-s2;
     yneg= 1;
   }
   else{
     y= s2-s4;
     yneg= 0;
   }

   x= s1 - s3;

   if (s3>s1){		// NOTPOS:
      x= s3-s1;
      if (!yneg){
			buph= tableph[256 * x + y] + 0x0100;
			z= tablepyt[256 * (x/2 + 128) + y/2];
      }
      else{ // NEGAY3:
      	buph= tableph[256 * y + x] + 0xfe00;
			z= tablepyt[256 * ((UI)x/2 + 128) + y/2 + 128];
      }
 //    buph= buph*64;
   }
   else if (x==0)
   {  if (!yneg)
      {	 buph= 0x4000>>6;
	 z= tablepyt[y/2];
      }
      else
      {	buph= 0xc000>>6;
			z= tablepyt[y/2 + 128];
      }
   }
   else if (yneg)
   {  buph= tableph[256 * x + y] + 0xff00;
      z= tablepyt[128 * x + y/2 + 128];
   }
   else
   {  buph= tableph[256 * y + x];
      z= tablepyt[128 * x + y/2];
   }

   // ROTBUPH:

   buph= fasekor[buph & 0x3ff];

   buph= buph + fasepos[i];
   
   // OUTBUFA:
    if (z>buamav)
    {  if (buamav!=255)
	  buamav += 1;
    }
    else if (buamav!=0)
	 buamav -= 1;

}
// ** END of 1.6.1: burstfase *****




// ************************************************************
void freqfase(void)
{  UC s1,s2,s3,s4;
   UC y,x;
   UI *dualptr;
   UI i;
   static bit yneg;
   
   i= 0;
   // Get data from DUAL-port RAM:
	dualptr = &dualport[i];
   s1= *dualptr++;
   s2= *dualptr++;
   s3= *dualptr++;
   s4= *dualptr;

   // MAKEN:
   if (s4>s2){  
	  y= s4-s2;
     yneg= 1;
   }
   else{
     y= s2-s4;
     yneg= 0;
   }

   x= s1 - s3;

   if (s3>s1){
   // NOTPOS:
     x= s3-s1;
     if (!yneg){
       buph= tableph[256 * x + y] + 0x0100;
     }
     else{ // NEGAY3:
       buph= tableph[256 * y + x] + 0xfe00;
     }
   }
   else if (x==0){
     if (!yneg){
       buph= 0x4000>>6;
      }
      else{
       buph= 0xc000>>6;
      }
   }
   else if (yneg){
     buph= tableph[256 * x + y] + 0xff00;
   }
   else{
     buph= tableph[256 * y + x];
   }
 
   // ROTBUPH:
   buph= fasekor[buph & 0x3ff];

   // OUTBUFA:
}
// ** END of 1.6.1.f: freqfase *****




// *****************************************************************
void burstlock(void)
{  UI i;
   eph= subcref - buph;

   i= oldph;
   oldph= eph;
   minus= 0;

   if (eph > i){
    if ((eph - i) >= 0x8000)
	   minus= 1;
   }
   else 
    if (i-eph >= 0x8000)
	  minus= 1;

   // CALC:
   eph= eph/2 + i/2 + (0x8000 * minus);

   if ((phdet & 0xe000)==0 || (phdet & 0xe000)== 0xe000){
     phdet= eph>>1;
     if (phdet & 0x4000)  
      phdet |= 0x8000;
     else  
      phdet &= ~0x8000;
   }
   else{ 	// TSPH15:
     if ((phdet & 0x8000)==0)
      phdet= eph>>1;
     else  
      phdet= (eph>>1) | 0x8000;

   }

   // OUTDAC : phdet is written to 12-bit DAC V74.
   // data in phdet is placed in the most upper 12 bit, therefor a 
   // shift right 4 is performed
   phdet_todac = ((UI)((phdet>>4)) ^0x800);  // (bit 11 inverted)
   dacV74 = phdet_todac;


   if (!freq_sel)	// NOT FREQUENCY-LOCK
      hfasec();

// ** END of 1.6.2 **
}


// ************************************************************
void hlock(void)
{  hfasef();
   phdiff= href - hinput;
   if (phdiff & 0x80000000){
	  phdiff= -phdiff;
     if (!(phdiff & 0xFFFE0000)){
	   if (phdiff & 0xFFFFFC00)
       outf= 0x401;
		else 
	    outf= -phdiff;
   }
   else{  // SETPHD:
    if (g_sel)  
     phdiff= (UL)hlen_g * 256 - phdiff;
    else  
     phdiff= (UL)hlen_m * 256 - phdiff;
       	 
	 if (phdiff & 0xFFFFFC00)
     outf= 0x3ff;
	 else 
	  outf= phdiff;
   }
   }
   else // TSB1817:
   {  if (!(phdiff & 0xFFFE0000))
      { // TS4002:
	 if (phdiff & 0xFFFFFC00)
            outf= 0x3ff;
	 else outf= phdiff;
      }
      else{
       if (g_sel)  
        phdiff= (UL)hlen_g * 256 - phdiff;
       else  
        phdiff= (UL)hlen_m * 256 - phdiff;

	 if (phdiff & 0xFFFFFC00)
     outf= 0x401;
	 else 
	  outf= -phdiff;
      }
   }
   // SNDOUTF:
   outf <<= 1;		// multiply with 2

   // outf 12 bits to port dacV74 with bit 11 inverted 
   outf_todac = (UI)(outf ^0x800);
   dacV74 = outf_todac;
   hfasec();
// ** END of 1.6.3 **
}



// ************************************************************
void intern(void){
   dacV74 = internrefV74;	// write freq cal value to dacV74
}
// ** END of 1.6.4 **



// ************************************************************
void hfasec(void)
{  UC s1, s2;
   s1= (UC)(href>>11);
   s2= (UC)(hpos>>3);

   if (g_sel)
   {  if (s1>s2)
      {  s1 = s1-s2;
         if (s1>hcen_g)
         {  // S1BIG:
            s1= hcyk_g-s1;
	    if (s1>4)  linadd= add4;
         }
         else if (s1>4)  linadd= supr4;
      }
      else // S2BIG:
      {  s2= s2-s1;
         if (s2>hcen_g)
         { // S2BIG2:
	    s2= hcyk_g-s2;
	    if (s2>4)  linadd= supr4;
         }
         else if (s2>4)  linadd= add4;
      }
   }
   else
   {  if (s1>s2)
      {  s1 = s1-s2;
         if (s1>hcen_m)
         {  // S1BIG:
            s1= hcyk_m-s1;
	    if (s1>4)  linadd= add4;
         }
         else if (s1>4)  linadd= supr4;
      }
      else // S2BIG:
      {  s2= s2-s1;
         if (s2>hcen_m)
         { // S2BIG2:
	    s2= hcyk_m-s2;
	    if (s2>4)  linadd= supr4;
         }
         else if (s2>4)  linadd= add4;
      }
   }
}
