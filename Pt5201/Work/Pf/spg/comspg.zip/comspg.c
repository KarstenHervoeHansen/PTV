#include <utility.h>
#include <rs232.h>
#include <ansi_c.h>
#include <formatio.h>
#include <cvirte.h>		/* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>
#include "comspg.h"
#include "comspgutil.h"

#define spgaddr 0x15		// internal V24-addr for SPG
#define bbaddr 0x34		// internal V24-addr for BB
#define COMNo 1
#define baudrate 57600


const char COMstr[3][5] = {"","com1","com2"};
static int mainPNL;
int Err232, ComOpen;
char FKeystr[50], txtstr[2][50];
int v24addr;				// internal V24-addr



int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)	/* Needed if linking in external compiler; harmless otherwise */
		return -1;	/* out of memory */
	if ((mainPNL = LoadPanel (0, "comspg.uir", PANEL)) < 0)
		return -1;

	Err232 = OpenComConfig (COMNo, COMstr[COMNo], baudrate, 0, 8, 2, 500, 500);
	if (Err232 == 0)
	 ComOpen = TRUE;
	 else{
	 MessagePopup ("COM Port", "Open Failed");
	 exit(1);
	 }


	ResetTextBox (mainPNL, PANEL_COMTEXT, "");
	Fmt(txtstr[1],"%s<COM%i\n",COMNo);
	SetCtrlVal (mainPNL, PANEL_COMTEXT, txtstr[1]);
	Fmt(txtstr[1],"%s<Baud: %i",baudrate);
	SetCtrlVal (mainPNL, PANEL_COMTEXT, txtstr[1]);
	SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_CTRL_VAL, TRUE);
	SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_GREEN);


	v24addr = bbaddr;
	DisplayPanel (mainPNL);
	RunUserInterface ();
	return 0;
}




void SendCommand(char *sendstr){

char COM1Buf[50], *instr;
int n,l;
unsigned char csum;
unsigned int result;

if (ComOpen == FALSE){
 MessagePopup ("COM Port", "Port not open");
 return;
} 


SetCtrlVal (mainPNL, PANEL_ACKN, "   ");
SetCtrlVal (mainPNL, PANEL_RCVSTR, "      ");
SetCtrlVal (mainPNL, PANEL_SENDSTR, "     ");

csum = 0;
for (n=0; n < strlen(sendstr); n++)
 csum += sendstr[n];

csum &= 0x7F;

Fmt(COM1Buf,"%s<%c%s%c",v24addr,sendstr,csum);

FlushInQ(COMNo);
WriteCOMPort(COMNo, COM1Buf);

Fmt(txtstr[1],"%s<%xh%s%xh",(unsigned char)v24addr,sendstr,csum);
SetCtrlVal (mainPNL, PANEL_SENDSTR, txtstr[1]);

instr = ReadlnCOMPort(COMNo, 0.5);
if (strlen(instr) > 1){
 CopyString (txtstr[1], 0, instr, 1, strlen(instr));
 Scan (txtstr[1], "%s>%i", &result);
 Fmt(txtstr[0],"%s<%s  (%xh)",txtstr[1],result);
 SetCtrlVal (mainPNL, PANEL_RCVSTR, txtstr[0]);
 }


Fmt(txtstr[1],"%s<%xh",(instr[0] & 0xff));
SetCtrlVal (mainPNL, PANEL_ACKN, txtstr[1]);
																			
if ((unsigned char)instr[0] == 0x30)
 SetCtrlVal (mainPNL, PANEL_ACKN, "????" );

if (RS232Timeout == 1)
 SetCtrlVal (mainPNL, PANEL_RCVSTR, "timeout" );
else
if (COMbytes_read <= 1)
 SetCtrlVal (mainPNL, PANEL_RCVSTR, "      " );


}








int CVICALLBACK ExitCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			CloseCom(COMNo);
			QuitUserInterface (0);
			break;
	}
	return 0;
}

int CVICALLBACK FKeyCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			switch (control){
			 case PANEL_F1_BTN: GetCtrlVal (mainPNL, PANEL_F1_TEXT, FKeystr); break;
			 case PANEL_F2_BTN: GetCtrlVal (mainPNL, PANEL_F2_TEXT, FKeystr); break;
			 case PANEL_F3_BTN: GetCtrlVal (mainPNL, PANEL_F3_TEXT, FKeystr); break;

			 case PANEL_F5_BTN: GetCtrlVal (mainPNL, PANEL_F5_TEXT, FKeystr); break;
			 case PANEL_F6_BTN: GetCtrlVal (mainPNL, PANEL_F6_TEXT, FKeystr); break;
			 case PANEL_F7_BTN: GetCtrlVal (mainPNL, PANEL_F7_TEXT, FKeystr); break;
			 case PANEL_F8_BTN: GetCtrlVal (mainPNL, PANEL_F8_TEXT, FKeystr); break;
			}
			
			SendCommand(FKeystr);

			break;
	}
	return 0;
}



int CVICALLBACK V24Callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
int addrstate;
	switch (event) {
		case EVENT_COMMIT:
			 GetCtrlVal (mainPNL, PANEL_V24ADDR, &addrstate);
			switch (addrstate){
			 case 0: v24addr = bbaddr; break;
			 case 1: v24addr = spgaddr; break;
			}  
		break;
	}

	return 0;
}




int CVICALLBACK ComCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if ((control == PANEL_OPENCOM) && (ComOpen == FALSE)){
			 	Err232 = OpenComConfig (COMNo, COMstr[COMNo], baudrate, 0, 8, 2, 500, 500);
			 	ComOpen = TRUE;
				SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_GREEN);
			} 	
			else if ((control == PANEL_CLOSECOM) && (ComOpen == TRUE)){
				CloseCom(COMNo);
			 	ComOpen = FALSE;
				SetCtrlAttribute (mainPNL, PANEL_COMLED, ATTR_ON_COLOR, VAL_RED);

			
			}


			break;
	}
	return 0;
}
