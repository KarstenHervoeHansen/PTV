/*
********************************************************************
* Project	: PT5210  SYNC
* Filename	: EXT.H
* Version	: 1.2	961030
* Purpose	: Ext. Variables definitions
* Org.date	: 960506
* Author		: PRC
* Special	: This file should be included after the file 'equ.h'.
********************************************************************
HISTORY:

970114 RELEASED 1.1
*/

extern void checkfreqlock(void);


ex bit alian;
ex bit bulocken;
ex bit epapu;		//white bar is on active linie
ex bit level;
ex bit lockdet;
ex bit minus;
ex bit window;
ex bit g_sel;
ex bit d1_sel;

ex NUC atel, btel, ftel;
ex NUC buamav;
ex NUI buph;	//burst phase
ex NUC black;
ex NUC blackav;
ex bit cntenab;
ex NUC cvartel;
ex NUC errpre;
ex volatile NUI eph;
ex NUC genmode;
ex NUI genphase_g; //wanted genlock fase, updated from frontplate
ex NUI genphase_m; //wanted genlock fase, updated from frontplate
ex NUC godgren;	 //indicates which branch in SCH was last used
ex near long hinput;
ex near long hphzero_g;
ex near long hphzero_m;
ex near long href;
ex long phdiff;
ex NUI hpos;
ex NUI htel;
ex NUC levelcnt;
ex NUC linadd;
ex NUC lintyp;
ex volatile NUI oldph;
ex volatile NUI diffph;
ex NUI outf;
ex NUI outf_todac;
ex NUC papua;	//pal pulse ampl.
ex NUI phdet;
ex NUI phdet_todac;
ex NUC phgod;	//filter counter for line7
ex NUC schgod;	//filter counter for SCH routine
ex NUC schph;	//sch fase paa input signal
ex NUC sphgod;	//filter counter for line7
ex NUI subcpot;
ex NUI subcref;
ex NUC verr;
ex NUC trig;	//trig-niveau for 50 % sync		
ex NUI internrefV74;	// write freq cal value to dacV74
ex int h_dacv74_offset;

ex NUC lockcnt;		// lock counter for freq lock check
ex NUC phdet_ok;



sbit TP38 @ 0x399;	// Testpoint on P3.1 (pin 13)

// OUT PORTS
ex volatile UI dacV74;		//@ 0C000h port for output to DAC V74
ex volatile UI outport;		//@ 08000h output port in PLD
ex volatile UI typeport;	//@ 04000h typeport in PLD

// IN PORTS
ex volatile UI * dualptr1;
ex volatile UI * dualptr2;
ex unsigned int dualport[];
ex char * near dual;			//dual port ram
ex volatile UI hposport;	//@ 00402h PLD-port for read of extern h position
ex volatile UI statusport;	//@ 04000h read from statusport in PLD

// TABLES
ex code UC *tableph;	// pointer to phase table
ex code UC *tablepyt;	// pointer to 
ex code UC *tableam;     // pointer to ampl. table
ex code UI *fasekor;	// pointer to ampl. table
ex code UI *fasepos;
ex code UC tablestart_g[];
ex code UC tablestart_m[];


// PACKAGED BITS
ex UC outs;
ex UC doflags;
ex UC modebits;

// BITS IN BYTE: DOFLAGS:
extern bit	dolock;
extern bit	dosch;
extern bit	domode;
extern bit	doknap;
extern bit	doline7;
extern bit	nsf;

// BITS IN BYTE outsb:
extern bit	syncav;
extern bit	lockbit;
extern bit	spgint;
extern bit	buav;
extern bit	pal;
extern bit	slowlock;
extern bit	tcxomounted;
extern bit	freqlock;

// BITS IN BYTE savesb:
extern bit genlocken;
extern bit pplocken;

// BITS IN BYTE MODEBITS: 
extern bit	g_sel;
extern bit	int10_sel;
extern bit	freq_sel;
extern bit	a10m_sel;
extern bit	d1_sel;
extern bit	intern_sel;
extern bit	bulock_sel;

// FUNCTIONS
extern void burstfase(void);
extern void freqfase(void);
extern void hlock(void);
extern void intern(void);
extern void hfasec(void);
extern void hfasef(void);

