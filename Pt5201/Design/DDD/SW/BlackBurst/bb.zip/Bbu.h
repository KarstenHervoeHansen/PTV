/*
********************************************************************
* Project	: PT5210  Black Burst
* Filename	: BBU.H
* Version	: 1.2
* Purpose	: Variables definitions
* Org.date	: 960515
* Author	: PRC
********************************************************************
HISTORY:
000322 New I/O-addr for PT5201. Addr for BB3 added
970120 Changed name from VARS.H
970114 RELEASED 1.1
*/

bit Acknowledge;
/*
// Port addresses for PT5210
volatile UC typeport1 @	0xfff;	// port for linietype (and high of line, corse)
volatile UC hfasecport1 @ 0x1000; // port for line type
volatile UC bulowport1 @ 0x2000; // port for burst phase, low
volatile UC buhiport1 @	0x3000; // port for burst phase, high
volatile UC hfasefport1 @ 0x4000; // port for line phase, fine


volatile UC typeport2 @	0x8000;	// port for linietype (and high of line, corse)
volatile UC hfasecport2 @ 0x9000; // port for line type
volatile UC bulowport2 @ 0xA000; // port for burst phase, low
volatile UC buhiport2 @	0xB000; // port for burst phase, high
volatile UC hfasefport2 @ 0xC000; // port for line phase, fine
*/




// Port adresses PT5201     byte       word  
far UC typeport1 	@ 0x01FFE;  // 00FFF port for linietype and hfase high, corse
far UC hfasecport1 @ 0x02000;  // 01000 port for hfase low
far UC bulowport1 @ 0x04000;  // 02000 port for burst phase, low
far UC buhiport1 	@ 0x06000;  // 03000 port for burst phase, high
far UC hfasefport1 @ 0x08000;  // 04000 port for line phase, fine

far UC typeport2 	@ 0x10000;  // 08000 port for linietype and hfase high, corse
far UC hfasecport2 @ 0x12000;  // 09000 port for hfase low
far UC bulowport2 @ 0x14000;  // 0A000 port for burst phase, low
far UC buhiport2 	@ 0x16000;  // 0B000 port for burst phase, high
far UC hfasefport2 @ 0x18000;  // 0C000 port for line phase, fine

far UC typeport3 	@ 0x20000;  // 10000 port for linietype and hfase high, corse
far UC hfasecport3 @ 0x22000;  // 11000 port for hfase low
far UC bulowport3 @ 0x24000;  // 12000 port for burst phase, low
far UC buhiport3 	@ 0x26000;  // 13000 port for burst phase, high
far UC hfasefport3 @ 0x28000;  // 14000 port for line phase, fine



// PORT BITS **
sbit fieldpuls1 @ 0x39c;	// T0  P3.4   pin16
sbit fieldpuls2 @ 0x399;	// Tx  P3.1   pin13
sbit fieldpuls3 @ 0x398;	// Rx	 P3.0   pin11
sbit P1_6 @ 0x38E;			// Testpoint TP7

// tables
extern code UC typeg[];
code UC *tablephg= typeg;
extern code UC typem[];
code UC *tablephm= typem;
extern code UI sfaseg[];
extern code UI sfasem[];


