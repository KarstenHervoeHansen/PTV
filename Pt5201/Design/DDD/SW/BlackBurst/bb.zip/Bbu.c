/********************************************************************
* Project	: PT5210/5201  Black Burst
* Filename	: BBU.C
* Revision	: 990920
* Purpose	: Main module, Interrupt- and Command-Handling.
* Org.date	: 960515
* Author		: PRC/PF
********************************************************************
HISTORY:

000412 Redesign for PT5201 (BB3 added, line11 in BB1, new cal DACs)
990920	RELEASED 3.2
        Correction for faulty NV-RAM's (autoincrement faiL)
981112	RELEASED 3.1
980915	RELEASED 3.0
980428 Error: SCH-phase is not correct after a system change(eg.HG to HM),
	as 'sch1buf' should be corrected with 'schcalm1' instead of
	'schcalg1' (modulus 2048).
971201 fixed: 'HQ','JQ','HB','JB' was not in kommand list.
	RELEASED 2.2
970925 Added two IIC dummy-reads to start-up to prevent doublestart error.
970908 #define version 021  corrected to ... 21 (021 is OCTAL).
9707	RELEASED 2.1
970703 'std' was not set in state 2 in CharHandler, now corrected.
	RELEASED 2.0
970224 Now check of 'std' if not 'req', 'save' or 'quit' (else a faulty
	command, e.g. HG? would be executed as HG <unknown number>)	
970120 VARS.H changed name to BBU.H
970114	RELEASED 1.1
970106 Added HA?, HQ?, HB?, HO?, HH?, -also for channel 2 (J..)
961205 Optimized for speed
961118 Calibration routines added
960925 Rearrangement of buffer load


DAC overview:  V15=DAC1-8   V25=DAC9-16
			BB1	BB2	BB3
level		 1		 3		 5
offset	 2		 4		 6
gain		 7		 8		 9


*/

#include <xa.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <intrpt.h>
#include "equ.h"
#include "seri1.h"
#include "iniic.h"
#include "dac.h"
#include "bbu.h"

// VERSION SETTING:     xxy = version xx.y, first 'x' can not be '0'.
#define swversion 10

// HW version info:     xxy = version xx.y, first 'x' can not be '0'.
#define hwversion 10     // should be read from info-register in PLD

// V24 ADDRESS: Is 0x00 if NOT option-BBU, 0xf0 if OPTION
#define myaddress 0x34		// see 'seri1.c'


// START-UP BY TURNING OFF THE WATCH-DOG
#asm
	psect	text, global, reloc=2, align=2
		global	powerup, start
powerup:
	clr	0x02fa		;clear watchdog enable flag
	mov.b	0x45d,#0xa5	;watchdog1
	mov.b	0x45e,#0x5a	;watchdog2
	jmp	start
#endasm
	



near char header1;
NUL Number;		// Number received on v24-bus
NUI Number1;		// second number received on v24-bus
bit std,req,quit,save;	// flags for requests from frontplate
NUC errstatus;		// error status

NUL ts;				// total phase (from 'phases1', 'phases2' & 'phases3')
NUI vfase1, vfase2, vfase3;		// no. of lines from origin (0-2499 in G)
NUI vfase1old, vfase2old, vfase3old;	// old no. of lines from origin
NUI vbuf1, vbuf2, vbuf3;		// new no. of lines from origin
NUI lincnt1, lincnt2, lincnt3;		// actual line no.
NUL hfase1, hfase2, hfase3;		// no. of minor-steps from origin (a 0.14ns)
NUL hcalg1, hcalg2, hcalg3;		// H calibration values
NUL hcalm1, hcalm2, hcalm3;		// H calibration values
NUL lastphase1, lastphase2, lastphase3;	// store for latest H-phase
NUI lastsch1, lastsch2, lastsch3;

NUL CALphaseg1, CALphaseg2, CALphaseg3; // cal H-phase from master G
NUL CALphasem1, CALphasem2, CALphasem3; // cal H-phase from master M
NUI CALschg1, CALschg2, CALschg3;       // cal ScH-phase from master G
NUI CALschm1, CALschm2, CALschm3;       // cal ScH-phase from master M

NUL offsetg1, offsetg2, offsetg3;		// global offset G ch.1 and 2 (a 0.14ns)
NUL offsetm1, offsetm2, offsetm3;		// global offset M ch.1 and 2 (a 0.14ns)
NUI subfa1, subfa2, subfa3;				// no. of subc-steps (0-2047 in G)
NUI sf1buf, sf2buf, sf3buf;				// new no. of subc-steps
NUI subcoffs1, subcoffs2, subcoffs3;	// subcarr. offset steps

bit syst1, syst2, syst3;				// TV system (1=G)
bit sys1buf, sys2buf, sys3buf;		// new TV system (1=G)
bit poff1, poff2, poff3;				// flag for setup OFF (M) or line7 ON (G)
bit poff1buf, poff2buf, poff3buf;	// buffers for poff
NUL hf1buf, hf2buf, hf3buf;			// new no. of minor-steps from origin
NUI sch1, sch2, sch3;					// SCH-phase in minor-steps
NUI schcalg1, schcalg2, schcalg3;	// SCH-calibration values
NUI schcalm1, schcalm2, schcalm3;	// SCH-calibration values
NUI sch1buf, sch2buf, sch3buf;		// new SCH-phase in sub-steps
bit loaded1, loaded2, loaded3;		// flags for new values available
NUC dalev1, dalev2, dalev3;			// DAC levels
NUC daoff1, daoff2, daoff3;			// DAC offsets
NUC dagain1, dagain2, dagain3;		// DAC gain
bit ntsc_line11;			// line 11 pulse in NTSC (1=on  0=off)
// *****************************************************************

void NotFound(void)
{
}
// *****************************************************************

near struct kommando
{	 char Aa;
	 char Bb;
	 void (*funktion)(void);
};

// **** BB1 ********************************************************
banked interrupt void ext0_int(void){
UC lintyp;
//  P1_6= 0;	// for test

   if (fieldpuls1){
     if (loaded1){ // Copy new phases
		hfase1= hf1buf;
		vfase1= vbuf1;
		syst1= sys1buf;
		poff1= poff1buf;
		subcoffs1= sf1buf + sch1buf;
		loaded1= 0;
     }
     lincnt1= vfase1;
   }

   if (vfase1 == vfase1old)  
    lincnt1 += 1;
   else{
     if (vfase1 < vfase1old)
      lincnt1 += 2;
   vfase1old= vfase1;
   }

   if (syst1){
     if (lincnt1 >= gmod)  
		lincnt1= 0;
     lintyp= typeg[lincnt1] << 4;
     subfa1= (sfaseg[lincnt1] + subcoffs1) | 0x8000;
   }
    else{	// M-system
     if (lincnt1 >= mmod)
      lincnt1= 0;
      
     if (ntsc_line11){	// check if line11 is enabled
	     if (lincnt1 == 7)
	      lintyp = 0xC0;	// 12d placed in bit 7-4 (line type reg T3-0)
	      else
			lintyp= typem[lincnt1] << 4;
	  }
	  else 
     lintyp= typem[lincnt1] << 4;

     subfa1= (sfasem[lincnt1] + subcoffs1) & ~0x8000;
   }

   if (poff1){
    lintyp |= 0x08;
   } 
   
   typeport1= lintyp | (hfase1>>16 & 7);
   hfasefport1= ~((UC)(hfase1%256));

//   hfasecport1= (UC)(hfase1/256);
 #asm
   mov.w r1,#_hfasecport1
   mov.b[r1], _hfase1+1
#endasm

   bulowport1= (UC)(subfa1 & 0x00ff);
   buhiport1= (UC)((subfa1 & 0xff00)>>8);

// P1_6= 1;	// for test

}


// ****** BB2 ******************************************************
banked interrupt void ext1_int(void) // FV_BB2
{  UC lintyp;

//  P1_6= 0;	// for test

   if (fieldpuls2){
      if (loaded2){	// COPY NEW PHASES
		 hfase2= hf2buf;
		 vfase2= vbuf2;
		 syst2= sys2buf;
		 poff2= poff2buf;
		 subcoffs2= sf2buf + sch2buf;
		 loaded2= 0;
      }
      lincnt2= vfase2;
   }

   if (vfase2==vfase2old)
    lincnt2 += 1;
   else{
    if (vfase2<vfase2old)
     lincnt2 += 2;
   vfase2old= vfase2;
   }

   if (syst2){
     if (lincnt2 >= gmod)
      lincnt2= 0;
   lintyp= typeg[lincnt2] << 4;
   subfa2= (sfaseg[lincnt2] + subcoffs2) | 0x8000;
   }
   else{
    if (lincnt2 >= mmod)
     lincnt2= 0;
   lintyp= typem[lincnt2] << 4;
   subfa2= (sfasem[lincnt2] + subcoffs2) & ~0x8000;
   }

   if (poff2)
    lintyp |= 0x08;

   typeport2= lintyp | (hfase2>>16 & 7);
   hfasefport2= ~((UC)(hfase2%256));

//   hfasecport2= (UC)(hfase2/256);
 #asm  
   mov.w r1,#_hfasecport2
   mov.b[r1], _hfase2+1
#endasm
   
   bulowport2= (UC)(subfa2 & 0x00ff);
   buhiport2= (UC)((subfa2 & 0xff00)>>8);
   
// P1_6= 1;	// for test
}



// **** BB3 ********************************************************
banked interrupt void t2ex_int(void){
UC lintyp;

//  P1_6= 0;	// for test

	EXF2 = 0;	// clear flag, prevents further interrupts from T2EX pin

   if (fieldpuls3){
     if (loaded3){ // Copy new phases
		hfase3= hf3buf;
		vfase3= vbuf3;
		syst3= sys3buf;
		poff3= poff3buf;
		subcoffs3= sf3buf + sch3buf;
		loaded3= 0;
     }
     lincnt3= vfase3;
   }

   if (vfase3 == vfase3old)  
    lincnt3 += 1;
   else{
     if (vfase3 < vfase3old)
      lincnt3 += 2;
   vfase3old= vfase3;
   }

   if (syst3){
     if (lincnt3 >= gmod)  
		lincnt3= 0;
     lintyp= typeg[lincnt3] << 4;
     subfa3= (sfaseg[lincnt3] + subcoffs3) | 0x8000;
   }
    else{
     if (lincnt3 >= mmod)
      lincnt3= 0;
     lintyp= typem[lincnt3] << 4;
     subfa3= (sfasem[lincnt3] + subcoffs3) & ~0x8000;
   }

   if (poff3){
    lintyp |= 0x08;
   } 
   
   typeport3= lintyp | (hfase3>>16 & 7);
   hfasefport3= ~((UC)(hfase3%256));

//   hfasecport1= (UC)(hfase1/256);
 #asm
   mov.w r1,#_hfasecport3
   mov.b[r1], _hfase3+1
#endasm

   bulowport3= (UC)(subfa3 & 0x00ff);
   buhiport3= (UC)((subfa3 & 0xff00)>>8);

//  P1_6= 1;	// for test

}



// definitions for calculation of phases (used in phases1() and phases2()).
//   antal subc-steps = faktor * sync-steps (a 0,14 ns)
//   faktor= 3.579545   * 8 / 27    for G-system (1.31366481..)
//   faktor= 4.43361875 * 8 / 27    for M-system (1.06060592..)
//         = (fak1 * 65536 + fak2 ) / 2^31
#define fak1g	43046
#define fak2g	11053
#define fak1m	34753
#define fak2m	61275

#define vmodg	442368
#define vmodm	439296
#define tmodg	1105920000
#define tmodm	461260800

// *****************************************************************
void dummy(void){
 ;
}


// *** BB1 **********************************************************
void phases1(void)		// puts new phase in first buffer
{ 				// channel 1
   UL b, r;

   while (loaded1) ;

   if (sys1buf)
   {  ts= tmodg - Number + hcalg1 + offsetg1;
      vbuf1= ((UI)(ts / vmodg)+1)%gmod;	// no. of lines (pr. 1728*256)
      hf1buf= ts % vmodg;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1g) * 2 +  ((b*fak2g)>>15);
   }
   else
   {  ts= tmodm - Number + hcalm1 + offsetm1;
      vbuf1= ((UI)(ts / vmodm)+1) % mmod; // no. of lines (pr. 1716*256)
      hf1buf= ts % vmodm;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1m) * 2 +  ((b*fak2m)>>15);
   }
   sf1buf= r>>16;
   loaded1= 1;
}


// *** BB2 **********************************************************
void phases2(void)		// puts new phase in first buffer
{ 				// channel 2
   UL b, r;

   while (loaded2) ;

   if (sys2buf)
   {  ts= tmodg - Number + hcalg2 + offsetg2;
      vbuf2= ((UI)(ts / vmodg)+1) % gmod; // no. of lines (pr. 1728*256)
      hf2buf= ts % vmodg;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1g) * 2 +  ((b*fak2g)>>15);
   }
   else
   {  ts= tmodm - Number + hcalm2 + offsetm2;
      vbuf2= ((UI)(ts / vmodm)+1) % mmod; // no. of lines 
      hf2buf= ts % vmodm;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1m) * 2 +  ((b*fak2m)>>15);
   }
   sf2buf= r>>16;
   loaded2= 1;
}


// *** BB3 **********************************************************
void phases3(void)		// puts new phase in first buffer
{ 				// channel 3
   UL b, r;

   while (loaded3) ;

   if (sys3buf)
   {  ts= tmodg - Number + hcalg3 + offsetg3;
      vbuf3= ((UI)(ts / vmodg)+1) % gmod; // no. of lines (pr. 1728*256)
      hf3buf= ts % vmodg;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1g) * 2 +  ((b*fak2g)>>15);
   }
   else
   {  ts= tmodm - Number + hcalm3 + offsetm3;
      vbuf3= ((UI)(ts / vmodm)+1) % mmod; // no. of lines 
      hf3buf= ts % vmodm;	// the rest
      b= ts & 0x000000ff;
      r= (b * fak1m) * 2 +  ((b*fak2m)>>15);
   }
   sf3buf= r>>16;
   loaded3= 1;
}

// *****************************************************************
void readadr(void)	// HA  -read V24 address
{  if (req)
   {  req= 0;
      return_char(myaddress);
   }
}

// *****************************************************************
void load1g(void){	// HG  -receive new phase
   if (std){
      sys1buf= 1;				// system G, channel 1
      poff1buf= 0;			// line7 off
      lastphase1= Number;	// save new phase
      phases1();
   }
}

// *****************************************************************
void load2g(void){	// JG  -receive new phase
   if (std){
      sys2buf= 1;				// system G, channel 2
      poff2buf= 0;			// line7 off
      lastphase2= Number;	// save new phase
      phases2();
   }
}

// *****************************************************************
void load3g(void){	// KG  -receive new phase
   if (std){
      sys3buf= 1;				// system G, channel 3
      poff3buf= 0;			// line7 off
      lastphase3= Number;	// save new phase
      phases3();
   }
}

// *****************************************************************
void load1g7(void)	// HK  -receive new phase
{  if (std)
   {  sys1buf= 1;				// system G with line 7, channel 1
      poff1buf= 1;			// line7 on
      lastphase1= Number;	// save new phase
      phases1();
   }
}

// *****************************************************************
void load2g7(void)	// JK  -receive new phase
{  if (std)
   {  sys2buf= 1;				// system G, channel 2
      poff2buf= 1;			// line7 on
      lastphase2= Number;	// save new phase
      phases2();
   }
}

// *****************************************************************
void load3g7(void)	// KK  -receive new phase
{  if (std)
   {  sys3buf= 1;				// system G, channel 3
      poff3buf= 1;			// line7 on
      lastphase3= Number;	// save new phase
      phases3();
   }
}


// *****************************************************************
void load1m(void)	// HM  -receive new phase
{  if (std)
   {  sys1buf= 0;				// system M, channel 1
      poff1buf= 0;			// pedestal on
      lastphase1= Number;	// save new phase
      phases1();
   }
}

// *****************************************************************
void load2m(void)	// JM  -receive new phase
{  if (std)
   {  sys2buf= 0;				// system M, channel 2
      poff2buf= 0;			// pedestal on
      lastphase2= Number;	// save new phase
      phases2();
   }
}

// *****************************************************************
void load3m(void)	// KM  -receive new phase
{  if (std)
   {  sys3buf= 0;				// system M, channel 3
      poff3buf= 0;			// pedestal on
      lastphase3= Number;	// save new phase
      phases3();
   }
}


// *****************************************************************
void load1ms(void)	// HL  -receive new phase
{  if (std)
   {  sys1buf= 0;				// system M, channel 1
      poff1buf= 1;			// pedestal off
      lastphase1= Number;	// save new phase
      phases1();
   }
}

// *****************************************************************
void load2ms(void)	// JL  -receive new phase
{  if (std)
   {  sys2buf= 0;				// system M, channel 2
      poff2buf= 1;			// pedestal off
      lastphase2= Number;	// save new phase
      phases2();
   }
}

// *****************************************************************
void load3ms(void)	// KL  -receive new phase
{  if (std)
   {  sys3buf= 0;				// system M, channel 3
      poff3buf= 1;			// pedestal off
      lastphase3= Number;	// save new phase
      phases3();
   }
}


// *****************************************************************
void set1m11(void){	// HN  -set/read NTSC line 11 on/off   (BB1 only)
   if (std)
      ntsc_line11= Number;	// 1=on   0=off
   else if (req){
      req= 0;
      return_char(ntsc_line11);
   }
}

// *****************************************************************
void rdphase1(void){	// HB	-return phase  BB1
   if (req){
      req= 0;
      return_long(lastphase1);
   }
}

// *****************************************************************
void rdphase2(void)	// JB	-return phase  BB2
{  if (req)
   {  req= 0;
      return_long(lastphase2);
   }
}

// *****************************************************************
void rdphase3(void)	// KB	-return phase  BB3
{  if (req)
   {  req= 0;
      return_long(lastphase3);
   }
}


// *****************************************************************
void rdsyst1(void)		// HQ  -return system  BB1
{  if (req)
   {  req= 0;
      return_char((UC)(!sys1buf) * 2 + (UC)poff1buf);
   }
}

// *****************************************************************
void rdsyst2(void)		// JQ  -return system  BB2
{  if (req)
   {  req= 0;
      return_char((UC)(!sys2buf) * 2 + (UC)poff2buf);
   }
}

// *****************************************************************
void rdsyst3(void)		// KQ  -return system  BB3
{  if (req)
   {  req= 0;
      return_char((UC)(!sys3buf) * 2 + (UC)poff3buf);
   }
}


// *****************************************************************
void global1(void)		// HO  -set global offset phase BB1
{
   if (req){
      req= 0;
      if (sys1buf)  
       return_long(offsetg1);
      else  
       return_long(offsetm1);
   }
   else if (std){
      if (sys1buf)  
        offsetg1= tmodg - Number;
       else 
        offsetm1= tmodm - Number;
      Number= lastphase1;		// use latest H-phase
      phases1();
   }
}

// *****************************************************************
void global2(void){		// JO  -set global offset phase BB2
     if (req){
      req= 0;
      if (sys2buf)  
       return_long(offsetg2);
      else  
       return_long(offsetm2);
   }
   else if (std){
     if (sys2buf)  
        offsetg2= tmodg - Number;
       else 
        offsetm2= tmodm - Number;
      Number= lastphase2;		// use latest H-phase
      phases2();
   }
}

// *****************************************************************
void global3(void){		// KO  -set global offset phase BB3
     if (req){
      req= 0;
      if (sys3buf)  
       return_long(offsetg3);
      else  
       return_long(offsetm3);
   }
   else if (std){
     if (sys3buf)  
        offsetg3= tmodg - Number;
       else 
        offsetm3= tmodm - Number;
      Number= lastphase3;		// use latest H-phase
      phases3();
   }
}


// *****************************************************************
void scload1(void)	// HH  -read/set sch-phase, BB1
{  UI x;
   if (sys1buf) 
     x= schcalg1; // calculated in 'trimschg1'
    else 
     x= schcalm1;	// calculated in 'trimschm1'
     
   if (req){            // HH?
      req= 0;
      return_int(lastsch1);
   }
   else if (std){       // HH<ui>
      std= 0;
      lastsch1 = (UI)Number;
      sch1buf= (lastsch1 + x) % 2048;       // adjust value
      loaded1= 1;                           // signal new value
   }

}

// *****************************************************************
void scload2(void)	// JH  -read/set sch-phase, BB2
{   UI x;
   if (sys2buf)  
     x= schcalg2; 
    else 
     x= schcalm2;

   if (req){           // JH?
      req= 0;
      return_int(lastsch2);
   }
   else if (std){      // JH<ui>
      std= 0;
      lastsch2 = (UI)Number;
      sch2buf= (lastsch2 + x) % 2048;    // adjust value
      loaded2= 1;                        // signal new value
   }

}

// *****************************************************************
void scload3(void)	// KH  -read/set sch-phase, BB3
{   UI x;
   if (sys3buf)  
     x= schcalg3; 
    else 
     x= schcalm3;

   if (req){           // KH?
      req= 0;
      return_int(lastsch3);
   }
   else if (std){      // KH<ui>
      std= 0;
      lastsch3 = (UI)Number;
      sch3buf= (lastsch3 + x) % 2048;    // adjust value
      loaded3= 1;                        // signal new value
   }

}


// ***** H-phase ****************************************************
void trimphag1(void){		// HX  -read/set H-phases BB1 G
  if (req){
		req = 0;
		return_long(CALphaseg1);
	}
	else if (std){
      std= 0;
      CALphaseg1 = (UL)Number;
      hcalg1= (tmodg-CALphaseg1+hcaldefg) % tmodg;  // from master at power up
   }
}

// *****************************************************************
void trimphag2(void){		// JX  -read/set H-phases BB2 G
   if (req){
      req = 0;
      return_long(CALphaseg2);
   }
   else if (std){
      std= 0;
      CALphaseg2 = (UL)Number;
      hcalg2= (tmodg-CALphaseg2+hcaldefg) % tmodg;  // from master at power up
   }
}

// *****************************************************************
void trimphag3(void){		// KX  -read/set H-phases BB3 G
   if (req){
      req = 0;
      return_long(CALphaseg3);
   }
   else if (std){
      std= 0;
      CALphaseg3 = (UL)Number;
      hcalg3= (tmodg-CALphaseg3+hcaldefg) % tmodg;  // from master at power up
   }
}


// *****************************************************************
void trimpham1(void){		// HY  -read/set H-phases BB1 M
   if (req){
      req= 0;
      return_long(CALphasem1);
   }
   else if (std){
      std= 0;
      CALphasem1 = (UL)Number;
      hcalm1= (tmodm-CALphasem1+hcaldefm) % tmodm;  // from master at power up
   }
}

// *****************************************************************
void trimpham2(void){		// JY  -read/set H-phases BB2 M
  if (req){
      req = 0;   
      return_long(CALphasem2);			   // request from master
   }
   else if (std){
      std= 0;
      CALphasem2 = (UL)Number;
      hcalm2= (tmodm-CALphasem2+hcaldefm) % tmodm;  // from master at power up
   }
}

// *****************************************************************
void trimpham3(void){		// KY  -read/set H-phases BB3 M
  if (req){
      req = 0;   
      return_long(CALphasem3);			   // request from master
   }
   else if (std){
      std= 0;
      CALphasem3 = (UL)Number;
      hcalm3= (tmodm-CALphasem3+hcaldefm) % tmodm;  // from master at power up
   }
}





// ********** ScH ******************************************************
void trimschg1(void){  //  HT  BB1    read/set calibration sch	  G
   if (req){
		req = 0;
		return_int(CALschg1);			   // request from master
	}
	else if (std){
      std= 0;
      schcalg1= CALschg1= (UI)Number;  // from master at power up
   }
}

//*****************************************************************
void trimschg2(void){  //  JT  BB2    read/set calibration sch	  G
   if (req){
		req = 0;
		return_int(CALschg2);			   // request from master
	}
	else if (std){
      std= 0;
      schcalg2= CALschg2= (UI)Number;  // from master at power up
   }
}

//*****************************************************************
void trimschg3(void){  //  KT  BB3    read/set calibration sch	  G
   if (req){
		req = 0;
		return_int(CALschg3);			   // request from master
	}
	else if (std){
      std= 0;
      schcalg3= CALschg3= (UI)Number;  // from master at power up
   }
}


// ****************************************************************
void trimschm1(void){  //  HU  BB1    read/set calibration sch	  M
   if (req){
		req = 0;
		return_int(CALschm1);			   // request from master
	}
	else if (std){
      std= 0;
      schcalm1= CALschm1= (UI)Number;  // from master at power up
   }
}

// ****************************************************************
void trimschm2(void){  //  JU  BB2    read/set calibration sch	  M
   if (req){
		req = 0;
		return_int(CALschm2);			   // request from master
	}
	else if (std){
      std= 0;
      schcalm2= CALschm2= (UI)Number;  // from master at power up
   }
}

// ****************************************************************
void trimschm3(void){  //  KU  BB3    read/set calibration sch	  M
   if (req){
		req = 0;
		return_int(CALschm3);			   // request from master
	}
	else if (std){
      std= 0;
      schcalm3= CALschm3= (UI)Number;  // from master at power up
   }
}




// *** DAC BB1 *****************************************************
void daclev1(void)		// HD  -set/read DAC level BB1
{  
  	if (req){
     req= 0;
     return_char(dalev1);	// read value
   }
   else if (std) {
     dalev1= (UC)Number;
     Wr_dac(1,dalev1);	// set value in DAC#1
   }
}
// *****************************************************************

void dacoffset1(void)		// HC  -set/read DAC offset BB1
{  if (req)
   {  req= 0;
      return_char(daoff1);	// read value
   }
   else if (std)
   {  daoff1= (UC)Number;
      Wr_dac(2,daoff1);		// set value in DAC#2
   }
}

//****************************************************************
void dacgain1(void)  //    HE  set/read DAC gain in BB1
{  
   if (req){
      req= 0;
      return_char(dagain1);	// read value
   }
   else if (std){
      dagain1 = (UC)Number;
      Wr_dac(7, dagain1);		// set value in DAC#7
   }
}



// ** DAC BB2 ******************************************************

void daclev2(void)		// JD  -set/read DAC level BB2
{  if (req)
   {  req= 0;
      return_char(dalev2);	// read value
   }
   else if (std)
   {  dalev2= (UC)Number;
      Wr_dac(3,dalev2);		// set value in DAC#3
   }
}
// *****************************************************************

void dacoffset2(void)		// JC  -set/read DAC offset BB2
{  if (req)
   {  req= 0;
      return_char(daoff2);	// read value
   }
   else if (std)
   {  daoff2= (UC)Number;
      Wr_dac(4,daoff2);	// set value in DAC#4
   }
}


//*******************************************************************
void dacgain2(void) //     HE  set/read DAC gain in BB2
{  
   if (req){
      req= 0;
      return_char(dagain2);	// read value
   }
   else if (std){
      dagain2 = (UC)Number;
      Wr_dac(8, dagain2);		// set value in DAC#8
   }
}


//**** DAC BB3 *******************************************************
void daclev3(void)		// KD  -set/read DAC level BB3
{  
  	if (req){
     req= 0;
     return_char(dalev3);	// read value
   }
   else if (std) {
     dalev3= (UC)Number;
     Wr_dac(5,dalev3);	// set value
   }
}
// *****************************************************************

void dacoffset3(void)		// KC  -set/read DAC offset BB3
{  if (req)
   {  req= 0;
      return_char(daoff3);	// read value
   }
   else if (std)
   {  daoff3= (UC)Number;
      Wr_dac(6,daoff3);		// set value
   }
}

//****************************************************************
void dacgain3(void)  //    KE  set/read DAC gain in BB3
{  
   if (req){
      req= 0;
      return_char(dagain3);	// read value
   }
   else if (std){
      dagain3 = (UC)Number;
      Wr_dac(9, dagain3);		// set value in DAC#9
   }
}






// *****************************************************************

UC instring[11];	// receive string
UC instr_index;	// index into receive string (instring)


// *****************************************************************
void hwreport(void)	// reports hardware version (register in PLD)
{  if (req)                     // HV?
   {  req= 0;
      return_char(hwversion);
   }
}

// *****************************************************************
void swreport(void)	// reports up-software version
{  if (req)                     // HI?  ID?
   {  req= 0;
      return_char(swversion);
   }
}

// *****************************************************************
void opstart(void)	// BB3 mangler i opstart() <<<<<<<<<<<<
{
   hfase1= hcaldefg;
   hfase2= hcaldefg;
   hfase3= hcaldefg;
   lastphase1= -hcaldefg;
   lastphase2= -hcaldefg;
   lastphase3= -hcaldefg;
   lastsch1= 0;
   lastsch2= 0;
   lastsch3= 0;

   loaded1= loaded2= loaded3= 0;		// initiate fase-transfer
   sf1buf= sf2buf= sf3buf= 0;
   subfa1= subfa2= subfa3= 0;
   syst1= syst2= syst3= 1;				// default system= G
   sys1buf= sys2buf= sys3buf= 1;
   poff1= poff2= poff3= 0;				// set-up= off
   offsetg1= offsetg2= offsetg3= 0;	// global offset 0
   offsetm1= offsetm2= offsetm3= 0;

   // Load dac with default values
   dalev1= daclevdef;
   daoff1= dacofsdef;
   dagain1= dacgaindef;

   dalev2= daclevdef;
   daoff2= dacofsdef;
   dagain2= dacgaindef;

   dalev3= daclevdef;
   daoff3= dacofsdef;
   dagain3= dacgaindef;

   Wr_dac(1,daclevdef);	// BB1
   Wr_dac(2,dacofsdef); 
   Wr_dac(7,dacgaindef);

   Wr_dac(3,daclevdef);	// BB2
   Wr_dac(4,dacofsdef);
   Wr_dac(8,dacgaindef);

   Wr_dac(5,daclevdef);	// BB3
   Wr_dac(6,dacofsdef);
   Wr_dac(9,dacgaindef);

   loaded1= loaded2= loaded3= 0;

// Init ports in PLD
   bulowport1= bulowport2= bulowport3= 0;
   buhiport1= buhiport2= buhiport3= 0;
   hfasefport1= hfasefport2= hfasefport3= 0;
   hfasecport1= hfasecport2= hfasecport3= 0;
   typeport1= typeport2= typeport3= 0;

// no errors
   errstatus= 0;
   
// BB1 in NTSCmode: line11=off;
   ntsc_line11 = 0;
}

// *****************************************************************
void reset1(void){	// HZ  -Reset BB1 to default
   Wr_dac(1, daclevdef);	// set value
   Wr_dac(2, dacofsdef);
   Wr_dac(7, dacgaindef);

   dalev1= daclevdef;
   daoff1= dacofsdef;
   dagain1= dacgaindef;
   hcalg1= hcaldefg;
   hcalm1= hcaldefm;
   schcalg1= schcaldefg;
   schcalm1= schcaldefm;
}

// *****************************************************************
void reset2(void){	// JZ  -Reset BB2 to default
   Wr_dac(3, daclevdef);	// set value
   Wr_dac(4, dacofsdef);
   Wr_dac(8, dacgaindef);

   dalev2= daclevdef;
   daoff2= dacofsdef;
   dagain2= dacgaindef;
   hcalg2= hcaldefg;
   hcalm2= hcaldefm;
   schcalg2= schcaldefg;
   schcalm2= schcaldefm;
}

// *****************************************************************
void reset3(void){	// JZ  -Reset BB3 to default
   Wr_dac(5, daclevdef);	// set value
   Wr_dac(6, dacofsdef);
   Wr_dac(9, dacgaindef);

   dalev3= daclevdef;
   daoff3= dacofsdef;
   dagain3= dacgaindef;
   hcalg3= hcaldefg;
   hcalm3= hcaldefm;
   schcalg3= schcaldefg;
   schcalm3= schcaldefm;
}

// *****************************************************************
void readstat(void)	// ST?  HS?  -Read status
{  if (req)
   {  req= 0;
      return_char(errstatus);      
   }
}

// **** Table for arriving commands from internal V24 ***************
code const struct kommando kommandotabel[] = {
'H','A',readadr,
'I','D',swreport,
'H','I',swreport,
'H','V',hwreport,
'H','S',readstat,
'S','T',readstat,

'H','G',load1g,
'J','G',load2g,
'K','G',load3g,

'H','K',load1g7,
'J','K',load2g7,
'K','K',load3g7,

'H','M',load1m,
'J','M',load2m,
'K','M',load3m,

'H','L',load1ms,
'J','L',load2ms,
'K','L',load3ms,

'H','Q',rdsyst1,
'J','Q',rdsyst2,
'K','Q',rdsyst3,

'H','B',rdphase1,
'J','B',rdphase2,
'K','B',rdphase3,

'H','O',global1,
'J','O',global2,
'K','O',global3,

'H','H',scload1,
'J','H',scload2,
'K','H',scload3,

'H','X',trimphag1,
'J','X',trimphag2,
'K','X',trimphag3,

'H','Y',trimpham1,
'J','Y',trimpham2,
'K','Y',trimpham3,

'H','T',trimschg1,
'J','T',trimschg2,
'K','T',trimschg3,

'H','U',trimschm1,
'J','U',trimschm2,
'K','U',trimschm3,

'H','D',daclev1,
'J','D',daclev2,
'K','D',daclev3,

'H','C',dacoffset1,
'J','C',dacoffset2,
'K','C',dacoffset3,

'H','E',dacgain1,
'J','E',dacgain2,
'K','E',dacgain3,

'H','Z',reset1,
'J','Z',reset2,
'K','Z',reset3,

'H','N',set1m11,
'S','W',dummy
};

// ** Command machine ******************************************************
void CommandExecute(char A,char B) {
UC x;
for (x = 0; x < (sizeof(kommandotabel)/sizeof(struct kommando)); x++)
   if (A==kommandotabel[x].Aa)
      if (B==kommandotabel[x].Bb)
      {
	 header1 = A;
	 kommandotabel[x].funktion();
	 break;
      }
}
// *****************************************************************

void CharHandler(UC c)
{  static UC MesState;
   static char First,Second;
   switch ( MesState){
      case 0: if(isalpha(c)){
  	      		First = toupper(c); 
  	      		MesState = 1;
	      	}  break;
      case 1: 	if(isalpha(c)){
    	      	  Second =toupper(c); 
    	      	  MesState = 2; 
    	      	  Number = 0;
	      	}
					else 
					 MesState= 0;
	      		break;
	      	
      case 2:	if(isdigit(c))  
      			 Number = (c-'0') + 10 * Number;
					else if (c==',')  
					 MesState= 3;
					else if (c==34){
		   		MesState= 4;		// was quote, start string
				   instr_index= 0;
					}
		else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$'){
		   MesState = 5;
		   std= 0; quit= 0; save= 0; req= 0;
	           if (c == '?') req = 1;
	           else if (c == '!') 
	            quit = 1;
	           else if (c == '$') 
	            save = 1;
				  else  std= 1;
	           // CommandExecute(First,Second);
		}
		else MesState= 0;
		break;
		
      case 3:	if(isdigit(c))  
					 Number1 = 10 * Number1 + (c-'0');
					else if (c==34){
					  MesState= 4;		// was quote, start string
					  instr_index= 0;
					}
		else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$'){
		   MesState = 5;
		   std= 0; quit= 0; save= 0; req= 0;
		   if (c == '?') 
		    req = 1;
		   else if (c == '!') 
		    quit = 1;
		   else if (c == '$') 
		    save = 1;
		   else  std= 1;
		   // CommandExecute(First,Second);
		}
		else 
		 MesState= 0;
		break;
		
      case 4:	if (c==34)  
      			 instring[instr_index]= 0;  // end the string
					else if (c==10 || c==';' || c==13 || c== '?' || c== '!' || c== '$')
					{  MesState = 5;
		   std= 0; quit= 0; save= 0; req= 0;
		   if (c == '?') 
		    req = 1;
		   else if (c == '!') 
		    quit = 1;
		   else if (c == '$') 
		    save = 1;
		   else  
		    std= 1;
		   // CommandExecute(First,Second);
		}
		else  
		 instring[instr_index++]= c; // save the char in string
		break;

      case 5:	MesState = 0;
					if (c==0x80){
					 CommandExecute(First,Second);
					}
					break;
					
      default:	MesState = 0; 
      			break;
   }
}
// *****************************************************************

void kommun(void)
{  UC gc;
   while ((gc=get_char1()) != 0)	/* handle characters from buffer */
		  CharHandler(gc);
}
// *****************************************************************
// *****************************************************************
void main(void)
{
// System set-up, manual p.281
  BCR= 0x06;	// set 20 bit BUS, 16 bit DATA

// Program status word, manual p.75
  PSWH= 0x8F;	// highest priority for system
  PSWL= 0;		// clear flags

// Bus timing: manual p.290
  BTRH= 0xAE;	// ae; foer 970107:0xaa; EXT. BUS timing, Data Cycle
  BTRL= 0xC9;	// c9; foer 0xca; EXT. BUS timing, Wr+ALE-pulses+Code
		// ved 0xcd bliver option for langsom til at detekteres!

// System config register, manual p.386, p.76
  SCR= 0;	// timer speed prescaler (0 gives 4, 4 gives 16, 8 gives 64)

  WDCON= 0;
  WFEED1= 0xA5; // stop watchdog (needs food first)
  WFEED2= 0x5A;

  PSWH= 0x80;  // lowest priority for system

 // set-up counters and interrupts
   IEL= 0;		// reset timers
   IT0= 1;		//INT0 edge trig
   IT1= 1;		//INT1 edge trig
   EX0= 1;		//Enable interrupt from INT0
   EX1= 1;		//Enable interrupt from INT1

// Timer 1 as baud rate generator for UART 1
   TMOD= 0x00;	// T1 = 16 bit auto-reload, T0 = not used
   ET1= 0;		// interrupt from timer0 & timer1 disabled
   ET0= 0;
   RTL1= -8;	// reload value for Timer 1, sets Baud rate to 57600
   RTH1= -1;
   TR1= 1;		// start timer 1

// Timer 2 as external interrupt on pin T2EX (used by BB3)
	T2CON = 0x09;	// enable interrupt from EXT2 pin (P1.7)
	TR2 = 0;			// stop timer2
	ET2 = 1;			// enable timer2 interrupt
	
   SWE |= 1;		// enable SW-interrupt 1 for moving command to cyclic buffer
   S1CON= 0xf8;	// 0xf2,Transmit mode 3, 9 bit UART, Address mode, Rec.enable
						// bit 7-3 = 1

/* DEFINITION OF INTERRUPTS (see manual pg.82)
  Interrupt:	Level:	Reg-bank:
EX0  (line1)	15	2	banked
EX1  (line2)	15	2	banked
T2   (line3)	15	2	banked
serial1			14	1	banked
ser.1-end		1	0	not banked

// SOFTWARE-INTERRUPTS:
none
*/

ROM_VECTOR(IV_EX0, ext0_int, IV_SYSTEM+IV_PRI15+IV_BANK2)
ROM_VECTOR(IV_EX1, ext1_int, IV_SYSTEM+IV_PRI15+IV_BANK2)
ROM_VECTOR(IV_T2, t2ex_int, IV_SYSTEM+IV_PRI15+IV_BANK2)
ROM_VECTOR(IV_RI1, serial1_int, IV_SYSTEM+IV_PRI14+IV_BANK1)
ROM_VECTOR(IV_SWI1, serial_end, IV_SYSTEM+IV_PRI01+IV_BANK0)

IPA0= 0x0f;	// TIM0/EX0 prior.
IPA1= 0x0f;	// TIM1/EX1 prior.
IPA2= 0x0f;	// TIM2 prior.
IPA5= 0x0e;	// serial 1 TX/Rx prior.


S1ADDR= myaddress;	// set V24-receive address
S1ADEN= 0xFF;  // mask for receive address (zeroes makes don't care)

serial1_init();

// SET DEFAULT VALUES
opstart();

EA= 1;			// enable all interrupts


// *****************************************************************

// main interrupt waiting loop

   while(1){
    kommun();
   }
   
}
