
#define NUC unsigned char
#define NUL unsigned long
#define UL NUL
#define NUI unsigned short
#define bit char
#define byte char

#define daclevdef 125
#define dacofsdef 120
#define dacgaindef 110
#define hcaldefg	1105919210L
#define hcaldefm	230626860L
#define schcaldefg	1855
#define schcaldefm	1736
#define tmodg	1105920000L

				
unsigned short	x,
				fla_sch1,
				fla_phase1;



NUC myaddress;
NUC cc;
NUL Number;						// Number received on v24-bus
NUI Number1;					// second number received on v24-bus
bit std,req,quit,save;		// flags for requests from frontplate
NUC errstatus;					// error status

NUL ts,ts1;									// total phase (from 'phases1' and 'phases2')
NUI vfase1, vfase2, vfase3;		// no. of lines from origin (0-2499 in G)
NUI vfase1old, vfase2old, vfase3old;	// old no. of lines from origin
NUI vbuf1, vbuf2, vbuf3;				// new no. of lines from origin
NUI lincnt1, lincnt2, lincnt3;		// actual line no.
NUL hfase1, hfase2, hfase3;			// no. of minor-steps from origin (a 0.14ns)
NUL hcalg1, hcalg2, hcalg3;			// H calibration G-values
NUL hcalm1, hcalm2, hcalm3;			// H calibration M-values
NUL lastphase1, lastphase2, lastphase3; // store for latest H-phase

NUL CALphaseg1, CALphaseg2, CALphaseg3; // cal H-phase from master G
NUL CALphasem1, CALphasem2, CALphasem3; // cal H-phase from master M
NUI CALschg1, CALschg2, CALschg3;       // cal ScH-phase from master G
NUI CALschm1, CALschm2, CALschm3;       // cal ScH-phase from master M

NUI lastsch1,lastsch2,lastsch3;		//  store for latest sch-phase
NUL offsetg1, offsetg2, offsetg3;	// global offset G ch.1 and 2 (a 0.14ns)
NUL offsetm1, offsetm2, offsetm3;	// global offset M ch.1 and 2 (a 0.14ns)
NUI subfa1, subfa2, subfa3;			// no. of subc-steps (0-2047 in G)
NUI sf1buf, sf2buf, sf3buf;			// new no. of subc-steps
NUI subcoffs1, subcoffs2, subcoffs3;	// subcarr. offset steps
bit syst1, syst2, syst3;				// TV system (1=G)
bit sys1buf, sys2buf, sys3buf;		// new TV system (1=G)
bit poff1, poff2, poff3;				// flag for setup OFF (M) or line7 ON (G)
bit poff1buf, poff2buf,poff3buf;		// buffers for poff
NUL hf1buf, hf2buf, hf3buf;			// new no. of minor-steps from origin
NUI sch1, sch2, sch3;					// SCH-phase in minor-steps
NUI schcalg1, schcalg2, schcalg3;	// SCH-calibration values
NUI schcalm1, schcalm2, schcalm3;	// SCH-calibration values
NUI sch1buf, sch2buf, sch3buf;		// new SCH-phase in sub-steps
bit loaded1, loaded2, loaded3;		// flags for new values available
NUC dalev1, dalev2, dalev3;			// DAC levels
NUC daoff1, daoff2, daoff3;			// DAC offsets
NUC dagain1, dagain2, dagain3;		// DAC gain




void phases1(void){             // puts new phase in first buffer
 				// channel 1
   NUL b, r;


   if (sys1buf)
     ts= tmodg - Number + hcalg1 + offsetg1;


}


void Wr_dac(byte dacno, byte data){

}

void reset1(void)	// HZ  Reset BB1 to default
{  // download default trim
   Wr_dac(1, daclevdef);	// set value
   Wr_dac(2, dacofsdef);
   Wr_dac(7, dacgaindef);

   dalev1= daclevdef;
   daoff1= dacofsdef;
   dagain1= dacgaindef;
   hcalg1= hcaldefg;
   hcalm1= hcaldefm;
   schcalg1= schcaldefg;
   schcalm1= schcaldefm;
}


void load1g(void){    // HG  -receive new phase
  if (std){
    sys1buf= 1;		// system G, channel 1
    poff1buf= 0;		// line7 off
    lastphase1= Number;	// save new phase
	 phases1();
  }
}


void trimphag1(void){  //  HX  BB1   read/set calibration H-phases	  G
   if (req){
		req = 0;
		//return_long(CALphaseg1);
	}
	else if (std){
      std= 0;
      CALphaseg1 = (UL)Number;
      hcalg1= (tmodg-CALphaseg1+hcaldefg) % tmodg;  // from master at power up
    }
}







int main (int argc, char *argv[])
{
offsetg1= offsetg2= offsetg3= 0;	// global phase offset = 0

reset1();	// HZ


Number = 2000;
std = 1;
load1g(); // HG

Number = 1000;
std = 1;
load1g(); // HG

Number = 500;
std = 1;
load1g(); // HG





trimphag1();	// HX  get saved cal value from master


Number = 0;
std = 1;
load1g();	// HG












// new -------------------------------------------
hcalg1 = hcaldefg;
Number = 205;
ts = ts1 = 0;

// h-phase

ts = tmodg - Number + hcalg1 + 0;

// save h-phase calibration
fla_phase1 = Number;

// start after calibration (ok: ts == ts1)
Number = 0;
hcalg1 = (tmodg - fla_phase1 + hcaldefg) % tmodg;
ts1 = tmodg - Number + hcalg1 + 0;



// sch-phase
Number = 777;
schcalg1= schcaldefg;   // ved reset
x = schcalg1;

sch1buf= (Number + x) % 2048;

// save sch-phase calibration
fla_sch1 = Number;




Number = 0;
schcalg1 = (fla_sch1 + schcaldefg) % 2048;
x = schcalg1;
sch1buf= (Number + x) % 2048;
	
	
	
	
	
	
	
	
	return 0;
}
