#include "equ.h"

far UC PLDDACPort @ 0x30000;  // word addr = 0x18000
near UC PLDDAC;
sbit P1_6 @ 0x38E;

/***************************************************************************/
/*	Wr_Dac																 	    		DAC.C	*/
/*																									*/
/* Author:		PF, 991004						    										*/
/* Revised:		991004				     													*/
/*																									*/
/* Function:	u-wire control of 8-bit DAC MB88347L via PLD-Port				*/
/*	Remarks:		dac#: 	 bit 11-8														*/
/*					dac data: bit 7-0															*/
/*					MSB (bit11) is send first												*/
/*					Clock: appr. 150 kHz														*/
/*					DI to DAC V25 is connected to DO of DAC V15						*/
/*	Returns:		--																				*/
/***************************************************************************/


void Wr_dac(UC dacno, UC data){
UI d;
UC n;

 PLDDAC &= 0xF8;		// clear bit 2-0 (LD, DI and CLK)
 PLDDACPort = PLDDAC;
 d = 0;
 switch (dacno){						// select dac no 1-10
	case  1:	d = 0x800; break;
	case  9:	d = 0x800; break;
	case  2:	d = 0x400; break;
	case 10:	d = 0x400; break;
	case  3:	d = 0xC00; break;
	case  4:	d = 0x200; break;
	case  5:	d = 0xA00; break;
	case  6:	d = 0x600; break;
	case  7:	d = 0xE00; break;
	case  8:	d = 0x100; break;
 }
 d += data;    			// put dac data into bit 7-0

 for (n = 0; n < 12; n++) {
 	if ((d & 0x0800) == 0x800)
   	PLDDAC |= 0x02;	// set DI bit 1
     else
   	PLDDAC &= 0xFD;	// clear DI bit 1
	PLDDACPort = PLDDAC;

	PLDDAC |= 0x01;		// set CLK bit 0
	PLDDACPort = PLDDAC;
	PLDDAC &= 0xFE;		// clear CLK bit 0
	PLDDACPort = PLDDAC;
  
	d <<= 1;					// shift to next bit
 } //for

 PLDDAC &= 0xF8;		// clear bit 2-0 (LD, DI and CLK)
 PLDDACPort = PLDDAC;
 if (dacno > 8){  // clock 12 times with DI = low
	for (n = 0; n < 12; n++){
	 PLDDAC |= 0x01;		// set CLK bit 0
	 PLDDACPort = PLDDAC;
	 PLDDAC &= 0xFE;		// clear CLK bit 0
	 PLDDACPort = PLDDAC;
	}
 }

  PLDDAC |= 0x04;			// start converting - set LD bit 2
  PLDDACPort = PLDDAC;
  PLDDAC &= 0xFB;			// clear LD bit 2
  PLDDACPort = PLDDAC;

 for (n = 0; n < 10; n++)	// delay to settle dac-output
  d=0;
 
}


