SUPERMAX E-CAD drill version 7.0.7
plated :
   num: 4300 size:  15.8mill =   0.4mm TOL= +0/-0.2mm
   num:   2 size:  15.8mill =   0.4mm
   num:   6 size:  35.4mill =   0.9mm
   num:  49 size:  39.4mill =     1mm
   num:   4 size:  47.2mill =   1.2mm
   num:   7 size:  55.1mill =   1.4mm
   num:   6 size:    63mill =   1.6mm
   num:  12 size:  78.7mill =     2mm
   num:   7 size:   126mill =   3.2mm
non plated :
   num: 192 size:  31.5mill =   0.8mm
   num:  14 size:  59.1mill =   1.5mm
   num:   2 size:    63mill =   1.6mm
   num:   6 size: 118.1mill =     3mm
   num:   2 size:   126mill =   3.2mm
first drilled hole x,y (14150,1993.8) mill = (359.41, 50.64) mm
FILE 72211 BYTES 1204<x<15574 and 1204<y<14393 lay : 255
drill completed
