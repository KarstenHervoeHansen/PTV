// NISerial.h, File Version: 1.5
// Extended I/O Control functions for National Instruments Serial Products
//
// National Instruments
// 11500 N Mopac Expwy
// Austin, TX 78759-3504  USA
//
// For support:  ni.com/support
//
// Copyright (c) 2002 National Instruments Corporation. All Rights Reserved.
//
// This file contains #defines and example code that can be used to access the 
// advanced features of NI-Serial products.  Please refer to the User Manual
// to determine which features and functions are supported with your hardware.
//
// Note:  These extended serial functions should only be used with NI-Serial
// hardware. 
//
// Note:  Using this functions with non-supported hardware may result in
// unexpected behavior.

#ifndef _NISERIAL_
#define _NISERIAL_

// These functions use the DeviceIoControl Windows function.  This function
// is defined in <winioctl.h>:
// 
// 	BOOL DeviceIoControl(
//  		HANDLE hDevice,			// handle to device (returned from CreateFile)
//  		DWORD dwIoControlCode,		// operation (ex: NISERIAL_SET_RS485_MODE)
//  		LPVOID lpInBuffer,			// pointer to input data buffer
//  		DWORD nInBufferSize,		// size of input data buffer
//  		LPVOID lpOutBuffer,			// pointer to output data buffer
//  		DWORD nOutBufferSize,		// size of output data buffer
//  		LPDWORD lpBytesReturned,		// byte count of output data buffer - always a pointer to a ULONG
//  		LPOVERLAPPED lpOverlapped	// overlapped information (always NULL for these functions)
// 	);

typedef ULONG TRANSCEIVER_MODE;   		// used for RS-485 and RS-232 transceiver mode functions

// RS-485 Transceiver Mode #defines
// ----------------------------------------------------------------------------

#define RS485_MODE_4WIRE		0x0		// Four-wire mode 
#define RS485_MODE_2W_ECHO   	0x1		// Two-wire DTR Control with echo
#define RS485_MODE_2W_DTR    	0x2	  	// Two-wire DTR Control without echo
#define RS485_MODE_2W_AUTO   	0x3		// Two-wire Auto Control
#define RS485_MODE_END_ENUM		0x4		// Not valid... Use for bounds checking only
#define RS485_MODE_DEFAULT   	RS485_MODE_4WIRE				

#define NISERIAL_SET_RS485_MODE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4091,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the current RS-485 transceiver mode
Input data buffer: TRANSCEIVER_MODE
Output data buffer: NULL

**Example**

ULONG bytecount;
TRANSCEIVER_MODE transceiver_mode = RS485_MODE_4WIRE;	// Set to four-wire mode
DeviceIoControl(
 	comhandle, 
	NISERIAL_SET_RS485_MODE,
	(PVOID) &transceiver_mode, sizeof(transceiver_mode),
 	(PVOID) NULL, 0,
	&bytecount,
 	NULL
);
*/

// The following is made available to set the RS-485 Transceiver Mode for legacy products and applications
// RS-485 Transceiver Mode #defines
// ----------------------------------------------------------------------------
#define SERIAL_TM_4WIRE		  0x80
#define SERIAL_TM_2W_ECHO	  0x81
#define SERIAL_TM_2W_DTR	  0x82
#define SERIAL_TM_2W_AUTO	  0x83

#define SERIAL_IOCTL_SET_TRANSCEIVER_MODE CTL_CODE(FILE_DEVICE_SERIAL_PORT,37,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the current RS-485 transceiver mode
Input data buffer: TRANSCEIVER_MODE
Output data buffer: NULL

**Example**

ULONG bytecount;
TRANSCEIVER_MODE transceiver_mode = SERIAL_TM_4WIRE;	// Set to four-wire mode
DeviceIoControl(
 	comhandle, 
	SERIAL_IOCTL_SET_TRANSCEIVER_MODE,
	(PVOID) &transceiver_mode, sizeof(transceiver_mode),
 	(PVOID) NULL, 0,
	&bytecount,
 	NULL
);
*/


#define NISERIAL_GET_RS485_MODE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4090,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current RS-485 transceiver mode as set by SET_RS485_MODE or the control panel
Input data buffer: NULL
Output data buffer: TRANSCEIVER_MODE

**Example**		   

ULONG bytecount;
TRANSCEIVER_MODE transceiver_mode;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_RS485_MODE,
	(PVOID) NULL, 0,
	(PVOID) &transceiver_mode, sizeof(transceiver_mode),
	&bytecount,
	NULL
);
*/

// RS-232 Transceiver Mode #defines
#define RS232_MODE_DTE	    	0x00		// DTE mode	
#define RS232_MODE_DCE	    	0x01		// DCE mode
#define RS232_MODE_AUTO	    	0x02	 	// 232Auto (automatic detect) mode
#define RS232_MODE_END_ENUM  	0x03		// Not valid... Use for bounds checking only
#define RS232_MODE_DEFAULT   	RS232_MODE_DTE	

#define NISERIAL_SET_RS232_MODE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4081,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the current RS-232 transceiver mode
Input data buffer: TRANSCEIVER_MODE
Output data buffer: NULL

**Example**

ULONG bytecount;
TRANSCEIVER_MODE transceiver_mode = RS232_MODE_AUTO;	// Set to 232Auto Mode
DeviceIoControl(
	comhandle,
	NISERIAL_SET_RS232_MODE,
	(PVOID) &transceiver_mode, sizeof(transceiver_mode),
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/
					  
#define NISERIAL_GET_RS232_MODE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4080,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current RS-232 transceiver mode as set by SET_RS232_MODE or the control panel
Input data buffer: NULL
Output data buffer: TRANSCEIVER_MODE

**Example**		   

ULONG bytecount;
TRANSCEIVER_MODE transceiver_mode;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_RS232_MODE,
	(PVOID) NULL, 0,
	(PVOID) &transceiver_mode, sizeof(transceiver_mode),
	&bytecount,
	NULL
 );
*/

// RS-232 Transceiver State #defines
typedef ULONG SERIAL_CONNECTION;
#define SERIAL_CONNECTION_INVALID	0x00
#define SERIAL_CONNECTION_VALID	0x01
#define SERIAL_CONNECTION_END_ENUM	0x02	// Not valid... Use for bounds checking only	

// This struct is passed in the output data buffer
typedef struct _SERIAL_RS232_STATE {	
	TRANSCEIVER_MODE	PortMode;
	SERIAL_CONNECTION	Connection;
} SERIAL_RS232_STATE,*PSERIAL_RS232_STATE;

#define NISERIAL_GET_RS232_STATE	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4082,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current RS-232 mode (DTE or DCE) and connection state (valid or invalid) 
	Note:  If Connection is SERIAL_CONECTION_INVALID, and TRANSCEIVER_MODE is RS232_MODE_AUTO, then PortMode
	will be unknown, and may report as either DTE or DCE.  
Input data buffer: NULL
Output data buffer: SERIAL_RS232_STATE

**Example**		   

ULONG bytecount;
SERIAL_RS232_STATE serial_rs232_state;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_RS232_STATE,
	(PVOID) NULL, 0,
	(PVOID) &serial_rs232_state, sizeof(serial_rs232_state),
	&bytecount,
	NULL
); 
*/

#define NISERIAL_SET_DCD		    	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4072,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the DCD line when the RS-232 port is in DCE mode (may be ignored when in DTE mode)
Input data buffer: NULL
Output data buffer: NULL

**Example**
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_SET_DCD,
	(PVOID) NULL, 0,
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/

#define NISERIAL_CLR_DCD		    	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4071,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Clears the DCD line when the RS-232 port is in DCE mode (may be ignored when in DTE mode)
Input data buffer: NULL
Output data buffer: NULL

**Example**

DeviceIoControl(
	comhandle,
	NISERIAL_CLR_DCD,
	(PVOID) NULL, 0,
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/

// GET_DCD #defines
typedef bool SERIAL_DCD_OUT;
#define SERIAL_DCD_ON	true
#define SERIAL_DCD_OFF	false

#define NISERIAL_GET_DCD		    	CTL_CODE(FILE_DEVICE_SERIAL_PORT,4070,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current status of the DCD line when the RS-232 port is in DCE mode 
as set by SET_DCD and CLR_DCD.  This value is NOT the same as returned by GetCommModemStatus
Input data buffer: NULL
Output data buffer: SERIAL_DCD_OUT

**Example**

SERIAL_DCD_OUT serial_dcd_out;
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_DCD,
	(PVOID) NULL, 0,
	(PVOID) &serial_dcd_out, sizeof(serial_dcd_out),
	&bytecount,
	NULL
);
*/

#define NISERIAL_SET_RI				CTL_CODE(FILE_DEVICE_SERIAL_PORT,4062,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the RI line when the RS-232 port is in DCE mode (may be ignored when in DTE mode)
Input data buffer: NULL
Output data buffer: NULL

**Example**

ULONG bytecount;
DeviceIoControl(
 	comhandle,
	NISERIAL_SET_RI,
	(PVOID) NULL, 0,
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/

#define NISERIAL_CLR_RI				CTL_CODE(FILE_DEVICE_SERIAL_PORT,4061,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Clears the RI line when the RS-232 port is in DCE mode (may be ignored when in DTE mode)
Input data buffer: NULL
Output data buffer: NULL

**Example**

ULONG bytecount;
DeviceIoControl(
 	comhandle,
	NISERIAL_CLR_RI,
	(PVOID) NULL, 0,
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/

// GET_RING_INDICATOR #defines
typedef bool SERIAL_RI_OUT;
#define SERIAL_RI_ON	true
#define SERIAL_RI_OFF	false

#define NISERIAL_GET_RI 	  			CTL_CODE(FILE_DEVICE_SERIAL_PORT,4060,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current status of the RI line when the RS-232 port is in DCE mode 
as set by SET_RI and CLR_RI.  This value is NOT the same as returned by GetCommModemStatus
Input data buffer: NULL
Output data buffer: SERIAL_RI_OUT

**Example**

SERIAL_RI_OUT serial_ri_out;
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_RI,
	(PVOID) NULL, 0,
	(PVOID) &serial_ri_out, sizeof(serial_ri_out),
	&bytecount,
	NULL
);
*/
 
// 485_BIAS #defines
typedef ULONG SERIAL_RS485_BIAS;
#define RS485_BIAS_OFF			0
#define RS485_BIAS_ON			1
#define RS485_BIAS_END_ENUM		2
#define RS485_BIAS_DEFAULT		RS485_BIAS_ON

#define NISERIAL_SET_RS485_BIAS    		CTL_CODE(FILE_DEVICE_SERIAL_PORT,4031,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Sets the RS-485 bias resistor mode
Input data buffer: SERIAL_RS485_BIAS
Output data buffer: NULL

**Example**

SERIAL_RS485_BIAS serial_rs485_bias = RS485_BIAS_ON;	// Turn on RS-485 on-board biasing
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_SET_RS485_BIAS,
	(PVOID) &serial_rs485_bias, sizeof(serial_rs485_bias),
	(PVOID) NULL, 0,
	&bytecount,
	NULL
);
*/

#define NISERIAL_GET_RS485_BIAS    		CTL_CODE(FILE_DEVICE_SERIAL_PORT,4030,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current RS-485 bias resistor mode as set by SET_RS485_BIAS or the control panel
Input data buffer: NULL
Output data buffer: SERIAL_RS485_BIAS

**Example**

SERIAL_RS485_BIAS serial_rs485_bias;
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_RS485_BIAS,
	(PVOID) NULL, 0,
	(PVOID) &serial_rs485_bias, sizeof(serial_rs485_bias),
	&bytecount,
	NULL
);
*/

// GET_INTERFACE_TYPE #defines
typedef ULONG SERIAL_INTERFACE;
#define RS485_INTERFACE			0x00
#define RS232_INTERFACE			0x01
#define INTERFACE_END_ENUM		0x02		// Not valid... Use for bounds checking only
#define DEFAULT_INTERFACE		RS232_INTERFACE

#define NISERIAL_GET_INTERFACE_TYPE		CTL_CODE(FILE_DEVICE_SERIAL_PORT,4050,METHOD_BUFFERED,FILE_ANY_ACCESS)
/*
Returns the current serial interface type (physical layer)
Input data buffer: NULL
Output data buffer: SERIAL_INTERFACE

**Example**

SERIAL_INTERFACE serial_interface
ULONG bytecount;
DeviceIoControl(
	comhandle,
	NISERIAL_GET_INTERFACE_TYPE,
	(PVOID) NULL, 0,
	(PVOID) &serial_interface, sizeof(serial_interface),
	&bytecount,
	NULL
);
*/

#endif // _NISERIAL_