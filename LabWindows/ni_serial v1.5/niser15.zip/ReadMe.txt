National Instruments Serial Software for Windows 2000/NT/XP/Me/9x for the
AT-232, AT-485, PCMCIA-232, PCMCIA-485, PCI-232, PCI-485, 
PXI-8420, PXI-8421, PXI-8422 and PXI-8423
Version 1.5

Copyright (C) National Instruments Corp. 1995-2003 
All Rights Reserved.

Thank you for purchasing this Serial interface board and NI-Serial software
for Microsoft Windows 2000/NT/XP/Me/9x.

We appreciate communicating with the people who use our products.  We are
also very interested in hearing about the applications you develop using
our products. Our web-site at "ni.com" provides advanced support and 
services, and contact information.

=============================
Contents of this Distribution
=============================
1. Full Installer: Running SETUP.EXE will launch the full installer (including
   options to choose Product Manuals, and Acrobat� Reader).
2. "Acrobat" folder: Contains one file that will install Acrobat� Reader 5.05.
3. "Floppy" folder: The contents of this folder can be copied to a 1.44Mb floppy
   to create a single-floppy minimum installer (without product manuals, etc.)
4. "NI-Serial Documentation" folder: Contains the product manual for all the different
   hardware platforms for various Windows operating systems, in Portable
   Document Format (PDF).
5. "Win2000XP", "WinMe9x", "WinNT" folders: These contain the actual program
   files that are installed for each operating system.