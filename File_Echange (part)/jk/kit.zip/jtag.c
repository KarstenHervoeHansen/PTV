/***************************************************************************/
/*  Copyright DK-Audio A/S, 2006                                           */
/*  Project:  JTAG HDTPG FPGA programmer, using 8051F320 Cygnal            */
/*            processor.                                                   */
/*  Module:   jtag.C                                                       */
/*  Author:   Jnausz Kuzminski                                             */
/*  Date:     02.06.2006                                                   */
/*  Status:   Version 1.0                                                  */
/*  Purpose:  Main program for PT8641 JTAG programmer example.             */
/*  Note:                                                                  */
/*  Note:    F320 has 16K Flash and                                        */
/*           Internal RAM  255 bytes                                       */
/*           XARM         1024 bytes                                       */
/*           XRAM         1024 dedicated as USB buffer.                    */
/*           This program uses software supplied by Xilinx to program FPGA */
/*           with .xvf file (modules: lenval.c, micro.c and ports.c).      */
/*           The .xvf file is transmitted by a PC, in binary form, using   */
/*           a simple soft-handshake protocol.  function xsvfExecute()     */
/*           retirieves received data and controls JTAG signals.           */
/*           JTAG pins are defined in ports.c                              */
/*           Serial COM params are 115200, n, 8, 1                         */
/*           All initailization is in ini.c.                               */
/*                                                                         */
/***************************************************************************/
#pragma WARNINGLEVEL (1) /* Lists only those warnings which may generate   */
                         /* incorrect code. Default is 2.                  */
/***************************************************************************/


#include <C8051F320.h>
#include "define.h"
#include <string.h>
#include "micro.h"
#include "ports.h"
#include "serial.h"


/*
//-------------------
// Global CONSTANTS
//-------------------
*/
#include "io.c"

/*************************/
/*  Function PROTOTYPES  */
/*************************/
void config(void);


void main (void)
  {
  UC i;
  UC j;

  config();
  serinit();

  LED = 1;
  flush();

  ES0 = 1;       /* Enable serial interrupt   */
  EA  = 1;

#if 0
  /* Do simple echoing of incoming characters */
  while (1)
    {
    if (getch(&i)) 
      putch(i);
    LED = ~LED;
    }
#endif



lab1:
  flush();

  putch('S');
  putch('T');
  putch('A');

  /* Do simple hanshaking (synhronnization) at the beginning */
  while (1)
    {
    if (getch(&i))       /* wait for START from SERVER (transmits START) */
      {                  /* removes  START sent by master */
      /* The flush() below is not in order to flush, but to zero rx_outptr */
      flush(); 
      break;
      }
    else
      continue;
    }

  LED = 0;
  i = xsvfExecute();  /* do JTAG progamming */
  LED = 0;

  if (i != 0)         /* if not success.... */
    {
    putch(ERR);
    putch('E');
    putch('R');
    putch('R');
    putch('O');
    putch('R');
    putch('\n');
    LED = 0;
  while (1)           /* and stop here */
    ;
    }
  else
    {
    putch(SUCCESS);   /* signal success */
    LED = 1;
    }
  putch('O');
  putch('K');
  putch('\n');
  //goto lab1;
  while (1)           /* and stop here */
    ;
   }

