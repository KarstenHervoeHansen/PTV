/***************************************************************************/
/*  Copyright DK-Audio A/S, 2005                                           */
/*  Project:  PT8641 HDTPG (PT8612), using 8051F320 Cygnal                 */
/*            processor.                                                   */
/*  Module:   ini.C                                                        */
/*  Author:   Jnausz Kuzminski                                             */
/*  Date:     01.03.2006                                                   */
/*  Status:   Version 1.0                                                  */
/*  Purpose:  This is initialization routine obtained from Cygnal config   */
/*            wizard version 2.04 for F320 processor.                      */
/*            UART uses Timer0 for Baud Rate.                              */
/***************************************************************************/
#include <C8051F320.h>  // Register definition file.

void config (void)
  {
  int n = 0;

  PCA0MD &= ~0x40;     //disable watchdog timer

//----------------------------------------------------------------
// CROSSBAR REGISTER CONFIGURATION
//
// NOTE: The crossbar register should be configured before any  
// of the digital peripherals are enabled. The pinout of the 
// device is dependent on the crossbar configuration so caution 
// must be exercised when modifying the contents of the XBR0, 
// XBR1 registers. For detailed information on 
// Crossbar Decoder Configuration, refer to Application Note 
// AN001, "Configuring the Port I/O Crossbar Decoder". 
//----------------------------------------------------------------

// Configure the XBRn Registers

  XBR0 = 0x01;  // Crossbar Register 1
  XBR1 = 0x40;  // Crossbar Register 2 (weak pull-ups globally disabled)
                // (weak pull-ups globally enabled = 0x40)
/* We must have weak pull-ups enabled, otherwise if there is no */
/* load on input port, reading from it may give changing level. */

// Select Pin I/0

// NOTE: Some peripheral I/O pins can function as either inputs or 
// outputs, depending on the configuration of the peripheral. By default,
// the configuration utility will configure these I/O pins as push-pull 
// outputs.
                      // Port configuration (1 = Push Pull Output)
    P0MDOUT = 0xC3; // Output configuration for P0 (bit 7 as LEVOK)
    P1MDOUT = 0xFC; // Output configuration for P1 
    P3MDOUT = 0x00; // Output configuration for P3 

    P0MDIN = 0xF3;  // Input configuration for P0
    P1MDIN = 0xFF;  // Input configuration for P1
    P3MDIN = 0xFF;  // Input configuration for P3

    P0SKIP = 0x0C;  //  Port 0 Crossbar Skip Register
    P1SKIP = 0x00;  //  Port 1 Crossbar Skip Register


/* New values for JTAG signals from P2 */
  P2MDOUT = 0xFC;   /* Output configuration for P2 (0x0C)           */
  P2MDIN  = 0xFC;   /* Input configuration for P2                   */
  P2SKIP  = 0x00;   /* Port 2 Crossbar Skip Register                */


//----------------------------------------------------------------
// Comparator Register Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// Oscillator Configuration
//----------------------------------------------------------------

  OSCXCN = 0x67;  // EXTERNAL Oscillator Control Register 
#if 1
  for (n = 0; n < 255; n++)
    ;
#endif                              // wait for osc to start
  while ( (OSCXCN & 0x80) == 0 )
    ;                              // wait for xtal to stabilize

  CLKSEL = 0x01;   // = External Oscillator
  //OSCICN = 0x03;   // Internal Oscillator Control Register

//----------------------------------------------------------------
// SPI Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// Reference Control Register Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// ADC Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// UART0 Configuration
//----------------------------------------------------------------
    SCON0 = 0x30; //0x98; //0x30;        // Serial Port Control Register

    PCON  = 0x00;       // Power Control Register

//----------------------------------------------------------------
// SMBus Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// PCA Configuration
//----------------------------------------------------------------
//----------------------------------------------------------------
// Timers Configuration 9600 BR @ 11.059200 MHz
//----------------------------------------------------------------
#if 0
    CKCON = 0x01;     // Clock Control Register: Timer1 uses SYSCLK / 4
    TL0   = 0x00;     // Timer 0 Low Byte
    TH0   = 0x00;     // Timer 0 High Byte
    TL1   = 0x00;     // Timer 1 Low Byte
    TH1   = 0x70;     // BaudRate = 9600
    TMOD  = 0x20;     // Timer Mode Register
    TCON  = 0x40;     // Timer Control Register 
    
#else
//----------------------------------------------------------------
// Timers Configuration 115200 BR @ 11.059200 MHz
//----------------------------------------------------------------

    CKCON = 0x08;     // Clock Control Register: Timer1 uses SYSCLK
    TL0   = 0x00;     // Timer 0 Low Byte
    TH0   = 0xFF;     // Timer 0 High Byte
    TL1   = 0x00;     // Timer 1 Low Byte
    TH1   = 0xD0;     // BaudRate = 115200
    TMOD  = 0x20;     // Timer Mode Register
    TCON  = 0x00;     // Timer Control Register 

#endif
//----------------------------------------------------------------
// Reset Source Configuration
// NOTE! : Comparator 0 must be enabled before it is enabled as a 
// reset source.
//------------------------------------------------------------------
  RSTSRC = 0x00;  // Reset Source Register

  TR1 = 1;       //start timer1
  RI0 = 0;       //clear receive interrupt bit
  TI0 = 0;       //clear transmit interrupt bit

  }              //End of config
