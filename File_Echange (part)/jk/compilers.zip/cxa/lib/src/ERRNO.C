/*
 *	Version : @(#)errno.c	1.3	
 */

/**************************************************************************
**                                                                        *
**  FILE        :  errno.c                                                *
**                                                                        *
**  DESCRIPTION :  Definition of common used errno variable.              *
**                                                                        *
**  COPYRIGHT   :  1996 Copyright TASKING, Inc.                           *
**                                                                        *
**************************************************************************/

int errno;	
