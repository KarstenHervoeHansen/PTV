/*
 *	@(#)remove.c	1.3
 */

/**************************************************************************
**                                                                        *
**  FILE        :  remove.c                                               *
**                                                                        *
**  DESCRIPTION :  Source file for remove() routine                       *
**                                                                        *
**                 This routine should be customised.                     *
**                                                                        *
**  COPYRIGHT   :  1996 Copyright TASKING, Inc.                           *
**                                                                        *
**************************************************************************/

#include <stdio.h>

int
remove( const char * name )
{
	name;
	return( 0 );
}
