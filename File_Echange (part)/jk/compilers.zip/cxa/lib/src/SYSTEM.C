/*
 *	@(#)system.c	1.3
 */

/**************************************************************************
**                                                                        *
**  FILE        :  system.c                                               *
**                                                                        *
**  DESCRIPTION :  Skeleton for system() function.                        *
**                                                                        *
**  COPYRIGHT   :  1996 Copyright TASKING, Inc.                           *
**                                                                        *
**************************************************************************/

#include <stdlib.h>

int system( const char *s )
{
	return 0;
}

