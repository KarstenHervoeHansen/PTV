/*
 *	@(#)getenv.c	1.3
 */

/**************************************************************************
**                                                                        *
**  FILE        :  getenv.c                                               *
**                                                                        *
**  DESCRIPTION :  Skeleton for getenv() function.			  *
**                                                                        *
**  COPYRIGHT   :  1996 Copyright TASKING, Inc.                           *
**                                                                        *
**************************************************************************/

#include <stdlib.h>

char *getenv( const char *name )
{
	name;
	return NULL;
}

