/*
 *	@(#)rename.c	1.3
 */

/**************************************************************************
**                                                                        *
**  FILE        :  rename.c                                               *
**                                                                        *
**  DESCRIPTION :  Source file for rename() routine                       *
**                                                                        *
**                 This routine should be customised.                     *
**                                                                        *
**  COPYRIGHT   :  1996 Copyright TASKING, Inc.                           *
**                                                                        *
**************************************************************************/

#include <stdio.h>

int
rename( const char * old, const char * new )
{
	old;
	new;
	return( 0 );
}
