/***************************************************************************/
/*  Copyright DK-Audio A/S, 2005                                           */
/*  Project:  PT8641 HDTPG, using 8051F320 Cygnal                          */
/*            processor.                                                   */
/*  Module:   PT8641.C                                                     */
/*  Author:   Jnausz Kuzminski                                             */
/*  Date:     23.02.2006                                                   */
/*  Status:   Version 2.0                                                  */
/*  Purpose:  Main program for PT8641 unit.                                */
/*  Note:                                                                  */
/*  Note:    F320 has 16K Flash and                                        */
/*           Internal RAM  255 bytes                                       */
/*           XARM         1024 bytes                                       */
/*           XRAM         1024 dedicated as USB buffer.                    */
/*                                                                         */
/*  Changes:  19.04.2006: new signal   LEVOK = 1; to master introduced.    */
/***************************************************************************/
#pragma WARNINGLEVEL (1) /* Lists only those warnings which may generate   */
                         /* incorrect code. Default is 2.                  */
/***************************************************************************/


#include <C8051F320.h>
#include "define.h"
#include <string.h>
#include "cmd.h"
#include "eeprom.h"

/*
//-------------------
// Global CONSTANTS
//-------------------
*/
#include "io.c"

/*************************/
/*  Function PROTOTYPES  */
/*************************/
void init_all(void);
void config(void);


void main (void)
  {
  config();

  RS232Init();

  I2cInit(); /* program will hang here if no eeprom mounted! */

  LED   = 0;
  LEVOK = 1;
  while (1)
    {
    if (TestInputBuffer())
      CharHandler();
    }
  }

