

typedef struct COMMAND_STRUCT
  {
  char Cmd1;
  char Cmd2;
/*  void ( *Exec)(); No more function pointers, to enable overlaying */
  };


extern UC   MySlaveAddress;
extern UL   Parameter[3];
extern char CmdDelimiter;
extern char Cmd[2];
extern char idata String[17]; /* used to hold string, if sent by master */


void send(UC gen, UI, UC*, int);
UC   spi_transfer (UC, UC);
void CharHandler(void);
void WriteString(UC idata *);
void WriteVal(UL);
void WriteChar(char);
bit  TestInputBuffer(void);
void RS232break(void);
void RS232Init(void);

