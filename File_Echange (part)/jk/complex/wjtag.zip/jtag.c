/***************************************************************************/
/*  Copyright DK-Audio A/S, 2006                                           */
/*  Project:  JTAG HDTPG FPGA programmer, using 8051F320 Cygnal            */
/*            processor.                                                   */
/*  Module:   jtag.C                                                       */
/*  Author:   Jnausz Kuzminski                                             */
/*  Date:     02.06.2006                                                   */
/*  Status:   Version 1.0                                                  */
/*  Purpose:  Main program for PT8641 JTAG programmer.                     */
/*  Note:                                                                  */
/*  Note:    F320 has 16K Flash and                                        */
/*           Internal RAM  255 bytes                                       */
/*           XARM         1024 bytes                                       */
/*           XRAM         1024 dedicated as USB buffer.                    */
/*                                                                         */
/***************************************************************************/
#pragma WARNINGLEVEL (1) /* Lists only those warnings which may generate   */
                         /* incorrect code. Default is 2.                  */
/***************************************************************************/


#include <C8051F320.h>
#include <stdio.h>
#include "define.h"
#include <string.h>
#include "micro.h"
#include "ports.h"
#include "serial.h"


/*
//-------------------
// Global CONSTANTS
//-------------------
*/
#include "io.c"

/*************************/
/*  Function PROTOTYPES  */
/*************************/
void config(void);


void main (void)
  {
  UC i;

  config();


  EA   = 1;   //global interrupt enable
  D4   = 0;
  D2   = 0;
  i    = 0;
#if 1
  flush();
  while (1)
    {
    if (!getch(&i))       /* wait for START from SERVER (transmits START) */
      {
      continue;
      }
    else
      break;
    }
#endif
  flush();
  i = xsvfExecute();
  
  if (i != 0)
    {
    putch(ERR);
    D2 = 1;
    }
  else
    {
    putch(SUCCESS);
    }

  while (1)
    ;
      //pulseClock();
  }

