#pragma code symbols debug objectextend
 /*
 ; DK-Technologies A/S
 ;
 ; FILE NAME        serial.c
 ; PURPOSE          Module containing serial port 0 interrupt routine and
 ;                  character output routine for 8051F320 Cygnal
 ;                  processor.
 ; SPEC             Janusz Kuzminski
 ; DESIGN           Janusz Kuzminski
 ; CODING           Janusz Kuzminski
 ; CODE INSP.
 ; TEST
 ; LAST UPDT:       28.06.2006.
 ;
 ; NOTES:           This module contains serial comms routines
 ;                  for 8051F320 Cygnal processor.  Both reception and
 ;                  transmission are interrupt controlled.
 ;
 ;
*/



#include <C8051F320.h>
#include "define.h"
#include "serial.h"

#define RX_SERBUFLEN  50 //64
#define TX_SERBUFLEN  50 //64

#define DEFDEL        100
#define T2START  Timer2_Init(0x7fff)

UC idata rx_serbuf[RX_SERBUFLEN];
UC rx_inptr;
UC rx_outptr;

UC idata tx_serbuf[TX_SERBUFLEN];
UC tx_inptr;
UC tx_outptr;
UC timoutlo;
UC timouthi;

UC bdata serflags;
sbit  tempty    = serflags^0; /* transmiter empty flag */
sbit  T2timeout = serflags^1;

sfr16 TMR2RL    = 0xca;                    // Timer2 reload value
sfr16 TMR2      = 0xcc;                    // Timer2 counter

UC    t2del;

/**********************************************************************
 * NAME       void flush(void)
 * PURPOSE    
 *            To initialize buffers for reception and transmission.
 *
 * ARGUMENTS  None
 *
 * RETURNS    Nothing
 *
 * EXTERNS    None.
 *
/*  Notes:    
 **********************************************************************/
void flush(void)
  {
  rx_inptr  = 0;
  rx_outptr = 0;
  tempty    = 1;
  }

#if 0
bit serhit(void)
  {
  if (rx_inptr != rx_outptr)
    return 1;
  else
    return 0;
  }
#endif

/**********************************************************************
 * NAME       char putch (char c)
 * PURPOSE    To place character in transmiter buffer and, if transmiter
 *            is empty, commence transmission (TI0 = 1)
 *
 * ARGUMENTS  Character to output
 *
 * RETURNS    Character to output.
 *
 * EXTERNS    None.
 *
 * NOTES:     
 **********************************************************************/
UC putch(UC c)
  {
  ES0 = 0; /* disable serial interrupt while mainipulatig buffer */
  tx_serbuf[tx_inptr] = c;
  tx_inptr++;
  if (tx_inptr == TX_SERBUFLEN)
    tx_inptr = 0;

  if (tempty)
    {
    tempty = 0;
    TI0 = 1;     /* restart manually the interrupt routine if tempty */
    }
  ES0 = 1;
  return(c);
  }

/**********************************************************************
 * NAME       void serint0(void) interrupt 4 using 1
 * PURPOSE    This is serial reception/transmission interrut routine.
 *
 * ARGUMENTS  None
 *
 * RETURNS    Nothing
 *
 * EXTERNS    None.
 *
 * NOTES:     When receiving character interrupt occurs, it is read 
 *            from UART and placed into rx_serbuf[].  Input pointer
 *            to this buffer (rx_serbuf) is incremented and on reaching
 *            RX_SERBUFLEN zeroed, i.e. no buffer overflow check is 
 *            implemented.
 * 
 *            When transmitting (when a character has left the UART),
 *            next character (if any) is fetched from tx_serbuf[] and
 *            moved to the UART.  Output pointer to this buffer is 
 *            incremented and if equal to TX_SERBUFLEN, zeroed.  No 
 *            check for buffer overflow is made.
 *            void serint0(void) interrupt 4 using 1
 **********************************************************************/
void serint0(void)
  {
  if (RI0)
    {
    rx_serbuf[rx_inptr] = SBUF0;
    RI0 = 0;
    rx_inptr++;
    if (rx_inptr == RX_SERBUFLEN)
      rx_inptr = 0;
    }
  else
    {
    if (TI0) /* means that a character has left the transmitter */
      {
      if (tx_outptr != tx_inptr) /* if another character waiting in buffer */
        {
        TI0 = 0;
        SBUF0 = tx_serbuf[tx_outptr];
        tx_outptr++;
        if (tx_outptr == TX_SERBUFLEN)
          tx_outptr = 0;
        }
      else  /* tx_outptr = tx_inptr and TI0: last character left buffer */
        {
        TI0 = 0;
        tempty = 1;
        }
      }
    }
  }

/**********************************************************************
 * NAME       UC getch(UC * c)
 * PURPOSE    To fetch a character from serial buffer.
 *
 * ARGUMENTS  None
 *
 * RETURNS    0 - if there is no character to fetch after timeout
 *            1 - otherwise
 *
 * EXTERNS    None.
 *
 * NOTES:     
 **********************************************************************/
UC getch(UC * c)
  {

  if (rx_outptr == 0)
    putch(START);

  T2START;

  while (rx_inptr == rx_outptr)
    {
    if (T2timeout)
      {
      TR2 = 0;   // stop Timer2
      return (0);
      }
    }

  TR2 = 0;       // stop Timer2
  ES0 = 0;
  *c = rx_serbuf[rx_outptr];
  rx_outptr++;
  if (rx_outptr == RX_SERBUFLEN)
    rx_outptr = 0;
  ES0 = 1;
  return (1);
  }

/**************************************************************************/
/*  Timer 2 used for timeout delay                                        */
/**************************************************************************/
// Configure Timer2 to 16-bit auto-reload and generate an interrupt at 
// interval specified by <counts> using SYSCLK/48 as its time base.
//
void Timer2_Init (int counts)
  {
  TMR2CN    = 0x00;        // Stop Timer2; Clear TF2;
                           // use SYSCLK/12 as timebase
  TMR2RL    = -counts;     // Init reload values
  TMR2      = 0xffff;      // set to reload immediately
  ET2       = 1;           // enable Timer2 interrupts
  TR2       = 1;           // start Timer2
  t2del     = DEFDEL;
  T2timeout = 0;
  }
//-----------------------------------------------------------------------------
// Timer2_ISR
//-----------------------------------------------------------------------------
// This routine changes the state of the LED whenever Timer2 overflows.
//
void Timer2_ISR (void) interrupt 5
  {
  TF2H = 0;               // clear Timer2 interrupt flag

  t2del--;
  if (!t2del)
    {
    T2timeout = 1;
    t2del = DEFDEL;
    }
  }


/* end of serial.c */

