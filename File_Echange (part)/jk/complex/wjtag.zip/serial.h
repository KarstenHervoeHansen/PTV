/* serial.h */

UC   getch(UC *);
bit  serhit(void);
void serint0(void);
UC   putch(UC);
void flush(void);
void Timer2_Init (int);
void Timer2_ISR (void);

