/************************************************************************
 * FILE NAME        wxcom.c
 * PURPOSE          Module implementing character based serial
 *                  communication library for Windows.
 *
 * SPEC             Janusz Kuzminski
 * DESIGN           Janusz Kuzminski
 * CODING           Janusz Kuzminski
 * CODE INSP.
 * TEST             This module is tested with rgb.c program, which
 *                  originally was written for DOS together with 
 *                  DOS serial communication module xcom.c
 *                  rgb.c and wxcom.c are compiled by bcc32, resulting
 *                  in 32bit DOS protected mode executable.
 *                  Behaviour of this executable must be identical to 
 *                  one obtained for DOS (compiled with BC3).
 *                  This module was also tested with loadall.c ver.3,
 *                  which is a program for uploading program data to PT5202.
 *
 * LAST UPDT:       19.01.2005
 *                  02.02.2005: Names of certain functions changed.
 *                  14.06.2006: Xcom_Getch() function added.
 *
 * NOTES:           This module contains functions with the same names
 *                  and functionalities as xcom.c module.
 *                  
 *                  Timeouts on receive are not implemented using 
 *                  Windows native functions, the are implemented using
 *                  ftime() from Standard Library.
 *                  Xcom_Init() sets timeouts to values enabling ReadFile()
 *                  and WriteFile() to return immediately.
 *
 *                  This module provides the following functions:
 *
 *                    int   Xcom_Init(int, long, int, int, int, long);
 *                    void  Xcom_Close(int);
 *                    int   Xcom_Putchar(uchar, int);
 *                    int   Xcom_Putdata(uchar *, int, int);
 *                    void  Xcom_Flush(int);
 *                    int   Xcom_DataReady(int);
 *                    int   Xcom_Getchar(uchar *, int);
 *                    int   Xcom_Getch(uchar *, int);
 *                    int   Xcom_Getchar_wtimeout(uchar *, int, long);
 *
 ************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <sys/types.h> 
#include <sys/timeb.h>
#include <time.h>
#include "xcom.h"

typedef struct
   {
   long delay;           /* time to wait */
   struct timeb start;   /* start time   */
   } chrono_t;

/* Global variables for this module only */
static HANDLE       WinPort;
static DCB          NewDCB, OldDCB;
static COMMTIMEOUTS OldTMO, NewTMO;
static long         rx_timeout;
static BYTE         char_received;
static char        *CommPortTxt[] =
  { 
  "COM1",
  "COM2",
  "COM3",
  "COM4",
   NULL
  };

/* in winbase.h
 
#define NOPARITY            0
#define ODDPARITY           1
#define EVENPARITY          2
#define MARKPARITY          3
#define SPACEPARITY         4

#define ONESTOPBIT          0
#define ONE5STOPBITS        1
#define TWOSTOPBITS         2

these below are masks, not actual values:

#define DATABITS_5        ((WORD)0x0001)
#define DATABITS_6        ((WORD)0x0002)
#define DATABITS_7        ((WORD)0x0004)
#define DATABITS_8        ((WORD)0x0008)
#define DATABITS_16       ((WORD)0x0010)
#define DATABITS_16X      ((WORD)0x0020)

*/
#if 0
typedef struct _DCB
  {
  DWORD DCBlength;      /* sizeof(DCB)                     */
  DWORD BaudRate;       /* Baudrate at which running       */
  DWORD fBinary: 1;     /* Binary Mode (skip EOF check)    */
  DWORD fParity: 1;     /* Enable parity checking          */
  DWORD fOutxCtsFlow:1; /* CTS handshaking on output       */
  DWORD fOutxDsrFlow:1; /* DSR handshaking on output       */
  DWORD fDtrControl:2;  /* DTR Flow control                */
  DWORD fDsrSensitivity:1; /* DSR Sensitivity              */
  DWORD fTXContinueOnXoff: 1; /* Continue TX when Xoff sent */
  DWORD fOutX: 1;       /* Enable output X-ON/X-OFF        */
  DWORD fInX: 1;        /* Enable input X-ON/X-OFF         */
  DWORD fErrorChar: 1;  /* Enable Err Replacement          */
  DWORD fNull: 1;       /* Enable Null stripping           */
  DWORD fRtsControl:2;  /* Rts Flow control                */
  DWORD fAbortOnError:1; /* Abort all reads and writes on Error */
  DWORD fDummy2:17;     /* Reserved                        */
  WORD wReserved;       /* Not currently used              */
  WORD XonLim;          /* Transmit X-ON threshold         */
  WORD XoffLim;         /* Transmit X-OFF threshold        */
  BYTE ByteSize;        /* Number of bits/byte, 4-8        */
  BYTE Parity;          /* 0-4=None,Odd,Even,Mark,Space    */
  BYTE StopBits;        /* 0,1,2 = 1, 1.5, 2               */
  char XonChar;         /* Tx and Rx X-ON character        */
  char XoffChar;        /* Tx and Rx X-OFF character       */
  char ErrorChar;       /* Error replacement char          */
  char EofChar;         /* End of Input character          */
  char EvtChar;         /* Received Event character        */
  WORD wReserved1;      /* Fill for now.                   */
  } DCB, *LPDCB;
#endif


/*        Protos           */
static BOOL end_chrono (chrono_t c);
static void start_chrono (chrono_t *c, long t);



/**********************************************************************
 * NAME       int Xcom_Init(int port, long baud, int data, 
 *                          int parity, int stop, long time_out)
 *            
 * PURPOSE    To open COM port.
 *
 * ARGUMENTS  int  port     - port number
 *            long baud     - baud rate
 *            int  data     - data len
 *            int  parity   - parity
 *            int  stop     - stop bits
 *            long time_out - receive timeout in mS
 *
 * RETURNS    0 if not successful
 *            1 otherwise
 *
 * EXTERNS    None.
 *
 * NOTES:     Data length may be 7 or 8 bits.
 *            Parity may have following values:
 *
 *            NOPARITY     0
 *            ODDPARITY    1
 *            EVENPARITY   2
 *            MARKPARITY   3
 *            SPACEPARITY  4
 *
 *            Stop bits may have following values:
 *
 *            1 - one stop bit
 *            2 - two stop bits
 *
 **********************************************************************/
int Xcom_Init(int port, long baud, int data, int parity, int stop, long time_out)
  {
  rx_timeout = time_out;

  WinPort = CreateFile(CommPortTxt[port], GENERIC_WRITE | GENERIC_READ, 
                    0, NULL, OPEN_EXISTING, 0, NULL);

#if 0

HANDLE CreateFile
  (
  LPCTSTR               lpFileName,
  DWORD                 dwDesiredAccess,
  DWORD                 dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  DWORD                 dwCreationDisposition,
  DWORD                 dwFlagsAndAttributes,
  HANDLE                hTemplateFile
  );

  m_hCom = CreateFile(
         m_CommPort,
         GENERIC_READ | GENERIC_WRITE,
         0,                // comm devices must be opened w/exclusive-access
         NULL,              //  no security attrs
         OPEN_EXISTING,    // comm devices must use OPEN_EXISTING
         0,                // not overlapped I/O (dwFlagsAndAttributes)
         NULL              // hTemplate must be NULL for comm devices
        );
#endif

  if (WinPort == INVALID_HANDLE_VALUE)
    {
    printf("Xcom_Init: Cannot open comport nr: %d.\n", port);
    return (0);
    }
  
  // get current DCB for saving
  if (!GetCommState(WinPort, &OldDCB))
    {
    printf("Xcom_Init: Cannot get old commstate.\n\n");
    return (0);
    }
  // load new DCB with old one
  if (!GetCommState(WinPort, &NewDCB))
    {
    printf("Xcom_Init: Cannot get new commstate.\n\n");
    return (0);
    }

  // change new DCB as needed
  NewDCB.DCBlength = sizeof(DCB);
  NewDCB.BaudRate  = baud;        //115200;

  switch (data)
    {
    case 8:
      NewDCB.ByteSize  = (BYTE) 8;
      break;
    case 7:
      NewDCB.ByteSize  = (BYTE) 7;
      break;
    default:
      printf("Xcom_Init: Invalid data length = %d.\n", data);
      return (0);
    }

  switch (parity)
    {
    case NOPARITY:
    case ODDPARITY:
    case EVENPARITY:
    case MARKPARITY:
    case SPACEPARITY:
      NewDCB.Parity    = (BYTE)  parity;
      break;
    default:
      printf("Xcom_Init: Invalid parity value = %d.\n", parity);
      return (0);
    }

  switch (stop)
    {
    case 2:
      NewDCB.StopBits  = (BYTE) TWOSTOPBITS;
      break;
    case 1:
      NewDCB.StopBits  = (BYTE) ONESTOPBIT;
      break;
    default:
      printf("Xcom_Init: Invalid stopbit value = %d.\n", stop);
      return (0);
    }

    NewDCB.fOutxCtsFlow      = FALSE;
    NewDCB.fOutxDsrFlow      = FALSE;
    NewDCB.fDtrControl       = DTR_CONTROL_DISABLE;
    NewDCB.fDsrSensitivity   = FALSE;
    NewDCB.fTXContinueOnXoff = TRUE;
    NewDCB.fOutX             = FALSE;
    NewDCB.fInX              = FALSE;
    NewDCB.fNull             = FALSE;
    NewDCB.fRtsControl       = RTS_CONTROL_DISABLE;
    NewDCB.fAbortOnError     = TRUE;
    NewDCB.fParity           = FALSE;

  // set new DCB
  if (!SetCommState(WinPort, &NewDCB))
    {
    printf("Xcom_Init: Cannot set comstate.\r\n");
    return (0);
    }

  GetCommTimeouts(WinPort,& OldTMO);
  GetCommTimeouts(WinPort,& NewTMO);

/*
typedef struct _COMMTIMEOUTS
  {
  DWORD ReadIntervalTimeout; 
  DWORD ReadTotalTimeoutMultiplier; 
  DWORD ReadTotalTimeoutConstant; 
  DWORD WriteTotalTimeoutMultiplier; 
  DWORD WriteTotalTimeoutConstant; 
 } COMMTIMEOUTS, *LPCOMMTIMEOUTS; 

  Our purpose is to set timeouts in such a manner, that both
  read and write operations return immediately.

  Text below is from "Time-Outs" in Whin32SDK Help:

  If all read time-out parameters are zero, read time-outs are not 
  used, and a read operation is not complete until the requested 
  number of bytes have been read or an error occurs. 

  Similarly, if all write time-out parameters are zero, a write 
  operation is not completed until the requested number of bytes 
  have been written or an error occurs. 

  "If the read interval time-out parameter is the MAXDWORD value 
  and both read total time-out parameters are zero, a read operation 
  is completed immediately after reading whatever characters are 
  available in the input buffer, even if it is empty. 
  This is the same as the ReadComm function in previous versions of Windows."
*/
  NewTMO.ReadIntervalTimeout         = MAXWORD; /* The above statement does not hold     */
  NewTMO.ReadTotalTimeoutMultiplier  = 1;       /* Seting both both read total time-out  */
  NewTMO.ReadTotalTimeoutConstant    = 0;       /* parameters to zero causes  ReadFile() */
                                                /* to never return.                      */
/* 
  Below is text from MS VC++ v6 Help:

  If an application sets ReadIntervalTimeout and ReadTotalTimeoutMultiplier to 
  MAXDWORD and sets ReadTotalTimeoutConstant to a value greater than zero and 
  less than MAXDWORD, one of the following occurs when the ReadFile function 
  is called: 

    .If there are no characters in the input buffer, ReadFile waits until a 
    character arrives and then returns immediately. 


    .If no characters arrive within the time specified by ReadTotalTimeoutConstant, 
    ReadFile times out. 

  ********** This does not hold either! ********************
*/

/*
    Below is text from MS VC++ v6 Help:

    A value of zero for both the WriteTotalTimeoutMultiplier and 
    WriteTotalTimeoutConstant members indicates that total time-outs are
    not used for write operations. 

    Does that mean that WriteFile() returns immediately?
*/
  NewTMO.WriteTotalTimeoutMultiplier = 0;
  NewTMO.WriteTotalTimeoutConstant   = 0;

  if (!SetCommTimeouts(WinPort, &NewTMO))
    {
    printf("Xcom_Init: Cannot set timeouts.\r\n");
    return (0);
    }
  return (1);
  }

/**********************************************************************
 * NAME       void Xcom_Close(int port)
 *            
 * PURPOSE    To close COM port.
 *
 * ARGUMENTS  int  port - dummy argument, used for compatibility 
 *
 * RETURNS    Nothing.
 *
 * EXTERNS    None.
 *
 * NOTES:     
 **********************************************************************/
void Xcom_Close(int port)
  {
  SetCommState(WinPort, &OldDCB);
  SetCommTimeouts(WinPort, &OldTMO);
  CloseHandle(WinPort);
  }

/**********************************************************************
 * NAME       void Xcom_Flush(int port)
 *            
 * PURPOSE    To remove all receoved chars from buffer.
 *
 * ARGUMENTS  int  port - dummy argument, used for compatibility 
 *
 * RETURNS    Nothing.
 *
 * EXTERNS    None.
 *
 * NOTES:     The flush is implemented by reading (using Xcom_DataReady())
 *            until Xcom_DataReady() reports 'data not ready'.
 **********************************************************************/
void Xcom_Flush(int port)
  {
  uchar c;

  while(Xcom_DataReady(port)) /* wait for timeout */
    ;
  }

/**********************************************************************
 * NAME       int Xcom_DataReady(int port)
 *            
 * PURPOSE    To check if a character was received.
 *
 * ARGUMENTS  int  port - dummy argument, used for compatibility 
 *
 * RETURNS    0 - if no character is available
 *            1 - if a character is available
 *           -1 - on read errors
 *
 * EXTERNS    None.
 *
 * NOTES:     This function uses ReadFile().  If a character is 
 *            available, it will be read and removed from buffer, 
 *            i.e. it will be lost.  Therefore, this function places 
 *            that character in the global variable
 *              char_received.
 *            Subsequent call to Xcom_Getch() 
 *            will return that character to caller.
 *            Due to initialization of timeouts (Xcom_Init()), 
 *            ReadFile() always returns immediately.
 *            Because fAbortOnError is TRUE in initialization function,
 *            we use ClearCommError() in case of errors here in order 
 *            enable further receive operations.
 *            This function is implemented in order to enable using 
 *            polling the serial connection:
 *            
 *            if (Xcom_DataReady(port))
 *              {
 *              c = Xcom_Getch(port)
 *              process_character();
 *              }
 *            else
 *              {
 *              do_something_else();
 *              }
 *           
 *              
 **********************************************************************/
int Xcom_DataReady(int port)
  {
  DWORD   bytes_read;
  BOOL    tmp;
  BYTE    ch;
  DWORD   werr;

  tmp = ReadFile(WinPort, &ch, 1, &bytes_read, NULL); /* read one char */
  if (!tmp)
    {
    printf("Xcom_DataReady: ReadFile error!\n");
    ClearCommError(WinPort, &werr, NULL);
    return (-1);          /* signal read errors */
    }
  if (bytes_read == 0)
    return (0);           /* if nothing received, return 0 */
  else
    {
    char_received = ch;
    return (1);
    }    
  }

/**********************************************************************
 * NAME       int Xcom_Getchar(uchar * c, int port)
 *
 * PURPOSE    To fetch a character from serial receive buffer with
 *            default timeout.
 *
 * ARGUMENTS  uchar * c - poiter to result.
 *            int port  - dummy parameter.
 *
 * RETURNS    0 if a character does not arrive during RXTIMEOUT,
 *            1 otherwise, a received character is placed at c
 *            
 *
 * EXTERNS    None.
 * NOTES
 **********************************************************************/
int Xcom_Getchar(uchar *c, int port)
  {
  chrono_t timeout;

  start_chrono (&timeout, rx_timeout);
  while(!Xcom_DataReady(port))
    if (end_chrono(timeout))
      {
      return (0);            /* timeout */
      }
  *c = char_received;
  return (1);                
  }

/**********************************************************************
 * NAME       int Xcom_Getch(uchar * c, int port)
 *
 * PURPOSE    To fetch a character from serial receive buffer without
 *            timeout.
 *
 * ARGUMENTS  uchar * c - poiter to result.
 *            int port  - dummy parameter.
 *
 * RETURNS    1, char_received, obtained by previous call to 
 *            Xcom_DataReady(), is placed at c
 *            
 *
 * EXTERNS    None.
 * NOTES
 **********************************************************************/
int Xcom_Getch(uchar *c, int port)
  {
  *c = char_received;
  return (1);                
   }
/**********************************************************************
 * NAME       int Xcom_Getchar_wtimeout(uchar *c, int port, long mytimeout)
 *
 * PURPOSE    To fetch a character from serial receive buffer with timeout
 *            value other than default.
 *
 * ARGUMENTS  uchar * c - poiter to result.
 *            int port  - dummy parameter.
 *            long mytimeout - timeout in mS
 *
 * RETURNS    0 if a character does not arrive during RXTIMEOUT,
 *            1 otherwise, a received character is placed at c
 *
 * EXTERNS    None.
 * NOTES
 **********************************************************************/
int Xcom_Getchar_wtimeout(uchar *c, int port, long mytimeout)
  {
  chrono_t timeout;
  long     tmp_timeout;

  tmp_timeout = rx_timeout; /* save default timeout */
  rx_timeout  = mytimeout;  /* set new timeout      */

  start_chrono (&timeout, mytimeout);
  while(!Xcom_DataReady(port))
    if (end_chrono(timeout))
      {
      rx_timeout = tmp_timeout; /* restore default timeout */
      return (0);
      }
  *c = char_received;
  rx_timeout = tmp_timeout;     /* restore default timeout */
  return (1);
  }

/**********************************************************************
 * NAME       int Xcom_Getstring(uchar *str, int port)
 *
 * PURPOSE    To receive string terminated by newline.
 *
 * ARGUMENTS  uchar *str   - destination buffer
 *            int port     - comport.
 *
 * RETURNS    1 on success
 *            0 on failure
 *
 * EXTERNS    None.
 *
 * NOTES      
 **********************************************************************/
int Xcom_Getstring(uchar *str, int port)
  {
  int    i;
  uchar  c;

  c = 0;
  i = 0;
  while (c != '\n')
    {
    if (!Xcom_Getchar_wtimeout(&c, port,  2000L))
      {
      str[i] = 0;;
      return (0);
      }
    else
      {
      str[i] = c;
      i++;
      if (i == MAXSTRING) /* in no more buffer space... */
        {
        str[i] = 0;
        return (0);
        }
      }
    }
  str[i] = 0;;
  return (1);
  }

/**********************************************************************
 * NAME       int Xcom_Putchar(uchar c, int port)
 *
 * PURPOSE    To send one character.
 *
 * ARGUMENTS  uchar c   - character to send.
 *            int port  - dummy parameter.
 *
 * RETURNS    0 - on wrte errors
 *            1 - otherwise
 *
 * EXTERNS    None.
 *
 * NOTES      If successful, WriteFile() returns nonzero, if not,
 *            returned value is zero.
 *            Because fAbortOnError is TRUE in initialization function,
 *            we use ClearCommError() in case of errors here in order 
 *            enable further send operations.
 **********************************************************************/
int Xcom_Putchar(uchar c, int port)
  {
  DWORD dummy;
  int   i;
  BOOL  tmp;
  DWORD werr;

  tmp = WriteFile(WinPort, &c, 1, &dummy, NULL);
  if (!tmp)
    {
    printf("Xcom_Putchar: WriteFile error!\n");
    ClearCommError(WinPort, &werr, NULL);
    return (0);          /* signal write errors */
    }
  return (1);
  }

/**********************************************************************
 * NAME       int Xcom_Putstring(uchar *c, int port)
 *
 * PURPOSE    To send a string.
 *
 * ARGUMENTS  uchar *c   - buffer containing string
 *            int port   - comport.
 *
 * RETURNS    1
 *
 * EXTERNS    None.
 *
 * NOTES      
 **********************************************************************/
int Xcom_Putstring(uchar *c, int port)
  {
  int i;

  i = 0;
  while (*(c + i))
    {
    Xcom_Putchar(*(c + i), port);
    i++;
    }
  return (1);
  }


/**********************************************************************
 * NAME       void Xcom_Putdata(uchar *buff, int nr, int port)
 *
 * PURPOSE    To send a number of characters.
 *
 * ARGUMENTS  *buff     - characters to send.
 *            int  nr   - number of characters to send
 *            int port  - dummy parameter.
 *
 * RETURNS    0 - on wrte errors
 *            1 - otherwise
 *
 * EXTERNS    None.
 *
 * NOTES      If successful, WriteFile() returns nonzero, if not,
 *            returned value is zero.
 *            Because fAbortOnError is TRUE in initialization function,
 *            we use ClearCommError() in case of errors here in order 
 *            enable further send operations.
 **********************************************************************/
int Xcom_Putdata(uchar *buff, int nr, int port)
  {
  DWORD dummy;
  int   i;
  BOOL  tmp;
  DWORD werr;

  tmp = WriteFile(WinPort, buff, nr, &dummy, NULL);
  if (!tmp)
    {
    printf("Xcom_Putdata: WriteFile error!\n");
    ClearCommError(WinPort, &werr, NULL);
    return (0);          /* signal write errors */
    }
  return (1);
  }


/* initialize chronometer */
static void start_chrono (chrono_t *c, long t)
  {
  ftime (&(c->start));
  c->delay = t;
  }

/* return TRUE if time has expired */
static BOOL end_chrono (chrono_t c)
  {
  struct timeb temp;
  long t;

  ftime (&temp);
  /* convert difference to milliseconds */ 
  t = (temp.time - c.start.time) * 1000 + ((long)temp.millitm - (long)c.start.millitm);

  return (t >= c.delay);
  }

/**********************************************************************
 * NAME       void pass_time(long mseconds)
 *
 * PURPOSE    To provide a delay
 *
 * ARGUMENTS  long mseconds - required delay in miliseconds
 *
 * RETURNS    Nothing
 *
 * EXTERNS    None.
 *
 * NOTES      None.
 **********************************************************************/
void pass_time(long mseconds)
  {
  chrono_t ptime;

  start_chrono (&ptime, mseconds);
  while(1)
    {
    if (end_chrono(ptime))
      {
      return;
      }
    }
  }