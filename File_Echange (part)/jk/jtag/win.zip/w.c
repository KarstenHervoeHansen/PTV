/************************************************************************
 * FILE NAME  dkplay.c
 * PURPOSE    To transfer a .xvf file via RS232 to Cygnal F320 kit
 *            running JTAG loader for Virtex2 FPGA.
 *            
 * SPEC       Janusz Kuzminski
 * DESIGN     Janusz Kuzminski
 * CODING     Janusz Kuzminski
 * CODE INSP. 
 * TEST       
 *            
 * LAST UPDT: 13.06.2006
 *            
 * NOTES:     This module is to be linked with xcom, Windows 
 *            RS232 comms module.
 *            Invocation:
 *            dkplay port file
 *            This program works as follows:
 *            This program is a Server, the F320 program is a Client.
 *            This program transmits data read from file.  It does not
 *            transmit other data, apart from RDY signal at the 
 *            begining, which is used for handshaking with the Client.
 *            It receives commands from the Client, which
 *             cause the following:
 *             START   - start transmitting data from file,
 *             STOP    - stop  transmitting data from file,
 *             ERR     - print failure message and exit,
 *             SUCCESS - print success message and exit.
 *            
 *            The comport is initialized to 115200, n, 8, 1.
 *            When started, this program waits for the F320 to 
 *            send start command, which is START.  While waiting,
 *            this program sends the RDY signal each second.  While 
 *            waiting it is possible to exit this program by 
 *            pressing a key.
 *            After the start command arrives this program reads
 *            each byte from file and transmits them to the F320.
 *            Under the fransfer, this program listens to the F320
 *            and if ERROR is received (meaning error), the program
 *            exits with an error code.  Otherwise, the flow control
 *            is START/STOP.  This is necessary during the Client
 *            executing the XRUNTEST procedure, which is a 
 *            long delay and consequently, the Client cannot
 *            collect incoming data.
 *            When the whole file is 
 *            transferred, the program waits for SUCCESS or ERROR
 *            from the Client.
 *                  
 ************************************************************************/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <time.h>
#include <setjmp.h>
#include <math.h>
#include "xcom.h"

#define RX_SERBUFLEN  50 //64

#define RDY      (UC) 0x33
#define START    (UC) 0x31
#define STOP     (UC) 0x32
#define ERR      (UC) 0x20
#define SUCCESS  (UC) 0x1B
#define ENQ      (UC) 0xAA
#define CSUMFAIL (UC) 0xF0

#define CRC8CONST     0xB8
#define STARTCRCVALUE 0x2A

#define  UL unsigned long
#define  UI unsigned short
#define  UC unsigned char

#define  VERSION (float) 1.0

#define MOVING_PIN_SPEED 1


char *rotating_pin[] =  /* rotating pin: one step per 20 lines sent */
  {
  "|",
  "/",
  "-",
  "\\",
  NULL
  };

/*        Prototypes                */
void give_info(void);
UC   crc8(UC*, UC);
int  handshake(int);
void do_exit(int, int, char *message);

int main(int argc, char ** argv)
  {
  HANDLE   Hfile;
  int      i, k;
  int      port;
  BYTE     c;
  BOOL     tmp;
  BOOL     run;
  DWORD    bytes_read;
  clock_t  startClock;
  clock_t  endClock;
  double   seconds;
  long     cnt;         /* used to control rotating pin */
  UC       csum;
  UC       dbuffer[RX_SERBUFLEN + 1];
  UL       del;

  if (argc != 3)
    {
    give_info();
    return (1);
    }
  tmp = 0;
  cnt = 0;

  printf("DKPLAY Version %.2f.\n", VERSION);
  port = atoi(argv[1]);  /* first command line arg is comport */

  if (!Xcom_Init(port - 1, 115200L, 8, 0, 2, 2000L))
    {
    printf("main: Cannot open COM%d.\n", port);
    Xcom_Close(port);
    return (1);
    }

  /* open file specified in command line arg */
  Hfile = CreateFile(argv[2], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
  if (Hfile == INVALID_HANDLE_VALUE)
    {
    printf("main: Cannot open file %s.\r\n", argv[2]);
    return (1);
    }

  /*************************** Wait for START command ********************/
  Xcom_Flush(port);
  startClock = clock();
  run        = 0;
  
  for (i = 0; i < RX_SERBUFLEN + 1; i++)
    dbuffer[i] = 0;
  csum = crc8(dbuffer, RX_SERBUFLEN);
  //printf("Checksum for zeroed buffer: csum = %d.\n", csum);

  /* Transfer the file and listen for ERROR or SUCCESS */
#if 1
  while (1)
    {
    /* Check for keypress */
    if (kbhit())
      {
      getche();
      printf("User Break1.\n");
      goto lab1;
      }
    if (Xcom_Getchar(&c, port))
      {
      if (c == START) /* ENQ */
        {
        Xcom_Getchar(&c, port);    /* Get checksum */
        printf("Checksum received: c = %d.\n", c);
        csum = 228;
        Xcom_Putchar(START, port); /* ENQ */
        break;
        }
      else
        continue;
      }
    }
  printf("Handshake done.\n");
#endif
  while (1)
    {
    /* Check for keypress */
    if (kbhit())
      {
      getche();
      printf("User Break2.\n");
      goto lab1;
      }
    /* Check for START / STOP or ERR */
    if (Xcom_DataReady(port)) /* if OK, places char in char_received.. */
      {
      //printf("DataReady  ");
      Xcom_Getch(&c, port); /* .. without timeout.. returns char_received. */
      switch (c)
        {
        case START:
          /* get checksum and compare it to local checksum here */
          Xcom_Getchar(&c, port);
          if (c != csum)
            {
            printf("Checksum Error! rec = %d  csum = %d.\n", c, csum);
            goto lab1;
            }
          //printf("Start Comand Received. rec = %d  csum = %d.\n", c, csum);
          run = 1;
          break;
        case ERR:
          run = 0;
          printf("ERR Command Received. cnt = %ld.\n", cnt);
          goto lab1;
        case SUCCESS:
          run = 0;
          printf("SUCCESS Command Received. cnt = %ld.\n", cnt);
          goto lab1;
        default:
          run = 1;
          printf("NONE Command Received c = %d cnt = %ld.\n", (int) c, cnt);
          break;
        }
      }  /* if (Xcom_DataReady(port)) */
    if (run)
      {
      for (i = 0; i < RX_SERBUFLEN; i++)
        {
        bytes_read = ReadFile(Hfile, &c, 1, &bytes_read, NULL); /* read one char */
        if (bytes_read == 0) /* EOF reached, wait for SUCCESS */
          {
          printf("File transferred, waiting for SUCCESS.\n");
          run = 0;
          for (; i < RX_SERBUFLEN; i++)
            dbuffer[i] = 0;
  
          break;
          }
        dbuffer[i] = c;
        cnt++;
        if (!(cnt % 10000))
          printf("%ld sent.\r", cnt);
        }
      csum = crc8(dbuffer, RX_SERBUFLEN);
      for (i = 0; i < RX_SERBUFLEN; i++) /* Transmit buffer */
        {
        Xcom_Putchar(dbuffer[i], port);
#if 1
        for (del = 0; del < 0x2fff; del++)
           tmp++;
#endif
        }
      run = 0; /* stop sending after RX_SERBUFLEN chars have been sent */
      } /* if (run) */
    } /* while (1) */
lab1:
  printf("\n");
  printf("%ld characters sent.\n", cnt);
  endClock = clock();
  seconds = (double)((endClock - startClock) / CLOCKS_PER_SEC);
  printf("Execution Time = %.1f seconds\n", seconds);
  Xcom_Close(port);
  CloseHandle(Hfile);
  return (0);
  }

void give_info(void)
  {
  printf("dkplay.exe: transfers .xvf file to F320 processor.\n");
  printf("Version %.2f.\n", VERSION);
  printf("Invocation: dkplay port file\n");
  }

void do_exit(int code, int comport, char *message)
  {
  Xcom_Close(comport);
  printf("%s", message);
  exit (code);
  }

UC crc8(UC* buff, UC buffLen)
  {
  UC i;
  UC chk;
  UC *ptr_stop;

  ptr_stop = buff + buffLen;
  chk = STARTCRCVALUE;

  while(buff < ptr_stop)
    {
    chk ^= *buff;
    for(i = 0 ; i < 8; i++)
      chk = (UC)((chk & 1) ? (chk >> 1) ^ CRC8CONST : (chk >> 1));
    buff++;
    }
  return chk;
  }


