/************************************************************************
 * FILE NAME  dkplay.c
 * PURPOSE    To transfer a .xvf file via RS232 to Cygnal F320 kit
 *            running JTAG loader for Virtex2 FPGA.
 *            
 * SPEC       Janusz Kuzminski
 * DESIGN     Janusz Kuzminski
 * CODING     Janusz Kuzminski
 * CODE INSP. 
 * TEST       
 *            
 * LAST UPDT: 13.06.2006
 *            
 * NOTES:     This module is to be linked with xcom, Windows 
 *            RS232 comms module.
 *            Invocation:
 *            dkplay port file
 *            This program works as follows:
 *            This program is a Server, the F320 program is a Client.
 *            This program transmits data read from file.  It does not
 *            transmit other data, apart from RDY signal at the 
 *            begining, which is used for handshaking with the Client.
 *            It receives commands from the Client, which
 *             cause the following:
 *             START   - start transmitting data from file,
 *             STOP    - stop  transmitting data from file,
 *             ERR     - print failure message and exit,
 *             SUCCESS - print success message and exit.
 *            
 *            The comport is initialized to 115200, n, 8, 1.
 *            When started, this program waits for the F320 to 
 *            send start command, which is START.  While waiting,
 *            this program sends the RDY signal each second.  While 
 *            waiting it is possible to exit this program by 
 *            pressing a key.
 *            After the start command arrives this program reads
 *            each byte from file and transmits them to the F320.
 *            Under the fransfer, this program listens to the F320
 *            and if ERROR is received (meaning error), the program
 *            exits with an error code.  Otherwise, the flow control
 *            is START/STOP.  This is necessary during the Client
 *            executing the XRUNTEST procedure, which is a 
 *            long delay and consequently, the Client cannot
 *            collect incoming data.
 *            When the whole file is 
 *            transferred, the program waits for SUCCESS or ERROR
 *            from the Client.
 *                  
 ************************************************************************/
#define USE_WIN

#ifdef USE_WIN
#include <windows.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include <dos.h>
#include <time.h>
#include <setjmp.h>
#include <math.h>
#include "xcom.h"

#define RX_SERBUFLEN  50 //64

#define RDY     (UC) 0x33
#define START   (UC) 0x31
#define STOP    (UC) 0x32
#define ERR     (UC) 0x20
#define SUCCESS (UC) 0x1B
#define ENQ     (UC) 0xAA

#define  UL unsigned long
#define  UI unsigned short
#define  UC unsigned char

#define  VERSION (float) 3.0

#define MOVING_PIN_SPEED 1


char *rotating_pin[] =  /* rotating pin: one step per 20 lines sent */
  {
  "|",
  "/",
  "-",
  "\\",
  NULL
  };

/*        Prototypes                */
void give_info(void);
void do_exit(int, int, char *message);
void wait_4_any_key(void);
int check_4_key(int place);

int main(int argc, char ** argv)
  {
#ifdef USE_WIN
  FILE*    Hfile;
#else
  HANDLE   Hfile;
#endif
  int      i, k;
  int      port;
  UC       c;
  UC       tmp;
  UC       run;
  UL       bytes_read;
  clock_t  startClock;
  clock_t  endClock;
  double   seconds;
  long     cnt;         /* count of bytes read from file */
  UC       board;
  UC       strbuff[MAXSTRING];

  if (argc != 4)
    {
    give_info();
    return (1);
    }

  cnt = 0;         /* number of bytes sent */
  startClock = clock();

  board = (UC)atoi(argv[2]);  /* second command line arg is board */
  if ((board < 1) || (board > 3))
    {
    printf("main: Board may be 1, 2 or 3.\n");
    return (1);
    }


#ifdef USE_WIN
  printf("DKPLAY for Windows Version %.2f.\n", VERSION);
#else
  printf("DKPLAY for DOS Version %.2f.\n", VERSION);
#endif
  port = atoi(argv[1]);  /* first command line arg is comport */
  if ((port < 1) || (port > 2))
    {
    printf("main: Comport may be 1 or 2\n");
    return (1);
    }

  port -= 1;

  /* open file specified in command line arg */

#ifdef USE_WIN
  Hfile = CreateFile(argv[3], GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
  if (Hfile == INVALID_HANDLE_VALUE)
    {
    printf("main: Cannot open file %s.\r\n", argv[2]);
    return (1);
    }
#else
  Hfile = fopen(argv[3],  "rb");
  if (Hfile == NULL)
    {
    printf("main: Cannot open file %s.\r\n", argv[2]);
    return (1);
    }
#endif


#if 1
  if (!Xcom_Init(port, 9600L, 8, MARKPARITY, 2, 2000L))
    {
    printf("main: Cannot open COM%d.\n", port);
    Xcom_Close(port);
    return (1);
    }

  strcpy(strbuff, "*IDN?;");
  Xcom_Putstring(strbuff, port);    /* Display PT5300 info */

  for (i = 0; i < MAXSTRING; i++)
    strbuff[0] = 0;

  if (!Xcom_Getstring(strbuff, port))
    {
    printf("Communication Error 1.\n");
    goto lab1;
    }
  else
    printf("Generator: %s\n", strbuff);

  strcpy(strbuff, ":FACT:PASS 'Marilyn';");
  Xcom_Putstring(strbuff, port);


  strcpy(strbuff, ":FACT:PASS?;");
  Xcom_Putstring(strbuff, port);

  if (!Xcom_Getstring(strbuff, port))
    {
    printf("Communication Error 2.\n");
    goto lab1;
    }
  else
    {
    if (!strcmp(strbuff, "OFF"))
      {
      printf("Communication Error 3.\n");
      goto lab1;
      }
    }

  switch (board)
    {
    case 1:
      strcpy(strbuff, ":FACT:V24C:ADDR BBU_1;");
      break;
    case 2:
      strcpy(strbuff, ":FACT:V24C:ADDR BBU_2;");
      break;
    case 3:
      strcpy(strbuff, ":FACT:V24C:ADDR BBU_3;");
      break;
    }
  Xcom_Putstring(strbuff, port);

  strcpy(strbuff, ":FACT:V24C:COMM 'UA?';"); /* get board address */
  Xcom_Putstring(strbuff, port);

  if (!Xcom_Getstring(strbuff, port))
    {
    printf("Communication Error 4. Board %d is not mounted.\n", (int)board);
    goto lab1;
    }
  else
    {
    /*printf("Board Address: 0x%x\n", atoi(strbuff)); */
    /* set 5300 into transparent mode */
    strcpy(strbuff, ":SYST:UPL 1;");
    Xcom_Putstring(strbuff, port);
    }
  /* Note: the delay below is necessary, as without it, the last character (;) */
  /* is sent corrupted, apparently because of Xcom_Close().                    */
  /* This is despite MSDN text on WriteFile states that WriteFile() does not   */
  /* return until the operation has been completed.                            */
  pass_time(3000);
  Xcom_Close(port);


#endif
/*************           BAUD RATE CHANGE  wait_4_any_key();    *******************************/


  if (!Xcom_Init(port, 115200L, 8, MARKPARITY, 2, 2000L))
    {
    printf("main: Cannot open COM%d.\n", port);
    Xcom_Close(port);
    return (1);
    }  

  /*************************** Wait for START command ********************/
  Xcom_Flush(port);
  startClock = clock();
  run        = 0;

  /* Transfer the file and listen for ERROR or SUCCESS */
#if 1
  while (1)
    {
    /* Check for keypress */
    if (check_4_key(1))
      {
      goto lab1;
      }
    if (Xcom_Getchar(&c, port))
      {
      if (c == START) /* ENQ */
        {
        Xcom_Putchar(START, port); /* ENQ */
        break;
        }
      else
        continue;
      }
    }
  printf("Handshake done.\n");
#endif
  while (1)
    {
    /* Check for keypress */
    if (check_4_key(2))
      {
      goto lab1;
      }
    /* Check for START / STOP or ERR */
    if (Xcom_DataReady(port))
      {
      //printf("DataReady  ");
      Xcom_Getch(&c, port); /* remove char from bufer */
      switch (c)
        {
        case START:
          run = 1;
          //printf("Start Comand Received.\n");
          break;
        case ERR:
          run = 0;
          printf("ERR Command Received. cnt = %ld.\n", cnt);
          goto lab1;
        case SUCCESS:
          run = 0;
          printf("SUCCESS Command Received. cnt = %ld.\n", cnt);
          goto lab1;
        default:
          printf("NONE Command Received c = 0x%x cnt = %ld.\n", (int) c, cnt);
          break;
        }
      }  /* if (Xcom_DataReady(port)) */
    if (run)
      {
      for (i = 0; i < RX_SERBUFLEN; i++)
        {
#ifdef USE_WIN
        bytes_read = ReadFile(Hfile, &c, 1, &bytes_read, NULL); /* read one char */
#else
        bytes_read = fread(&c, 1, 1, Hfile); /* read one char */
#endif
        if (bytes_read == 0) /* EOF reached, wait for SUCCESS */
          {
          printf("File transferred, waiting for SUCCESS.\n");
          run = 0;
          break;
          }
        Xcom_Putchar(c, port); /* transmit character from file */
        cnt++;
#if 1
        if (!(cnt % 10000))
          printf("%ld sent.\r", cnt);
#endif
        }
      run = 0; /* stop sending after RX_SERBUFLEN chars have been sent */
      } /* if (run) */
    } /* while (1) */
lab1:
  printf("\n");
  endClock = clock();
  seconds = (double)((endClock - startClock) / CLOCKS_PER_SEC);
  printf("Execution Time = %.1f seconds\n", seconds);
  printf("%ld characters sent.\n", cnt);
  Xcom_Close(port);
#ifdef USE_WIN
  CloseHandle(Hfile);
#else
  fclose(Hfile);
#endif
  return (0);
  }

void give_info(void)
  {
  printf("dkplay.exe: transfers .xvf file to F320 processor.\n");
  printf("Version %.2f.\n", VERSION);
  printf("Invocation: dkplay port board file\n");
  }

void do_exit(int code, int comport, char *message)
  {
  Xcom_Close(comport);
  printf("%s", message);
  exit (code);
  }

void wait_4_any_key(void)
  {
  printf("Press any key to continue....\n");
  while (!kbhit())
    ;
  getch();
  return;
  }

int check_4_key(int place)
  {
  if (kbhit())
    {
    getch();
    printf("User Break %d.\n", place);
    return (1);
    }
  else
    return (0);
  }
