


extern int ltcPNL;
extern int LTC_TotalTest(void);
extern char *ReadLTCKUNumber (void);
extern char *ReadLTCProdDate (void);
extern char *ReadLTCCalDate (void);
