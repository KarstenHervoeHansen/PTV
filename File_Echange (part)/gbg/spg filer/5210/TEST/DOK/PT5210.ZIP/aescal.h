
extern int TestAudioGen(void);
extern char *ReadAudioKUNumber (void);
extern char *ReadAudioProdDate (void);
extern char *ReadAudioCalDate (void);
