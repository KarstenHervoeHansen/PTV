/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 1996. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  OPLYS_PNL                       1
#define  OPLYS_PNL_CALDATO               2
#define  OPLYS_PNL_PRODDATO              3
#define  OPLYS_PNL_KUNUMMER              4
#define  OPLYS_PNL_NC12                  5
#define  OPLYS_PNL_PHIL                  6


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* (no callbacks specified in the resource file) */ 


#ifdef __cplusplus
    }
#endif
