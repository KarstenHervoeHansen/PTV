/*
File:	tabposm.c
*/
#include <stdio.h>


code unsigned int faseposm[]=
{ 1,1,1,1,1,1,1
};

