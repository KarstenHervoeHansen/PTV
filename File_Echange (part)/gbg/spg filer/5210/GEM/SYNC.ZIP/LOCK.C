#include	<xa.h>
#include	"equ.c"
#include	"ext.h"
/*
;********************************************************
; filename	: lock.c	ver.	960430		*
;********************************************************
; HISTORY:
*/
// static UI i;
extern void burstlock(void);
extern bit genlocken;
extern UC vargod;	//TEST
sbit P1_5 @ 0x38d;	//TEST
volatile UC testa000 @ 0xa000;	//TEST
volatile UC testa002 @ 0xa002;	//TEST
volatile UC testa004 @ 0xa004;	//TEST
volatile UC testa006 @ 0xa006;	//TEST
volatile UC testa008 @ 0xa008;	//TEST
volatile UC testa00a @ 0xa00a;	//TEST
near UI testtal, testgltal;	//TEST
near UC gem1, gem2, gem3, gem4;	//TEST
near UC fejltel;	//TEST

void lock(void)
{ 
//   P1_5= 0;	//TEST
   
   if (!genlocken)
      goto SETINT;
   if (verr>0)
      goto SETINT;
   burstfase();
   if (blackav<=syg1)
      goto SETINT;
   if (!syncav && blackav<=syg2)
      goto SETINT;

    // CKSLOW:
   if (slowlock)
      goto SETSLOW;
   if (!bulocken)
      goto NOBU;
   if (buamav<=buamg1)
      goto NOBU;
   if (!buav && buamav<=buamg2)
      goto NOBU;

   // PALG:
   if (lockdet)	//<960509a6
   {  errpre= 3;
      outs= palglock;
   }
   else
   {  errpre= 1;
      outs= palgunl;
   }
   // BULO:
   burstlock();
   goto OUTLOCK;
   
NOBU:
   if (lockdet=1)
   {  errpre= 3;
      outs= hlocked;
   }
   else
   {  errpre= 1;
      outs= hunl;
   }
   // HLOC:
   hlock();
   goto OUTLOCK;

SETSLOW:
   outs= slowerr;	
   intern();
   goto OUTLOCK;
    
SETINT:
   if (vargod)
   {  vargod= 0;
   }
   outs= internl;
   intern();

   OUTLOCK:
   if (level)  outport= outs | 0x20;
   else  outport= outs & ~0x20;
   dolock= 0;

//   P1_5= 1;	//TEST
   
} // END of 1.6: lock *****

// ************************************************************
// static bit yneg;


void burstfase(void)
{  UC s1,s2,s3,s4;
   UC y,x;
   UI i;
   UC z;
   static bit yneg;
   
   i= hpos + bupos;
   if (i>hlen)  i -= hlen;
 //  i= (i>>2) * 4;	// <960508d
   if (i>255)  i -= 4;

   
   testa000= (UC)(i >> 4);	//TEST
   if (i>0x800)
      testa000= (UC)(i >>8);

   
   // GETDUAL:
   s1= dual[i];
   gem1= s1;	//TEST

   s2= dual[i+1];
   gem2= s2;	//TEST

   s3= dual[i+2];
   gem3= s3;	//TEST

   s4= dual[i+3];
   gem4= s4;	//TEST

//   black= (s1+s2+s3+s4) >> 2;
   black= (s1+s2+s3) /3;

   testa002= black; //TEST
   


   if (black > blackav)
   {  if (blackav!=255)
	  blackav += 1;
   }
   else if (blackav!=0)
	 blackav -= 1;

   // MAKEN:
 //  xnneg= 0;	// <960508d4
 //  ynneg= 0;

 //  xn = s3-s2; if (xn<0) { xnneg= 1; xn= -xn;}
 //  yn = s4-s1; if (yn<0) { ynneg= 1; yn= -yn;}
   if (s4>s2)
   {  y= s4-s2;
      yneg= 1;
   }
   else
   {  y= s2-s4;
      yneg= 0;
   }

   x= s1 - s3;

   if (s3>s1)
   // NOTPOS:
   {  x= s3-s1;
      if (!yneg)
      {  buph= tableph[256 * x + y] + 0x0100;
	 z= tablepyt[256 * (x/2 + 128) + y/2];
      }
      else // NEGAY3:
      {	 buph= tableph[256 * y + x] + 0xfe00;
	 z= tablepyt[256 * (x/2 + 128) + y/2 + 128];
      }
 //    buph= buph*64;
   }
   else if (x==0)
   {  if (!yneg)
      {	 buph= 0x4000>>6;
	 z= tablepyt[y/2];
      }
      else
      {	 buph= 0xc000>>6;
	 z= tablepyt[y/2 + 128];
      }
   }
   else if (yneg)
   {  buph= tableph[256 * x + y] + 0xff00;
      z= tablepyt[128 * x + y/2 + 128];
   }
   else
   {  buph= tableph[256 * y + x];
      z= tablepyt[128 * x + y/2];
   }
 //  buph= buph*64;


   testa004= (UC)(buph >> 2);	//TEST

   testtal= (buph >> 2) & 0x7f;		//TESTAFSNIT

   {  if (testtal>testgltal)
      {  if (testtal-testgltal > 10)
            fejltel++;
      }
      else
      {  if (testgltal-testtal > 10)
            fejltel++;
      }
   }
   if (fejltel==255)
   	fejltel= 0;
   	
   testgltal= testtal;

 
   // ROTBUPH:
   buph= fasekor[buph & 0x3ff];


   testa006= (UC)(buph >> 8);	//TEST

   
/*
   // TEST:
   // outf 12 bits to port freqh and freql, freqh-bit3 invert.
   //buph &= 0xfff;
   freqh= ((UC)(buph>>12)) ^8;  // high byte, bit 3 inverted
   a= (UC)(buph>>4);	// low byte
   freql= a;
   freqload= a;
*/

   buph= buph + fasepos[i];

   testa008= (UC)(i >> 4);	//TEST

   
/*
   // TEST:
   // outf 12 bits to port freqh and freql, freqh-bit3 invert.
   //buph &= 0xfff;
   freqh= ((UC)(buph>>12)) ^8;  // high byte, bit 3 inverted
   a= (UC)(buph>>4);	// low byte
   freql= a;
   freqload= a;
*/

   // OUTBUFA:
    if (z>buamav)
    {  if (buamav!=255)
	  buamav += 1;
    }
    else if (buamav!=0)
	 buamav -= 1;

}
// ** END of 1.6.1: burstfase *****

// *****************************************************************
void burstlock(void)
{  UC a;
   UI i;
   eph= subcref - buph;

/*
   // TEST:
   // outf 12 bits to port freqh and freql, freqh-bit3 invert.
   freqh= ((UC)(eph>>12)) ^8;  // high byte, bit 3 inverted
   a= (UC)(eph>>4);	// low byte
   freql= a;
   freqload= a;
*/

   i= oldph;
   oldph= eph;
   minus= 0;

   // make eph = (eph+i)/2  - (circular mean value) *

   if (eph > i)
   {  if ((eph - i) >= 0x8000)
	 minus= 1;
   }
   else if (i-eph >= 0x8000)
	 minus= 1;

   // CALC:
   eph= eph/2 + i/2 + (0x8000 * minus);

/*
   testtal= eph;		//TESTAFSNIT
   testa00a= testtal>>8;
   if (vargod)
   {  if (testtal>testgltal)
      {  if (testtal-testgltal > 0x800)
            testgltal= testtal;
      }
      else
      {  if (testgltal-testtal > 0x800)
            testgltal= testtal;
      }
   }
   testgltal= testtal;
*/



/*
   // TEST:
   // outf 12 bits to port freqh and freql, freqh-bit3 invert.
   freqh= ((UC)(eph>>12)) ^8;  // high byte, bit 3 inverted
   a= (UC)(eph>>4);	// low byte
   freql= a;
   freqload= a;
*/
   

   if ((phdet & 0xe000)==0 || (phdet & 0xe000)== 0xe000)
   {  phdet= eph>>1;
      if (phdet & 0x4000)  phdet |= 0x8000;
   }
   else
   { // TSPH15:
      if ((phdet & 0x8000)==0)
            phdet= eph>>1;
      else  phdet= (eph>>1) | 0x8000;
/*      
      {  if ((eph & 0x8000)==0)
            phdet= eph>>1;
         else  phdet= eph>>1;
      }
      else // TSPH2:
      {  if ((eph & 0x8000)==0)
	    phdet= (eph>>1) + 0x8000;
         else
         {  phdet= (eph>>1) + 0x8000;;
            //phdet |= 0x8000;
         }
      }
*/
   }


   // OUTDAC:  phdet upper 12 bits to port freqh and freql, freqh-bit3 invert.
   freqh= ((UC)(phdet>>12)) ^8;  // nipple 3 (bit 3 inverted)
   a= (UC)(phdet>>4);	// nipple 2+1
   freql= a;
   freqload= a;





   hfasec();
// ** END of 1.6.2 **
}
// ************************************************************
void hlock(void)
{  UC a;
   hfasef();
   phdiff= href - hinput;
   if (phdiff & 0x80000000)
   {  phdiff= hinput - href;
      if (phdiff < 0x00020000)
      { // TS400:
	 if (phdiff >= 0x00000400)
             outf= 0x401;
	 else outf= -phdiff;
      }
      else  // SETPHD:
      {	 phdiff= (UL)hlen*256 - phdiff;
         if (phdiff >= 0x00000400)
            outf= 0x3ff;
	 else outf= phdiff;
      }
   }
   else // TSB1817:
   {  if (phdiff < 0x00020000)
      { // TS4002:
	 if (phdiff >= 0x00000400)
            outf= 0x3ff;
	 else outf= phdiff;
      }
      else
      {	 phdiff= (UL)hlen*256 - phdiff;
         if (phdiff >= 0x00000400)
            outf= 0x401;
	 else outf= -phdiff;
      }
   }
   // SNDOUTF:
   outf <<= 1;

   // outf LOWER 12 bits to port freqh and freql, freqh-bit3 invert.
   freqh= ((UC)(outf/256)) ^8;  // high byte, bit 3 inverted
   a= (UC)(outf & 0x00ff);	// low byte
   freql= a;
   freqload= a;
   hfasec();
// ** END of 1.6.3 **
}
// ************************************************************
void intern(void)
{  UC a;
   freqh= (UC)(freqref>>8);
   a= (UC)(freqref & 0x00ff);
   freql= a;
   freqload= a;
}
// ** END of 1.6.4 **
// ************************************************************
void hfasec(void)
{  UC s1, s2;
   s1= (UC)(href>>11);
   s2= (UC)(hpos>>3);
   if (s1>s2)
   {  s1 = s1-s2;
      if (s1>hcen)
      { // S1BIG:
         s1= hcyk-s1;
	 if (s1>4)  linadd= add4;
      }
      else if (s1>4)  linadd= supr4;
   }
   else // S2BIG:
   {  s2= s2-s1;
      if (s2>hcen)
      { // S2BIG2:
	 s2= hcyk-s2;
	 if (s2>4)  linadd= supr4;
      }
      else if (s2>4)  linadd= add4;
   }
}
