#include <xa.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <intrpt.h>
#include "equ.c"
#include "vars.c"

/*
;********************************************************
; filename	: BBU.C					*
;********************************************************
// HISTORY

	public 	start,wait
	extrn code(knap,line7,lock,mode,sch,vint)
	extrn code(lineint,vtimerint,tablestart,startf4,kommun)
*/

#define UC unsigned char
#define UI unsigned int
#define UL unsigned long



extern void PutData1(char A,char B,unsigned char x);
// extern void Serial1_int(void);
// ROM_VECTOR(IV_T0, timer0_int, IV_PSW)
// ROM_VECTOR(IV_T1, timer1_int, IV_PSW)
ROM_VECTOR(IV_EX0, ext0_int, IV_PSW)
ROM_VECTOR(IV_EX1, ext1_int, IV_PSW)
ROM_VECTOR(IV_RI1, Serial1_int, IV_PSW)

extern char get_char1();

char header1;
UC cc;
UI Number;
bit req,quit,save;	// flags for requests from frontplate
/* RECEIVE/SEND SYNTAX:					*/
/* Serial:	PutCmd(A,B)				*/
/*		PutData(A,B,data);			*/
/*		PutData16(A,B,data);			*/
/*		PutStr("string");			*/

// ********************************************************************
void NotFound(void) {
}
// ********************************************************************

near struct kommando {
	 char Aa;
	 char Bb;
	 void (*funktion)(void);
};
// ********************************************************************

interrupt void ext0_int(void)
{ 
  UL ts, r;
  UI a, b;
  UC lintyp;

  P3_0= 0;
  if (fieldpuls1==1)
  { lincnt1= 0;
    subfa1= 0;
    hfasefport1= (UC)(hfase1 & 0x000000ff);
    hfasecport1= (UC)((hfase1 & 0x000fff00)>>8);
  }

  else
  { lincnt1= (lincnt1+1)%gmod;
    lintyp= typeg[lincnt1];


    // CALCULATE BURST FASE
    ts= t + tcal;
    a= ts>>16; b= ts & 0x0000ffff;
    r= ((a*fsubh)<<16) +  ((a*fsubl)) + ((b*fsubh));
    subfa1= (r>>16) & 0x7ff;
  }
  if (poff1)  lintyp |= 8;
  typeport1= lintyp;
  if (syst1)  subfa1 |= 0x8000;
  bulowport1= (UC)(subfa1 & 0x00ff);
  buhiport1= (UC)((subfa1 & 0xff00)>>8);
  P3_0= 1;
} 
// ********************************************************************
interrupt void ext1_int(void) // FV_BB2
{
  UL ts, r;
  UI a, b;
  UC lintyp;

  P3_1= 0;
  if (fieldpuls2)
  { lincnt2= 0;
    subfa2= 0;
    hfasefport2= (UC)(hfase2 & 0x000000ff);
    hfasecport2= (UC)((hfase2 & 0x000fff00)>>8);
  }
  else
  { lincnt2= (lincnt2+1)%gmod;
    lintyp= typeg[lincnt2];

    // CALCULATE BURST FASE
    ts= t + tcal;
    a= ts>>16; b= ts & 0x0000ffff;
    r= ((a*fsubh)<<16) +  ((a*fsubl)) + ((b*fsubh));
    subfa2= (r>>16) & 0x7ff;
  }
  if (poff2)  lintyp |= 8;
  typeport2= lintyp;
  if (syst2)  subfa2 |= 0x8000;
  bulowport2= (UC)(subfa2 & 0x00ff);
  buhiport2= (UC)((subfa2 & 0xff00)>>8);
  P3_1= 1;
} 

// ********************************************************************
/* interrupt void timer0_int(void)
{
}
// ********************************************************************
interrupt void timer1_int(void)
{
} */
// ********************************************************************

// ********************************************************************
void main(void)
{ UI v;

  for (v=0;v<65000;v++)  	// delay start-up

// System set-up
  BTRL= 0xff;	// EXT. BUS timing, 0x5f is min.
  BTRH= 0xff;	// do., DATA, 0x9f is min.
  BCR= 0x02;	// set 20 bit BUS, 8 bit DATA
  PSWL= 0;	// clear flags
  PSWH= 0x80;	// enable system mode
  SCR= 0;	// (0)prescaler 4

// set-up counters and interrupts
  EX0= 1;		//ENABLE INTR FROM EXT0
  EX1= 1;		//ENABLE INTR FROM EXT1
  IT0= 1;		//INTR0 EDGE TRIG
  IT1= 1;		//INTR1 EDGE TRIG
  IPA0= 0x06;		// EX0 prior.
  IPA1= 0x06;		// EX1 prior.

  TMOD= 0x21;	//T1 =8 bit reload, T0 =16 bit (not used)
  ET1= 0;	// intrpt from timer1 disabled
  RTL1= -48;	// reload value for Timer 1, sets Baud rate to 9600

/* alternativ til timer 1: timer2 til V24 (max-rate)
  T2MOD= 0x31;	// use T2 for V24_1, count up
  T2CAPH= -1;	// set reload values for max Baud
  T2CAPL= -1;
  TH2= -1;	// set for max. Baud
  TL2= -1;
  TR2= 1;	// start V24-timer
*/

  S1CON= 0xF2;	// Transmit mode 3,  9 bit UART,  Address mode, Rec.enable
  IPA5= 0x77;	// serial 1 prior.
  ERI1= 1;	// enable ser.1 receive
  // ETI1= 1;	// enable ser.1
  S1ADDR= 0xC0;	// receive address
  S1ADEN= 0xFD;	// mask for receive address
  // receive address = 11000000 AND 11111101 = 110000X0

// preset some internals

// recall some internals

// enable interrupts
  EA= 1;			//enable all interrupts
  TR1= 1;	// start V24-timer
	
// interrupt waiting loop
// WAIT:	
  while(1)
  { ; // PutData1('G','O',0x55);
  }
}

/* ********************************************************************	*/

/* ********************************************************************	*/
/* TABLE FOR ARRIVING COMMANDOS	FROM V24				*/
/* ********************************************************************	*/
void dummy(void)
{ ;
}

code const struct kommando kommandotabel[] = {

'S','W',dummy,
'P','R',dummy
};
/* ********************************************************************	*/
/* Command Machine							*/
/* ********************************************************************	*/
CommandExecute(char A,char B) {
UC x;
for (x = 0; x < (sizeof(kommandotabel)/sizeof(struct kommando)); x++)
   if (A==kommandotabel[x].Aa)
      if (B==kommandotabel[x].Bb)
      {	
	header1 = A;
	kommandotabel[x].funktion();
	break;
      }
}
// ***************************************************************
CharHandler(char c)
{ static UC MesState;
  static char First,Second;
  switch ( MesState)
  { case 0: if(isalpha(c) || (c=='?'))
  	    { First = toupper(c); MesState = 1;} break;
    case 1: if(isalpha(c) || (c=='?'))
    	    { Second =toupper(c); MesState = 2; Number = 0;} break;
    case 2: if(isdigit(c))  Number = 10 * Number + (c-'0');
	    if (c== 10 || c== '?' || c== '!' || c== '$')
	    { MesState = 0;
	      if (c == '?') req = 1; else req = 0;
	      if (c == '!') quit = 1; else quit = 0;
	      if (c == '$') save = 1; else save = 0;
	      CommandExecute(First,Second);
	    } break;
    default: MesState = 0; break;
  }
}

// ***************************************************************
void kommun(void)
{   while ((cc=get_char1()) != 0)	/* handle characters from buffer */
		  CharHandler(cc);

}
// ***************************************************************

