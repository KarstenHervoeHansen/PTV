/*
File:	tabpytm.c
*/

#include <stdio.h>

code unsigned char pytm[]=
{ 1,1,1,1,1,1,1
};
