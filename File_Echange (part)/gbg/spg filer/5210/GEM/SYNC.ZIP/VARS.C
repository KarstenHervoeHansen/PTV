/*
File name: vars.c
Project:   PT5210
Purpose:   variables definitions
Author:    PRC
Org date:  960506
Special:   This file should be included after the file 'equ.c'.

History:

*/


// BUFFER
near UC combuf[8];	//buffer for commands from master uP


// BYTE VARIABLES IN BIT AREA
// UC saves;
volatile UC doflags @ 0x20;
volatile UC outs @ 0x21;

// OTHER BITS
bit alian;	 //
bit bulocken;	 //
bit cntenab;	//line counter enable
bit epapu;	 //white bar is on active linie
bit level;  	//level shift bit
bit lockdet;	 //
bit minus;	 //flag for negative medium result
bit window;	 //flag for field pulse in window

// BYTE VARIABLES
NUC atel;	 //taeller rundt til 5 paa line  		| disse 3 signaler
NUC black;	 //gennemsnits sort vaerdi
NUC blackav;	//black value average
NUC btel;	//taeller rundt til 125 paa carry fra a	| udgoer tilsammen en
NUC buam;
NUC buamav;	 //
NUI buph;
NUC cvartel;	//taeller varighed til outdata loades fra tabel
NUC dpoint;	//data pointer in table
NUI eph;	//external burst phase
NUC errpre;	//error preset variable
NUC ftel;	 	//taeller rundt til 4 paa carry fra b	| 8 field linie taeller
NUI genphase; 	//wanted genlock fase, updated from frontplate
NUC godgren;	//indicates which branch in SCH was last used
NUI hpos;	//position of extern line
NUI htel;	 //H-counter
NUI i;	 	//local variable
NUI j;	 	//local variable
NUC levelcnt;	//counter for good/bad fields
NUC linadd;	//correction value for LINTYP output
NUC lintyp;	//last read line type
NUI oldph;	//old ext. burst phase
NUC oldread;	 //last legal kommun. port read value
NUI outf;	//output freq.
NUC palav;	 //
NUC papua;	 //pal pulse ampl.
NUC papulock;	//taeller til at finde ud af om der er 8 fields puls
NUI phdet;	//phasedet. var. for use in freq.lock
NUC phgod;	 //filter counter for line7
NUC savacc;	//store for accu
NUC schgod;	//filter counter for SCH routine
NUC schph;	 //sch fase paa input signal
NUC speeddel; 	//counter for button speeder delay
NUC speedval; 	//button speeder rate
NUC sphgod;	 //filter counter for line7
NUI subcpot;	//wanted subc genlock phase, derived from genphase
NUI subcref;	//subc phase in aktual line
NUC sync;	//gennemsnits sync vaerdi
NUC trig;	//trigger niavue for 50 % sync		
NUC verr;	//taeller der taeller ned paa gode fields
NUI x;		//immediate result from burstfase
NUI y;		//immediate result from burstfase
NUI z;		//immediate result from burstfase


#if gvers==1
NUC secamav;	 //for secam filter

#else
NUC oldpalm;	 //
NUC diff;	 //for PALM filter
NUC palm;	 // Do.

#endif


// BITS IN BYTE: DOFLAGS(@20)
volatile bit	dolock	@ 0x100;
volatile bit	dosch	@ 0x101;
volatile bit	domode	@ 0x102;
volatile bit	doknap	@ 0x103;
volatile bit	doline7	@ 0x104;
volatile bit	nsf	@ 0x105;

// BITS IN BYTE outsb (@21): 
volatile bit	syncav	@ 0x108;
volatile bit	lockbit	@ 0x109;
volatile bit	spgint	@ 0x10a;
volatile bit	buav	@ 0x10b;
volatile bit	pal	@ 0x10c;
volatile bit	slowlock @ 0x10d;
volatile bit	secam	@ 0x10e;
volatile bit	tau	@ 0x10f;

// BITS IN BYTE savesb(@22): 
volatile bit genlocken @ 0x110;
volatile bit pplocken  @ 0x111;


// PORT ADDRESSES

char dualport @ 0x4000;	// dual port ram;
char * near dual = &dualport;
volatile UC freql @	0x6000;	//port for output frequency, low byte 	(sel 3)
volatile UC freqh @	0x6080;	//	-	-	-  high byte 	(sel 4)
volatile UC outport @	0x4fff;	//output  port
volatile UC freqload @  0x8000;	//pseudo-port for update of DAC
volatile UC typeport @	0x2000;	//port for output of linietype 		(sel 5)

volatile UC ehportl  @	0x2001;	//port for read-in of exstern h position, low byte  (sel 7)
volatile UC ehporth  @	0x0201;	//	-	-	-	-    	 high byte (sel 8)



// VARIABLES 24BIT
near UL scratc;	 //scratch pad, 3 bytes
	
near UL hinput;	 //maalt horisontal fase af input signal
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near UL href;	 //oensket horisontal fase af input signal
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near UL hphzero;	 //calibrerings data til indstilling af genlock fase
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen
near UL phdiff;		//fase difference mellem input og oensket fase
			// maalt som ram position
			// bestaar af 3 byte 
			// 2 der giver ram position i clockpulser
			// 1 der giver underindelingen


// PORT BITS
// sbit P3_0 @ 0x398;
// sbit P1_5 @ 0x38d;

// TABLES
code UC * near tableph;
extern code UC fase[];

code UC * near tablepyt;
extern code UC pytg[];
extern code UC pytm[];

code UC *near tableam;
extern code UC divi[];

code UI * near fasekor;
extern code UI fasekorg[];
extern code UI fasekorm[];

code UI * near fasepos;
extern code UI faseposg[];
extern code UI faseposm[];
