/*
File:		mas.c
Author:		PRC
HISTORY:

 Rel.0.0 002xxxxx
960214 Created
*/
/* Denne fil indeholder i starten nogle HI-SOFT eksempler som
   kommentarer for at hj�lpe overgangen fra KEIL.
*/
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <xa.h>
#include <intrpt.h>

/* ANDRE MULIGE INCLUDES FOR HI-SOFT-C:
assert.h conio.h errno.h float.h hitech.h intrpt.h
limits.h setjmp.h stdarg.h stddef.h sys.h time.h
*/
// INCLUDE FRA AKTUELT DIR:
#include "vars.c"

/* KEIL KOMPATIBILITET:
#define XBYTE ((UC *) 0x00000L)
#define xdata		// gammel 'xdata' i bank 0
#define xdata far	// 'xdata' i 64K-banke
#define data  near	// interne 'data'
*/

/* VARIABLE: */
#define UC unsigned char	// praktiske forkortelser
#define UI unsigned int
/* UC, bit, char, int */

/* ADDRESSING:
IN:  0:RAM, 2000:IND1, 4000:IND2, 6000-ffff:Free, 10000-:Mirror
OUT: 0:RAM, 2000:UD1, 4000:UD2, 6000:UD3, 8000:UD4, A000:UD5, 
     C000-ffff: Free, 10000-:Mirror
ROM: 0-1ffff: Program, 20000-3ffff: PGA-Data, 40000-7ffff: Free, 80000-:Mirror
*/
/* CONSTANTS: */
volatile UC  ind1 @ 0x2001;	// input port 1
volatile UC  ind2 @ 0x4001;	// input port 2
volatile UC  ud1 @ 0x2001;	// output port 1
volatile UC  ud2 @ 0x4001;	// output port 2
volatile UC  ud3 @ 0x6001;	// output port 3
volatile UC  ud4 @ 0x8001;	// output port 4
volatile UC  ud5 @ 0xa001;	// output port 5
code far UC  pgadata @ 0x20000;	// PGA-PROM
#define    Unit_RESET   ud4 &= ~0x80; // MRES down
#define    Unit_RESET_off   ud4 |= 0x80; // MRES down

/* DEFINING HARDWARE */
/* sbit    Front_RESET    =   P3^4; */

UC c, cc;		// common globals
UI Number;		// IEEE number transfer data
UI teller;		// time-out counter
bit Acknowledge;	// Acknowledge after IIC communication
char header1;		// store for 1'st letter in frontpl. cmd.
bit req,quit,save;	// flags for requests from frontplate

// ********** TEMPERATURE VARIABLES *******
int temp;		// temperature
UI oldtemp, grense;	// temperature stores
UC tempcnt;		// counter for speed change filter
bit shotdown;		// flag for very hot apparatus
UC tempwarn;		// flag for hot apparatus

// ********** SYSTEM VARIABLES *******
UC slicer;	// time window counter
UC glremstate;	// store for old remote state
UC options;	// bits 0..4 is source/vidkey/vidproc/secprog/async
UC reread;	// counter for re-read of sync gen. (time-out)
bit Timer_flag;		// control bit for 21 ms timing
bit genbusy, bufbusy;	// generator not ready to receive, bus busy
bit req_ready;		// ready to answer requests
UI fejl;



/* 
** BLANDEDE DEFINITIONER ***
const int  version = 3;		// konstant
const char * cptr;		// pointer til en konstant
volatile UC  P1 @ 0x430;	// svarer til assembler:  _P1  equ  430h
   (SFR's er defineret i filen xa.h:  #include <xa.h>)
   NB! alle var's og alle porte som kan �ndres af INT-rutiner
   skal erkl�res som VOLATILE! 
   static bit  flag1;		// opretter bit i: psect rbit
static bit  P3_0 @ 0x3a0;	// erkl�rer SFR-bit (er ikke i xa.h)
static UC  R2H @ 0x05;		// erkl�rer 8-bit register
static UI starttab[]= { 0x0000, 0x8A99};
code int count= 0x1234;		// opretter count i: psect code
code int * countptr;		// opretter pointer til psect code
   NB! code pointer er IKKE kompatibel med normal eller far pointer!
*/
/* LINKER:
Linkeren l�gger RAM og ROM i forskellige 'psect'.
f. eks: rbit, text, code.
*/

/* ********************************************************************	*/
/* void put_char (UC c)
{   while (!TI0) ;    // wait for transmitter ready
    TI0 = 0;
    S0BUF = c;
} */
/* ********************************************************************	*/
void pause(UI time)
{ while (time>0)  time--;	// delay= 1 us + time x 5 us
}
/* ********************************************************************	*/
/* Definition af interruptfunktion (HI-TECH, si.82):
ROM_VECTOR(IV_RI0, Serial0_int, IV_PSW)
 Andre interrupt-def:  se sidst i filen: xa.h */
/* ******************************************************************** */
/* interrupt void serial_int(void)
  { 		// en interrupt funktion m� ikke have parametre
  if (fieldno & 1)
  { lineno= 18; delay(2);}		// drop a line intr. in field 2
  else lineno= 0; // foer omvendt!!!
  fielcnt++;		// count fields
  delay (39);		// wait n x 3 + 1us
  vflag= 1;		// set flag for "field was here"
  R2H= port2tab[lineno] | v24on;
} */
/* ********************************************************************	*/
/* Erkl�ring af extern ASM-rutine (si.84): extern char left(char);
   Selve ASM-rutinen: se si.84-86.
   Bem�rk: Navne i ASM skal have '_' (underscore) foran C-navnet */
/* ********************************************************************	*/
/* INLINE-ASM:
#asm
	MOV	R0,_var
#endasm      NB! Denne form m� ikke indg� i flow-kontrol (if, while, m.m.)
Alternativ:
 asm("MOV  R0, _var");    Kan indg� alle steder.
*/


/* ********************************************************************	*/
void modesel(void)
{ char a;
  a= 1;
}
/* ********************************************************************	*/
struct kommando {
	 char Aa;
	 char Bb;
	 void (*funktion)(void);
};
void warntemp(void) {
};
/* ********************************************************************	*/
/* TABLE FOR ARRIVING COMMANDOS	FROM FRONTPLATE				*/
/* ********************************************************************	*/
code const struct kommando kommandotabel[] = {
// STATUS
'V','M',modesel,
// TESTSIGNAL
/* 'P','G',&group_select,
// MODE
'S','Y',&syins,
// LOCK
'L','S',&lockstat,
// SYNC
'S','F',&subfa,
'G','F',&genfine,
'G','C',&gencorse,
'A','Z',&autozero,
'B','G',&blgenlo,
'S','S',&sourcesel,
// TTL
'T','P',&progpin,
// IEEE
'I','A',&ieeeadr,
'R','I',&remoask,
// REQUEST
'R','Q',&request,
'W','T',&warntemp,
// TEST
'M','T',&temprap,
// OPTIONS
'S','P',&secprog,
'x','x',&NotFound */
};
/* ********************************************************************	*/
/* Command Machine							*/
/* ********************************************************************	*/
CommandExecute(char A,char B) {
UC x;
for (x = 0; x < (sizeof(kommandotabel)/sizeof(struct kommando)); x++)
   if (A==kommandotabel[x].Aa)
      if (B==kommandotabel[x].Bb)
      {	
	header1 = A;
	kommandotabel[x].funktion();
	break;
      }
}
/* ********************************************************************	*/
CharHandler(char c)
{ static UC MesState;
  static char First,Second;
  switch ( MesState)
  { case 0: if(isalpha(c) || (c=='?'))
  	    { First = toupper(c); MesState = 1;} break;
    case 1: if(isalpha(c) || (c=='?'))
    	    { Second =toupper(c); MesState = 2; Number = 0;} break;
    case 2: if(isdigit(c))  Number = 10 * Number + (c-'0');
	    if (c== 10 || c== '?' || c== '!' || c== '$')
	    { MesState = 0;
	      if (c == '?') req = 1; else req = 0;
	      if (c == '!') quit = 1; else quit = 0;
	      if (c == '$') save = 1; else save = 0;
	      CommandExecute(First,Second);
	    } break;
    default: MesState = 0; break;
  }
}
/* ********************************************************************	*/
/* void Next_please(void) interrupt 0 
{ genbusy = 0; } */
/* ********************************************************************	*/

ROM_VECTOR(IV_T0, Timer_int, IV_PSW)
ROM_VECTOR(IV_RI0, Serial0_int, IV_PSW)
ROM_VECTOR(IV_RI1, Serial1_int, IV_PSW)

#define xtal 30000000
/* ******************************************************************** */
interrupt void Timer_int(void)
{ TH0 = -255; // xtal/100/256/4;  // Load timer to appr. 100 Hz
  Timer_flag = 1;
}
/* ********************************************************************	*/

/* UC get_char(void)
{
  return(0);
} */
/* ********************************************************************	*/
void main(void)
/* ********************************************************************	*/
/* ********************************************************************	*/
{ UI i;
  UC /*i,n,*/x;

// System set-up
  BTRL= 0xff;	// EXT. BUS timing, 0x5f is min.
  BTRH= 0xff;	// do., DATA, 0x9f is min.
  BCR= 0x02;	// set 20 bit BUS, 8 bit DATA
  PSWL= 0;	// clear flags
  PSWH= 0x80;	// enable system mode
  SCR= 0;	// (0)prescaler 4
  
// Serial set-up
  S0CON= 0xD2;	// Transmit mode 3,  9 bit UART, Receive enable
  S1CON= 0xF2;	// Transmit mode 3,  9 bit UART,  Address mode, Rec.enable
  // PCON= 0;	// => SMOD = 0, not double Baud Rate
  //  TI0= 1;	// set transmitter ready
  S1ADDR= 0xC0;	// receive address
  S1ADEN= 0xFD;	// mask for receive address
  // receive address = 11000000 AND 11111101 = 110000X0
  
// Timer set-up
  TMOD= 0x21;	// timer 1: 8 bit autoload; timer 0: 16 bit count
  RTL1= -48;	// reload value for Timer 1, sets Baud rate to 9600
  TH0= -255;	// start value
  T2MOD= 0x31;	// use T2 for V24_1, count up
  T2CAPH= -1;	// set reload values
  T2CAPL= -1;
//  T2CON= 0x30;	// use T2 for V24_0
  TH2= -1;	// set for max. Baud
  TL2= -1;
  TR2= 1;	// start V24-timer
  
// Interrupt setting
  EX0= 1;	// enable ext0
  ET0= 1;	// enable timer0 intrpt
  ET1= 0;	// intrpt from timer1 disabled
  IT0 = 1;	// edge trig on ext0
  IT1 = 1;	// edge trig on ext1
  IPA0= 0x30;	// equ: PT0= 3
  IPA4= 0x88;	// serial 0 intrpt.
  IPA5= 0xaa;	// serial 1 intrpt.
  EA = 1 ;	// enable all
  
  TR0 = 1;	// start loop timer
  TR1= 1;	// start V24-timer
  
           // Default settings
//  extern void memalloc(void);	// reserve space for resident variables
 //  memalloc();			/* allocate memory
//  initpoint();		// initiate pointers

  Write_iic2(0x90,0x40,0);	// turn off blower

  oldtemp = 255;		// initiate temper. control
  tempwarn = 0;
  slicer=0;
  Number=0;
  teller=0;
  options=0;
  reread=0;


/* ********************************************************************	*/
/* Reset all units.
   Each execution off "Port-pin = 1" causes a pulse of appr. 30 mA to
   run for 167 nsec. The inner loop below is running 7 usec.
   Due to capacitive loading (5 * 1.5 uF on Unit_RESET) the reset procedure
   uses 100 msec with 0.160 usec / 7 usec * 30mA to reach a guarantied level
   on the reset pins.
   After ending the reset pulse the software will wait for another 20 msec
   to allow all units to do their own initialisation.			*/
/* ********************************************************************	*/
  x = 0;
  while(x++ < 6)
  { Timer_flag = 0;
    while (Timer_flag == 0 ) { Unit_RESET;}
  }
  genbusy = 1;		// set generator 'BUSY' flag
  Unit_RESET_off;
// Wait for units to init their IIC interface

  pause(20);		// wait 20ms

// Check phases

//  bufptr = 0;
//  x = romcheck();	// perform ROM check - TAKES TIME!

 // wait for other promcheck etc., max. 0.66 sec

/* ********************************************************************	*/
 // RECALL OLD SETTINGS
  grense = templimit-2;		// limit for blower (high temp.)
//  Watch_dog_pin = ~Watch_dog_pin;
//  eeromcheck();
//  pause(300);		// TEST: wait 300ms
  fejl = 0;
  // ramcheck();
  // checkopt();		// find options

  if (fejl & ramerr)
  { // load_ram();
    // defphases();
    // ttlinit(0);		// make default ttl-tables[0..1]
  }

  // opstart();


/* ********************************************************************	*/
/* ENDLESS LOOP
/* ********************************************************************	*/
  while(1)
  {  while(Timer_flag == 0)	// while waiting for timer flag
    {	if (req_ready)		// moved to here 931220
	if (!bufbusy)  // read new orders only when GEN. buffer is empty
	   while ((cc=get_char1()) != 0)	// handle characters from buffer
		  CharHandler(cc);
/*	
	if ((options & 1)  && souready)
	{ if (soureq && souend)
	  {
	    if (!souerr)
	    {	if ((cc=Read_iic(0x44)) == 0xff)
		{ souerr= 1;
		  if (++soutiout > 2)
		  { soureq= 0; soutiout= 0; souerr= 0;}
		}
		else
		{ soureq= 0; soutiout= 0;
		  soudecode(cc);
		}
	    }
	  }
	  else if ((cc=getsource()) != 0)	// if more in buffer
	  { Write_iic(0x44,cc);			// then send
	    souready= 0;
	    if (souend)
	    { souhead= cc; souend= 0;
		if (cc & 0x40)  soureq= 1;	// request type
	    }
	    else if (cc==0xff)  souend= 1;
	  }
	}

// ** SEND TO GENERATOR ***
// The bit genbusy=0 shows that the Generator is ready to receive a byte.
//   If bufptr > 0 a byte is taken from cmdbuf[bufptr-1] and sent to the generator
*/

/*	if (bufptr>0)	 
	{   bufbusy = 1;	// f�r: (!genbusy)
	    if (!genbusy) 	
	    {	genbusy = 1;  	// f�r (bufptr)
		Write_iic(0x4E,cmdbuf[(bufptr--)-1]); // send
		if (Acknowledge)  teller3 = 0;
		else
		{ if (teller3 < 5)  bufptr++;  // resend up to 5 times
		  fejl |= gencomerr;
		}
	    }
	    else if (++teller3 > 9 )   	// if Gen. not ready > 9 times
	    {	fejl |= (genfferr + gencomerr);	// then set error bit	
		genbusy = 0;		// and force Gen. ready
	    }
	    if (bufptr==0)  bufbusy=0;	// unlock buffer
	}
*/	else bufbusy = 0;
    }
    
// 10 ms TIMER EXPIRED
/* ********************************************************************	*/
     if (slicer&1) ; // syncmanage(); // read/write routine for sync gen.
/*
     // Remote control (IEEE488, RS232, TTL ,... )
    if (glo<2)
    {       if (2 == RemotePoll() ) {
                Code = PM91Maskine(RemoteGet());
                if (Code != 0) {
                    if(CmdParameters == 0 && CmdParam[0].Type == 0 ) {
                    }
                    else {
                        CmdParameters++;
                    }
                    Code = IEEExecute(Code);
                    // Returns Error-code
                    if ( Code != 0 ) {
                        StatReturn(Code);
                    }
                }
            }
    }

*/
    Timer_flag = 0;
    slicer++; if (slicer > 10) slicer = 1;	// divide in 21 windows

    if (slicer&1)
    { // readttl();	// read TTL ports every 20ms to collect inputs
    }	

    if (slicer == 1) 				/* window 1 */
/* ********************************************************************	*/
    {  temp = Read_iic(0x90); // set blower speed from NTC resistor temp
	if (temp==0) temp= 255;
	if (temp==oldtemp) tempcnt=25;
	else if (--tempcnt==0 || oldtemp>temp+1)
	{   tempcnt = 25;
	    oldtemp = temp;
  // MANAGE TEMPERATURE WARNINGS
	    if (temp> hottemp+2)		// test if colder than HOT
	    { if (tempwarn!=0)
	      { tempwarn=0; warntemp(); } // warning off
	    }	
	    else if (temp< panictemp)		// test if warmer than TOOHOT
	    { shotdown= 1;			// then shot down
	      if (tempwarn!=2)
	      { tempwarn=2; warntemp(); } // WARNING to frontplate4e
	    }
	    else if (temp< hottemp)		// test if warmer than HOT
	    { if (tempwarn!=1)
	      { tempwarn=1; warntemp(); } // WARNING to frontplate
	    }
 	    if (temp> panictemp+10)
	    if (shotdown)
	    { shotdown=0; // NOT TOOHOT, CANCEL SHOTDOWN
	      // klardat= 0;	// normal start without data reset
	      // restart();
	    }
  // SET BLOWER SPEED
	    if (temp>grense)
	    {	temp= 0;	// cold, blower off
		grense = templimit-2;
	    }
	    else
	    {	grense = templimit;
		temp= 336 + blowvolt - 2*temp - temp/2;
		if (temp<0) temp= 0;
		else if (temp>255) temp =255;
		
		if (temp<0)  temp = 0;
	// Adjust 'blowvolt' to set the lowest blower voltage. 1V pr.12.
	// control the blower voltage gain by the term: (3*temp) >>1
	    }
	    Write_iic2(0x90,0x40,(UC)temp);
	}
    }

    if (slicer == 2) 		/* window 2 */
/* ********************************************************************	*/
    {
    }

    if (slicer == 3) 		/* window 3 */
/* ********************************************************************	*/
    {
    }

    if (slicer == 4)		/* window 4 */
/* ********************************************************************	*/
    {
    }

    if (slicer == 5)		/* window 5 */
/* ********************************************************************	*/
    {
    }

    if (slicer == 6)		/* window 6 */
/* ********************************************************************	*/
  { /*	ttlexe();	// scan inputs and execute
	ttloutin();	// do output and read input
*/   
  }	

    if (slicer == 7)		/* window 7 */
/* ********************************************************************	*/
    { Wr_iic_2(0x44,'A');
    }

    if (slicer == 8) 		/* window 8 */
/* ********************************************************************	*/
    { PutData('G','O',0x55);
      PutData1('G','O',0x55);
    }

    if (slicer == 9) 		/* window 9 */
/* ********************************************************************	*/
    { Write_iic(0xa0,0x55);
      i= Read_iic(0xa0);
    }
/* ********************************************************************	*/
  }
}
