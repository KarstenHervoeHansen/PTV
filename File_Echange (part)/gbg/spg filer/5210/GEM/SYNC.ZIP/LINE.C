#include <xa.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <intrpt.h>
#include "equ.c"
#include "ext.h"
#include "tables.c"


/*	'I N T E R R U P T    R O U T I N E S'
********************************************************
 filename	: line.c				*
 version	: 960731				*
 author		: p.christiansen			*
 optimized for	: speed					*
 specialities	:					*
********************************************************
	public 	hfasef,lineint,line7,mode,sch
	extrn   data(start1,start2,start3,start4)
	extrn	code(kommun,tablestart)
*/

extern UC vargod;	// TEST
extern bit genlocken;

code UC * near tableptr;

interrupt void line_int(void)
{  UI i;

   if (cntenab)		// count only H-lines if enabled
   {  htel += 1;
     if (htel==0)
		TF0= 1;	// counter was zero, set vtimer-interrupt
   }
   else
      i= htel;
   if (ns==1)
   { // nsf= 1; //<960509d

      if (vargod)
	 vargod= 0;

     verr= verrpre;
  }
// ADOWN  :
   atel -= 1;		// count lines
   if (atel==0)
   {  btel -= 1;		// count 3xlines
     if (btel==0)
	// 1 frame gone
      {	 if (syncav)
	 {  if (levelcnt)  levelcnt -= 1;	// good/bad field-filter
	 }
	 else
// NOSNC:
	 {  if (levelcnt & 128)
	    {  level = !level;
	       levelcnt= 0;
	    }
	    else levelcnt += 20;
	 }
// CKLOCK:
	 if (lockbit)
	 {  if (blackav > level2)  level= 1;
	    else if (blackav <= level1)  level= 0;
	 }
// SETA:
	 atel= afield;	// re-load 9-line counter
	 btel= bmax;	// re-load 70*9 counter
	 ftel -= 1;
	 if (ftel==0) ftel= fmax; // 8 fields gone, re-load frame counter
// GETDUR:
		// set subcref (correct later for frame no.) *
#if gvers==1
	 subcref= subcpot+(4-ftel)*0x4000;	// set new reference, G
#define tblsize 28
	 tableptr= tablestart + (4-ftel) * tblsize;
#else
	 subcref= subcpot+(2-ftel)*0x8000;	// set new reference, M
#define tblsize 26
	 tableptr= tablestart + (2-ftel) * tblsize;
#endif	
// DPOK:
// get new duration and line type from table **
	 lintyp= *tableptr; tableptr++;
	 cvartel= *tableptr; tableptr++;
	 typeport= lintyp;
      }
      else
      // SETAMAX:
      {  atel= amax;		// re-load 9-line counter
         cvartel -= 1;	// count duration (c= c-1)
    
         if (cvartel==0)
         {  lintyp= *tableptr; tableptr++;	// Get new type and duration
	    cvartel= *tableptr; tableptr++;
         }
         // NOTFRAME:
         typeport= lintyp;
      }
   }
   else
   // TSACAL:
   {  cvartel -= 1;	// count duration (c= c-1)
      if (cvartel==0)
      {  lintyp= *tableptr; tableptr++; // Get type and duration
	 cvartel= *tableptr; tableptr++;
      }
      // TSACAL2:
      if (atel==acal)
      {	 typeport= (lintyp | linadd);	// line 6 of 9 is found
	 linadd= 0;
	 subcref += subcinc;		// add 25Hz offset to subc
	 hpos= 256*ehporth + ehportl;	// get ext. hpos
	 if (hpos & 0x8000)  lockdet= 1; else lockdet= 0;
	 hpos &= 0x07ff;
	 // find special lines
	 doflags |= btable[btel];
      }
      else
      // TSSAMP:
      {	 if (atel==asamp)  
            {  typeport= lintyp | samp;	// atel = 8 found
	    }
	 else
	    {  typeport= lintyp;
            }
      }
   }
// ** END of 1: lineint *****
}

// ***************************************************************
void line7(void)
{  UI i;
   if (genlocken && syncav && !verr && buav) //<960509d
   {
#if gvers==1
      if (ftel==4)
      {  i= (oldph>>8) & 0xfffc;
         if (i==pha40 || i==pha45)
         { // TSG1:
            phgod= errpre;
            if (phdiff<sch61)  sphgod= errpre;
 //         else if (schph> sch62) sphgod= errpre; <960509d
            else if (sphgod==0)
            {  sphgod= errpre; 
	       ftel= 2;
	       linadd= add2;
            }
            else  sphgod -= 1;
         }
         else 
         {  //TSM40:
            sphgod= errpre;
            if (i==pham40 || i==pham45)
            // TSTPHGOD:
            {  if (phgod==0)
               {  phgod= errpre;
                  ftel= 3;
                  linadd= add1;
               }
               else phgod -= 1;
            }
            else phgod= errpre;
         }
      }
#else
      if (ftel==1)
      {  // TSG1:
         phgod= errpre;
         if (phdiff<sch61)  sphgod= errpre;
 //      else if (schph> sch62) sphgod= errpre; <960509d
         else if (sphgod==0)
         {  sphgod= errpre; 
	    ftel= 2;
	    linadd= add2;
         }
         else  sphgod -= 1;
      }
#endif
   }
   doline7= 0;
}
// ** END of 1.2: line7 *****
// ***************************************************************
void palpuls(void)
{  UI i;
   i= hpos + papupos;
   if (i >= hlen)  i= i - hlen;
   papua += dual[i];
   papua -= black;
   if (papua > papug)  epapu= 1;
   else epapu= 0;
}
// ***************************************************************
void mode(void)
{  subcpot= (((UL)genphase * 1135 / 864) % 1024) << 6; //<960509c
   href= hphzero + (UL)genphase;
   if (href >= ((long)hlen<<8))  href= href - ((long)hlen<<8);
   domode= 0;
}
// ***************************************************************
void sch(void)
{
   if (genlocken && syncav && !verr && buav)
   {  hfasef();
      phdiff= href - hinput;
//    schph= (phdiff % 1024) >> 2; //<960509d
      if (phdiff & 0x80000000)
      {  phdiff= hinput - href;
         if (phdiff < 0x00020000)
         {  if (phdiff > phmar)
            {  if (godgren==1)
               {  if (schgod==0)
	          { linadd= add4; schgod= errpre;
	          }
	          else schgod -= 1;
	       }
	       else
	       {  godgren= 1; // SETGREN: 
	          schgod= errpre;
	       }
            }
            else
            {  // line7();
	       schgod= errpre;
            }
         }
         else // NEWPHD:
         {  phdiff= ((UL)hlen*256) - phdiff;
            if (phdiff > phmar)
            {  if (godgren==2)
               {  if (schgod==0)
                  {  linadd= supr4; schgod= errpre;
                  }
                  else schgod -= 1;
               }
               else
               {  godgren= 2;
                  schgod= errpre;
               }
            }
            else
            {  // line7();
               schgod= errpre;
            }
         }
      }
      else // POSIT:
      {
         if (phdiff < 0x00020000)
         {  if (phdiff > phmar)
            {  if (godgren==3)
	       {  if (schgod==0)
	          {  linadd= supr4; schgod= errpre;
	          }
	          else schgod -= 1;
	       }
	       else
	       {  godgren= 3;
	          schgod= errpre;
	       }
            }
            else
            {  // line7();
               schgod= errpre;
            }
         }
         else // TSPHAD:
         {  phdiff= (UL)hlen*256 - phdiff;
            if (phdiff > phmar)
            {  if (godgren==4)
               {  if (schgod==0)
                  {  linadd= add4;
                     schgod= errpre;
                  }
                  else schgod -= 1;
               }
               else
               {  godgren= 4;
                  schgod= errpre;
               }
            }
            else
            {  // line7();
               schgod= errpre;
            }
         }
      }
   }
   dosch= 0;
}	
// ** END of 1.5: sch *****

// ***********************************************************
//static near UI j;
void hfasef(void)
{  UI i,j;
   UC s1, s2, s3, x, y;

   i= hpos - hstart;
   if (i & 0x8000)  i += hlen;
   // SETTRIG:
   trig= black>>1;

gets1:
   s1= dual[i];
   if (s1>trig)
   // S1BIG:
   {  j= i + 1;
      if (j==hlen)  j= 0;
      s2= dual[j];
      x= s1 - s2;
      y= s1 - trig;
      s3= tableam[y*256 +x];
      hinput= (UL)i <<8;
//      hinput <<= 8;
      hinput += s3;
   }
   else
   {  i -= 1;
      // TSI15:
      if (i & 0x8000)  i += hlen;
      goto gets1;
   }
}
// ** END of 1.5.1: hfasef *****

