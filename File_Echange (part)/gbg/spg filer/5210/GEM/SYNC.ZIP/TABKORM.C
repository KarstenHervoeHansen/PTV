/*
File:	tabkorm.c
*/
#include <stdio.h>


code unsigned int fasekorm[]=
{ 1,1,1,1,1,1,1
};

