/*
********************************************************************
* Project	: PT5210  MASTER
* Filename	: PIIC2.C
* Version	: 0.0	961219
* Purpose	: IIC driver for IIC2 on ext. port
* Org.date	: 960215
* Author	: PRC
********************************************************************
HISTORY:
961231 Removed inline assembler programming in ByteTxb, (KEn)
961230 Added 20ms delay when writing in EEPROM, (KEn)
961220 Fixed error in SDA definition.
961219 Added routines for read and write EEPROM
960710 Commands changed to IIC1_... (IIC2_...)
960215 Adapted to XA processor, related to UIIC.C
*/

#include <stdio.h>
#include <xa.h>                      // define 8051 registers 

#include "mas.h"

#define SDA	(( ind1 & 8)>>3)
#define SCL	(ind1 & 4)
#define SDA_0		{ ud1buf &= ~8; ud1= ud1buf;}
#define SCL_0		{ ud1buf &= ~4; ud1= ud1buf;}
#define SDA_1		{ ud1buf |= 8; ud1= ud1buf;}
#define SCL_1		{ ud1buf |= 4; ud1= ud1buf;}
// Each "pau=0" delays xx us. (0.15?)
#define PAUS0		pau=0;
#define PAUS		PAUS0;PAUS0
#define PAUS1		PAUS0;PAUS0;PAUS0
#define SCL_3L		SCL_0;PAUS1;PAUS;PAUS
#define SCL_3H		SCL_1;PAUS1;PAUS1
#define STARTCond	SDA_0;PAUS1;PAUS1;PAUS;SCL_0
#define STOPCond	SDA_0;SCL_3L;SCL_1;while((SCL)==0); SCL_3H;SDA_1;PAUS1;PAUS

static near UC pau;
sbit  CY @ 0x207;				     // Carry
sbit  Acknowledge;

// *****************************************************************

bit ByteTxb( UC XS) {

	static bit Ack;
	register UC NoOfBit = 8;

   do {									// Coded to almost fastest execute time
		SCL_0;
		XS <<= 1;
		if ( CY)
			SDA_1
		else
			SDA_0;
		PAUS1;
		SCL_1; PAUS1; PAUS;
		while( SCL == 0)
			;
		SCL_0; PAUS;
	} while( --NoOfBit);

	SDA_1; SDA_1; SDA_1; PAUS1;
											// Ready for reading Acknowledge bit
	SCL_1; PAUS; PAUS;
	while( SCL == 0)
		;
	Ack = !(SDA);						// Read here ack-bit
	SCL_0;

	return( Ack);
}
// *****************************************************************

UC IIC2_Read( UC Address) {
	register UC B;

	STARTCond;
	Acknowledge = ByteTxb(Address+1);
	PAUS1; PAUS;

	B = 0;							// Read byte into B
	Address = 8;					// Use Address as loop - counter
	do {
		PAUS0;
		SCL_1; PAUS1;
		while(( SCL) == 0)
			;							// ******* GENINDS�TTES!
		B += B + SDA;				// B += B + (char)SDA;
		SCL_0; PAUS1; PAUS; PAUS;
	} while ( --Address != 0);

   // Write Acknowledge bit  (`1` for last byte to read )

	SDA_1;
	SCL_1; PAUS1; PAUS;pau=0;
	while((SCL) == 0)
		;								// ***** GENINDS�TTES!
	SCL_0;

	STOPCond;
	return( B);
}
// *****************************************************************

bit IIC2_Write( UC Address,UC Data) {

	STARTCond;
	Acknowledge = ByteTxb( Address);
	Acknowledge = ByteTxb( Data);
	STOPCond;

	return( Acknowledge);
}
// *****************************************************************

bit IIC2_Write2( UC Address,UC Data,UC Data2) {

	STARTCond;
	Acknowledge = ByteTxb( Address);
	ByteTxb( Data);
	ByteTxb( Data2);
	STOPCond;

	return( Acknowledge);
}
// *****************************************************************

bit IIC2_WrStr( UC Address, UC subadr, char *s) {
	register UC i;				// EEPROM string write routine

	STARTCond;
	Acknowledge = ByteTxb( Address);
	ByteTxb( subadr);

	for (i=0; i<10;i++) {
		ByteTxb( s[i]);
		if (s[i] == '\0')
			break;
		if ((( i+1) & 3) == 0) {
			STOPCond;			// packet write, enables use of alternative EEPROM
			waitms(20);			// wait while NVRAM store bytes

			STARTCond;			// store next (1-4) bytes
			Acknowledge = ByteTxb( Address);
			ByteTxb( subadr+i+1);
      }
   }
   STOPCond;
   waitms(20);              // wait while NVRAM store bytes

   return(Acknowledge);     // NB! allow 20ms before next write
}
// *****************************************************************

bit IIC2_RdStr( UC Address, UC subadr, char *s) {
	register UC i;							// EEPROM string read routine

	IIC2_Write( Address, subadr);		// Set RAM address

	for ( i=0; i<10;i++)
		s[i]= IIC2_Read( Address);		// Read char

	s[10]= '\0';

	return( Acknowledge);
}
// *****************************************************************

bit IIC2_WrLongInt( UC Address, UC subadr, UL a, UI b) {

	STARTCond;
	Acknowledge = ByteTxb(Address);
	ByteTxb(subadr);
	ByteTxb((UC)((a & 0xff000000)>>24));
	ByteTxb((UC)((a & 0x00ff0000)>>16));
	ByteTxb((UC)((a & 0x0000ff00)>>8));
	ByteTxb((UC)(a & 0x000000ff));
	STOPCond;
	waitms(20);								// Wait while NVRAM store bytes

	STARTCond;								// Store next (1-4) bytes
	Acknowledge = ByteTxb(Address);
	ByteTxb(subadr+4);
	ByteTxb((UC)((b & 0xff00)>>8));
	ByteTxb((UC)(b & 0x00ff));
	STOPCond;
	waitms(20);								// Wait while NVRAM store bytes
 
	return(Acknowledge);
}
// *****************************************************************

UL IIC2_RdLong( UC Address, UC subadr) {
	register UC i;
	UL y;

	IIC2_Write( Address, subadr);			// Set RAM address

	for ( y=i=0; i<4 ;i++)
		y = (UL) IIC2_Read( Address) + 256*y;

	return( y);
}

// *****************************************************************

UI IIC2_RdInt( UC Address, UC subadr) {
	UI y;

	IIC2_Write( Address, subadr);			// Set RAM address

	y = 256*IIC2_Read( Address);			// Read SCH-phase
	y += IIC2_Read( Address);

	return( y);
}
