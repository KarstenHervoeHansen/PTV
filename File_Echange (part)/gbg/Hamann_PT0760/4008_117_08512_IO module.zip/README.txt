Date: 2008-05-08 - Company: DK-Technologies A/S - Engineer: MTE

Description:

This is a 4 layer PCB with the following build (Apertures are included in gerber and drill file(s)):

Board Outline: board_outline.art
Top Silkscreen : silkscreen_top.art
Top Soldermask : soldermask_top.art
Top Copper Layer (signal + components) : top.art
Copper layer 2 (GND) : Layer2.art
Copper Layer 3 (3.3V): Layer3.art
Bottom Copper Layer (signal) : bottom.art
Bottom Soldermask : soldermask_bot.art
Drill files for all layers: drill-1-4.drl
Stencil for the top layer: stencil_top.art (needs review from Protec)

Top side is component side. No components or silkscreen on bottom side. 

Top Layer contains Coupled Micro Strip Line. Impedance has been calculated to match a distance between top and 2nd layer of around 240um. This must be accomplished within �10um.

Any questions, write to "mte@dk-t.net" or call +45 44850257.
 




