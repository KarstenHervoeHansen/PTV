Function jk_ReadlnCOMPort(PortNo : WORD; var InputStr : STRING; Timeout : WORD) : WORD;
var
 Counter    : WORD;
 RetChar    : CHAR;
 s          : STR_1;
 Boolean    : RdCode;
begin
  InputStr := '';
  Counter  := 0;
  repeat
    RdCode := Async_Buffer_Check(RetChar);
      if (RdCode = true) then
        begin
          s[1] := RetChar;
          InputStr := InputStr + s[1];
        end;
      else
        Counter := Counter + 1;
  until (RetChar = CR) OR (WaitCode = _TIME_OUT);
ReadlnCOMPort := WaitCode + (RdCode SHL 4) + (PortStatus SHL 8);
end;
