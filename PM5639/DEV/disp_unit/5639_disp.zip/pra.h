#pragma large 
#pragma code
#pragma symbols
#pragma optimize( 4, size)
#if 0
#pragma objectextend
#pragma noregparms
#endif
