/* FILE:    combine.c
   DATE:    19.09.2002
   AUTHOR:  JK
   PURPOSE: This program is used to create binary program file
            for 8603.  The output from compiler is a hex file.
            It is then converted to binary (xx.bin) by hex2bin.
            this binary file must then be combined with sound 
            which are contained in 
            TSTSND15 DAT       524,288  03-24-98  9:17a
            These files are in .\include directory.
            This program does:

            1.Copies contents of TSTSND15 DAT into a new binary file
            2.Moves pointer to beginning of file
            3.Copies xx.bin into binary file
            4.Moves pointer to 0xB000, where pin data is to be
            6.Names the binary file as PT8603.bin

*/
#include <stdio.h>
#include <alloc.h>
#include <dos.h>
#include <fcntl.h>

#define UI unsigned int
#define UC unsigned char
#define UL unsigned long

void give_info(void);
void give_info(void)
  {
  printf("combine: combines sound and program binaries \n");
  printf("for PT8603.  Resulting combination is named PT8603.bin\n");
  printf("Invocation: combine 8603_binary_input_file.\n");
  exit(3);
  }

int main(int argc, char *argv[])
  {
  FILE *    pt8603_fptr;
  FILE *    sound_fptr;
  FILE *    output_fptr;
  int       c;
  int       i;

  _fmode = O_BINARY;

  if ((argc != 2))
    {
    give_info();
    }

  if ((pt8603_fptr = fopen(argv[1], "r+b")) == NULL)
    {
    printf("Cannot open input binary file: %s\n", argv[1]);
    exit(1);
    }

  if ((sound_fptr = fopen(".\\include\\D1tstsnd.dat", "r+b")) == NULL)
    {
    printf("Cannot open binary sound file: %s\n", ".\\include\\D1tstsnd.dat");
    exit(1);
    }

  if ((output_fptr = fopen("PT8603.bin", "wb")) == NULL)
    {
    printf("Cannot open binary output file: %s\n", "PT8603.bin");
    exit(1);
    }

  /* copy .\include\TSTSND15 DAT into PT8603.bin */
  /* sound data contains 0xFF from beginning (0) to 0xCA00 */
  while ((c = fgetc(sound_fptr)) != EOF)
    fputc(c, output_fptr);

  /* move pointer to beginning of PT8603.bin */
  fseek(output_fptr, 0, SEEK_SET);

  /* copy 8603 program file file into PT8603.bin */
  while ((c = fgetc(pt8603_fptr)) != EOF)
    fputc(c, output_fptr);
 
  /* move pointer to 0x0xB000 in PT8603.bin */
  fseek(output_fptr, 0xB000, SEEK_SET);

  close(sound_fptr);
  close(pt8603_fptr);
  exit(0);
  }


