/***************************************************************************/
/*  Copyright PHILIPS TV TEST EQUIPMENT A/S, BRONDBY 1997              */
/*  Project:    PT8602/03 SDI Digital test signal generator            */
/*  Module:    D1UTIL.C                                    */
/*  Author:    Kim Engedahl, DEV                              */
/*  Org. date:  960703                                    */
/*  Rev. date:  970512, KEn  DEV                              */
/*  Status:    Version 1.0                                  */
/*                                                  */
/*  This module contains the following functions:                  */
/*                                                  */
/*    void Copy_TextRAM()                                  */
/*    void Copy_SoundRAM()                                  */
/*    void Wait10ms()                                    */
/*                                                  */
/* Changes:                                            */
/* 970429: New: clicks in Copy_SoundRAM                        */
/* 970428: New: Wait10ms() function                            */
/***************************************************************************/

/***************************************************************************/
/* Include files:                                        */

#include <string.h>
#include <xa.h>

#include "d1gener.h"
#include "d1util.h"
#include "d1tables.h"
#include "comm.h"


//***************************************************************************
//  VARIABLES USED IN InsertOSDText()
//***************************************************************************
#define TEXT_X_POS  30

static char* textPtr;

static near UC tmpChar;
static near UC noSamples;
static near UC charAddr;
static near UI RAMaddr;
static near UI ndx;

code char FirstLineText[]  = "PT8603 MOVING TEXT";
code char SecondLineText[] = "DIGITAL VIDEO PT8603";
code char ThirdLineText[]  = "DIGITAL VIDEO";

code char *our_text[3] =
  {
  {FirstLineText},
  {SecondLineText},
  {ThirdLineText}
  };

/***************************************************************************/
/*  stringlen                                          D1CMD.C */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 980309                         */
/* Revised:    980601, KEn                                     */
/*                                                  */
/*  Function:  Return the length of a string in samples.              */
/*  Remarks:    --                                        */
/*  Returns:    The string length in samples.                      */
/*  Updates:    --                                        */
/***************************************************************************/
UC stringlen(char* textptr)
  {
  UC no = 0;
  UC tmp;

  while (tmp = *textptr++)      // Get no of samples for each character
    no += TextTable[2 * (tmp - 32)];

  return(no);
  }

/***************************************************************************/
/*  CenterTextString                                               D1CMD.C */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 971120                                    */
/* Revised:    980601, KEn                                                 */
/*                                                                         */
/*  Function:  Center a textstring around a user specified X coordinate.   */
/*  Remarks:    --                                                         */
/*  Returns:    Constant defining X coordinate of all 3 text lines         */
/*  Updates:    --                                                         */
/***************************************************************************/
UC CenterTextString(UC center, char* TextPtr)
  {
  //return (15);
  return(center - (stringlen(TextPtr) >> 1));
  }

/***************************************************************************/
/*  ClearOSDLine                                                 D1UTIL.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 980309                                    */
/* Revised:   980601, KEn                                                  */
/*                                                                         */
/*  Function: Clear complete line in video RAM.                            */
/*  Remarks:  If the line to clear is currently being displayed OR if      */
/*            there is LESS than 40 lines until BEGINNING displaying the   */
/*            line, WAIT until the line has been displayed, before         */
/*            clearing.                                                    */
/*  Returns:    --                                                         */
/*  Updates:    --                                                         */
/***************************************************************************/
void ClearOSDLine(UC lineno)
  {
  register UI i;
    
  switch (lineno)
    {
    case 1:
      if (line_has_text1)
        {                           // If line 1 is being displayed..
        while (line_has_text1)      //  wait to clear the line until AFTER
          ;                         //  the line has been displayed.
        }
      else
        {
        if (line_count_for_text1 < 40)
          {                          // If LT 40 lines to displaing line 1..
          while (!line_has_text1)    //  wait until the line is BEING displayed
            ;
          while (line_has_text1)     //  and wait to clear the line until
            ;                        //  AFTER the line has been displayed.
          }
        }
      break;

    case 2:
      if (line_has_text2)
        {                            // If line 2 is being displayed..
        while (line_has_text2)       //  wait to clear the line until AFTER
          ;                          //  the line has been displayed.
        }
      else
        {
        if (line_count_for_text2 < 40)
          {                          // If LT 40 lines to displaing line 2..
          while (!line_has_text2)    //  wait until the line is BEING displayed
            ;
          while (line_has_text2)     //  and wait to clear the line until
            ;                        //  AFTER the line has been displayed.
          }
        }
      break;

    case 3:
      if (line_has_text3)
        {                            // If line 3 is being displayed..
        while (line_has_text3)       //  wait to clear the line until AFTER
          ;                          //  the line has been displayed.
        }
      else
        {
        if (line_count_for_text3 < 40)
          {                          // If LT 40 lines to displaing line 3..
          while (!line_has_text3)    //  wait until the line is BEING displayed
            ;          
          while (line_has_text3)     //  and wait to clear the line until
            ;                        //  AFTER the line has been displayed.
          }
        }
      break;
    }

  i = 0x80*lineno;  // Start position in video RAM to delete 0x80
  noSamples = 128;  // 128 ORIG

  while(noSamples--)
    TextPort[i++] = 0;
  }

/***************************************************************************/
/*  InsertOSDText                                   D1UTIL.C  */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 980309                          */
/* Revised:    980601, KEn                                     */
/*                                                  */
/*  Function:  Insert string into video RAM.                      */
/*  Remarks:    This function should ONLY be called RIGHT after a call to   */
/*          ClearOSDLine.                                */
/*  Returns:    --                                        */
/*  Updates:    --                                        */
/***************************************************************************/
#if 1
void InsertOSDText(UC lineno, UC xpos, char* textptr)
  {
  RAMaddr = 0x80*lineno + xpos; // Start position in video RAM to insert 0x80

  while (tmpChar = *textptr++)
    {
    ndx = 2*(tmpChar - 32);

    noSamples = TextTable[ndx++];     // Get no of samples for character
    charAddr  = TextTable[ndx];       // Get 1st character address

    while (noSamples--)
      {
      TextPort[RAMaddr++] = charAddr++;

      //if (RAMaddr > 0x1A5)
        //return;
      }
    }
  }
#else
void InsertOSDText(UC lineno, UC xpos, char* textptr)
  {
  UC i;

  if (lineno == 1)
    i = 32;
  else
    i = 16;

  RAMaddr = 0x80*lineno + xpos; // Start position in video RAM to insert 0x80

  while (i--)
    {
    tmpChar = *textptr++;
    if (tmpChar == 0)
      break;
    ndx = 2*(tmpChar - 32);

    noSamples = TextTable[ndx++];     // Get no of samples for character
    charAddr  = TextTable[ndx];       // Get 1st character address

    while (noSamples--)
      {
      TextPort[RAMaddr++] = charAddr++;
      }
    }
  }
#endif

/***************************************************************************/
/*  WriteOSDText                                                 D1UTIL.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 980309                                    */
/* Revised:   980601, KEn                                                  */
/*                                                                         */
/*  Function:  Update text insertion in video text RAM.                    */
/*  Remarks:   FuBK patterns in complex text style is special.             */
/*  Returns:   Nothing                                                     */
/*  Updates:    --                                                         */
/***************************************************************************/
void WriteOSDText(UC lineno)
  {
  switch (lineno)
    {
    case 1:
      ClearOSDLine(1);
      InsertOSDText(1, TextXPos, OSDText[0]);
      break;
    case 2:
      ClearOSDLine(2);
      InsertOSDText(2, TextXPos, OSDText[1]);
      break;
    case 3:
      ClearOSDLine(3);
      InsertOSDText(3, TextXPos, OSDText[2]);
      break;
    }
  }

/***************************************************************************/
/*  Copy_TextRAM                                                 D1UTIL.C  */
/*                                                                         */
/* Author:    Kim Engedahl, DEV, 970325                                    */
/* Revised:    970325                                                      */
/*                                                                         */
/*  Function:  Load a new string to video text RAM                         */
/*  Remarks:                                                               */
/*  Returns:    --                                                         */
/*  Updates:    --                                                         */
/***************************************************************************/
void Copy_TextRAM()
  {
  UC i;

  for (i = 0; i < 3; i++)
    {
    ClearOSDLine(i + 1);
    WriteOSDText(i + 1);
    }
  }

/***************************************************************************/
/*  Copy_SoundRAM                                   D1UTIL.C  */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 970325                          */
/* Revised:    970429                                       */
/*                                                  */
/*  Function:                                          */
/*  Remarks:                                            */
/*  Returns:    --                                        */
/*  Updates:    --                                        */
/***************************************************************************/
void Copy_SoundRAM()
  {
  static bit TmpSoundEnable;

  code far UC* SilentAddr;
  code far UC* SignalAddr;
  UI i, j;

  TmpSoundEnable = SoundEnable;

  SoundEnable = OFF;
  while (Status & 0xC0)      // Wait for sound OFF
    ;

  SilentAddr = SoundPageTable[AudioSilence];  // Silence STEREO

  if (AudioSignal > AudioStereoBBC1kHz)
    {
    if (AudioSignal < AudioDual)
      SilentAddr += 0x1200;            // Silence MONO
    else 
      SilentAddr += 0x2400;            // Silence DUAL SOUND
    }

  TextStatus &= 0xF3;                // Reset click information

  if (AudioLevel == AudioSilence)
    {                                // If audiolevel == SILENCE..
    for (j = 0; j < 11520; j += 2304)
      for (i = 0; i < 2304; i++)
        {
        EA = 0;
        PageSelect = 1;              // Select downloading sound RAM

        LowSoundRAM[j+i] = SilentAddr[i];
        HighSoundRAM[j+i] = SilentAddr[i+2304];

        PageSelect = 0;
        EA = 1;
        }
    }
  else
    {
    SignalAddr = SoundPageTable[AudioLevel] + SoundOffsetTable[AudioSignal];
    
    switch(AudioSignal)
      {                          // TextStatus bit 2,3 used for CLICK
      case AudioStereoEBU1kHz:
      case AudioMonoEBU1kHz:
        TextStatus |= 0x04;
        break;
      case AudioStereoBBC1kHz:
        TextStatus |= 0x08;
        break;
      case AudioMonoBBC1kHz:        // No click bit in AudioMonoEBU1kHz
        break;
      }

    TextStatusPort = TextStatus;

    switch(AudioSignal)
      {
      case AudioStereo1kHz:         // Alt. sound/silence in click area
      case AudioStereoEBU1kHz:      // Alt. sound/silence in click area
      case AudioStereoBBC1kHz:      // Silence in ALL click area
      case AudioMonoEBU1kHz:        // Silence in ALL click area
      case AudioMonoBBC1kHz:        // There's no click, ie. don't care
        for (j = 0; j < 11520; j += 2304)
          for (i = 0; i < 2304; i++)
            {
            EA = 0;
            PageSelect = 1;      // Select downloading sound RAM

            LowSoundRAM[j+i]  = SignalAddr[i];
            HighSoundRAM[j+i] = SignalAddr[i+2304];

            PageSelect = 0;
            EA = 1;            // Allow possible interrupt

            PageSelect = 0;      // Dummy statement

            EA = 0;
            PageSelect = 1;      // Select downloading sound RAM

            if (((i % 6) < 3) ||
               (AudioSignal == AudioStereoBBC1kHz) ||
               (AudioSignal == AudioMonoEBU1kHz))
              {
              LowClickSoundRAM[j+i] = SilentAddr[i];
              HighClickSoundRAM[j+i] = SilentAddr[i+2304];
              }
            else
              {
              LowClickSoundRAM[j+i] = SignalAddr[i];
              HighClickSoundRAM[j+i] = SignalAddr[i+2304];
              }
            PageSelect = 0;
            EA = 1;            // Allow possible interrupt
            }
        break;
      case AudioStereo800Hz:
      case AudioDual:
        for (i = 0; i < 11520; i++)
          {
          EA = 0;
          PageSelect = 1;          // Select downloading sound RAM

          LowSoundRAM[i] = SignalAddr[i];
          HighSoundRAM[i] = SignalAddr[i+11520];

          PageSelect = 0;
          EA = 1;
          }
        break;
      }
    }
  SoundEnable = TmpSoundEnable;
  }

/***************************************************************************/
/*  Wait10ms                                       D1UTIL.C  */
/*                                                  */
/* Author:    Kim Engedahl, DEV, 970428                          */
/* Revised:    970429                                       */
/*                                                  */
/*  Function:  Wait 10 ms                                  */
/*  Remarks:    Line interrupt is used for counting -> system dependant    */
/*  Returns:    --                                        */
/*  Updates:    --                                        */
/***************************************************************************/
void Wait10ms()
  {
  register UI j;
  register UC cnt;

  j = LineCnt;          // Delay for 10ms, while NVRAM store bytes
  cnt = 0;

  while (cnt < 160)      
    if (j - LineCnt)
      {
      j = LineCnt;
      cnt++;
      }
  }
