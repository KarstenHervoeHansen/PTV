/*  Algor for moving text in 8603                                          */
/*  Updates:    26.06.2002: Moving text feature added, JK                  */
/***************************************************************************/
banked interrupt void LineIntr(void)
  {  
  UI temp;

  if (TVSystem == PALG)
    {
  /* BEGIN */
    if ((LineCnt == 10) || (LineCnt == (10 + ODD_FIELD_OFFSET_G)))  // once per field....
      {                                                  // line 10 and 323..
      if (TextMovementDir == DOWN)
        {
        STARTOFTEXT++;
        line_count_for_text++;
        if (STARTOFTEXT >= 100)
          TextMovementDir = UP;
        }
      else    //Up movement.
        {
        STARTOFTEXT--;
        line_count_for_text--;
        if (STARTOFTEXT <= 48)
          TextMovementDir = DOWN;
        }
      }
  /* END */
    if (TF1)
      {                              // If delayed field interrupt..
      TF1 = 0;                       //  setup for line 3, (app. 12us)
      TF0 = 0;                       // Clear possible LINE CNT intr.

      LineCnt  = 2;

      line_count_for_text = STARTOFTEXT - 3;
      line_has_text  = 0;
      }
    else
      {  
      if (++LineCnt >= 625)   // new field...
        {  
        LineCnt = 0;
        line_count_for_text = STARTOFTEXT; // so we have to count 
        }                                  //  down lines down to one with text  
      if (!--line_count_for_text)         // this counts down lines with or without text
        {
        if (line_has_text)    // if this is the last line with text...
          {  
          line_has_text       = 0;  
          line_count_for_text = 297;  // number of lines without text

          Status &= 0xFE;             // S1S0 = X0: S0 = 0;
          }
        else
          {                      // ...last line without text...
          line_has_text       = 1;
          line_count_for_text = 16;   // number of lines with text

          if (TextEnable)            // If text on selected..  
            Status |= 0x01;      // S1S0 = X1: S0 = 1;
          }
        StatusPort = Status;
        }
      }
    }
  else
    {}  // NTSC
  if (TF0)
    {                                   // Update in pattern, app. 20us
    TF0       = 0;
    }
  }

