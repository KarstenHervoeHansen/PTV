
�ndret:	fr 169-06-00 15:11

sh.110-1 12703934_110-1.pdf
sh.115-1 12703934_115-1.pdf

12703934.dwg (side 110-1 samt 115-1 tekstlayout)
12703934.dxf (side 110-1 samt 115-1 tekstlayout) (AutoCad 2000)

                             postscript    windows
Fonte som bruges er: ariab - ariab.shx  -  Arial MT Bold
 

For farvespecifikation se 4008 140 00000