
�ndret:	fr 16-06-00 15:50

sh.110-1 10758584_110-1.pdf
10758584.dwg
10758584.dxf (AutoCad 2000)


05/11-2002/ GBg

Rev.3 er sendt til Hougaard & Koefoed
Rev. 4 er blevet rettet mht. overflade behandling, men denne st�r ogs� ogs� p� silketryk filen.