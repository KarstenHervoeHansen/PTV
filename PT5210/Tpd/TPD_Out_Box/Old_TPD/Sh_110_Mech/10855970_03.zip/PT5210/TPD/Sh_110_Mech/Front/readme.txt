
�ndret:	ti 14-06-00 12:15
sh.110-1  10855973 _110-1.pdf

10855973.dwg
10855973.dxf (AutoCad 2000)


                             postscript    windows
Fonte som bruges er: arim  - arim.shx   -  Arial MT Medium      (PT nr. +tekst)
                     arie  - arie.shx   -  Arial MT Extra Bold  (ProTeleVision)
                     ariab - ariab.shx  -  Arial MT Bold        (resten af teksten)
                        

For farvespecifikation se 4008 140 00000