
�ndret:	fr 14-06-00 15:11
sh.110-1 12703862_110-1.pdf
sh.110-2 12703862_110-2.pdf
sh.115-1 12703862_115-1.pdf

12703862.dwg (side 110-1, 110-2 m�ltegning samt 115-1 tekstlayout)
12703862.dxf  (AutoCad 2000)

                             postscript    windows
Fonte som bruges er: arim  - arim.shx   -  Arial MT Medium      (PT nr. +tekst)
                     arie  - arie.shx   -  Arial MT Extra Bold  (ProTeleVision)
                     ariab - ariab.shx  -  Arial MT Bold        (resten af teksten)
                                                   

For farvespecifikation se 4008 140 00000