28/02-2003:

Stencil, layer 9 tilf�jet fiducial marks for pasta maske.
REF1 of REF2


Ny Cadstar fil Z1706853

Gl. stencil gerber omd�bt til STEN1_GL