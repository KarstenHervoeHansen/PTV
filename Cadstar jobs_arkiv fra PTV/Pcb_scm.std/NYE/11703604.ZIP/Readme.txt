12-06-2003/GBg

Rev. 4 af jobbet er dd. kopieret over til PCB_SCM.std\nye.

Der er lavet en ny layer.ger, da bane p� lag 15 ikke var inkluderet.

