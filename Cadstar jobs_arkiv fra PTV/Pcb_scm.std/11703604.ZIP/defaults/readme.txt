12-06-2003/GBG

Bem�rk:
De originale ppn filer eksisterer ikke til rev 4.
Gerber filer er checket op mod print der k�rer i produktion nu; dog er 12NC ikke rettet p� disse.


Den ekstra bane der er lagt ind, ligger p� lag 15 !
Derfor skal denne inkluderes i lag2.ppn

Der er ogs� rettet i stelplanet.
